package Inca::Logger;

###############################################################################

=head1 NAME

Inca::Logger - Wrapper to encapsulate dependence on Logger::Log4perl

=head1 SYNOPSIS

=for example begin

  use Inca::Logger ":all";

=for example end
   
=head1 DESCRIPTION

This module wraps the functions exported by Log::Log4perl, allowing access
to them when the module is installed and preventing clients from puking
otherwise.

=begin testing

  use Test::Exception;
  use strict;

  use Inca::Logger
  # TODO

=end testing

=cut
###############################################################################


#=============================================================================#
# Usage
#=============================================================================#
use strict;
use warnings;
require Exporter;
use vars qw($AUTOLOAD @ISA @EXPORT @EXPORT_OK);

#=============================================================================#
# Export help
#=============================================================================#
@ISA = qw(Exporter);

# export tags

our %EXPORT_TAGS = (
  'all' => ['get_logger', 'init']
);
@EXPORT_OK = ( @{ $EXPORT_TAGS{all} } );
@EXPORT = qw( );
my $log4perlAvailable;

BEGIN {
  $log4perlAvailable = 0;
  eval {
    require Log::Log4perl;
    $log4perlAvailable = 1;
  };
}

sub get_logger {
  my($class, $tag) = @_;
  if($log4perlAvailable) {
    return Log::Log4perl->get_logger($tag);
  }
  my $self = { };
  return bless($self, $class);
}

sub init {
  if($log4perlAvailable) {
    Log::Log4perl->init(@_);
  }
}

sub AUTOLOAD {
  if($AUTOLOAD =~ /fatal|die/) {
    my ($self, $msg) = @_;
    die $msg;
  }
}

1;

__END__

=head1 EXAMPLE
  
  use Inca::Logger ":all";
  Inca::Logger->init();
  $logger = Inca::Logger->get_logger('mylog');
  $logger->info("Any message");
  $logger->fatal("Any message");

=head1 AUTHOR

Jim Hayes <jhayes@sdsc.edu>

=cut
