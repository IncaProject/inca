package Inca::ReporterManager;

################################################################################

=head1 NAME

Inca::ReporterManager - Executes an Inca reporter subscription

=head1 SYNOPSIS

=for example begin

  use Inca::ReporterManager;
  use Inca::Subscription;
  use Inca::ReporterManager::ReporterCache;
  my $subscription = new Inca::Subscription();
  $subscription->read( "subscription.xml" );
  my $scheduler = new Inca::ReporterManager();
  my $credentials = { cert => "t/certs/client_ca1cert.pem",
                      key => "t/certs/client_ca1keynoenc.pem",
                      passphrase => undef,
                      trusted => "t/certs/trusted" };
  $scheduler->setCredentials( $credentials );
  $scheduler->setCheckPeriod( 1 );
  $scheduelr->setDepots( "incas://localhost:$port" );
  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  $scheduler->setReporterCache( $rc );
  $scheduler->dispatch( $subscription );

=for example end

=head1 DESCRIPTION

This module implements the Scheduler which receives a subscription request
from either a reporter agent or a local Inca administrator indicating an add,
replace, or delete request followed by a set of reporter descriptions. The
Scheduler looks at the subscription and then consults the reporter
administrator to find out which reporters it needs in order fulfill the
subscription and sends it back to the reporter agent. The reporter agent will
then send the necessary reporters to the reporter manager.

Each reporter description indicates a reporter url, a set of input arguments,
timeout, frequency of execution, execution priority, and a storage policy
(for now, a set of depots interested in the results).  For each group of 
reporters, a scheduler is specified to execute them.  For example, if the
reporter execution is on-demand, the scheduler hands the request to the
Sequential scheduler.  In many cases, the Cron scheduler will be requested,
that is the reporter execution is scheduled and the frequency of execution is
managed by an internal cron table.  Other schedulers to include would be
an e2e bandwidth measurement scheduler, queue scheduler, etc. When the
scheduled time for a reporter comes, a RIM is launched to run the reporter.

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#

# pragmas
use strict;
use warnings;
use vars qw($VERSION $AUTOLOAD);

# Inca
use Inca::Constants qw(:params);
use Inca::Logger;
use Inca::Validate qw(:all);
use Inca::IO;
use Inca::Subscription;

# Perl standard
use Carp;
use Data::Dumper;
use Socket qw(:crlf);

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $SELF_PARAM_REQ = { isa => "Inca::ReporterManager" };
my $CHECK_PERIOD_PARAM_OPT = { %{$POSITIVE_INTEGER_PARAM_OPT}, default => 2 };
my $PING_TIMEOUT = 10;

my %SCHEDULERS = ( sequential => "Inca::ReporterManager::Scheduler::Sequential",
                   cron       => "Inca::ReporterManager::Scheduler::Cron" );

#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 new( %Options )

Class constructor which returns a new Inca::ReporterManager object.
The constructor may be called with any of the following attributes.

=over 2 

B<Options>:

=over 13

=item checkPeriod

A positive integer indicating the period in seconds of which to check the
reporter for a timeout [default: 2]

=item credentials

A reference to a hash array containing the credential information.

=item depotURIs

A list of depot uris.  The report will be sent to the first depot in the list.
If the first depot is unreachable, the next depots in the list will be tried.

=item reporterCache 

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=item rimPath

A string containing the path to the reporter-instance-manager executable.

=item tmpDir

A string containing a path to a temporary file space that Inca can use while
executing reporters

=back

=back

=begin testing

  use Inca::ReporterManager;
  use Test::Exception;
  lives_ok { new Inca::ReporterManager() } 'object created';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $self = {};
  
  bless ($self, $class);

  # set up defaults
  $self->{logfile} = undef;
  $self->{repositories} = [];
  $self->{schedulers} = {};
  $self->{logger} = Inca::Logger->get_logger( $class );

  # read options
  my %options = validate( @_, { checkPeriod => $CHECK_PERIOD_PARAM_OPT,
                                credentials => $HASHREF_PARAM_OPT,
                                depotURIs => $ARRAYREF_PARAM_OPT,
                                reporterCache => $REPORTER_CACHE_PARAM_OPT,
                                rimPath => $SCALAR_PARAM_OPT,
                                tmpDir => $SCALAR_PARAM_OPT } );

  $self->setCheckPeriod($options{checkPeriod}) if exists $options{checkPeriod};
  $self->setCredentials($options{credentials}) if exists $options{credentials};
  $self->setDepots( @{$options{depotURIs}} ) if exists $options{depotURIs};
  $self->setReporterCache( $options{reporterCache} ) 
    if exists $options{reporterCache};
  $self->setRimPath( $options{rimPath} ) if exists $options{rimPath};
  $self->setTmpDirectory( $options{tmpDir} ) if exists $options{tmpDir};
                                
  return $self;
}

#-----------------------------------------------------------------------------#

=head2 setCheckPeriod( $secs )

Set the period for how often to check the reporter for exceeding its timeout.

=over 2

B<Arguments>:

=over 13

=item secs

A positive integer indicating the period in seconds of which to check for
resource timeouts.

=back

=back

=begin testing


  use Inca::ReporterManager;

  my $scheduler = new Inca::ReporterManager( checkPeriod => 3 );
  is( $scheduler->getCheckPeriod(), 3, 'set check period from constructor' );
  $scheduler->setCheckPeriod( 10 );
  is( $scheduler->getCheckPeriod(), 10, 'set check period' );
  $scheduler = new Inca::ReporterManager();
  is( $scheduler->getCheckPeriod(), 2, 'default check period is 2' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setCheckPeriod {
  my ( $self, $secs ) =
     validate_pos( @_, $SELF_PARAM_REQ, $POSITIVE_INTEGER_PARAM_REQ );

  $self->{check_period} = $secs;
}

#-----------------------------------------------------------------------------#

=head2 getCheckPeriod( )

Get the period for how often to check the reporter for exceeding its timeout.

=over 2

B<Returns>:

A positive integer indicating the period in seconds of which to check for
resource timeouts.

=back

=cut 
#-----------------------------------------------------------------------------#
sub getCheckPeriod {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{check_period};
}

#-----------------------------------------------------------------------------#

=head2 setDepots( @depot_uris )

Specify the destination depots that are used to send the report on completion.
The report will be sent to the first depot in the list.  If the first depot is
unreachable, the next depots in the list will be tried.

=over 2

B<Arguments>:

=over 13

=item depot_uris

Any number of strings containing a uri to a depot [host:port, ...]

=back

=back
     
=begin testing         

  use Inca::ReporterManager;
  use Test::Exception;

  my $scheduler = new Inca::ReporterManager(depotURIs=>["cuzco.sdsc.edu:8234"]);
  my @depots = $scheduler->getDepots();
  is( $depots[0], "cuzco.sdsc.edu:8234", 'Set depots works from constructor' );
  $scheduler->setDepots( qw(inca.sdsc.edu:8235 inca.sdsc.edu:8236) );
  @depots = $scheduler->getDepots();
  is( $depots[0], "inca.sdsc.edu:8235", 'Set depots works from function (1)' );
  is( $depots[1], "inca.sdsc.edu:8236", 'Set depots works from function (2)' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setDepots {
  my ( $self, @depot_uris ) =
     validate_pos( @_, $SELF_PARAM_REQ, $URI_PARAM_REQ,
                       ($URI_PARAM_REQ) x (@_ - 2) );

  @{$self->{depots}} = @depot_uris;
}

#-----------------------------------------------------------------------------#

=head2 getDepots( )

Retrieve the destination depots that are used to send the report on
completion.

=over 2

B<Returns>:

An array of strings containing uris to depots [host:port, ...]

=back

=cut 
#-----------------------------------------------------------------------------#
sub getDepots {        
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  if ( exists $self->{depots} and defined $self->{depots} ) {
    return @{$self->{depots}};
  } else {
    return;
  }
}

#-----------------------------------------------------------------------------#

=head2 setReporterCache( $reporter_cache )

Specify the reporter administrator to use in order to find a path to a local
copy of a reporter (from its URI).

=over 2

B<Arguments>:

=over 13

=item reporter_cache

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=back

=back

=begin testing

  use Inca::ReporterManager;
  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;

  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  my $rc_new = new Inca::ReporterManager::ReporterCache( "/tmp" );
  my $scheduler = new Inca::ReporterManager( reporterCache => $rc );
  is( $scheduler->getReporterCache->getLocation(), "t",
          'set reporter admin worked from constructor' );
  $scheduler->setReporterCache( $rc_new );
  is( $scheduler->getReporterCache->getLocation(), "/tmp",
          'set reporter admin worked from set/get functions' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setReporterCache {
  my ( $self, $reporter_cache) =
     validate_pos( @_, $SELF_PARAM_REQ, $REPORTER_CACHE_PARAM_REQ );


  $self->{reporter_cache} = $reporter_cache;
}

#-----------------------------------------------------------------------------#

=head2 getReporterCache( )

Retrieve the reporter administrator to use in order to find a path to a local
copy of a reporter (from its URI).

=over 2

B<Returns>:

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=back

=cut
#-----------------------------------------------------------------------------#
sub getReporterCache {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{reporter_cache};
}

#-----------------------------------------------------------------------------#

=head2 setCredentials( \%credentials )

Specify the credentials to use.

=over 2

B<Arguments>:

=over 13

=item credentials

A reference to a hash array containing the credential information.

=back

=back

=begin testing

  use Inca::ReporterManager;
  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;

  my $credentials = { cert => 't/cert.pem', key => 't/key.pem',
                      passphrase => 'secret', trusted => 't/trusted' };
  my $credentials_new = { cert => 't/new/cert.pem', key => 't/key.pem',
                      passphrase => 'supersecret', trusted => 't/trusted' };
  my $scheduler = new Inca::ReporterManager( 
                  credentials => $credentials );
  ok( eq_hash($scheduler->getCredentials(), $credentials), 
          'set credentials worked from constructor' );
  $scheduler->setCredentials( $credentials_new );
  ok( eq_hash($scheduler->getCredentials(), $credentials_new), 
          'set/get credentials worked' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setCredentials {
  my ( $self, $credentials ) =
     validate_pos( @_, $SELF_PARAM_REQ, HASHREF );

  $self->{credentials} = $credentials;
}

#-----------------------------------------------------------------------------#

=head2 getCredentials( )

Retrieve the security credentials.

=over 2

B<Returns>:

A reference to a hash array containing the paths to the security 
credentials.

=back

=cut
#-----------------------------------------------------------------------------#
sub getCredentials {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{credentials};
}

#-----------------------------------------------------------------------------#

=head2 setRimPath( $path )

Specify the path to the reporter-instance-manager script.

=over 2

B<Arguments>:

=over 13

=item path

A string containing the path to the reporter-instance-manager script.

=back

=back

=begin testing

  use Inca::ReporterManager;
  use Test::Exception;

  my $sched = new Inca::ReporterManager(); 
  is( $sched->getRimPath(), undef, 'default rim_path set' );
  dies_ok { $sched->setRimPath( "bin/reporter-instance-manager" ) }
          'setRimPath fails when not executable';
  $sched->setRimPath( "sbin/reporter-instance-manager" );
  is( $sched->getRimPath(), "sbin/reporter-instance-manager", 
      'set/getRimPath work' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setRimPath {
  my ( $self, $path ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  if ( ! -x $path ) {
    $self->{logger}->logdie( 
      "Path '$path' to reporter-instance-manager is not executable" 
    );
  }
  $self->{rim_path} = $path;
}

#-----------------------------------------------------------------------------#

=head2 getRimPath( )

Retrieve the path to the reporter-instance-manager script.

=over 2

B<Returns>:

A string containing the path to the reporter-instance-manager script.

=back

=cut
#-----------------------------------------------------------------------------#
sub getRimPath {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{rim_path};
}

#-----------------------------------------------------------------------------#

=head2 setTmpDirectory( $path )

Specify a temporary file space that Inca can use while executing reporters.

=over 2

B<Arguments>:

=over 13

=item path

A string containing a path to a temporary file space 

=back

=back

=begin testing

  use Inca::ReporterManager;
  use Test::Exception;

  my $sched = new Inca::ReporterManager(); 
  is( $sched->getTmpDirectory(), undef, 'default tmp set' );
  $sched->setTmpDirectory( "/scratch" );
  is( $sched->getTmpDirectory(), "/scratch", 'set/getTmpDirectory work' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setTmpDirectory {
  my ( $self, $path ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  $self->{tmpdir} = $path;
}

#-----------------------------------------------------------------------------#

=head2 getTmpDirectory( )

Retrieve the path to a temporary file space that Inca can use while executing
reporters

=over 2

B<Returns>:

A string containing a path to a temporary file space.

=back

=cut
#-----------------------------------------------------------------------------#
sub getTmpDirectory {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{tmpdir};
}

#-----------------------------------------------------------------------------#

=head2 hasTmpDirectory( )

Return true if a temporary file space has been set for Inca.

=over 2

B<Returns>:

A boolean indicating true if a temporary file space has been set; otherwise
returns false.

=back

=begin testing

  use Inca::ReporterManager();
  my $sched = new Inca::ReporterManager();
  ok( ! $sched->hasTmpDirectory(), 'hasTmpDirectory for false' );
  $sched->setTmpDirectory( "/tmp" );
  ok( $sched->hasTmpDirectory(), 'hasTmpDirectory for true' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub hasTmpDirectory {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return exists $self->{tmpdir};
}

#-----------------------------------------------------------------------------#

=head2 dispatch( $subscription )

Read add/delete reporter requests in subscription and route to
appropriate scheduler.

=over 2

B<Arguments>:

=over 13

=item subscription

An object of type Inca::Subscription containing add/delete reporter
requests

=back

=back

=begin testing

  untie *STDOUT;
  untie *STDERR;

  use Inca::ReporterManager;
  use Inca::Subscription;
  use Inca::ReporterManager::ReporterCache;
  use IO::Socket::SSL;
  use strict;
  use warnings;
  use Cwd;
  use File::Spec;

  sub testRM {
    my $subscription_file = shift;
    my $depot = shift;
    my $sleep = shift;
    my $credentials = shift;
    my $verify = shift;
    if ( ! defined $verify ) {
      $verify = 1;
    }

    my $subscription = new Inca::Subscription();
    my $result = $subscription->read( $subscription_file );
    ok( $result, "$subscription_file ok") if $verify;

    my $rc = new Inca::ReporterManager::ReporterCache( "t",
      errorReporterPath => "bin/inca-null-reporter"
    );
  
    ok( ! -f "./depot.tmp.$$", "no depot file exists so far" ) if $verify;
    my $rm = new Inca::ReporterManager();
    $rm->setCheckPeriod( 1 );
    $rm->setReporterCache( $rc );
    $rm->setDepots( $depot );
    $rm->setTmpDirectory( "/tmp" );
    $rm->setCredentials( $credentials );
    $rm->setRimPath( "sbin/reporter-instance-manager" );
    $rm->dispatch( $subscription );
    $result = $rm->start();
    ok( $result, "RM started" ) if $verify; 
    if ( defined $sleep ) {
      ok( $sleep, "sleeping for $sleep seconds" ) if $verify;
      my $result = sleep($sleep+1);
      cmp_ok( $result, ">=", $sleep, "slept for $sleep seconds" ) if $verify; 
    }
    $result = $rm->stop();
    ok( $result, "RM stopped" ) if $verify; 
    if ( defined $credentials ) {
      return;
    }
    ok( -f "./depot.tmp.$$", "depot file created" ) if $verify;
    local $/;
    open( FD, "<./depot.tmp.$$" );
    my $content = <FD>;
    close FD;
    unlink "./depot.tmp.$$";
    my @content_array = split( /\n/, $content );
    return wantarray ? @content_array : $content;
  }

  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );
  my $content = testRM( "t/subscription.xml", $file_depot, 20 );
  like( $content, qr/^<\S*report .*>.*/m, 
        "looks like reporter was printed to file for sequential");

  # test file with cron
  my @content_array = testRM( "t/cron_subscription.xml", $file_depot, 130 );
  my @num_gcc_reports = grep( />gcc</, @content_array );
  cmp_ok( scalar(@num_gcc_reports), ">=", 2, "at least 2 gcc reports found" );
  cmp_ok( scalar(@num_gcc_reports), "<=", 3, "3 or less gcc reports found" );
  my @num_ssl_reports = grep( />openssl</, @content_array );
  cmp_ok( scalar(@num_ssl_reports), ">=", 2, "at least 2 ssl reports found" );
  cmp_ok( scalar(@num_ssl_reports), "<=", 3, "ssl reports found" );

  # test add/delete capability
  my $subscription = new Inca::Subscription();
  $subscription->read( "t/cron_subscription.xml" );
  my $delete_subscription = new Inca::Subscription();
  $delete_subscription->read( "t/delete_cron_subscription.xml" );
  my $rc = new Inca::ReporterManager::ReporterCache( "t",
    errorReporterPath => "bin/inca-null-reporter"
  );
  my $rm = new Inca::ReporterManager();
  $rm->setCheckPeriod( 1 );
  $rm->setReporterCache( $rc );
  $rm->setDepots( "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" ) );
  $rm->setTmpDirectory( "/tmp" );
  $rm->setRimPath( "sbin/reporter-instance-manager" );
  $rm->dispatch( $subscription );
  my $result = $rm->start();
  $rm->dispatch( $delete_subscription );
  ok( $result, "RM add started" ); 
  sleep(70);
  ok( -f "./depot.tmp.$$", "depot file created" ); 
  local $/;
  open( FD, "<./depot.tmp.$$" );
  $content = <FD>;
  close FD;
  unlink "./depot.tmp.$$";
  @content_array = split( /\n/, $content );
  @num_gcc_reports = grep( />gcc</, @content_array );
  @num_ssl_reports = grep( />ssl</, @content_array );
  is( scalar(@num_gcc_reports), 0, "0 gcc reports found" );
  cmp_ok( scalar(@num_ssl_reports), ">=", 1, "at least 1 ssl reports found" );
  cmp_ok(scalar(@num_ssl_reports), "<=", 2, "no more than 2 ssl reports found");
  $rm->stop();

  # test cron with 2 groups
  @content_array = testRM( "t/cron_subscription2.xml", $file_depot, 130 );
  @num_gcc_reports = grep( />gcc</, @content_array );
  cmp_ok( scalar(@num_gcc_reports), ">=", 1, "at least one gcc report found" );
  cmp_ok(scalar(@num_gcc_reports), "<=", 2, "no more than 2 gcc reports found");
  @num_ssl_reports = grep( />openssl</, @content_array );
  cmp_ok( scalar(@num_ssl_reports), ">=", 1, "at least one ssl report found" );
  cmp_ok(scalar(@num_ssl_reports), "<=", 2, "no more than 2 ssl reports found");
  my @gmt = grep( /gmt/, @content_array );
  my ($minute1) = $gmt[0] =~ /(\d\d):\d\dZ/g;
  my ($minute2) = $gmt[1] =~ /(\d\d):\d\dZ/g;
  is( $minute2 - $minute1, 1, "time difference is one minute" );

  # test mixed
  @content_array = testRM( "t/mixed_subscription.xml", $file_depot, 70 );
  @num_gcc_reports = grep( />gcc</, @content_array );
  cmp_ok( scalar(@num_gcc_reports), ">=", 1, "at least one gcc report found" );
  cmp_ok(scalar(@num_gcc_reports), "<=", 2, "no more than 2 gcc reports found");
  @num_ssl_reports = grep( />openssl</, @content_array );
  is( scalar(@num_ssl_reports), 1, "one ssl report found" );

  # test ssl
  use Inca::IO;
  use Inca::Net::Client;
  use Inca::Net::Protocol::Statement;
  my $port = 8517;
  my @clientCredentials = ( { cert => "t/certs/client_ca1cert.pem",
                              key => "t/certs/client_ca1keynoenc.pem",
                              passphrase => undef,
                              trusted => "t/certs/trusted" },
                            { cert => "t/certs/client_ca1cert.pem",
                              key => "t/certs/client_ca1key.pem",
                              passphrase => "test",
                              trusted => "t/certs/trusted" }
                          );
  my $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  my $pid;
  for ( my $i = 0; $i <= $#clientCredentials; $i++ ) {
    if ( $pid = fork() ) {
      # accept first report
      sleep 5; # give time for resources to cleanup in second round
      my $server_sock = $server->accept();
      my $depot = Inca::Net::Client->_connect( $server_sock );
      ok( $depot->hasReadStatement( "START", "1" ), "read START" );
      $depot->writeStatement( "OK", "1" );
      my $content = ""; 
      my $line;
      while( $line = <$server_sock> ) {
        if ( $line =~ /END/ ) {
          close $server_sock;
        }
        $content .= $line;
      } 
      like( $content, qr/^<\S*report .*>.*/m, 
            "$i looks like first reporter was printed to socket");
  
      # accept second report
      $server_sock = $server->accept();
      $depot = Inca::Net::Client->_connect( $server_sock );
      ok( $depot->hasReadStatement( "START", "1" ), "read START" );
      $depot->writeStatement( "OK", "1" );
      $content = ""; 
      while( $line = <$server_sock> ) {
        if ( $line =~ /END/ ) {
          close $server_sock;
        }
        $content .= $line;
      } 
      like( $content, qr/^<\S*report .*>.*/m, 
            "$i looks like second reporter was printed to socket");
    } else {
      testRM( "t/subscription.xml", "incas://localhost:$port", 20, 
              $clientCredentials[$i], 0 );
      exit;
    }
  }
  close $server;


=end testing

=cut
#-----------------------------------------------------------------------------#
sub dispatch {
  my ( $self, $subscription) = 
      validate_pos( @_, $SELF_PARAM_REQ, $SUBSCRIPTION_PARAM_REQ );

  if ( ! $self->hasTmpDirectory() ) {
    $self->{logger}->fatal( "No temporary file space has been set" );
  }

  my $i = 0;
  my $errored_reporter_groups = [];
  my @schedulers_to_start;
  for my $group ( $subscription->getReporterGroups() ) {
    $self->{logger}->info( 
      "Received subscription change request '" . $group->getAction() .
      "' from agent"
    );
    if ( $group->hasScheduler() ) {
      my $scheduler = $self->_getScheduler( $group->getSchedulerName() );
      if ( $scheduler->isRunning() ) {
        $self->{logger}->info( 
          "Stopping " .  $group->getSchedulerName() . " scheduler"
        );
        $scheduler->stop();
        push( @schedulers_to_start, $scheduler );
      }
      $self->{logger}->info( 
        "Dispatching group $i to " .  $group->getSchedulerName() . " scheduler"
      );
      if ( ! $scheduler->submit($group->getAction(), 
                                $group->getSchedulerArgs(),
                                $group->getReporters()) ) {
        $self->{logger}->error( "Scheduler rejected reporters" );
        push( @{$errored_reporter_groups}, $i );
      } 
    } else {
      $self->{logger}->error( "No scheduler found for group $i " );
    }
    $i++;
  }
  for my $scheduler ( @schedulers_to_start ) {
    $self->{logger}->info( "Restarting " .  ref($scheduler) . " scheduler" );
    $scheduler->start();
  }

  return $errored_reporter_groups;
}

#-----------------------------------------------------------------------------#

=head2 setLogger( )
  
Set a log file for the reporter-instance-managers.

=cut
#-----------------------------------------------------------------------------#
sub setLogger {
  my ( $self, $logfile ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  $self->{logfile} = $logfile;
}

#-----------------------------------------------------------------------------#

=head2 start( )

Start execution of the schedulers that require specific start/stop.

=begin testing

  untie *STDOUT;
  untie *STDERR;

  use Inca::ReporterManager;
  use Inca::Subscription;
  use Inca::ReporterManager::ReporterCache;
  use IO::Socket::SSL;

  my $rc = new Inca::ReporterManager::ReporterCache( "t",
    errorReporterPath => "bin/inca-null-reporter"
  );

  my $cron_subscription = new Inca::Subscription();
  $cron_subscription->read( "t/cron_subscription.xml" );
  $rm = new Inca::ReporterManager();
  $rm->setCheckPeriod( 1 );
  $rm->setReporterCache( $rc );
  $rm->setDepots( "file:./depot.tmp.$$" );
  $rm->setTmpDirectory( "/tmp" );
  $rm->dispatch( $cron_subscription );
  ok( $rm->start(), "rm started" );
  ok( $rm->stop(), "rm stopped" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub start {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  my $num_schedulers_started = 0;
  my ( $name, $scheduler );
  while( ($name, $scheduler) = each %{$self->{schedulers}} ) {
    if ( $scheduler->isRunning() ) {
      $self->{logger}->info( "$name scheduler already running" );
      $num_schedulers_started++;
    } elsif ( $scheduler->start() ) {
      $self->{logger}->info( "$name scheduler started" );
      $num_schedulers_started++;
    } else {
      $self->{logger}->error( "Error starting $name scheduler" );
    }
  }
  if ( $num_schedulers_started < scalar(keys %{$self->{schedulers}}) ) {
    return 0;
  } else {
    return 1;
  }
}

#-----------------------------------------------------------------------------#

=head2 stop( )

Stop execution of the schedulers that require specific start/stop.

=cut
#-----------------------------------------------------------------------------#
sub stop {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  my $num_schedulers_stopped = 0;
  my ( $name, $scheduler );
  while( ($name, $scheduler) = each %{$self->{schedulers}} ) {
    if ( $scheduler->stop() ) {
      $self->{logger}->info( "$name scheduler stopped" );
      $num_schedulers_stopped++;
    } else {
      $self->{logger}->error( "Error stopping $name scheduler" );
    }
  }
  if ( $num_schedulers_stopped < scalar(keys %{$self->{schedulers}}) ) {
    return 0;
  } else {
    return 1;
  }
}

#-----------------------------------------------------------------------------#

=head2 storePackage( $uri, $filename, $version, $installpath, $content )

Store the specified package into the reporter cache.  

=over 2

B<Arguments>:

=over 13

=item uri

A string containing the URI of the reporter that will be used to identify
the reporter in the depot.

=item filename

A string containing the filename that the package should be stored under.

=item version

A string containing the version of the package.

=item installpath

A string containing the directory the package should be stored under
relative to the reporter cache location.

=item perms

A string of format "[0-7][0-7][0-7]" that can be used to set the permissions
of the stored file after its written to disk.  A value of undef means that
no change of permissions is needed.

=item content

The content of the package to store to disk.

=back

B<Returns>:
True if the package is succesfully cached in the reporter cache and 
false otherwise.

=back

=begin testing

  use Inca::ReporterManager;
  use Inca::ReporterManager::ReporterCache;

  my $rm = new Inca::ReporterManager();
  my $rc = new Inca::ReporterManager::ReporterCache( "var/cache" );
  $rm->setReporterCache( $rc );
  my $result = $rm->storePackage( 
    "http://inca.sdsc.edu/reporters/lib/Reporter.pm",
    "Reporter.pm",
    "1.5",
    "lib/perl",
    undef,
    "" 
  );
  is( $rm->getReporterCache()->getPath( 
        "http://inca.sdsc.edu/reporters/lib/Reporter.pm" 
      ),
      "var/cache/lib/perl/Reporter.pm",
      "getPath returned okay for Reporter.pm" );
  `rm -fr var/cache`;

=end testing

=cut
#-----------------------------------------------------------------------------#
sub storePackage {
  my ($self, $uri, $filename, $version, $installpath, $perms, $content) =
    validate_pos(
      @_, $SELF_PARAM_REQ, $URI_PARAM_REQ, SCALAR, SCALAR, SCALAR,
          SCALAR|UNDEF, SCALAR
    );

  return $self->getReporterCache()->storePackage( 
    $uri, $filename, $version, $installpath, $perms, $content
  );
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# _getSchedulerClassName( $scheduler_id )
#
# Return the name of the scheduler class given a scheduler identifier. 
#
# Arguments:
#
# scheduler_id   A string containing the identifier of the scheduler.
#
# Returns: 
#
# A string containing the name of the scheduler sub class
#

=begin testing

  use Inca::ReporterManager;

  is( Inca::ReporterManager->_getSchedulerClassName('sequential'),
      "Inca::ReporterManager::Scheduler::Sequential",
      '_getSchedulerClassName returns correct class for sequential' );
  is( Inca::ReporterManager->_getSchedulerClassName('cron'),
      "Inca::ReporterManager::Scheduler::Cron",
      '_getSchedulerClassName returns correct class for cron' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _getSchedulerClassName {
  my ( $self, $scheduler_id ) = 
     validate_pos( @_, $SELF_PARAM_REQ, $ALPHANUMERIC_PARAM_REQ );

  my $this_classname = __PACKAGE__;
  return $this_classname . "::Scheduler::" . ucfirst( $scheduler_id );
}

#-----------------------------------------------------------------------------#
# _createScheduler( $scheduler_class )
#
# Return a new scheduler object based on the scheduler class name
#
# Arguments:
#
# scheduler_class   A string containing the name of a scheduler class
#
# Returns: 
#
# A new scheduler object 
#

=begin testing

  use Inca::ReporterManager;
  use Inca::ReporterManager::ReporterCache;
  use Inca::Subscription::ReporterGroup;

  # create scheduler object
  my $scheduler = new Inca::ReporterManager();
  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  $scheduler->setReporterCache( $rc );

  # test for sequential
  my $scheduler_object = $scheduler->_createScheduler(
                           "Inca::ReporterManager::Scheduler::Sequential" );
  isa_ok( $scheduler_object, "Inca::ReporterManager::Scheduler::Sequential",
          '_createScheduler returns sequential object' );

  # test for cron
  $scheduler_object = $scheduler->_createScheduler(
                           "Inca::ReporterManager::Scheduler::Cron" );
  isa_ok( $scheduler_object, "Inca::ReporterManager::Scheduler::Cron",
          '_createScheduler returns cron object' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _createScheduler {
  my ( $self, $scheduler_class ) = 
     validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  eval "require $scheduler_class";
  if ( $@ ) {
    $self->{logger}->error( 
      "Unable to find scheduler class '$scheduler_class': $@"
    );
    return undef;
  }
  my $new_scheduler = $scheduler_class->new( 
    undef, # no scheduler args now
    $self->getCheckPeriod(),
    $self->getCredentials(),
    [$self->getDepots()],
    $self->getReporterCache(),
    $self->getRimPath(),
    $self->getTmpDirectory()
  );
  $new_scheduler->setLogger( $self->{logfile} ) if ( defined $self->{logfile} );
  $self->{logger}->info( "Added scheduler object $scheduler_class" );
  return $new_scheduler;
}

#-----------------------------------------------------------------------------#
# _getScheduler( $scheduler )
#
# Return a scheduler object based on the scheduler type requested for the
# reporter group
#
# Arguments:
#
# scheduler  A string containing the name of a reporter scheduler (e.g.,
#            sequential, cron)
#
# Returns: 
#
# A scheduler object for the reporter group.
#

=begin testing

  tie *STDOUT, 'Catch', '_STDOUT_' or die $!;
  tie *STDERR, 'Catch', '_STDERR_' or die $!;

  use Inca::ReporterManager;
  use Inca::ReporterManager::ReporterCache;
  use Inca::Subscription::ReporterGroup;
  use Inca::Logger;

  my %logconfig = ( 
    'log4perl.rootLogger' => 'ERROR, Screen',
    'log4perl.appender.Screen' => 'Log::Dispatch::Screen',
    'log4perl.appender.Screen.stderr' => 1,
    'log4perl.appender.Screen.layout' => 'Log::Log4perl::Layout::SimpleLayout' 
  );
  Inca::Logger::init( \%logconfig );

  # test for sequential
  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  my $scheduler = new Inca::ReporterManager();
  $scheduler->setReporterCache( $rc );
  my $scheduler_object = $scheduler->_getScheduler( "sequential" );
  isa_ok( $scheduler_object, "Inca::ReporterManager::Scheduler::Sequential" );

  # test for non-existent scheduler
  $scheduler_object = $scheduler->_getScheduler( "notsched" );
  is( $scheduler_object, undef, 'fails when not a scheduler' );
  like( $_STDERR_, qr/Unknown scheduler type/, "warns correctly when not a scheduler" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _getScheduler {
  my ( $self, $scheduler ) = 
     validate_pos( @_, $SELF_PARAM_REQ, $ALPHANUMERIC_PARAM_REQ );

  # check to see if we have the scheduler instance already
  if ( exists $self->{schedulers}->{$scheduler} ) {
    return $self->{schedulers}->{$scheduler};
  }

  # otherwise, we need to create one
  my $scheduler_class = $self->_getSchedulerClassName( $scheduler );
  my $new_scheduler = $self->_createScheduler( $scheduler_class );
  if ( ! defined $new_scheduler ) {
    $self->{logger}->error( 
      "Unknown scheduler type '$scheduler' found for reporter group"
    );
    return undef;
  }
  # store for later use
  $self->{schedulers}->{$scheduler} = $new_scheduler;
  return $new_scheduler;
}

#-----------------------------------------------------------------------------#
# empty destructor (needed for test programs)
#-----------------------------------------------------------------------------#
sub DESTROY {
}

1; # need to return a true value from the file

__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

Does not recognize storage policies yet.

=cut
