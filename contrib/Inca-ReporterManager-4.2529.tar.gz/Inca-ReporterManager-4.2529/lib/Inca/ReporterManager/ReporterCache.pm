package Inca::ReporterManager::ReporterCache;

################################################################################

=head1 NAME

Inca::ReporterManager::ReporterCache - Manages the local cache of reporters
and libraries

=head1 SYNOPSIS

=for example begin

  use Inca::ReporterManager::ReporterCache;
  my $rc = new Inca::ReporterManager::ReporterCache( "var/cache" );

=for example end

=for example_testing
  # actually run above test and optionally test for specific values

=head1 DESCRIPTION

The Reporter Cache (RC) handles the maintenance and installation of
reporters and reporter libraries which it receives from the Reporter Agent
(who downloads it from one or more Reporter Repositories).  Reporters
will be stored in the "bin" directory and libraries in the "lib/perl" 
directory.

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#

# pragmas
use strict;
use warnings;
use vars qw($VERSION $AUTOLOAD);

# Inca
use Inca::Constants qw(:params);
use Inca::Logger;
use Inca::Validate qw(:all);

# cpan
use XML::Simple;

# Perl standard
use Carp;

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $SELF_PARAM_REQ = { isa => "Inca::ReporterManager::ReporterCache" };
my $DEFAULT_ERROR_REPORTER = "INCA_ERROR_REPORTER";
my $REPOSITORY_FILE = "repository.xml";
my %XML_OPTIONS = ( KeyAttr => { 'package' => 'uri' },
                    SuppressEmpty => undef );

#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 new( $location )

Class constructor which returns a new Inca::ReporterManager::ReporterCache
object.  The constructor must be called with $location and may be called with
any of the following attributes.

B<Arguments>:

=over 2 

=item location

A string containing the path to the local cache of reporter and libraries.
Reporters will be stored in the <location>/bin directory and libraries in
the <location>/lib/perl directory.

=back

B<Options>:

=over 13

=item errorReporterPath

A string containing the path to the special reporter used when generating
error reports

=back

=begin testing

  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;
  dies_ok { new Inca::ReporterManager::ReporterCache() } 'object created';
  lives_ok { new Inca::ReporterManager::ReporterCache( "var/cache" ) } 
           'object created';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $self = {};
  
  bless ($self, $class);

  $self->setLocation( shift );

  # set up defaults
  $self->{error_reporter} = undef;
  $self->{logger} = Inca::Logger::get_logger();

  # read options
  my %options = validate( @_, { errorReporterPath => $PATH_PARAM_OPT} );
  $self->setErrorReporterPath($options{errorReporterPath}) 
                                         if exists $options{errorReporterPath};

  $self->{catalogPath} = $self->{location} . "/" . $REPOSITORY_FILE;
  $self->{catalog} = { package => {} };
  if ( -e $self->{catalogPath} ) {
    eval {
      $self->{catalog} = XMLin( $self->{catalogPath}, %XML_OPTIONS,
                                 ForceArray => [ qw(package) ] );
    };
    if ( $@ ) {
      $self->{logger}->error( 
        "Problem reading repository catalog: $@; creating new file" 
      );
    }
  } 
  return $self;
}

#-----------------------------------------------------------------------------#

=head2 storePackage( $uri, $filename, $version, $installpath, $content )

Store the specified package into the reporter cache.  

=over 2

B<Arguments>:

=over 13

=item uri

A string containing the URI of the reporter that will be used to identify
the reporter in the depot.

=item filename

A string containing the filename that the package should be stored under.

=item version

A string containing the version of the package.

=item installpath

A string containing the directory the package should be stored under
relative to the reporter cache location.

=item perms

A string of format "[0-7][0-7][0-7]" that can be used to set the permissions
of the stored file after its written to disk.  A value of undef means that
no change of permissions is needed.

=item content

The content of the package to store to disk.

=back

B<Returns>:

True if the package is succesfully cached in the reporter cache and 
false otherwise.

=back

=begin testing

  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;

  my $rc = new Inca::ReporterManager::ReporterCache( "var/cache" );
  my $content = <<'FILE';
#!/usr/bin/perl -Icontrib/incareporters/lib/perl

use strict;
use warnings;
use Inca::Reporter::Version;

my $reporter = new Inca::Reporter::Version(
  version => 1.5,
  description => 'Reports the version of gcc',
  url => 'http://gcc.gnu.org',
  package_name => 'gcc'
);
$reporter->processArgv(@ARGV);

$reporter->setVersionByExecutable('gcc -dumpversion', '(.+)');
$reporter->print();
FILE
  my $result = $rc->storePackage( 
    "http://inca.sdsc.edu/reporters/cluster.compiler.gcc.version",
    "cluster.compiler.gcc.version",
    "1.5",
    "bin",
    "755",
    $content 
  );
  ok( $result, "gcc reporter succesfully cached" );
  ok( -x "var/cache/bin/cluster.compiler.gcc.version", "gcc executable" );
  $result = $rc->storePackage( 
    "http://inca.sdsc.edu/reporters/lib/Reporter.pm",
    "Reporter.pm",
    "1.5",
    "lib/perl",
    undef,
    "" 
  );
  ok( ! -x "var/cache/lib/perl/Reporter.pm", "Reporter.pm not executable" );
  is( $rc->getPath( "http://inca.sdsc.edu/reporters/lib/Reporter.pm" ),
      "var/cache/lib/perl/Reporter.pm",
      "getPath returned okay for Reporter.pm" );
  my $rc2 = new Inca::ReporterManager::ReporterCache( "var/cache" );
  is( $rc2->getPath( "http://inca.sdsc.edu/reporters/lib/Reporter.pm" ),
      "var/cache/lib/perl/Reporter.pm",
      "getPath returned okay for Reporter.pm" );
  `rm -fr var/cache`;

=end testing

=cut
#-----------------------------------------------------------------------------#
sub storePackage {
  my ($self, $uri, $filename, $version, $installpath, $perms, $content) = 
    validate_pos(
      @_, $SELF_PARAM_REQ, $URI_PARAM_REQ, SCALAR, SCALAR, SCALAR, 
          SCALAR|UNDEF, SCALAR
    );

  my $package_dir = $self->{location};
  my @subdirs = split( /\//, $installpath );
  for my $subdir ( @subdirs ) {
    $package_dir = $package_dir . "/" . $subdir;
    if ( ! -d $package_dir && ! mkdir($package_dir) ) {
      $self->{logger}->error( 
        "installpath '$package_dir' for $uri is not a directory; " . 
        "failed to create dir: $!" 
      );
      return 0;
    }
  }
  my $package_path = $self->{location} . "/" . $installpath . "/" . $filename;
  if ( ! open( FD, ">$package_path" ) ) {
    $self->{logger}->error( "Unable to open $package_path for writing $uri" );
    return 0;
  }
  print FD $content;
  close FD;
  if ( defined $perms ) {
    chmod( oct($perms), $package_path );
  }
  $self->{logger}->info( "Package '$uri' written to $package_path" );
  return $self->_updateCatalog($uri, $installpath . "/" . $filename, $version);
}

#-----------------------------------------------------------------------------#

=head2 setLocation( $path )

Set the location of the reporter repository on the local machine.  If the
path points to a non-existent directory, it errors out with a 'die' call.

=over 2

B<Arguments>:

=over 13

=item path

A string containing the path to the local cache of reporter and libraries.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;

  my $rc = new Inca::ReporterManager::ReporterCache( $ENV{HOME} );
  is( $rc->getLocation(), $ENV{HOME}, 'set Location works from constructor' );
  $rc->setLocation( "/tmp" );
  is( $rc->getLocation(), "/tmp", 'set/getLocation works' );
  dies_ok { $rc->getLocation( "blah" ); } 'dies when bad dir specified';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setLocation {
  my ( $self, $path ) = validate_pos( @_, $SELF_PARAM_REQ, $PATH_PARAM_REQ );

  if ( ! -d $path ) {
    if ( ! mkdir( $path ) ) {
      $self->{logger}->logconfess( 
        "specified cache '$path' is not a directory; failed to create dir: $!" 
      );
    }
  }
  $self->{location} = $path;
}

#-----------------------------------------------------------------------------#

=head2 getLocation( )

Get the location of the reporter repository on the local machine.

=over 2

B<Returns>:

A string containing the path to the local cache of reporter and libraries.

=back

=cut
#-----------------------------------------------------------------------------#
sub getLocation {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{location}; 
}

#-----------------------------------------------------------------------------#

=head2 setErrorReporterPath( $path )

Set the path to the special reporter that the reporter manager will use to
generate an error report if a reporter execution fails.  If the
path points to a non-existent file or is not executable, it errors out with a
'die' call.

=over 2

B<Arguments>:

=over 13

=item path

A string containing the path to the reporter.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;

  my $rc = new Inca::ReporterManager::ReporterCache( "var/cache",
                  errorReporterPath => "sbin/reporter-manager" );
  is($rc->getErrorReporterPath(), "sbin/reporter-manager", 
                  'set ErrorReporterPath works from init');
  $rc->setErrorReporterPath( "bin/inca-null-reporter" );
  is( $rc->getErrorReporterPath(), "bin/inca-null-reporter", 
      'set/getErrorReporterPath works' );
  dies_ok { $rc->setErrorPath( "/blah" ); } 'dies when points to no file';
  dies_ok { $rc->setErrorPath( "$ENV{HOME}/.ssh/known_hosts" ); } 
          'dies when points to non-executable file';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setErrorReporterPath {
  my ( $self, $path ) = validate_pos( @_, $SELF_PARAM_REQ, $PATH_PARAM_REQ );

  if ( ! -f $path ) {
    $self->{logger}->logconfess( "error reporter path '$path' is not a file" );
  } elsif( ! -x $path ) {
    $self->{logger}->logconfess( "error reporter at '$path' not executable" );
  }
  $self->{error_reporter} = $path;
}

#-----------------------------------------------------------------------------#

=head2 getErrorReporterPath( )

Get the error_reporter of the reporter repository on the local machine.

=over 2

B<Returns>:

A string containing the path to the local cache of reporter and libraries.

=back

=cut
#-----------------------------------------------------------------------------#
sub getErrorReporterPath {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{error_reporter}; 
}

#-----------------------------------------------------------------------------#

=head2 getPath( $reporter_uri )

Return a path to a local copy of a reporter using it's URI.

=over 2

B<Arguments>:

=over 13

=item path

A string containing a reporter uri [repositoryURI/name]

=back

B<Warning>:

Not full implemented yet.  Will just strip off the repository URI and
add it to the repository location.

=back

=begin testing

  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;

  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  my $path = $rc->getPath( "inca.sdsc.edu:8080/echo_report" );
  is( $path, "t/echo_report", 'getPath works for uri' );
  $path = $rc->getPath( "file:/usr/local/bin/echo_report" );
  is( $path, "t/echo_report", 'getPath works for file' );
  $path = $rc->getPath( "file:///usr/local/bin/echo_report" );
  is( $path, "t/echo_report", 'getPath works for file://' );
  $path = $rc->getPath( "file:/usr/local/bin/bogus_reporter" );
  is( $path, undef, 'getPath returns undef for non-existent reporter' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub getPath {
  my ( $self, $reporter_uri ) = 
     validate_pos( @_, $SELF_PARAM_REQ, $URI_PARAM_REQ);

  if ( exists $self->{catalog}->{package}->{$reporter_uri} ) {
    return $self->{location} . "/" .  
           $self->{catalog}->{package}->{$reporter_uri}->{path};
  } else {
    return undef;
  }
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# _updateCatalog( $uri, $relPath, $version )
# 
# Update the repository cache catalog with the following information about
# a package.
#   
# Arguments:
#
# uri       A string that contains the uri of the package.
#
# relPath   A string containing the relative path to the package location
#           in the cache.  
#
# version   A string containing the version of the package.
#
# Returns: 
#
# Returns true if the catalog was successfully update and false otherwise.
#-----------------------------------------------------------------------------#
sub _updateCatalog {
  my ( $self, $uri, $relPath, $version ) = validate_pos( @_, 
    $SELF_PARAM_REQ, $URI_PARAM_REQ, SCALAR, SCALAR 
  );

  $self->{catalog}->{package}->{$uri} = {path => $relPath, version => $version};
  eval {
    XMLout( $self->{catalog}, 
            %XML_OPTIONS,
            RootName => 'catalog', 
            NoAttr => 1,
            OutputFile => $self->{catalogPath} 
    );
  };
  if ( $@ ) {
    $self->{logger}->error( "Problem writing repository catalog: $@" );
    return 0;
  }
  return 1;
}

#-----------------------------------------------------------------------------#
# empty destructor (needed for test programs)
#-----------------------------------------------------------------------------#
sub DESTROY {
}

1; # need to return a true value from the file

__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

Currently just a stub.

=cut
