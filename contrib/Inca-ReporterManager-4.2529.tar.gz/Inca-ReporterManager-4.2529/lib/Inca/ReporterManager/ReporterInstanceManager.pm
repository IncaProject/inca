package Inca::ReporterManager::ReporterInstanceManager;

################################################################################

=head1 NAME

Inca::ReporterManager::ReporterInstanceManager - Manages reporter execution 

=head1 SYNOPSIS

=for example begin

  use Inca::ReporterManager::ReporterInstanceManager;
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();

  my $credentials = { cert => "t/certs/client_ca1cert.pem",
                      key => "t/certs/client_ca1keynoenc.pem", 
                      passphrase => undef,
                      trusted => "t/certs/trusted" };
  $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setCredentials( $credentials );
  $rim->setCheckPeriod(1);
  $rim->setUri( "file:///usr/local/bin/stream_report" );
  $rim->setDepots( "incas://localhost:$port" );
  $rim->setReporterCache( $rc );
  my $success = $rim->runReporter();

=for example end

=head1 DESCRIPTION

The Reporter Instance Manager (RIM) is responsible for launching a  reporter
instance and monitoring its execution. It will request the reporter from the
Reporter Administrator (who will download it if not available locally) and
then fork/exec it. The RIM monitors system usage of the reporter (CPU time,
wall clock time, and memory) and if it exceeds a specified timeout set for
either wall clock  time, CPU time, or memory, it will kill the reporter and
formulate an  error report. Otherwise upon reporter exit, the RIM will gather
stderr, stdout, usage statistics, and the depot list and send it  to the
Depot. The envelope is sent to the first available Depot in its list where the
data will then get passed to all interested  parties.

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#

# pragmas
use strict;
use warnings;
use vars qw($VERSION $AUTOLOAD);

# Inca
use Inca::Constants qw(:params);
use Inca::IO;
use Inca::Logger;
use Inca::Net::Protocol::Statement;
use Inca::Process;
use Inca::Validate qw(:all);
use Inca::Net::Client;

# Perl standard
use Carp;
use File::Temp qw(tempfile);
use File::Basename;

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $SELF_PARAM_REQ = { isa => "Inca::ReporterManager::ReporterInstanceManager"};

my $CHECK_PERIOD_PARAM_OPT = { %{$POSITIVE_INTEGER_PARAM_OPT}, default => 5 };
my $DEFAULT_TMP_DIR = "/tmp";
my $TMPFILE_TEMPLATE = "inca.rm.$$";
 
#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 new( %Options )

Class constructor which returns a new 
Inca::ReporterManager::ReporterInstanceManager object.  The constructor may be
called with any of the following attributes.

=over 2 

B<Options>:

=over 15

=item reporter

An object of type Inca::Subscription::Reporter which contains information
about the reporter to execute.

=item checkPeriod

A positive integer indicating the period in seconds of which to check the
reporter for a timeout [default: 5]

=item depotURIs

A list of depot uris.  The report will be sent to the first depot in the list.
If the first depot is unreachable, the next depots in the list will be tried.

=item reporterCache 

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=item credentials

A reference to a hash array containing the credential information.

=item tmpDir

A string containing a path to a temporary file space that Inca can use while
executing reporters

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Test::Exception;
  lives_ok { new Inca::ReporterManager::ReporterInstanceManager() } 
           'object created';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $self = {};
  
  bless $self, $class;

  # defaults
  $self->{logger} = Inca::Logger->get_logger( $class );
  $self->setTmpDirectory( $DEFAULT_TMP_DIR );

  # class variables
  my %options = validate( @_, { reporter => $REPORTER_PARAM_OPT,
                                depotURIs => $ARRAYREF_PARAM_OPT,
                                reporterCache => $REPORTER_CACHE_PARAM_OPT,
                                checkPeriod => $CHECK_PERIOD_PARAM_OPT,
                                credentials => $HASHREF_PARAM_OPT,
                                tmpDir => $SCALAR_PARAM_OPT
                              } );

  $self->setReporter( $options{reporter} ) if exists $options{reporter};
  $self->setCheckPeriod($options{checkPeriod}) if exists $options{checkPeriod};
  $self->setDepots( @{$options{depotURIs}} ) if exists $options{depotURIs}; 
  $self->setReporterCache( $options{reporterCache} ) 
    if exists $options{reporterCache};
  $self->setCredentials($options{credentials}) if exists $options{credentials};
  $self->setTmpDirectory( $options{tmpDir} ) if exists $options{tmpDir}; 

  return $self;
}

#-----------------------------------------------------------------------------#

=head2 setReporter( $reporter )

Set the reporter to be executed.

=over 2

B<Arguments>:

=over 13

=item reporter

An object of type Inca::Subscription::Reporter which contains information
about the reporter to execute.

=back

=back

=begin testing

  use Inca::Subscription::Reporter;
  use Inca::ReporterManager::ReporterInstanceManager;
  use Test::Exception;

  my $reporter1 = new Inca::Subscription::Reporter( uri => "file:uri1" );
  my $reporter2 = new Inca::Subscription::Reporter( uri => "file:uri2" );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
    reporter => $reporter1 
  );
  is ( $rim->getReporter()->getUri(), 'file:uri1', 
       'set reporter worked from constructor' );
  $rim->setReporter( $reporter2 );
  is ( $rim->getReporter()->getUri(), 'file:uri2', 'set/get reporter worked' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setReporter{
  my ( $self, $reporter) = 
    validate_pos( @_, $SELF_PARAM_REQ, $REPORTER_PARAM_REQ );

  $self->{reporter} = $reporter;
}

#-----------------------------------------------------------------------------#

=head2 getReporter( )

Retrieve the reporter that will be executed.

=over 2

B<Returns>:

An object of type Inca::Subscription::Reporter which contains information
about the reporter to execute.

=back

=cut
#-----------------------------------------------------------------------------#
sub getReporter {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{reporter};
}

#-----------------------------------------------------------------------------#

=head2 hasReporter( )

Return true if a reporter has been specified; otherwise return
false.

=over 2

B<Returns>:

Returns true if a reporter has been specified and false if it has not.

=back

=begin testing

  use Inca::Subscription::Reporter;
  use Inca::ReporterManager::ReporterInstanceManager();
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();
  ok( ! $rim->hasReporter(), 'hasReporter for false' );
  my $reporter = new Inca::Subscription::Reporter();
  $rim->setReporter( $reporter );
  ok( $rim->hasReporter(), 'hasReporter for true' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub hasReporter {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return exists( $self->{'reporter'} ) && defined( $self->{'reporter'} );
}

#-----------------------------------------------------------------------------#

=head2 setCheckPeriod( $secs )

Set the period for how often to check the reporter for exceeding its timeout.

=over 2

B<Arguments>:

=over 13

=item secs

A positive integer indicating the period in seconds of which to check for
resource timeouts.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;

  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                                                           checkPeriod => 3 );
  is( $rim->getCheckPeriod(), 3, 'set check period from constructor' );
  $rim->setCheckPeriod( 10 );
  is( $rim->getCheckPeriod(), 10, 'set check period' );
  $rim = new Inca::ReporterManager::ReporterInstanceManager( );
  is( $rim->getCheckPeriod(), 5, 'default check period is 5' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setCheckPeriod {
  my ( $self, $secs ) =
     validate_pos( @_, $SELF_PARAM_REQ, $POSITIVE_INTEGER_PARAM_REQ );

  $self->{check_period} = $secs;
}

#-----------------------------------------------------------------------------#

=head2 getCheckPeriod( )

Get the period for how often to check the reporter for exceeding its timeout.

=over 2

B<Returns>:

A positive integer indicating the period in seconds of which to check for
resource timeouts.

=back

=cut
#-----------------------------------------------------------------------------#
sub getCheckPeriod {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{check_period};
}

#-----------------------------------------------------------------------------#

=head2 setDepots( @depot_uris )

Specify the destination depots that are used to send the report on completion.
The report will be sent to the first depot in the list.  If the first depot is
unreachable, the next depots in the list will be tried.

=over 2

B<Arguments>:

=over 13

=item depot_uris

Any number of strings containing a uri to a depot [host:port, ...]

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Test::Exception;

  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                            depotURIs => ["cuzco.sdsc.edu:8234"] );
  my @depots = $rim->getDepots();
  is( $depots[0], "cuzco.sdsc.edu:8234", 'Set depots works from constructor' );
  $rim->setDepots( qw(inca.sdsc.edu:8235 inca.sdsc.edu:8236) );
  @depots = $rim->getDepots();
  is( $depots[0], "inca.sdsc.edu:8235", 'Set depots works from function (1)' );
  is( $depots[1], "inca.sdsc.edu:8236", 'Set depots works from function (2)' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setDepots {
  my ( $self, @depot_uris ) =
     validate_pos( @_, $SELF_PARAM_REQ, $URI_PARAM_REQ,
                       ($URI_PARAM_REQ) x (@_ - 2) );

  @{$self->{depots}} = @depot_uris;
}

#-----------------------------------------------------------------------------#

=head2 getDepots( )

Retrieve the destination depots that are used to send the report on completion.

=over 2

B<Returns>:

An array of strings containing uris to depots [host:port, ...]

=back

=cut
#-----------------------------------------------------------------------------#
sub getDepots {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  @{$self->{depots}};
}

#-----------------------------------------------------------------------------#

=head2 setReporterCache( $reporter_cache )

Specify the reporter administrator to use in order to find a path to a local
copy of a reporter (from its URI).

=over 2

B<Arguments>:

=over 13

=item reporter_cache

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;

  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  my $rc_new = new Inca::ReporterManager::ReporterCache( "/tmp" );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                  reporterCache => $rc );
  is( $rim->getReporterCache->getLocation(), "t",
          'set reporter admin worked from constructor' );
  $rim->setReporterCache( $rc_new );
  is( $rim->getReporterCache->getLocation(), "/tmp",
          'set reporter admin worked from set/get functions' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setReporterCache {
  my ( $self, $reporter_cache) =
     validate_pos( @_, $SELF_PARAM_REQ, $REPORTER_CACHE_PARAM_REQ );

  $self->{reporter_cache} = $reporter_cache;
}

#-----------------------------------------------------------------------------#

=head2 getReporterCache( )

Retrieve the reporter administrator to use in order to find a path to a local
copy of a reporter (from its URI).

=over 2

B<Returns>:

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=back

=cut
#-----------------------------------------------------------------------------#
sub getReporterCache {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{reporter_cache};
}

#-----------------------------------------------------------------------------#

=head2 setCredentials( \%credentials )

Specify the credentials to use.

=over 2

B<Arguments>:

=over 13

=item credentials

A reference to a hash array containing the credential information.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;

  my $credentials = { cert => 't/cert.pem', key => 't/key.pem',
                      passphrase => 'pwd', trusted => 't/trusted' };
  my $credentials_new = { cert => 't/new/cert.pem', key => 't/key.pem',
                      passphrase => undef, trusted => 't/trusted' };
  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                  credentials => $credentials );
  ok( eq_hash($rim->getCredentials(), $credentials), 
          'set credentials worked from constructor' );
  $rim->setCredentials( $credentials_new );
  ok( eq_hash($rim->getCredentials(), $credentials_new), 
          'set/get credentials worked' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setCredentials {
  my ( $self, $credentials ) =
     validate_pos( @_, $SELF_PARAM_REQ, HASHREF );

  $self->{credentials} = $credentials;
}

#-----------------------------------------------------------------------------#

=head2 getCredentials( )

Retrieve the security credentials.

=over 2

B<Returns>:

A reference to a hash array containing the paths to the security 
credentials.

=back

=cut
#-----------------------------------------------------------------------------#
sub getCredentials {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{credentials};
}

#-----------------------------------------------------------------------------#

=head2 hasCredentials( )

Return true if credentials have been specified; otherwise return false.

=over 2

B<Returns>:

A boolean indicating true if credentials have been specified and false if they
has not.

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager();
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();
  ok( ! $rim->hasCredentials(), 'hasCredentials for false' );
  my $credentials = { cert => 't/cert.pem', key => 't/key.pem',
                      passphrase => 'secret', trusted => 't/trusted' };
  $rim->setCredentials( $credentials );
  ok( $rim->hasCredentials(), 'hasCredentials for true' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub hasCredentials {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return exists $self->{credentials};
}

#-----------------------------------------------------------------------------#

=head2 setTmpDirectory( $path )

Specify a temporary file space that Inca can use while executing reporters.

=over 2

B<Arguments>:

=over 13

=item path

A string containing a path to a temporary file space 

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Test::Exception;

  my $rim = new Inca::ReporterManager::ReporterInstanceManager(); 
  is( $rim->getTmpDirectory(), "/tmp", 'default tmp set' );
  $rim->setTmpDirectory( "/scratch" );
  is( $rim->getTmpDirectory(), "/scratch", 'set/getTmpDirectory work' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setTmpDirectory {
  my ( $self, $path ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  $self->{tmpdir} = $path;
}

#-----------------------------------------------------------------------------#

=head2 getTmpDirectory( )

Retrieve the path to a temporary file space that Inca can use while executing
reporters

=over 2

B<Returns>:

A string containing a path to a temporary file space.

=back

=cut
#-----------------------------------------------------------------------------#
sub getTmpDirectory {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{tmpdir};
}

#-----------------------------------------------------------------------------#

=head2 runReporter( )

Contact the reporter administrator, retrieve the local path to the
reporter, and execute it.

B<Returns:>

Returns false if there was a problem either retrieving the reporter, running it,
or sending it to the depot.  Otherwise returns true for success.

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::Process::Usage;
  use Inca::ReporterManager::ReporterCache;
  use IO::Socket::SSL;
  use Inca::Subscription::Reporter;
  use Inca::Logger;
  use File::Spec;
  use Cwd;

  my %logconfig = ( 
    'log4perl.rootLogger' => 'FATAL, Screen',
    'log4perl.appender.Screen' => 'Log::Dispatch::Screen',
    'log4perl.appender.Screen.stderr' => 1,
    'log4perl.appender.Screen.layout' => 'Log::Log4perl::Layout::SimpleLayout' 
  );
  Inca::Logger::init( \%logconfig );

  sub verifyReportProtocolContent {
    my $content = shift;
    my $tag = shift;

    like( $content, qr/^START.*/, "runReporter($tag) - START found" );
    like( $content, qr/^REPORT.*/m, "runReporter($tag) - REPORT found" );
    unlike( $content, qr/^STDERR.*/m, "runReporter($tag) - STDERR not found" );
    like( $content, qr/^STDOUT.*/m, "runReporter($tag) - STDOUT found" );
    like( $content, qr/^<rep:report .*/m, "runReporter($tag) - start tag" );
    like( $content, qr/^<\/rep:report>.*/m, "runReporter($tag) - end tag" );
    like( $content, qr/^SYSUSAGE cpu_secs=.*/m, 
          "runReporter($tag) - SYSUSAGE found" );
    like( $content, qr/^wall_secs=.*/m, "runReporter($tag) - wall_secs found" );
    like( $content, qr/^memory_mb=.*/m, "runReporter($tag) - memory_mb found" );
  }

  my $rc = new Inca::ReporterManager::ReporterCache( "t",
     errorReporterPath => 'bin/inca-null-reporter' 
  );

  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );
  # simple execution to file
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/echo_report" );
  $reporter->setNiced( 1 );
  $reporter->setSetup( "sh -c \"" );
  $reporter->setCleanup( "\"" );
  $reporter->setTimeout( [ { name => "wallClockTime", value => 10 },
                         { name => "CPUTime", value => 10 },
                         { name => "memory", value => 20 } ] );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setCheckPeriod(1);
  $rim->setDepots( $file_depot );
  $rim->setReporterCache( $rc );
  $rim->setReporter( $reporter );
  my $success = $rim->runReporter();
  is( $success, 1, "runReporter returned true status" );
  open( FD, "./depot.tmp.$$" );
  local $/;
  my $content = <FD>;
  close FD;
  verifyReportProtocolContent( $content, "basic" );
  like( $content, qr/^SETUP sh -c \".*/m, "runReporter(basic) - SETUP found" );
  like( $content, qr/^CLEANUP \".*/m, "runReporter(basic) - CLEANUP found" );
  my ($wall_secs) = $content =~ /^wall_secs=(.*)/m;
  cmp_ok( $wall_secs, "<=", 1, "wall secs is reasonable" );
  unlink "./depot.tmp.$$";

  # not a valid reporter
  my $invalid_reporter = new Inca::Subscription::Reporter();
  $invalid_reporter->setUri( "file:///usr/local/bin/not_a_reporter" );
  $invalid_reporter->addArgument( "verbose", 1 );
  $invalid_reporter->addArgument( "help", "no" );
  $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setReporterCache( $rc );
  $rim->setDepots( $file_depot );
  $rim->setReporter( $invalid_reporter );
  $success = $rim->runReporter();
  is( $success, 0, "runReporter - non-existent reporter is caught" );
  open( FD, "./depot.tmp.$$" );
  local $/;
  $content = <FD>;
  close FD;
  verifyReportProtocolContent( $content, "non-existent reporter" );
  like( $content, qr/<completed>false<\/completed>.*/m, 
        "runReporter(non-existent reporter) - completed false" );
  like( $content, qr/<errorMessage>Unable to retrieve.*<\/errorMessage>.*/m, 
        "runReporter(non-existent reporter) - error message found" );
  like( $content, qr/<name>verbose<\/name>.*/m, 
        "runReporter(non-existent reporter) - arg found" );
  unlink "./depot.tmp.$$";

  # faulty reporter
  my $faulty_reporter = new Inca::Subscription::Reporter();
  $faulty_reporter->setUri( "file:///usr/local/bin/bad_reporter" );
  $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setReporterCache( $rc );
  $rim->setDepots( $file_depot );
  $rim->setReporter( $faulty_reporter );
  $success = $rim->runReporter();
  is( $success, 1, "runReporter - faulty reporter returns success" );
  open( FD, "./depot.tmp.$$" );
  local $/;
  $content = <FD>;
  close FD;
  verifyReportProtocolContent( $content, "faulty reporter" );
  like( $content, qr/<completed>false<\/completed>.*/m, 
        "runReporter(faulty reporter) - completed false" );
  like( $content, qr/<errorMessage>Exec of reporter .*<\/errorMessage>.*/m, 
        "runReporter(faulty reporter) - error message found" );
  unlink "./depot.tmp.$$";

  # badly written reporter
  my $poor_reporter = new Inca::Subscription::Reporter();
  $poor_reporter->setUri( "file:///usr/local/bin/bad_reporter2" );
  $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setReporterCache( $rc );
  $rim->setDepots( $file_depot );
  $rim->setReporter( $poor_reporter );
  $success = $rim->runReporter();
  is( $success, 1, "runReporter - badly written reporter returns success" );
  open( FD, "./depot.tmp.$$" );
  local $/;
  $content = <FD>;
  close FD;
  verifyReportProtocolContent( $content, "badly written reporter" );
  like( $content, qr/<completed>false<\/completed>.*/m, 
        "runReporter(badly written reporter) - completed false" );
  like( $content, qr/<errorMessage>.*no report.*/m, 
        "runReporter(badly written reporter) - error message found" );
  unlink "./depot.tmp.$$";

  # no report but there is stderr
  my $null_reporter = new Inca::Subscription::Reporter();
  $null_reporter->setUri( "file:///usr/local/bin/no_report" );
  $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setReporterCache( $rc );
  $rim->setDepots( $file_depot );
  $rim->setReporter( $null_reporter );
  $success = $rim->runReporter();
  is( $success, 1, "runReporter - no report returns success" );
  open( FD, "./depot.tmp.$$" );
  local $/;
  $content = <FD>;
  close FD;
  verifyReportProtocolContent( $content, "no report" );
  like( $content, qr/<completed>false<\/completed>.*/m, 
        "runReporter(no report) - completed false" );
  like( $content, qr/<errorMessage>.*no report.*/m, 
        "runReporter(no report) - error message found" );
  unlink "./depot.tmp.$$";

  # timeout
  my $long_reporter = new Inca::Subscription::Reporter();
  $long_reporter->setUri( "file:///usr/local/bin/stream_report" );
  $long_reporter->setTimeout( [ { name => "CPUTime", value => 1 },
                                { name => "memory", value => 100 } ] );
  $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setCheckPeriod(1);
  $rim->setDepots( $file_depot );
  $rim->setReporterCache( $rc );
  $rim->setReporter( $long_reporter );
  $success = $rim->runReporter();
  is( $success, 1, "runReporter returned true status" );
  open( FD, "./depot.tmp.$$" );
  local $/;
  $content = <FD>;
  close FD;
  verifyReportProtocolContent( $content, "timeout" );
  like( $content, qr/<completed>false<\/completed>.*/m, 
        "runReporter(timeout) - completed false" );
  like( $content, qr/<errorMessage>.*timed out.*/m, 
        "runReporter(timeout) - error message found" );
  my ($memory) = $content =~ /^memory_mb=(.*)/m;
  cmp_ok( $memory, ">=", 45, "runReporter(timeout) - memory is reasonable" );
  unlink "./depot.tmp.$$";

  # more resource intensive reporter to file
  $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setCheckPeriod(1);
  $long_reporter->setTimeout( [ { name => "wallClockTime", value => 100 },
                                { name => "CPUTime", value => 10 },
                                { name => "memory", value => 100 } ] );
  $rim->setDepots( $file_depot );
  $rim->setReporterCache( $rc );
  $rim->setReporter( $long_reporter );
  $success = $rim->runReporter();
  is( $success, 1, "runReporter returned true status" );
  open( FD, "./depot.tmp.$$" );
  local $/;
  $content = <FD>;
  close FD;
  verifyReportProtocolContent( $content, "stream" );
  ($memory) = $content =~ /^memory_mb=(.*)/m;
  cmp_ok( $memory, ">=", 45, "memory is reasonable" );
  unlink "./depot.tmp.$$";

  # more resource intensive reporter to ssl server
  use Inca::IO;
  my $port = 6328;
  my @clientCredentials = ( { cert => "t/certs/client_ca1cert.pem",
                              key => "t/certs/client_ca1keynoenc.pem", 
                              passphrase => undef,
                              trusted => "t/certs/trusted" },
                            { cert => "t/certs/client_ca1cert.pem",
                              key => "t/certs/client_ca1key.pem", 
                              passphrase => "test",
                              trusted => "t/certs/trusted" }
                          );
  my $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  my $pid;
  for ( my $i = 0; $i <= $#clientCredentials; $i++ ) {
    if ( $pid = fork() ) {
      my $server_sock = $server->accept();
      my $depot = Inca::Net::Client->_connect( $server_sock );
      my $start_stmt = $depot->readStatement();
      $depot->writeStatement( 
        "OK", 
        $Inca::Net::Protocol::Statement::PROTOCOL_VERSION
      );
      my $content = $start_stmt->toString();
      my $line;
      while( $line = <$server_sock> ) {
        $content .= $line;
        close $server_sock if $content =~ /END/;
      } 
      verifyReportProtocolContent( $content, "$i SSL - stream" );
    } else {
      $long_reporter = new Inca::Subscription::Reporter();
      $long_reporter->setUri( "file:///usr/local/bin/stream_report" );
      $rim = new Inca::ReporterManager::ReporterInstanceManager();
      $rim->setCredentials( $clientCredentials[$i] );
      $rim->setCheckPeriod(1);
      $rim->setDepots( "incas://localhost:$port" );
      $rim->setReporterCache( $rc );
      $rim->setReporter( $long_reporter );
      $success = $rim->runReporter();
      exit;
    }
  }
  close $server;

=end testing

=cut
#-----------------------------------------------------------------------------#
sub runReporter {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  my $reporter_executed_n_recorded = 0;

  $self->{logger}->info( "Begin executing " . $self->getReporter()->getUri() );
  my $cmdline = $self->_createCmdLine();
  $self->{logger}->info( "  $cmdline" );
  if ( ! defined $cmdline ) {
    $self->_generateErrorReport( 
                  "Unable to retrieve local copy of reporter for execution" );
  } else { # run the reporter
    my $process = new Inca::Process( tmpDir => $self->getTmpDirectory() );
    $process->setCheckPeriod( $self->getCheckPeriod() );
    if ( $self->getReporter()->hasTimeout() ) {
      $process->setTimeout( $self->getReporter()->getTimeout() );
    }
    $process->setCommandLine( $cmdline );
    if ( ! $process->run() ) {
      if ( $process->hasTimedOut() ) {
        $self->{usage} = $process->getUsage()->toString();
        $self->_generateErrorReport( "Reporter timed out" );
        $reporter_executed_n_recorded = 1;
      } else { # must have been error
        $self->_generateErrorReport( "Unable to execute reporter: error '$!'" );
      }
    } else {
      $reporter_executed_n_recorded = 1;
      $self->{stdout} = $process->getStdout();
      $self->{stderr} = $process->getStderr();
      if ( ! defined $self->{stdout} || $self->{stdout} eq "" ) {
        if ( ! defined $self->{stderr} || $self->{stderr} eq "" ) {
          if ( $! ne 0 ) {
            $self->_generateErrorReport( "Exec of reporter failed: error '$!'");
          } else {
            $self->_generateErrorReport(
              "Error running reporter: no stdout, stderr, nor system error" 
            );
          }
        } else {
          $self->_generateErrorReport(
            "Error, no report produced to stdout.  " .
            "The following was printed to stderr: \n" .
            $self->{stderr} 
          );
        }
      } else {
        $self->{usage} = $process->getUsage()->toString();
      }
    }
  }

  my $success = $self->_sendReportToDepot();

  if ( ! $success ) {
    $reporter_executed_n_recorded = 0;
    $self->{logger}->error( "  Unable to send report to available depots" );
    # in the future, save report
  }

  $self->{logger}->info( "End " . $self->getReporter()->getUri() );
  return $reporter_executed_n_recorded;
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# _createCmdLine( )
#
# Create the command-line string for executing the reporter.  If execution
# priority is set, then the process is run with nice.
#
# Returns: 
#
# A string containing the command to run the reporter with its arguments
# or undefined if there is an error locating the reporter in the local cache.
#
=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::ReporterManager::ReporterCache;
  use Inca::Subscription::Reporter;
  use Test::Exception;

  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "inca.sdsc.edu:8789/echo_report" );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                  reporter => $reporter,
                  reporterCache => $rc );
  is( $rim->_createCmdLine(), "t/echo_report",
          '_createCmdLine works for simple case' );
  $reporter->setNiced( 1 );
  $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                  reporter => $reporter,
                  reporterCache => $rc );
  is( $rim->_createCmdLine(), "nice t/echo_report",
          '_createCmdLine works for simple case with nice' );
  
  # try set setup and cleanup
  $reporter->setSetup( 'PATH=bin:${PATH}; ' );
  $reporter->setCleanup( '; rm -f /tmp/blah' );
  is( $rim->_createCmdLine(), 
      'PATH=bin:${PATH}; nice t/echo_report; rm -f /tmp/blah',
       '_createCmdLine works for setup and cleanup' );
  
  $reporter->addArgument( "name1", "value1" );
  $reporter->addArgument( "name1", "value2" );
  is( $rim->_createCmdLine(), 
      'PATH=bin:${PATH}; nice t/echo_report -name1="value1" -name1="value2"; rm -f /tmp/blah',
      '_createCmdLine works for with args' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _createCmdLine {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  # get path to local copy of reporter
  my $rc = $self->getReporterCache();
  if ( ! defined $rc ) {
    $self->{logger}->error( "No reporter cache specified" );
    return undef;
  }
  my $path = $rc->getPath( $self->getReporter()->getUri() );
  if ( ! defined $path ) {
    $self->{logger}->error( 
      "Unable to locate " . $self->getReporter()->getUri() . 
      " in local cache...skipping"
    );
    return undef;
  }
 
  # construct cmd line
  my $cmdline = "";
  if ( $self->getReporter()->hasSetup() ) {
    $cmdline .= $self->getReporter()->getSetup();
  }
  if ( $self->getReporter()->hasNiced() ) {
    $cmdline .= "nice ";
  }
  $cmdline .= $path;
  if ( $self->getReporter()->hasArguments() ) {
    $cmdline .= " " . $self->getReporter()->getArgumentsAsCmdLine();
  } 
  if ( $self->getReporter()->hasCleanup() ) {
    $cmdline .= $self->getReporter()->getCleanup();
  }
  return $cmdline; 
}

#-----------------------------------------------------------------------------#
# _generateErrorReport( $error_msg )
#
# Called after a reporter error has been detected.  Will generate a
# a special error report that can be sent to the depot.
#
# Arguments:
#
#  error_msg  A string indicating the reason for the reporter error.
#

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::Subscription::Reporter;
  use File::Spec;
  use Cwd;

  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/echo_report" );
  $reporter->setNiced( 1 );
  $reporter->setTimeout( [ { name => "wallClockTime", value => 10 },
                           { name => "CPUTime", value => 10 },
                           { name => "memory", value => 20 } ] );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setCheckPeriod(1);
  $rim->setReporter( $reporter );
  $rim->setDepots( $file_depot );
  my $rc = new Inca::ReporterManager::ReporterCache( "t",
    errorReporterPath => "bin/inca-null-reporter" 
  );
  $rim->setReporterCache( $rc );
  my $success = $rim->_generateErrorReport( "An Error Message" );
  like( $rim->{stdout}, qr/^<rep:report/m, "_generateErrorReport - report found");
  like( $rim->{stdout}, qr/<errorMessage>An Error Message/m, 
        "_generateErrorReport - error found" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _generateErrorReport {
  my ( $self, $error_msg ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  # get temp file options
  my %tempfile_options = ( UNLINK => 1, DIR => $self->getTmpDirectory() );
  my ($tfh, $tempfile) =
    tempfile("$TMPFILE_TEMPLATE.out.XXXXX", %tempfile_options);
  print $tfh $error_msg;

  my $cmdline = $self->getReporterCache()->getErrorReporterPath();
  $cmdline .= " --error_message_stdin=1";
  my $path = $self->getReporterCache()->getPath( $self->getReporter()->getUri() );
  if ( defined $path ) {
    $cmdline .= " --name=" . basename( $path );
  } else {
    $cmdline .= " --name=" . $self->getReporter()->getUri();
  }
  $cmdline .= " --completed=false";
  if ( $self->getReporter()->hasArguments() ) {
    $cmdline .= " -- " . $self->getReporter()->getArgumentsAsCmdLine();
  }
  $cmdline .= " < $tempfile";
  my $report = `$cmdline`;
  close $tfh;
  if ( $report eq "" ) {
    $self->{logger}->error( "  Unable to generate error report for " . 
                            $self->getReporter()->getUri() . ": $!" );
  }
  $self->{logger}->info( "  Generating error report for " . 
                          $self->getReporter()->getUri() . ": $error_msg " );
  $self->{stdout} = $report;
  $self->{stderr} = "";
  if ( ! exists $self->{usage} ) {
    my $zero_usage = new Inca::Process::Usage();
    $zero_usage->zeroValues();
    $self->{usage} = $zero_usage->toString();
  }
}

#-----------------------------------------------------------------------------#
# _sendReportToStream( $process, $client )
#
# Called from runReporter after the reporter has finished running to handle
# sending data to the depot.  This method is called from _sendReportToDepot
# (i.e., we have an open connection to a depot already and now just need
# to send data).
#
# Arguments:
#
#  process    An object of type Inca::Process that has just finished 
#             executing a reporter
#
#  client     An object of type Inca::Net::Client which is the open connection
#             we can write the report to.
#
# Returns: 
#
# Returns 1 if the report was sent to a depot; otherwise return 0. 
#-----------------------------------------------------------------------------#
sub _sendReportToStream {
  my ( $self, $client ) = validate_pos(@_, $SELF_PARAM_REQ, $CLIENT_PARAM_REQ);

  # send that a report is coming
  $client->writeStatement( "REPORT", $self->getReporter()->getUri() );

  # send stderr from reporter if it exists
  if ( defined $self->{stderr} && $self->{stderr} ne "" ) {
    $client->writeStatement( "STDERR", $self->{stderr} );
  }

  # send setup to reporter if it exists
  if ( $self->getReporter()->hasSetup() ) {
    $client->writeStatement( "SETUP", $self->getReporter()->getSetup() );
  }

  # send cleanup to reporter if it exists
  if ( $self->getReporter()->hasCleanup() ) {
    $client->writeStatement( "CLEANUP", $self->getReporter()->getCleanup() );
  }

  # send stdout from reporter
  $client->writeStatement( "STDOUT", $self->{stdout} );

  # send reporter usage information
  $client->writeStatement( "SYSUSAGE", $self->{usage} );

  # send end
  $client->writeStatement( Inca::Net::Protocol::Statement->getEndStatement() );

  # depot will either close socket when it accepts a report or send an
  # error response on error
  my $stream = $client->{stream};
  my $depot_response = <$stream>;
  if ( ! defined $depot_response or $depot_response eq '' ) {
    return 1;
  } else {
    my $depot_stmt = new Inca::Net::Protocol::Statement();
    $depot_stmt->setStatement( $depot_response );
    if ( $depot_stmt->getCmd() eq "ERROR" ) {
      $self->{logger}->error( 
        "  Error writing to depot: " .  $depot_stmt->getData()
      );
    } else {
      $self->{logger}->error( 
        "  Uknown response from the depot: " .  $depot_stmt->getStatement()
      );
    }
    return 0;
  }
}

#-----------------------------------------------------------------------------#
# _sendReportToDepot( $process )
#
# Called from runReporter after the reporter has finished running to handle
# sending data to the depot.  We send the report to the first accessible
# depot in our list. 
#
# Arguments:
#
#  process    An object of type Inca::Process that has just finished 
#             executing a reporter
#
# Returns: 
#
# Returns 1 if the report was sent to a depot; otherwise return 0. 

=begin testing

  untie *STDOUT;
  tie *STDERR, 'Catch', '_STDERR_' or die $!;

  use Inca::IO;
  use Inca::ReporterManager::ReporterCache;
  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::Net::Protocol::Statement;
  use Inca::Subscription::Reporter;

  use Inca::Logger;

  my %logconfig = ( 
    'log4perl.rootLogger' => 'ERROR, Screen',
    'log4perl.appender.Screen' => 'Log::Dispatch::Screen',
    'log4perl.appender.Screen.stderr' => 1,
    'log4perl.appender.Screen.layout' => 'Log::Log4perl::Layout::SimpleLayout' 
  );
  Inca::Logger::init( \%logconfig );

  sub runRIM {
    my $port = shift;

    sleep( 2 );
    my $reporter = new Inca::Subscription::Reporter();
    $reporter->setUri( "file:///usr/local/bin/echo_report" );
    my $credentials = { cert => "t/certs/client_ca1cert.pem",
                        key => "t/certs/client_ca1keynoenc.pem", 
                        passphrase => undef,
                        trusted => "t/certs/trusted" };
    my $rc = new Inca::ReporterManager::ReporterCache( "t",
      errorReporterPath => "bin/inca-null-reporter" 
    );
    my $rim = new Inca::ReporterManager::ReporterInstanceManager();
    $rim->setCredentials( $credentials );
    $rim->setCheckPeriod(1);
    $rim->setReporter( $reporter );
    $rim->setDepots( "incas://localhost:$port" );
    $rim->setReporterCache( $rc );
    return $rim->runReporter();
  }

  sub acceptReport {
    my $server = shift;
    my $response_cmd = shift;
    my $response_data = shift;

    my $server_sock = $server->accept();
    my $depot = Inca::Net::Client->_connect( $server_sock );
    my $start_stmt = $depot->readStatement();
    $depot->writeStatement( 
      "OK", 
      $Inca::Net::Protocol::Statement::PROTOCOL_VERSION
    );
    my $content = $start_stmt->toString();
    my $line;
    while( $line = <$server_sock> ) {
      $content .= $line;
      if ( $content =~ /END/ ) {
        if ( defined $response_cmd and defined $response_data ) {
          my $error = new Inca::Net::Protocol::Statement(
               cmd => $response_cmd,
               data => $response_data
          );
          print $server_sock $error->toString();
        }
        close $server_sock;
      }
    } 
  }

  my $port = 6329;
  my $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  my $pid;
  if ( $pid = fork() ) {
    my $success = runRIM( $port );
    is( $success, 1, "report accepted" );

    $success = runRIM( $port );
    is( $success, 0, "report rejected" );
    like( $_STDERR_, qr/This is an error/, "error logged when report rejected");
    like( $_STDERR_, qr/Unable to send report to available depots/, 
          "message logged when report not sent to the depot" );

    $_STDERR_ = "";
    $success = runRIM( $port );
    is( $success, 0, "report rejected" );
    like( $_STDERR_, qr/Uknown response/, "error logged when report rejected" );
    like( $_STDERR_, qr/Unable to send report to available depots/, 
          "message logged when report not sent to the depot" );
  } else {
    acceptReport( $server );
    acceptReport( $server, "ERROR", "This is an error message from the depot" );
    acceptReport( $server, "STARS", "shine at night" );
    exit;
  }
  close $server;

=end testing
=cut
#-----------------------------------------------------------------------------#
sub _sendReportToDepot {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  my $success = 0;
  my %credentials;

  # grab credentials if they're there (and needed)
  %credentials = %{ $self->getCredentials() } if $self->hasCredentials();

  # search for depot
  for my $uri ( $self->getDepots() ) {
    my $client = new Inca::Net::Client( $uri, %credentials ); 
    if ( defined $client ) {
      $self->{logger}->info( "  Sending report to $uri" );
      $success = $self->_sendReportToStream( $client );
      $client->close();
      last if $success; 
    } else {
      $self->{logger}->error( "Unable to connect to depot '$uri'" );
    }
  }

  return $success;
}

#-----------------------------------------------------------------------------#
# empty destructor (needed for test programs)
#-----------------------------------------------------------------------------#
sub DESTROY {
}

1; # need to return a true value from the file

__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

set/getStoragePolicy functions not thoroughly tested
set/getTimeout functions not thoroughly tested

=cut
