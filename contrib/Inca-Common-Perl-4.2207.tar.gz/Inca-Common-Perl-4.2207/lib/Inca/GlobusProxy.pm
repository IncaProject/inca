package Inca::GlobusProxy;

################################################################################

=head1 NAME

Inca::GlobusProxy - Manages the renewal of a globus proxy credential via MyProxy
      
=head1 SYNOPSIS

=for example begin

  use Inca::GlobusProxy;
  my $proxy = new Inca::GlobusProxy( "localhost", 7512, "smallen", 
                                     "bree987",  1 );
  $proxy->start();
  # ...
  $proxy->stop();

=for example end

=for example_testing
  # actually run above test and optionally test for specific values

=head1 DESCRIPTION

Will periodically check the default globus user proxy for validity.  If 
expired, will retrieve a new proxy credential from the specified MyProxy
server.

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#
use strict;
use warnings;
use Carp;
use vars qw/$VERSION $AUTOLOAD/;
use Params::Validate qw(:all);
use Inca::Constants qw(:all);
use Inca::Logger;

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

our $CHECK_PERIOD = 10 * $SECS_TO_MIN; # every 10 mins
my $MINIMUM_AGE = 4 * $SECS_TO_HOUR;

#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 new( $hostname, $port, $username, $password, $lifetime )

Class constructor which returns a new Inca::GlobusProxy object.  

=over 2 

B<Arguments>:

=over 13

=item hostname

A string containing the hostname of the MyProxy server.

=item port

An integer containing the port of the MyProxy server.

=item username 

An string containing the username that the credential is stored under on the
MyProxy server.

=item password

An string containing the password to access the credential stored on the 
MyProxy server.

=item lifetime

An integer containing the number of hours to request on the credential lifetime.

=back

=back

=begin testing

  use Inca::GlobusProxy;
  use Test::Exception;
  dies_ok { new Inca::GlobusProxy() } 'object not created';
  lives_ok { new Inca::GlobusProxy( "localhost", 7512, "ssmallen", "bree98",
  12 ) } 'object created';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $self = {};
  
  bless ($self, $class);

  $self->{pid} = undef;
  $self->{renew_at} = $MINIMUM_AGE + (2*$CHECK_PERIOD);
  $self->{logger} = Inca::Logger->get_logger( $class );

  ($self->{hostname}, $self->{port}, $self->{username}, $self->{password}, 
   $self->{lifetime} ) = validate_pos( @_, $HOST_PARAM_REQ, $PORT_PARAM_REQ,
                                           $ALPHANUMERIC_PARAM_REQ, 
                                           $ALPHANUMERIC_PARAM_REQ, 
                                           $POSITIVE_INTEGER_PARAM_REQ );

  return $self;
}

#-----------------------------------------------------------------------------#

=head2 start();

Forks off a process to manage the renewal of the globus proxy.

=over 2

B<Returns>:

True on successful process spawning; false otherwise.

=back

=begin testing

  use Inca::GlobusProxy;
  use Test::Exception;
  use POSIX ":sys_wait_h";

  `echo bree987 | myproxy-init -s localhost -l test -S -c 2`;
  my $myproxy = new Inca::GlobusProxy( "localhost", 7512, "test", 
                                       "bree987",  1 );
  $Inca::GlobusProxy::CHECK_PERIOD = 10;
  $myproxy->{renew_at} = 1000000;  # really long time
  ok( $myproxy->start(), "myproxy->start() returned success" );
  ok( kill( 0, $myproxy->{pid}), "proxy process forked" );
  sleep(2);
  my $timeleft = `grid-proxy-info -timeleft`; chomp($timeleft);
  sleep(12);
  my $new_timeleft = `grid-proxy-info -timeleft`; chomp($new_timeleft);
  cmp_ok( $new_timeleft-$timeleft, "<=",  10, "Renewed proxy" );
  ok( $myproxy->stop(), "process stopped" );
  sleep( 2);
  ok( waitpid( $myproxy->{pid}, WNOHANG) != 0, "proxy process killed" );
  `myproxy-destroy -s localhost -l test`;

=end testing

=cut
#-----------------------------------------------------------------------------#
sub start {
  my ( $self ) = validate_pos( @_, { isa => "Inca::GlobusProxy" } );

  # test for myproxy
  my %execs;
  for my $exec ( qw(myproxy-get-delegation grid-proxy-info) ) {
    my $testexec = `which $exec`;
    chomp( $testexec);
    $execs{$exec} = $testexec;
    if ( ! defined $testexec || $testexec eq '' ) {
      if ( -x "$ENV{GLOBUS_LOCATION}/bin/$exec" ) {
        $execs{$exec} = "$ENV{GLOBUS_LOCATION}/bin/$exec";
      } else {
        $self->{logger}->error( "$exec not found in path" );
        return 0;
      }
    }
  }

  my $pid;
  if ( ($pid = fork()) ) {
    $self->{pid} = $pid;
    return 1;
  } else {
    while( 1 ) {
      my $timeleft = `$execs{"grid-proxy-info"} -timeleft 2>/dev/null`;
      chomp( $timeleft ) if defined( $timeleft );
      if( ! defined($timeleft) || $timeleft eq "" 
          || $timeleft < $self->{renew_at} ) {
        my $myproxy_cmd = "$execs{'myproxy-get-delegation'} " .
                          "-s $self->{hostname} " .
                          "-p $self->{port} -t $self->{lifetime} " .
                          "-S -l $self->{username}";
        if ( exists $ENV{X509_USER_PROXY} ) {
          $myproxy_cmd .= " -o $ENV{X509_USER_PROXY}";
        }
        $self->{logger}->info( "Renewing proxy: $myproxy_cmd" );
        open( CMD, "|$myproxy_cmd >/dev/null 2>&1" ) or 
          $self->{logger}->error("Unable to run '$myproxy_cmd': $! $?");
        print CMD $self->{password};
        close CMD or 
          $self->{logger}->error( "Unable to close '$myproxy_cmd': $! $?" );
      }
      sleep( $CHECK_PERIOD );
    }
  }
}

#-----------------------------------------------------------------------------#

=head2 stop();

Kills the process that was monitoring the renewal of the user proxy.

=over 2

B<Returns>:

True on successful process killing; false otherwise.

=back

=cut
#-----------------------------------------------------------------------------#
sub stop{
  my ( $self ) = validate_pos( @_, { isa => "Inca::GlobusProxy" } );

  if ( defined $self->{pid} ) {
    return kill( 9, $self->{pid} );
  } else {
    return 1;
  }
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# empty destructor (needed for test programs)
#-----------------------------------------------------------------------------#
sub DESTROY {
}

1; # need to return a true value from the file

__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

None so far.

=cut
