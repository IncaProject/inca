package Inca::AgentClient;
use base qw(Inca::Net::Client);
@ISA = ( "Inca::Net::Client" );

################################################################################

=head1 NAME

Inca::AgentClient - Handles communication with Inca Agent.

=head1 SYNOPSIS

=for example begin

  use Inca::AgentClient;
  #my $client = new Inca::AgentClient( "inca://localhost:8090" );

=for example end

=head1 DESCRIPTION

Handle communication between the Inca reporter manager and the Inca agent.

=cut
################################################################################

#=============================================================================#
# Usage
#=============================================================================#
use strict;
use warnings;
use Carp;
use vars qw/$VERSION $AUTOLOAD/;
use Params::Validate qw(:all);
use Inca::Constants qw(:all);
use Inca::Net::Protocol::Statement;
use Inca::GlobusProxy;

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $SELF_PARAM_REQ = { isa => "Inca::AgentClient" };

#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 new( $uri, %Options )

Class constructor which returns a new Inca::AgentClient object.  The
constructor must be called with a $uri to the server.  The constructor
may be called with any of the following attributes.

=over 2

B<Arguments>:

=over 7

=item uri

A string in the format of <scheme>://<path> where

=over 13

=item scheme

The type of URI being represented by the string (either I<file> or I<incas>)

=item path

The location of the URI being represented (e.g., localhost:7070)

=back

=item args

A list of follow on arguments for the stream type (e.g., cert, key, and
trusted certificate directory for the SSL connection).

=back

=back

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $rm = shift;
  my $self = $class->SUPER::new( @_ );

  bless ($self, $class);
  $self->{rm} = $rm;
  $self->{proxy} = undef;

  return $self;
}

#-----------------------------------------------------------------------------#

=head2 close( )

Close the client connection to the server and stops the proxy renewal process
if defined.

=cut
#-----------------------------------------------------------------------------#
sub close {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );
  
  if ( defined $self->{proxy} ) {
    $self->{proxy}->stop();
  } 
  $self->SUPER::close();
}

#-----------------------------------------------------------------------------#

=head2 register( $id )

Register with the designated reporter agent and service commands.

=over 2

B<Returns>:

Returns true if the connection with the agent was terminated without 
error; false otherwise.

=back

=begin testing

  use Inca::ReporterManager;
  use Inca::Net::Protocol::Statement;
  use Inca::IO;
  use Inca::ReporterManager::ReporterCache;
  use Inca::Net::Client;
  use Inca::AgentClient;
  untie *STDOUT;
  untie *STDERR;

  sub acceptRegister {
    my $server = shift;

    sleep 2;
    my $server_sock = $server->accept();
    my $agent = Inca::Net::Client->_connect( $server_sock );
    Inca::AgentClient::_serverStart( $agent );
    Inca::AgentClient::_serverPing( $agent );
    Inca::AgentClient::_serverRegister( $agent );
    return $agent;
  }

  sub createAgentClient {
    my $port = shift;
    my $depot_port = shift;

    my $credentials = { cert => "t/certs/client_ca1cert.pem",
                        key => "t/certs/client_ca1keynoenc.pem",
                        trusted => "t/certs/trusted" };
    my $rc = new Inca::ReporterManager::ReporterCache( "t",
      errorReporterPath => "bin/inca-null-reporter"
    );
    my $rm = new Inca::ReporterManager();
    $rm->setCheckPeriod( 1 );
    $rm->setReporterCache( $rc );
    $rm->setDepots( "incas://localhost:$depot_port" );
    $rm->setTmpDirectory( "/tmp" );
    $rm->setCredentials( $credentials );
    $rm->setRimPath( "sbin/reporter-instance-manager" );
    my $client = new Inca::AgentClient( 
      $rm, 
      "incas://localhost:$port",
      %{$rm->getCredentials()}
    );
    return $client;
  }

  my $port = 8519;
  my $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  my $pid;
  if ( $pid = fork() ) {
    my $client = createAgentClient( $port, 8888 );
    is( $client->register("id0"), 1, "registration with agent was successful" );
  } else {
    waitpid( $pid, 0 );
    my $client = acceptRegister( $server );
    $client->writeStatement(Inca::Net::Protocol::Statement->getEndStatement());
    $client->close();
    exit;
  }

  # try to send it an error
  if ( $pid = fork() ) {
    my $agent = acceptRegister( $server );
    $agent->writeStatement( "boogedyboo", "" );
    my ($cmd, $data) = $agent->readStatement();
    is( $cmd, "ERROR", "manager errors on unexpected cmd"),
    $agent->writeStatement(Inca::Net::Protocol::Statement->getEndStatement());
    $agent->close();
    waitpid( $pid, 0 );
  } else {
    my $client = createAgentClient( $port, 8888 );
    $client->register("id0");
    exit;
  }

  `echo bree987 | myproxy-init -s localhost -l test -S -c 2 -a`;
  cmp_ok( $?, "==", 0, "proxy stored in myproxy server" );
  `grid-proxy-destroy >/dev/null 2>&1`;
  `grid-proxy-info >/dev/null 2>&1`;
  cmp_ok( $?, "!=", 0, "grid-proxy-info returned error" );
  if ( $pid = fork() ) {
    my $client = createAgentClient( $port, 8888 );
    is( $client->register("id0"), 1, "registration with agent was successful" );
    sleep( 10 );
    `grid-proxy-info >/dev/null 2>&1`;
    cmp_ok( $?, "==", 0, "grid-proxy-info returned success" );
    $client->close();
    ok( waitpid($client->{proxy}->{pid}, WNOHANG) != 0, "proxy process killed");
  } else {
    waitpid( $pid, 0 );
    my $client = acceptRegister( $server );
    Inca::AgentClient::_serverProxyRenew( 
      $client, "localhost", 7512, "test", "bree987", 1 
    );
    $client->writeStatement(Inca::Net::Protocol::Statement->getEndStatement());
    $client->close();
    exit;
  }

  # send a subscription
  my $depot_port = $port + 1;
  my $depot = Inca::IO->_startServer( $depot_port, "ca1", "t/certs/trusted" );
  # try to send it a subscription
  if ( $pid = fork() ) {
    my $agent = acceptRegister( $server );

    local $/;
    open( FD, "t/mixed_subscription.xml" );
    my $subscription = <FD>;
    close FD;
    $agent->writeStatement( "SUBSCRIPTION", $subscription );

    my $i = 0;
    for ( $i = 0; $i < 2; $i++ ) {
      my $depot_sock = $depot->accept();
      my $depotServer = Inca::Net::Client->_connect( $depot_sock );
      ok( $depotServer->hasReadStatement( 'START', '.*' ), "read depot start");
      $depotServer->writeStatement( "OK", '1' );
      ok( $depotServer->hasReadStatement('REPORT', '.*'), "read depot report");
      my ($cmd, $content) = $depotServer->readStatement();
      $depotServer->close();
      like( $content, qr/^<\S*report .*>.*/m, "depot received report $i");
    }

    my $result = $agent->readStatement();
    ok( defined $result, "agent receives response from manager" );
    is ( $result->getCmd(), "OK", "subscription accepted from agent" );

    $agent->writeStatement(Inca::Net::Protocol::Statement->getEndStatement());
    $agent->close();
    waitpid( $pid, 0 );
  } else {
    my $client = createAgentClient( $port, $depot_port );
    $client->register("id0");
    exit;
  }
  close $depot;

  # try to send it a package
  if ( $pid = fork() ) {
    my $agent = acceptRegister( $server );

    local $/;
    open( FD, "t/cluster.java.sun.version" );
    my $reporter = <FD>;
    close FD;
    $agent->writeStatement( "PACKAGE", 
                            "file:///usr/local/bin/cluster.java.sun.version" );
    $agent->writeStatement( "FILENAME", "cluster.java.sun.version" );
    $agent->writeStatement( "VERSION", "1.5" );
    $agent->writeStatement( "INSTALLPATH", "tmp" );
    $agent->writeStatement( "PERMISSION", "755" );
    $agent->writeStatement( "CONTENT", $reporter );
    ok( $agent->hasReadStatement( "OK", ".*" ), "package sent" );

    $agent->writeStatement(Inca::Net::Protocol::Statement->getEndStatement());
    `rm -fr t/tmp`;
    $agent->close();
    waitpid( $pid, 0 );
  } else {
    my $client = createAgentClient( $port, $depot_port );
    $client->register("id0");
    exit;
  }
  close $server;

=end testing

=cut
#-----------------------------------------------------------------------------#
sub register {
  my ($self, $id) = validate_pos(@_, $SELF_PARAM_REQ, SCALAR );

  $self->{logger}->info( "Attempting to register" );
  # try pinging 
  if ( ! $self->_ping() ) {
    return 0;
  }

  # try to register
  if ( ! $self->_register($id) ) {
    return 0;
  }

  my $lost_contact = 0;
  while( 1 ) { # until we get the end statement
    my ($cmd, $data) = $self->readStatement();
    if ( ! defined $cmd || $cmd eq '' ) { # we probably lost contact
      $self->{logger}->error( "Lost contact with agent '$self->{uri}'" );
      $lost_contact = 1;
      $self->{rm}->stop();
      last;
    }
    $self->{logger}->debug( "Received command '$cmd' from " . $self->{uri} );
    if ( $cmd eq "END" ) {
      $self->{logger}->info( "Received shutdown from Reporter Agent" );
      $self->{rm}->stop();
      last;
    } elsif ( $cmd eq "ERROR" ) {
      $self->{logger}->error( "Received error from reporter agent '$data'" );
    } elsif ( $cmd eq "PROXYRENEW" ) {
      $self->_proxyRenew( $data );
    } elsif ( $cmd eq "SUBSCRIPTION" ) {
      $self->_acceptSubscription( $data );
    } elsif ( $cmd eq "PACKAGE" ) {
      $self->_acceptPackage( $data );
    } else {
      $self->writeAndLogError( 
        "Received unknown command '$cmd' from $self->{uri}"
      );
    }
  }

  $self->close();

  return ! $lost_contact;
}

#e----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# _acceptPackage( $uri )
#
# Read the package from the agent and  store it.  Protocol goes like this:
#
# PACKAGE <uri>
# FILE <name>
# VERSION <version>
# INSTALLPATH <installpath>
# (opt) PERMISSION 755
# CONTENT <package text>
#
# Arguments:
#
# uri     A string that contains the uri of the package.
#
# Returns: 
#
# Returns true if the package was succesfully stored and false otherwise.
#-----------------------------------------------------------------------------#
sub _acceptPackage {
  my ( $self, $uri ) = validate_pos( @_, $SELF_PARAM_REQ, $URI_PARAM_REQ );

  my ( $cmd1, $filename ) = $self->readStatement();
  if ( $cmd1 ne "FILENAME" ) {
    $self->writeAndLogError( "Expected FILENAME; received $cmd1" );
    return 0;
  }
  my ( $cmd2, $version ) = $self->readStatement();
  if ( $cmd2 ne "VERSION" ) {
    $self->writeAndLogError( "Expected VERSION; received $cmd2" );
    return 0;
  }
  my ( $cmd3, $installpath ) = $self->readStatement();
  if ( $cmd3 ne "INSTALLPATH" ) {
    $self->writeAndLogError( "Expected INSTALLPATH; received $cmd3" );
    return 0;
  }
  my $permission = undef;
  my ( $cmd4, $content ) = $self->readStatement();
  if ( $cmd4 eq "PERMISSION" ) {
    $permission = $content;
    ( $cmd4, $content ) = $self->readStatement();
  } 
  if ( $cmd4 ne "CONTENT" ) {
    $self->writeAndLogError( "Expected CONTENT; received $cmd4" );
    return 0;
  }
  my $success = $self->{rm}->storePackage( 
    $uri, $filename, $version, $installpath, $permission, $content 
  );
  if ( $success ) {
    $self->writeStatement(Inca::Net::Protocol::Statement->getOkStatement());
  } else {
    $self->writeAndLogError( "Unable to cache package '$uri'" );
  }
}

#-----------------------------------------------------------------------------#
# _acceptSubscription( $subscriptionXml, $client )
#
# Read the subscription in $subscribe_stmt and reply to it.
#
# Arguments:
#
# Client  An object of Inca::Net::Client connected to the agent
#
# id      A resource identifier that the Reporter Agent can use to identify
#         the reporter manager.
#
# Returns: 
#
# Returns true if the register succeeds and false if it does not.
#
#-----------------------------------------------------------------------------#
sub _acceptSubscription {
  my ( $self, $subscriptionXml ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  my $subscription = new Inca::Subscription();
  if ( ! $subscription->read( $subscriptionXml) ) {
    $self->writeAndLogError(
      "Error in subscription detected; see manager log for more details"
    );
    return;
  }
  my $errored_reporter_groups = $self->{rm}->dispatch( $subscription );
  my $num_groups = scalar( $subscription->getReporterGroups() );
  if ( scalar(@{$errored_reporter_groups}) > 0 ) {
    $self->writeAndLogError(
      scalar(@{$errored_reporter_groups}) .  " out of " .
      "$num_groups reporter groups failed to be scheduled: " .
      join( " ", @${$errored_reporter_groups}) 
    );
  } else {
    $self->{logger}->info( "$num_groups reporter groups scheduled" );
    $self->writeStatement(Inca::Net::Protocol::Statement->getOkStatement());
  }
  if ( ! $self->{rm}->start() ) {
    $self->{logger}->error( "Unable to start schedulers" );
  }
}

#-----------------------------------------------------------------------------#
# _ping( )
#
# Send the PING command to the connected Agent.  If succeeds, return true.
#
# Returns:
#
# Returns true if ping command succeeds with Agent; false otherwise.

=begin testing

  use Inca::AgentClient;
  use Test::Exception;
  use Inca::IO;
  use Inca::Net::Client;

  my $port = 8519;
  my $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  my $pid;
  if ( $pid = fork() ) {
    my $client = new Inca::AgentClient( 
      undef, 
      "incas://localhost:$port", 
      cert => "t/certs/client_ca1cert.pem",
      key => "t/certs/client_ca1keynoenc.pem",
      trusted => "t/certs/trusted" 
    );
    ok( $client->_ping(), "client pings" );
    $client->close();
  } else { 
    sleep 2;
    my $server_sock = $server->accept();
    my $agent = Inca::Net::Client->_connect( $server_sock );
    Inca::AgentClient::_serverStart( $agent );
    Inca::AgentClient::_serverPing( $agent );
    $agent->close();
    exit;
  }                     
  $server->close();

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _ping {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  # try pinging 
  if ( !  $self->writeAndReadStatement( "PING", "ME", "OK", "ME" ) ) {
    $self->close();
    return 0;
  }
  $self->{logger}->info( "Succesfully pinged agent" );
  return 1;
}

#-----------------------------------------------------------------------------#
# _proxyRenew( $server )
#
# Receive proxy renewal inforamtion from agent.  Currently, we accept
# MyProxy credential information and use that to renew the user's proxy.
#
# Returns:
#
# Returns true if command succeeds with Agent; false otherwise.

=begin testing

  use Inca::AgentClient;
  use Test::Exception;
  use Inca::IO;
  use Inca::Net::Client;

  # store a proxy in myproxy server
  `echo bree987 | myproxy-init -s localhost -l test -S -c 2`;
  cmp_ok( $?, "==", 0, "proxy stored in myproxy server" );
  `grid-proxy-destroy >/dev/null 2>&1`;
  `grid-proxy-info >/dev/null 2>&1`;
  cmp_ok( $?, "!=", 0, "grid-proxy-info returned error" );

  my $port = 8519;
  my $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  my $pid;
  if ( $pid = fork() ) {
    my $client = new Inca::AgentClient( 
      undef, 
      "incas://localhost:$port", 
      cert => "t/certs/client_ca1cert.pem",
      key => "t/certs/client_ca1keynoenc.pem",
      trusted => "t/certs/trusted" 
    );
    ok( $client->hasReadStatement("PROXYRENEW", "localhost"),
        "received PROXYRENEW" );
    ok( $client->_proxyRenew( "localhost" ), "client renewed proxy" );
    ok( kill( 0, $client->{proxy}->{pid}), "proxy process forked" );
    sleep( 10 );
    `grid-proxy-info >/dev/null 2>&1`;
    cmp_ok( $?, "==", 0, "grid-proxy-info returned success" );
    $client->close();
    ok( waitpid($client->{proxy}->{pid}, WNOHANG) != 0, "proxy process killed");
  } else { 
    sleep 2;
    my $server_sock = $server->accept();
    my $agent = Inca::Net::Client->_connect( $server_sock );
    Inca::AgentClient::_serverStart( $agent );
    Inca::AgentClient::_serverProxyRenew( 
      $agent, "localhost", 7512, "test", "bree987", 1 
    );
    $agent->close();
    exit;
  }                     
  $server->close();
  `myproxy-destroy -s localhost -l test`;

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _proxyRenew {
  my ( $self, $server ) = validate_pos( @_, $SELF_PARAM_REQ, $HOST_PARAM_REQ );

  my ($port, $username, $password, $lifetime);
  my ($cmd, $data) = $self->readStatement();
  if ( $cmd eq "PORT" ) {
    $port = $data; 
  } else {
    $self->writeAndLogError( "Expected PORT; received '$cmd'" );
    return 0;
  }
  ($cmd, $data) = $self->readStatement();
  if ( $cmd eq "USERNAME" ) {
    $username = $data; 
  } else {
    $self->writeAndLogError( "Expected USERNAME; received '$cmd'" );
    return 0;
  }
  ($cmd, $data) = $self->readStatement();
  if ( $cmd eq "PASSWORD" ) {
    $password = $data; 
  } else {
    $self->writeAndLogError( "Expected PASSWORD; received '$cmd'" );
    return 0;
  }
  ($cmd, $data) = $self->readStatement();
  if ( $cmd eq "LIFETIME" ) {
    $lifetime = $data; 
  } else {
    $self->writeAndLogError( "Expected LIFETIME; received '$cmd'" );
    return 0;
  }

  $self->{logger}->info( "Received proxy renewal information" );
  $self->{proxy} = new Inca::GlobusProxy( 
    $server, $port, $username, $password, $lifetime 
  );
  if ( ! $self->{proxy}->start() ) {
    $self->writeAndLogError( 
      "Received proxy renewal info but unable to start proxy renewal process" 
    );
    return 0;
  } else {
    $self->writeStatement( Inca::Net::Protocol::Statement->getOkStatement() );
    $self->{logger}->info( "Proxy renewal process started" );
    return 1;
  }
}

#-----------------------------------------------------------------------------#
# _register( $id )
#
# Send the REGISTER command to the connected Agent.  If succeeds, return true.
#
# Returns:
#
# Returns true if register command succeeds with Agent; false otherwise.

=begin testing

  use Inca::AgentClient;
  use Test::Exception;
  use Inca::IO;
  use Inca::Net::Client;

  my $port = 8519;
  my $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  my $pid;
  if ( $pid = fork() ) {
    my $client = new Inca::AgentClient( 
      undef, 
      "incas://localhost:$port", 
      cert => "t/certs/client_ca1cert.pem",
      key => "t/certs/client_ca1keynoenc.pem",
      trusted => "t/certs/trusted" 
    );
    ok( $client->_register( "id0" ), "client registered" );
    $client->close();
  } else { 
    sleep 2;
    my $server_sock = $server->accept();
    my $agent = Inca::Net::Client->_connect( $server_sock );
    Inca::AgentClient::_serverStart( $agent );
    Inca::AgentClient::_serverRegister( $agent );
    $agent->close();
    exit;
  }                     
  $server->close();

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _register {
  my ($self, $id) = validate_pos(@_, $SELF_PARAM_REQ, SCALAR );

  # try to register
  if ( ! $self->writeAndReadStatement( "REGISTER", $id, "OK", "100" ) ) {
    $self->close();
    return 0;
  }
  $self->{logger}->info( "Successfully registered $id with Agent" );
  return 1;
}

#-----------------------------------------------------------------------------#
# _serverPing( $server )
#
# For testing only.  Accepts the client ping and acks it.
#
# Arguments:
#
# server     An object of type Inca::Net::Client for which commands can be
#            read and written
#-----------------------------------------------------------------------------#
sub _serverPing {
  my ( $server ) = validate_pos( @_, $CLIENT_PARAM_REQ );

  $server->hasReadStatement( "PING", "ME" );
  $server->writeStatement( "OK", "ME" );
  return; 
}

#-----------------------------------------------------------------------------#
# _serverProxyRenew( $server, $myproxy_server, $port, $username, $password, 
#                    $lifetime )
#
# For testing only.  Accepts the client ping and acks it.
#
# Arguments:
#
# server         An object of type Inca::Net::Client for which commands can be
#                read and written
#
# myproxy_server A string containing the name of the myproxy server to
#                renew the user credentials
#
# port           An integer containing the port of the myproxy server
#
# username      A string containing the username the myproxy credential is
#               stored under
#
# password      A string containing the password that can be used to 
#               authenticate and retrieve the myproxy credential
#
# lifetime      An integer containing the lifetime of the credential that
#               we should request from the myproxy server
#-----------------------------------------------------------------------------#
sub _serverProxyRenew {
  my ( $server, $myproxy_server, $port, $username, $password, $lifetime ) = 
    validate_pos( @_, $CLIENT_PARAM_REQ, $HOST_PARAM_REQ, $PORT_PARAM_REQ, 
                  $ALPHANUMERIC_PARAM_REQ, SCALAR, $POSITIVE_INTEGER_PARAM_REQ);

  $server->writeStatement( "PROXYRENEW", $myproxy_server );
  $server->writeStatement( "PORT", $port );
  $server->writeStatement( "USERNAME", $username );
  $server->writeStatement( "PASSWORD", $password );
  $server->writeStatement( "LIFETIME", $lifetime );
  $server->readStatement(); # read ok
  return; 
}

#-----------------------------------------------------------------------------#
# _serverRegister( $server )
#
# For testing only.  Accepts the client register and acks it.
#
# Arguments:
#
# server     An object of type Inca::Net::Client for which commands can be
#            read and written
#-----------------------------------------------------------------------------#
sub _serverRegister {
  my ( $server ) = validate_pos( @_, $CLIENT_PARAM_REQ );

  my ($cmd, $data) = $server->readStatement();
  my $reg_response;
  if ( $cmd eq "REGISTER" ) {
    $reg_response = Inca::Net::Protocol::Statement->getOkStatement();
  } else {
    my $error =  "Server received '$cmd' instead of REGISTER";
    $server->{logger}->error( $error );
    $reg_response = Inca::Net::Protocol::Statement->getErrorStatement( $error );
  }
  $server->writeStatement( $reg_response );
  return; 
}

#-----------------------------------------------------------------------------#
# _serverStart( $server )
#
# For testing only.  Accepts the client START and acks it.
#
# Arguments:
#
# server     An object of type Inca::Net::Client for which commands can be
#            read and written
#-----------------------------------------------------------------------------#
sub _serverStart {
  my ( $server ) = validate_pos( @_, $CLIENT_PARAM_REQ );

  $server->hasReadStatement( "START", "1" );
  $server->writeStatement( "OK", "1" );
  return; 
}

#-----------------------------------------------------------------------------#
# empty destructor (needed for test programs)
#-----------------------------------------------------------------------------#
sub DESTROY {
}

1;  # need to return a true value from the file


__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

Describe any known problems.

=cut
