package Inca::ReporterManager::Scheduler::Sequential;
use base qw(Inca::ReporterManager::Scheduler);
@ISA = ( "Inca::ReporterManager::Scheduler" );

################################################################################

=head1 NAME

Inca::ReporterManager::Scheduler::Sequential - Executes reporter in sequence

=head1 SYNOPSIS

=for example begin

  use Inca::ReporterManager::Scheduler::Sequential;
  use Inca::Subscription::Reporter;
  use Inca::ReporterManager::ReporterCache;
  use Cwd;
  use File::Spec;

  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$");

  my $sched = new Inca::ReporterManager::Scheduler::Sequential( 
                    1,
                    [ $file_depot ],
                    new Inca::ReporterManager::ReporterCache( 't'),
                    undef, 
                    undef );
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/echo_report" );
  $sched->submit( 'add', undef, $reporter );

=for example end

A scheduler for the reporter manager which executes reporters sequentially.
It does not take any additional configuration parameters.

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#

# pragmas
use strict;
use warnings;
use vars qw($VERSION $AUTOLOAD);

# Inca
use Inca::Constants qw(:params);
use Inca::ReporterManager::ReporterInstanceManager;
use Inca::Subscription::Reporter;
use Inca::Validate qw(:all);

# Perl standard
use Carp;
use Data::Dumper;
use POSIX;

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $SELF_PARAM_REQ = { isa => __PACKAGE__ };
my $ACTION_PARAM_REQ = { regex => qr/add/ };

#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 submit( $action, $scheduler_args, @reporters )

Accepts an action (currently only 'add') and any number of reporters.  These 
reporters will then be executed in a sequential order.

=over 2

B<Arguments>:

=over 13

=item action

A string containing an action (e.g., add, delete) pertaining to the group
of reporters.

=item scheduler_args

A reference to a hash array of arguments for the scheduler

=item reporters

An array of Inca::Subscription::Reporter objects.

=back

B<Returns>:

Returns true if at least one reporter is executed; otherwise returns false.

=back

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Inca::ReporterManager::Scheduler::Sequential;
  use Inca::Subscription::Reporter;
  use Inca::ReporterManager::ReporterCache;
  use Cwd;
  use File::Spec;

  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$");

  # test quick reporter
  my $sched = new Inca::ReporterManager::Scheduler::Sequential( 
    undef,
    1,
    undef,
    [ $file_depot ], 
    new Inca::ReporterManager::ReporterCache( 't',
      errorReporterPath => "bin/inca-null-reporter" 
    ),
    "sbin/reporter-instance-manager",
    "/tmp"
  );
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/echo_report" );
  my $status = $sched->submit( 'add', undef, $reporter );
  is( $status, 1, 'returned positive status' );
  sleep( 10 );
  ok( -f "./depot.tmp.$$", "submit to file - depot file created" );
  local $/;
  open( FD, "<./depot.tmp.$$" );
  my $content = <FD>;
  close FD;
  unlink "./depot.tmp.$$";
  like( $content, qr/^<rep:report .*/m, 
        "submit to file - looks like reporter was printed");

  # test benchmark reporter
  $sched = new Inca::ReporterManager::Scheduler::Sequential( 
    undef,
    1,
    undef,
    [ $file_depot ],
    new Inca::ReporterManager::ReporterCache( 't',
      errorReporterPath => "bin/inca-null-reporter" 
    ),
    "sbin/reporter-instance-manager",
    "/tmp",
  );
  $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/stream_report" );
  $reporter->setTimeout( [ { name => 'CPUTime', value => 20 } ] );
  $status = $sched->submit( 'add', undef, $reporter );
  is( $status, 1, 'returned positive status' );
  sleep( 15 );
  ok( -f "./depot.tmp.$$", "submit to ssl socket - depot file created" );
  local $/;
  open( FD, "<./depot.tmp.$$" );
  $content = <FD>;
  close FD;
  unlink "./depot.tmp.$$";
  my ($memory) = $content =~ /^memory_mb=(.*)/m;
  cmp_ok( $memory, ">=", 45, "submit to ssl socket - memory is reasonable" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub submit {
  my ( $self, $action, $args, @reporters ) = 
    validate_pos( @_, $SELF_PARAM_REQ, 
                      $ACTION_PARAM_REQ, 
                      HASHREF | UNDEF,
                      ($REPORTER_PARAM_REQ) x (@_ - 3) );
  if ( ref($args) eq "Inca::Subscription::Reporter" ) {
    $self->{logger}->error( "Expected HASHREF or UNDEF in parameter #2 (not Inca::Subscription::Reporter) for submit" );
    return 0;
  }

  if ( $action eq $Inca::ReporterManager::Scheduler::DELETE ) {
    $self->{logger}->error( ref($self) . " does not service delete requests" );
    return 0;
  }

  my $pid;
  if ( ($pid = fork()) ) {
    return scalar( @reporters );
  } else {
    for my $reporter ( @reporters ) {
      my $rim = new Inca::ReporterManager::ReporterInstanceManager(
                      reporter => $reporter,
                      checkPeriod => $self->{check_period},
                      depotURIs => $self->{depot_uris},
                      reporterCache => $self->{reporter_cache},
                      tmpDir => $self->{tmpdir}
                      );
      if ( exists $self->{credentials} and defined $self->{credentials} ) {
        $rim->setCredentials( $self->{credentials} );
      }
      if ( ! $rim->runReporter() ) {
        $self->{logger}->error( "Problem running " . $reporter->getUri() );
      }
    }
    exit;
  }
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# empty destructor (needed for test programs)
#-----------------------------------------------------------------------------#
sub DESTROY {
}

1; # need to return a true value from the file

__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

No known problems.

=head1 SEE ALSO

L<Inca::ReporterManager::Scheduler>

=cut
