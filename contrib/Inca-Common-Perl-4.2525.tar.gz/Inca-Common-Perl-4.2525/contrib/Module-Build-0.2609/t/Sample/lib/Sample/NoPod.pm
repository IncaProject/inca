package Sample::NoPod;

# this is a module without any pod (they do happen, y'know :)
# test for manifypods

1;
