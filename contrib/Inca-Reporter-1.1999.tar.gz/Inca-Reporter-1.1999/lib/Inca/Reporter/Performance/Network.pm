package Inca::Reporter::Performance::Network;
use Inca::Reporter::Performance;
@ISA = ('Inca::Reporter::Performance');

################################################################################

=head1 NAME

Inca::Reporter::Performance::Network - Convenience module for performance-related network reporters

=head1 SYNOPSIS

  use Inca::Reporter::Performance::Network;
  my $performance = new Inca::Reporter::Performance::Network( "some_id" );
  ...
  my $benchmark = new Inca::Reporter::Performance::Benchmark("sample");
  $benchmark->addParameter( "num_cpus", 16 );
  $benchmark->addStatistic( "bandwidth", 10, units => "Mb/s" );
  $performance->addBenchmark( $benchmark );
  $reporter->print();

=head1 DESCRIPTION

Module for writing performance related network reporters.  This is a subclass
of Inca::Reporter::Performance which adds on convenience methods for
running pairwise measurements.

=cut 
################################################################################

use strict;
use warnings;
use Carp;
use Inca::Reporter::Performance::Benchmark;
use POSIX "setsid";
use Cwd;

use constant WAIT_TIME => 5;

#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $self = $class->SUPER::new( @_ );
  $self->{endpoint_pid} = undef;
  $self->{endpoint_out} = '';
  $self->{measurement_success} = 0;
  bless ($self, $class);
  return $self;
}

#-----------------------------------------------------------------------------#

=head2 startEndpoint
  (exec => $executable, arguments => undef, success_mark => $mark, 
   remote => undef, outputfile => undef)

=cut
#-----------------------------------------------------------------------------#
sub startEndpoint {
  my ($self, %options) = @_;
  my $arguments = $options{arguments};
  my $executable = $options{exec};
  my $mark = $options{success_mark};
  my $remote = $options{remote};
  my $output = $options{outputfile};

  # start process
  my $success = 0;
  $self->{endpoint_pid} = open(CHILD_STDOUT, '-|');
  if(!defined($self->{endpoint_pid})) {
    $self->setResult(0, "problem starting endpoint '$executable': $!");
    $self->print();
    exit;
  }
  if($self->{endpoint_pid} == 0) {
    setsid();
    my $command_line = $self->_getCommandLine($executable, $arguments, $remote);
    exec "$command_line 2>&1";
  }
  # check to see if it is up (if mark is defined)
  if(defined($mark)) {
    my $line;
    while($line = <CHILD_STDOUT>) {
      $self->{endpoint_out} .= $line;
      return if $self->{endpoint_out} =~ /$mark/;
    }
    # success mark not found
    my $error = "problem starting endpoint: output '" . $self->{endpoint_out} . 
                "' doesn't contain success mark '$mark'";
    $self->setResult(0, $error);
    $self->print();
    exit;
  }
}

#-----------------------------------------------------------------------------#

=head2 stopEndpoint

If the endpoint process persists pass the measurement, use this function
to kill the endpoint process by sending the process a sig interrupt.

=cut
#-----------------------------------------------------------------------------#
sub stopEndpoint {
  my $self = shift;
  my $gid = getpgrp($self->{endpoint_pid});
  kill 2, -$gid;
}

#-----------------------------------------------------------------------------#

=head2 startMeasurement(exec => $executable, mark => $mark, remote => undef)

B<Inputs>:

=over 13

=item executable

The command to execute to run the measurement to the endpoint.

=back

B<Options>:

=over 13

=item mark

If the executable doesn't return an error exit code upon error use mark
to look for a string printed to stdout that indicates that it was started
up correctly.  If that string is not found, then we assume that the executable
was not started correctly.

=item remote

If true, then use Globus to do remote execution

=item outputfile

If specified and remote is true, the contents of the remote file will be 
copied back to the local directory.  Use this option if the executable prints
results to a file rather than to stdout. Can be a string or array of strings. 

=back

=cut
#-----------------------------------------------------------------------------#
sub startMeasurement {
  my ($self, %options) = @_;
  my $arguments = $options{arguments};
  my $executable = $options{exec};
  my $mark = $options{success_mark};
  my $outputfile = $options{outputfile};
  my $remote = $options{remote};

  if(defined($self->{endpoint_pid}) && $self->{endpoint_pid} <= 0) {
    $self->setResult(0, 'No endpoint started yet');
    $self->print();
    exit;
  }

  my $command_line = $self->_getCommandLine
    ($executable, $arguments, $remote, $outputfile);
  my $output = `$command_line 2>&1`;
  if($? != 0) {
    $self->setResult
      (0, "problem starting measurement '$command_line': $output $!");
    $self->print();
    exit;
  }
  sleep(WAIT_TIME);
  
  # check output
  if(defined($mark) && $output !~ /$mark/) {
    my $error = "problem with running measurement: output '$output" .
                "' doesn't contain success mark '$mark'";
    $self->setResult(0, $error);
    $self->print();
    exit;
  }
  $self->{measurement_success} = 1;
  return $output;
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# _getCommandLine($executable, $arguments, $remote, $outputfile)
#-----------------------------------------------------------------------------#
sub _getCommandLine {
  my ($self, $executable, $arguments, $remote, $outputfile) = @_;
  my $result;
  if(!defined($remote)) {
    $result = $executable;
    $result .= " $arguments" if defined($arguments);
  } else {
    $result = "globusrun -s -o -r $remote '" .
              "&(executable=\$(GLOBUSRUN_GASS_URL)/$executable)";
    $result .= "(arguments=$arguments)" if defined($arguments);
    if(defined($outputfile)) {
      my $cwd = getcwd();
      my @files = ref($outputfile) eq 'ARRAY' ? @{$outputfile} : ($outputfile);
      $result .= '(file_stage_out=';
      foreach my $file(@files) {
        $result .= "($file \$(GLOBUSRUN_GASS_URL)/$cwd/$file)";
      }
      $result .= ')(file_clean_up=' . join(' ', @files) . ')';
    }
    $result .= "'";
  }
  return $result;
}

#-----------------------------------------------------------------------------#
# DESTROY
#
# Cleans up the endpoint process by sending a INT signal to the process group
#-----------------------------------------------------------------------------#
sub DESTROY {
  my $self = shift;
  if(!$self->{measurement_success} && defined($self->{endpoint_pid}) &&
     $self->{endpoint_pid} > 0) {
    my $gid = getpgrp($self->{endpoint_pid});
    kill 2, -$gid;
  }
  $self->SUPER::DESTROY;
}

__END__

=head1 EXAMPLE

  my $reporter = new Inca::Reporter::Performance::Network( "file_transfer_time");
  $reporter->setUrl( "http://totally.madeup.org" );
  $reporter->setVersion( '$Revision: 1.7 $' );
  $reporter->addArgument( "file" );
  $reporter->setDescription( "Measures the time it takes to copy a file from one directory to another");
  $reporter->processArgs( @ARGV );
  my $file = $reporter->getValue( "file" );
  my $time_before = time();
  `cp $file /gpfs`;
  my $time_after = time();
  my $elapsed_time = $time_after - $time_before;
  my $benchmark = new Inca::Reporter::Performance::Network::Benchmark( "file_transfer_time");
  $benchmark->addStatistic( "elapsed_time", $elapsed_time, units => "secs" );
  $reporter->addBenchmark( $benchmark );
  $reporter->print();

=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 SEE ALSO

L<Inca::Reporter::Performance::Network::Benchmark>, L<Inca::Reporter::Logging>

=cut
