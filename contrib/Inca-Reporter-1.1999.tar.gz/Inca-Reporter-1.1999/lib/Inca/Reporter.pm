package Inca::Reporter;

################################################################################

=head1 NAME

Inca::Reporter - Module for creating Inca reporters

=head1 SYNOPSIS

  use Inca::Reporter;
  my $reporter = new Inca::Reporter(
    version => 0.1,
    description => 'A really helpful reporter description',
    url => 'http://url.to.more.reporter.info'
  );

=head1 DESCRIPTION

This module creates Inca reporters according to the reporter specification:

http://repo.teragrid.org/head/inca/testing/docs/guides/userguide_html/index.html

It provides an API for setting reporter attributes (e.g., url, version)
and two main functions which provide the reporter functionality: processArgv
and print.  processArgv parses the command-line arguments and handles help,
verbose, and output arguments.  print is used to print the final report based
on the output arguments.

The constructor may be called with any number of attributes, and attributes can
be set and queried later with their corresponding get/set functions (described
below).  For example,

  my $reporter = new Inca::Reporter();
  $reporter->setUrl('http://url.to.more.reporter.info');
  $reporter->setVersion(0.1);

=cut
################################################################################

use strict;
use warnings;
use Carp;
use File::Basename 'basename';
use Net::Domain 'hostfqdn';
use Sys::Hostname;

#=============================================================================#

=head1 CLASS METHODS

=cut

#=============================================================================#

#-----------------------------------------------------------------------------#

=head2 new

Class constructor which returns a new Inca::Reporter object.  The constructor
may be called with any of the following parameters.

=over 13

=item body

the body of the report.  Should be formatted as follows (taken directly from
spec)

=over 3

=item *

There are two kinds of body elements: branch and leaf. A leaf element has the
form <name>value</name> where name is a valid XML tag, and value is any string.
A branch element may have other branch elements defining sub trees or leaf
elements.

=item *

The first child of a branch element must be a leaf which specifies an ID for
the branch. The leaf must be named ID. Its value may be a string that conforms
to the rules for XML tag names. I.e. no spaces or special characters.  This
restriction makes it possible to refer to any value using a simple DNS-style
traversal of the tree, such as "sdsc.services.GridFTP.bandwidth".  Any number
of other leaves or branches may included after the first ID leaf.

=item *

All child branches under a parent must have unique IDs. It is common to give a
branch element the same ID as its tag when it should be a singleton, that is if
there should only be one of them.

=item *

Tags shall not use XML attributes such as <foo my_attr="bar">

=back

=item completed

boolean (0 or 1) indicating whether or not the reporter has completed
generating the information it is intended to produce

=item description

a verbose description of the reporter

=item fail_message

a message describing why the reporter failed to complete its task

=item url

URL to get more information about the reporter

=item version

the version of the reporter; defaults to 0

=back

=cut

#-----------------------------------------------------------------------------#
sub new {

  my ($this, %attrs) = @_;
  my $class = ref($this) || $this;
  my $self = {
    args => {},
    argv => [],
    body => undef,
    completed => 0,
    description => undef,
    dependencies => [],
    fail_message => undef,
    log_entries => [],
    log_pat => '^$',
    temp_paths => [],
    url => undef,
    version => '0'
  };
  bless($self, $class);

  $self->addArg('help', 'display usage information (no|yes)', 'no', 'no|yes');
  $self->addArg
    ('log', 'log message types included in report', 0,
     '[01234]|debug|error|info|system|warn');
  $self->addArg('verbose', 'verbosity level (0|1|2)', '0', '[012]');
  $self->addArg('version', 'show reporter version (no|yes)', 'no', 'no|yes');
  $self->addDependency( __PACKAGE__ );

  # check to see if user specified any attributes in arguments
  foreach my $attr(keys %attrs) {
    carp "'$attr' is an invalid attribute" if !exists($self->{$attr});
    $self->{$attr} = $attrs{$attr};
  }

  return $self;

}

#-----------------------------------------------------------------------------#

=head2 addArg($name, $description, $default, $pattern)

Adds an command line argument (invocation syntax -name=value) to the reporter.
If supplied, the optional $description will be printed as part of the help
information.  If supplied, $default indicates that the argument is optional;
argValue will return $default if the command line does not include a value for
the argument.  The optional $pattern specifies a pattern for recognizing valid
argument values; the default is '.+'.

=cut

#-----------------------------------------------------------------------------#
sub addArg {
  my ($self, $name, $description, $default, $pattern) = @_;
  carp "Missing name argument" and return if !defined($name);
  $self->{args}->{$name} = {
    description => $description,
    default => $default,
    pat => defined($pattern) ? $pattern : '.+'
  };
}

#-----------------------------------------------------------------------------#

=head2 addDependency($dependency [, ...])

Add one or more dependencies to the list of modules on which this reporter
depends.  Dependencies are reported as part of reporter help output to assist
reporter repository tools in their retrievals.  NOTE: dependencies on the
standard Inca reporter library modules are added by the modules themselves,
so a reporter only needs to invoke this method to report external dependencies.

=cut

#-----------------------------------------------------------------------------#
sub addDependency {
  my ($self, @dependencies) = @_;
  foreach my $dependency(@dependencies) {
    push(@{$self->{dependencies}}, $dependency);
  }
}

#-----------------------------------------------------------------------------#

=head2 argValue($name, $position)

Called after processArgv, returns the value of the position'th instance
(starting with 1) of the $name command-line argument.  Returns the value of the
last instance if position is not supplied.  Causes a fatal error if $name is
not a recognized argument.  Returns default value for $name if it has one and
$name is include fewer than $position times on the command line.

=cut

#-----------------------------------------------------------------------------#
sub argValue {
  my ($self, $name, $position) = @_;
  carp "Missing name argument" and return undef if !defined($name);
  carp "'$name' is not a valid command line argument name" and return undef
    if !exists($self->{args}->{$name});
  my @argv = @{$self->{argv}};
  if(!defined($position)) {
    @argv = reverse(@argv);
    $position = 1;
  }
  foreach my $arg(@argv) {
    return $1 if $arg =~ /^$name=(.*)$/ && --$position < 1;
  }
  return $self->{args}->{$name}->{default};
}

#-----------------------------------------------------------------------------#

=head2 argValues($name)

Called after processArgv, returns an array of all values specified for the
$name command-line argument.  Causes a fatal error if $name is not a recognized
argument.  Returns a single-element array containing the default value for
$name if it has one and $name does not appear on the command line.

=cut

#-----------------------------------------------------------------------------#
sub argValues {
  my ($self, $name) = @_;
  carp "Missing name argument" and return undef if !defined($name);
  carp "'$name' is not a valid command line argument name" and return undef
    if !exists($self->{args}->{$name});
  my $default = $self->{args}->{$name}->{default};
  my @result;
  foreach my $arg(@{$self->{argv}}) {
    push(@result, $1) if $arg =~ /^$name=(.*)$/;
  }
  push(@result, $default) if $#result < 0 && defined($default);
  return @result;
}

#-----------------------------------------------------------------------------#

=head2 compiledProgramOutput(%params)

A convenience; compiles and runs a program and returns its output (stdout and
stderr) after removing the source and exec files.  Recognized params:

=over 13

=item code

the code to compile; required

=item compiler

the compiler to invoke; defaults to cc

=item language

source file language--one of 'c', 'c++', 'fortran', or 'java'; defaults to 'c'.

=item out_switch

the switch to use to specify the compiler output file; defaults to '-o '

=item switches

additional switches to pass to the compiler; defaults to ''

=item timeout

max seconds compilation/execution may take; returns undef on time-out

=back

=cut

#-----------------------------------------------------------------------------#
sub compiledProgramOutput {
  my ($self, %params) = @_;
  my $code = $params{code};
  my $compiler = defined($params{compiler}) ? $params{compiler} : 'cc';
  my $lang = defined($params{language}) ? $params{language} : 'c';
  my $extension = $lang eq 'c++' ? 'C' : $lang eq 'fortran' ? 'f' :
                  $lang eq 'java' ? 'java' : 'c';
  my $prefix = "src$$";
  my $timeout = $params{timeout};
  if($lang eq 'java') {
    $code =~ s/class\s+\w+/class $prefix/;
  }
  my $path = "$prefix.$extension";
  return if !open(OUTPUT, ">$path");
  print OUTPUT $code;
  close OUTPUT;
  my $out = defined($params{out_switch}) ? $params{out_switch} : '-o ';
  my $switches = defined($params{switches}) ? $params{switches} : '';
  my $cmd =
    $lang eq 'java' ? "($compiler $path $switches && java $prefix)" :
                      "($compiler $path $out$prefix $switches && ./$prefix)";
  # Allow for dynamic libraries in any link directories.
  my $oldLd = $ENV{LD_LIBRARY_PATH};
  if($switches =~ /-L\s*\S+/) {
    my @paths = $switches =~ /-L\s*(\S+)/g;
    $ENV{LD_LIBRARY_PATH} = join(':', @paths);
    $ENV{LD_LIBRARY_PATH} .= ":$oldLd" if defined($oldLd);
  }
  my $output = $self->loggedCommand($cmd, $timeout);
  delete $ENV{LD_LIBRARY_PATH};
  $ENV{LD_LIBRARY_PATH} = $oldLd if defined($oldLd);
  $self->loggedCommand("/bin/rm -f $prefix*");
  return $output;
}

#-----------------------------------------------------------------------------#

=head2 failPrintAndExit($msg)

A convenience; calls setResult(0, $msg) and print() before exiting the reporter.

=cut

#-----------------------------------------------------------------------------#
sub failPrintAndExit {
  my ($self, $msg) = @_;
  $self->setResult(0, $msg);
  $self->print();
  exit;
}

#-----------------------------------------------------------------------------#

=head2 getBody

Returns the body of the report.

=cut

#-----------------------------------------------------------------------------#
sub getBody {
  my $self = shift;
  return $self->{body};
}

#-----------------------------------------------------------------------------#

=head2 getCompleted

Returns the completion indicator of the reporter.

=cut

#-----------------------------------------------------------------------------#
sub getCompleted {
  my $self = shift;
  return $self->{completed};
}

#-----------------------------------------------------------------------------#

=head2 getDescription

Returns the description of the reporter.

=cut

#-----------------------------------------------------------------------------#
sub getDescription {
  my $self = shift;
  return $self->{description};
}

#-----------------------------------------------------------------------------#

=head2 getFailMessage

Returns the failure message of the reporter.

=cut

#-----------------------------------------------------------------------------#
sub getFailMessage {
  my $self = shift;
  return $self->{fail_message};
}

#-----------------------------------------------------------------------------#

=head2 getUrl

Returns the url which describes the reporter in more detail.

=cut

#-----------------------------------------------------------------------------#
sub getUrl {
  my $self = shift;
  return $self->{url};
}

#-----------------------------------------------------------------------------#

=head2 getVersion

Returns the version of the reporter.

=cut

#-----------------------------------------------------------------------------#
sub getVersion {
  my $self = shift;
  return $self->{version};
}

#-----------------------------------------------------------------------------#

=head2 log($type, @msgs)

Appends each element of @msgs to the list of $type log messages stored in the
reporter. $type must be one of 'debug', 'error', 'info', 'system', or 'warn'.

=cut

#-----------------------------------------------------------------------------#
sub log {
  my ($self, $type, @msgs) = @_;
  return if $self->{log_pat} !~ /$type/;
  foreach my $msg(@msgs) {
    print STDERR "$type: $msg\n" if $self->argValue('verbose') eq '0';
    push(@{$self->{log_entries}}, {type => $type, time => time(), msg => $msg});
  }
}

#-----------------------------------------------------------------------------#

=head2 loggedCommand($cmd, $timeout)

A convenience; appends $cmd to the 'system'-type log messages stored in the
reporter, then runs $cmd and returns its output.  If $timeout is specified,
aborts the execution of $cmd and returns undef if it doesn't complete within
$timeout seconds.

=cut

#-----------------------------------------------------------------------------#
sub loggedCommand {
  my ($self, $cmd, $timeout) = @_;
  $self->log('system', $cmd);
  return `$cmd 2>&1` if !defined $timeout;
  my $output;
  eval {
    local $SIG{ALRM} = sub {die "alarm\n"};
    alarm $timeout;
    $output = `$cmd 2>&1`;
    alarm 0;
  };
  return $output;
}

#-----------------------------------------------------------------------------#

=head2 print($verbose)

A convenience; prints report($verbose) to stdout.

=cut

#-----------------------------------------------------------------------------#
sub print {
  my ($self, $verbose) = @_;
  print $self->report($verbose) . "\n";
}

#-----------------------------------------------------------------------------#

=head2 processArgv(@ARGV)

Processes @ARGV which is a list of command-line arguments of the form:

-name1=value1 -name2=value2 ...

The following options are predefined:

=over 5

=item help

=over 5

=item yes

Prints help information describing the reporter inputs, then forces the
reporter to exit.  If the verbose level is 0, the output will be text;
otherwise, it will be Inca XML.

=item no (default)

Normal reporter execution.

=back

=item verbose

=over 5

=item 0 (default)

print will only produce "completed" or "failed".

=item 1

print will produce Inca reporter XML.

=item 2

print will produce Inca reporter XML that includes help information.

=back

=item version

=over 5

=item yes

Prints the reporter version number and exits.

=item no (default)

Normal reporter execution.

=back

=back

=cut

#-----------------------------------------------------------------------------#
sub processArgv {
  my ($self, @argv) = @_;

  my ($arg, @argValues, @missing, @patterns);

  if($#argv == 0) {
    # we have a single argument; check to see if the input is URL-style query
    # string, e.g.,  -file=test.pl&help=no&verbose=1
    @argv = split(/&/, $argv[0]) if $argv[0] =~ /&/;
  } elsif($#argv == -1) {
    # maybe we're running as a CGI script
    @argv = split(/&/, $ENV{'QUERY_STRING'}) if defined $ENV{'QUERY_STRING'};
  }

  my $badArg;
  foreach $arg(@argv) {
    my ($name, $value) = split(/=/, $arg);
    $value = 'yes' if !defined($value);
    $name =~ s/^-//;
    if(!exists($self->{args}->{$name})) {
      $badArg = "unknown argument '$name'";
    } elsif($value !~ /$self->{args}->{$name}->{pat}/) {
      $badArg = "'$value' is not a valid value for -$name";
    }
    push(@argValues, "$name=$value");
  }
  $self->{argv} = \@argValues;
  $self->failPrintAndExit($badArg) if defined($badArg);

  if($self->argValue('help') ne 'no') {
    if($self->argValue('verbose') eq '0') {
      my $description = $self->getDescription();
      my $version = $self->getVersion();
      my $url = $self->getUrl();
      my $text = "";
      my $usage = basename($0);
      foreach my $arg(sort(keys %{$self->{args}})) {
        my $default = $self->{args}->{$arg}->{default};
        my $description = $self->{args}->{$arg}->{description};
        $text .= "  -$arg\n";
        $text .= "\t$description\n" if defined($description);
        $usage .= " -$arg" . (defined($default) ? "=$default" : "");
      }
      print "NAME:\n  " . basename($0) . "\n" .
            "VERSION:\n  " .
              (defined($version) ? $version : "No version") . "\n" .
            "DESCRIPTION:\n  " .
              (defined($description) ? $description : "No description") . "\n" .
            "URL:\n  " .
              (defined($url) ? $url : "No URL") . "\n" .
            "SYNOPSIS:\n  $usage\n$text\n";
    } else {
      print $self->_reportXml($self->_helpXml()) . "\n";
    }
    exit;
  }
  if($self->argValue('version') ne 'no') {
    print basename($0) . ' ' . $self->getVersion() . "\n";
    exit;
  }

  foreach $arg(keys %{$self->{args}}) {
    push(@missing, $arg) if !defined($self->argValue($arg));
  }
  if($#missing == 0) {
    $self->failPrintAndExit("Missing required argument '$missing[0]'");
  } elsif($#missing > 0) {
    $self->failPrintAndExit
      ("Missing required arguments '" . join("', '", @missing) . "'")
  }

  foreach $arg($self->argValues('log')) {
    if($arg =~ /^[01234]$/) {
      my @allTypes = ('', 'error', 'warn', 'system', 'info', 'debug');
      $arg = join('|', @allTypes[1 .. $arg]);
    }
    push(@patterns, $arg);
  }
  $self->{log_pat} = join('|', @patterns) if $#patterns >= 0;

}

#-----------------------------------------------------------------------------#

=head2 report($verbose)

Returns report text or XML, depending on the value (0, 1, 2) of $verbose.  Uses
the value of the -verbose switch if $verbose is undef.

=cut

#-----------------------------------------------------------------------------#
sub report {
  my ($self, $verbose) = @_;
  my $result;
  my $completed = $self->getCompleted();
  my $msg = $self->getFailMessage();
  $verbose = $self->argValue('verbose') if !defined($verbose);
  if($verbose == '0') {
    $result = $completed ? 'completed' : 'failed';
    $result .= ": $msg" if defined($msg);
  } else {
    my ($completedXml, $messageXml);
    $self->setBody($self->reportBody())
      if $completed && !defined($self->getBody());
    $messageXml = $self->xmlElement('errorMessage', 1, $msg) if defined($msg);
    $completedXml =
      $self->xmlElement('completed', 1, $completed ? 'true' : 'false');
    $result = $self->_reportXml(
      $self->xmlElement('body', 0, $self->getBody()),
      $self->xmlElement('exitStatus', 0, $completedXml, $messageXml),
      $verbose == '2' ? $self->_helpXml() : undef
    );
  }
  return $result;
}

#-----------------------------------------------------------------------------#

=head2 reportBody

Constructs and returns the XML contents of the report body.  Child classes
should override the default implementation, which returns undef.

=cut

#-----------------------------------------------------------------------------#
sub reportBody {
  return undef;
}

#-----------------------------------------------------------------------------#

=head2 setBody($body)

Sets the body of the report to $body.

=cut

#-----------------------------------------------------------------------------#
sub setBody {
  my $self = shift;
  $self->{body} = shift;
}

#-----------------------------------------------------------------------------#

=head2 setCompleted($completed)

Sets the completion indicator of the reporter to the boolean $completed.

=cut

#-----------------------------------------------------------------------------#
sub setCompleted {
  my $self = shift;
  $self->{completed} = shift;
}

#-----------------------------------------------------------------------------#

=head2 setDescription($description)

Sets the description of the reporter to $description.

=cut

#-----------------------------------------------------------------------------#
sub setDescription {
  my $self = shift;
  $self->{description} = shift;
}

#-----------------------------------------------------------------------------#

=head2 setFailMessage($msg)

Sets the failure message of the reporter to $msg.

=cut

#-----------------------------------------------------------------------------#
sub setFailMessage {
  my $self = shift;
  $self->{fail_message} = shift;
}

#-----------------------------------------------------------------------------#

=head2 setResult($completed, $msg)

A convenience; calls setCompleted($completed) and setFailMessage($msg).

=cut

#-----------------------------------------------------------------------------#
sub setResult {
  my ($self, $completed, $msg) = @_;
  $self->setCompleted($completed);
  $self->setFailMessage($msg);
}

#-----------------------------------------------------------------------------#

=head2 setUrl($url)

Sets the url for the reporter to $url.

=cut

#-----------------------------------------------------------------------------#
sub setUrl {
  my $self = shift;
  $self->{url} = shift;
}

#-----------------------------------------------------------------------------#

=head2 setVersion($version)

Sets the version of the reporter to $version.  $version can be a raw
CVS-modified revision string (i.e., the string will be checked and parsed).

=cut

#-----------------------------------------------------------------------------#
sub setVersion {
  my ($self, $version) = @_;
  carp 'Undefined version not allowed' and return if !defined($version);
  $self->{version} = $version =~ 'Revision: (.+) ' ? $1 : $version;
}

#-----------------------------------------------------------------------------#

=head2 tempFile(@paths)

A convenience.  Adds each element of @paths to a list of temporary files that
will be deleted automatically when the reporter is destroyed.

=cut

#-----------------------------------------------------------------------------#
sub tempFile {
  my $self = shift;
  push(@{$self->{temp_paths}}, @_);
}

#-----------------------------------------------------------------------------#

=head2 xmlElement($name, $escape, @contents)

Returns the XML element $name surrounding @contents.  $escape should be true
only for leaf elements; in this case, the each special XML character (<>&) in
@contents is replaced by the equivalent XML entity.

=cut

#-----------------------------------------------------------------------------#
sub xmlElement {
  my ($self, $name, $escape, @contents) = @_;
  my $innards = '';
  foreach my $content(@contents) {
    next if !defined($content);
    if($escape) {
      $content =~ s/&/&amp;/g;
      $content =~ s/</&lt;/g;
      $content =~ s/>/&gt;/g;
    }
    $content =~ s/^</\n</;
    $innards .= $content;
  }
  $innards =~ s/^( *)</  $1</gm;
  $innards =~ s/>$/>\n/;
  return "<$name>$innards</$name>";
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# _helpXml
#
# Returns help information formatted as the body of an Inca report.
#-----------------------------------------------------------------------------#
sub _helpXml {
  my $self = shift;
  my (@argsXml, $arg, @depsXml, $dep);
  foreach $arg(sort(keys %{$self->{args}})) {
    my $info = $self->{args}->{$arg};
    my $defaultXml;
    $defaultXml = $self->xmlElement('default', 1, $info->{default})
      if defined $info->{default};
    my $description = defined($info->{description}) ? $info->{description} : '';
    push(@argsXml,
         $self->xmlElement('argDescription', 0,
           $self->xmlElement('ID', 1, $arg),
           $self->xmlElement('accepted', 1, $info->{pat}),
           $self->xmlElement('description', 1, $description),
           $defaultXml
         )
      );
  }
  foreach $dep(@{$self->{dependencies}}) {
    push(@depsXml,
         $self->xmlElement('dependency', 0, $self->xmlElement('ID', 1, $dep))
        );
  }
  return $self->xmlElement('help', 0,
    $self->xmlElement('ID', 1, 'help'),
    $self->xmlElement('name', 1, basename($0)),
    $self->xmlElement('version', 1, $self->getVersion()),
    $self->xmlElement('description', 1, $self->getDescription()),
    $self->xmlElement('url', 1, $self->getUrl()),
    @argsXml,
    @depsXml
  );
}

#-----------------------------------------------------------------------------#
# _iso8601Time($time)
#
# Returns the UTC time for the time() return value $time in ISO 8601 format:
# CCMM-MM-DDTHH:MM:SSZ
#-----------------------------------------------------------------------------#
sub _iso8601Time {
  my ($self, $time) = @_;
  my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday) = gmtime($time);
  return sprintf("%04d-%02d-%02dT%02d:%02d:%02dZ",
                 $year + 1900, $mon + 1, $mday, $hour, $min, $sec);
}

#-----------------------------------------------------------------------------#
# _reportXml($content1, $content2, ...)
#
# Returns XML report beginning with the header and input sections plus any
# contents specified in the arguments.
#-----------------------------------------------------------------------------#
sub _reportXml {
  my ($self, @contents) = @_;
  my $argsXml;
  my @argXmls;
  my $logXml;
  my @logXmls;

  my $hostname = hostname();
  if ( $hostname !~ /\./ ) {
    $hostname = hostfqdn();
  }
  my @header = (
    $self->xmlElement('gmt', 1, $self->_iso8601Time(time())),
    $self->xmlElement('hostname', 1, $hostname ),
    $self->xmlElement('name', 1, basename($0)),
    $self->xmlElement('version', 1, $self->getVersion())
  );
  foreach my $arg(sort(keys %{$self->{args}})) {
    my @valuesXml;
    foreach my $value($self->argValues($arg)) {
      push(@valuesXml, $self->xmlElement('value', 1, $value));
    }
    push(@valuesXml, $self->xmlElement('value', 1, '')) if $#valuesXml < 0;
    push(@argXmls,
         $self->xmlElement('arg', 0,
           $self->xmlElement('name', 1, $arg),
           @valuesXml
         )
    );
  }
  $argsXml = $self->xmlElement('args', 0, @argXmls) if $#argXmls >= 0;
  foreach my $entry(@{$self->{log_entries}}) {
    push(@logXmls,
         $self->xmlElement($entry->{type}, 0,
           $self->xmlElement('gmt', 1, $self->_iso8601Time($entry->{time})),
           $self->xmlElement('message', 1, $entry->{msg}),
         )
        );
  }
  $logXml = $self->xmlElement('log', 0, sort(@logXmls)) if $#logXmls >= 0;
  my $result = $self->xmlElement('rep:report', 0,
    @header,
    $argsXml,
    $logXml,
    @contents
  );
  $result =~ s#<rep:report#<rep:report xmlns:rep='http://inca.sdsc.edu/dataModel/report_2.1'#;
  return "<?xml version='1.0'?>\n" . $result;
}

sub DESTROY {
  my $self = shift;
  unlink @{$self->{temp_paths}} if $#{$self->{temp_paths}} >= 0;
}

1;

__END__

=head1 EXAMPLE

  use strict;
  use warnings;
  use Inca::Reporter;
  my $reporter = new Inca::Reporter(
    name => 'selfPathReporter',
    version => '1.0.0',
    description => 'Reports the path to the reporter',
    url => 'http://mothership.ufo.edu'
  );
  $reporter->processArgv(@ARGV);
  $reporter->setBody($reporter->xmlElement('path', 1, $0));
  $reporter->print();

Running this reporter with -verbose=1 will produce output that looks something
like this.

  <?xml version='1.0'?>
  <rep:report xmlns:rep='http://inca.sdsc.edu/dataModel/report_2.1'>
    <gmt>Tue Jan  7 07:55:44 2005</gmt>
    <hostname>blue.ufo.edu</hostname>
    <name>selfPathReporter</name>
    <version>1.0.0</version>
    <args>
      <arg>
        <name>help</name>
        <value>no</value>
      </arg>
      <arg>
        <name>log</name>
        <value></value>
      </arg>
      <arg>
        <name>verbose</name>
        <value>1</value>
      </arg>
      <arg>
        <name>version</name>
        <value>no</value>
      </arg>
    </args>
    <body>
      <path>sr</body>
    </body>
    <exitStatus>
      <completed>true</completed>
    </exitStatus>
  </rep:report>

=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=cut
