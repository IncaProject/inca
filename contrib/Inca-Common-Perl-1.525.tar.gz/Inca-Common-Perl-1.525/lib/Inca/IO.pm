package Inca::IO;

################################################################################

=head1 NAME

Inca::IO - Wrapper module for handling type-specific IO streams.

=head1 SYNOPSIS

=for example begin

  use Inca::IO; 
  my $stream = new Inca::IO( "ssl:localhost:1111", cert => "mycert.pem",  
                            key => "mykey.pem", trusted => "mytrustedcertdir" );
  print $stream "important data";
  close( $stream );

  # or

  $stream = new Inca::IO( "file:/home/file" );
  print $stream "important data";
  close( $stream );

=for example end

=head1 DESCRIPTION

This module provides an abstract factory for dealing with different IO
streams.  It currently handles 2 types:

=over 8

=item B<Type>

B<Format>

=item file

file:path_to_file

=item ssl

ssl:hostname:port 

=back

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#

use strict;
use warnings;
use Carp;
use vars qw($VERSION $AUTOLOAD);
use Params::Validate qw(:all);
use URI;
use IO::Socket::SSL;
use IO::File;

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $HOST_EXPR = { regex => qr/[\w\.]+/ };
my $PORT_EXPR = { regex => qr/\d+/ };
my $PATH_EXPR = { type => SCALAR };

#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#

=head2 new( $uri, @args )

Class constructor which returns a new Inca::IO object based on the uri.

=over 2

B<Arguments>:

=over 7

=item uri

A string in the format of <scheme>:<fragment> where

=over 13

=item scheme

The type of URI being represented by the string (either I<file> or I<ssl>)

=item fragment

The location of the URI being represented (e.g., localhost:7070)

=back

=item args

A list of follow on arguments for the stream type (e.g., cert, key, and
trusted certificate directory for the SSL connection).

=back

=back

=begin testing

  use Inca::IO;
  use Test::Exception;
  use File::Temp qw/ :POSIX /;
dies_ok { new Inca::IO() } 'dies when called with no args';
  my $filename = tmpnam();
  my $io = new Inca::IO( "file:$filename" );
  print $io "hi\n";
  close( $io );
  open( CHECK, "< $filename" );
  local $/;
  my $contents = <CHECK>;
  close CHECK;
  is( $contents, "hi\n", "able to write to file IO stream from constructor" );

  my $port = 6428;
  my $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  my $pid;
  if ( $pid = fork() ) {
    my $server_sock = $server->accept();
    is( <$server_sock>, "hi\n", 
        "able to write to SSL IO stream from constructor" );
    close $server_sock;
  } else {
    $io = new Inca::IO( "ssl:localhost:$port", 
                        cert => "t/certs/client_ca1cert.pem",
                        key => "t/certs/client_ca1keynoenc.pem", 
                        trusted => "t/certs/trusted" );
    print $io "hi\n";
    close $io;
    exit;
  }
  close $server;

=end testing

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $class = shift;
  my $self;

  my $uri_string = shift;
  my $uri = new URI( $uri_string );

  if ( $uri->scheme =~ "file" ) {
    my $path = $uri->opaque;
    return Inca::IO->createFileWriteStream( $path );
  } elsif ( $uri->scheme =~ "ssl" ) {
    my ( $host, $port ) = split( ":", $uri->opaque );
    my @creds = Inca::IO->_readSSLCreds( @_);
    return Inca::IO->createSSLWriteStream( $host, $port, @creds );
  } else {
    croak "Unknown stream '", $uri->scheme, "'";
  }
  if ( ! defined($self) ) {
    die "Error: unable to create IO stream to ", $uri->as_string();
  }
  return bless $self, ref($class) || $class;
}

#-----------------------------------------------------------------------------#

=head2 createFileWriteStream( $path )

Create new Inca::IO object which wraps a IO::File object.  

=over 2

B<Arguments>:

=over 7

=item path

A string that contains the path to the file to be written to.

=back

B<Returns>:

A new IO::File object. 

=back

=begin testing

  use strict;
  use warnings;
  use Inca::IO;
  use Test::Exception;
  use File::Temp qw/ :POSIX /;

  my $filename = tmpnam();
  my $io = Inca::IO->createFileWriteStream( $filename );
  isa_ok( $io, "IO::File", 'IO::File object created from createFileWriteStream' );
  print $io "Hello there\n";
  ok( -f $filename, 'file creation works' );
  close( $io );
  open( CHECK, "< $filename" );
  local $/;
  my $contents = <CHECK>;
  close CHECK;
  is( $contents, "Hello there\n", "able to write to file IO stream" );
  unlink $filename;
  ok( ! -f $filename, 'file deleted ok' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub createFileWriteStream {
  my $class = shift;
  my $self;

  my @args = validate_pos( @_, SCALAR );
  my $path = $args[0];
  return new IO::File( ">> $path" );
}

#-----------------------------------------------------------------------------#

=head2 createSSLWriteStream( $host, $port, $cert, $key, $trusted_certs )

Create new Inca::IO object which wraps a IO::Socket::SSL.

=over 2

B<Arguments>:

=over 7

=item host

A string that contains the name of the host to contact.

=item port

An integer that contains the port number on the host to contact.

=item cert

A string containing the path to the certificate file.

=item key

A string containing the path to the key file.

=item trusted_certs

A string containing the path to the trusted certificate file or directory.

=back

B<Returns>:

An object of type IO::Socket::SSL. 

=back

=begin testing

  use strict;
  use warnings;
  use Inca::IO;
  use IO::Socket::SSL;
  use IO::Socket;
  use Test::Exception;
  untie *STDOUT;
  untie *STDERR;


  my $port = 6428;
  my $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  ok( $server, "server set up correctly for testing" ) || 
      diag( "Failure was $!\n" );

  my ( $pid, $i );
  my @test_data;
  my @test_desc = ( 'connect with same CA worked - dir',
                    'connect with same CA worked - file',
                    'connect with different CA worked' );
  if ( $pid = fork() ) {
    for ( $i = 0; $i <= $#test_desc; $i++ ) {
      my $server_sock = $server->accept();
      my $out;
      while ( defined ($out = <$server_sock>) ) {
        push ( @test_data, $out );
      }
      close $server_sock;
    }
  } else {
    # same ca using trusted ca dir
    my $client = Inca::IO->_startClient( $port, "ca1", 't/certs/trusted' );
    print $client "hi\n";
    close $client;

    # same ca using trusted ca file
    $client = Inca::IO->_startClient( $port, "ca1", 't/certs/all.pem', 
                           trust_type => "file" );
    print $client "hi\n";
    close $client;

    # different ca using trusted ca file
    $client = Inca::IO->_startClient( $port, "ca2", 't/certs/trusted' );
    print $client "hi\n";
    close $client;

    exit;
  }
  for ( $i = 0; $i <= $#test_desc; $i++ ) {
    is( $test_data[$i], "hi\n", $test_desc[$i] );
  }
  close $server;

  ###### server doesn't trust client ########
  $port++;
  $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted/917e65e4.0",
                                    trust_type => "file" );
  ok( $server, "server set up correctly for testing" ) || 
      diag( "Failure was $!\n" );

  if ( $pid = fork() ) {
    eval {
      my $new_client = Inca::IO->_startClient( $port, "ca2", 't/certs/trusted' );
    };
    like( $@, qr/Unable to create/, 'server does not trust client' );
  } else {
    my $server_sock = $server->accept();
    exit;
  }
  close $server;

  ######### client doesn't trust server ########
  $port++;
  $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted" );
  ok( $server, "server set up correctly for testing" ) || 
      diag( "Failure was $!\n" );
  if ( $pid = fork() ) {
    eval {
      my $new_client = Inca::IO->_startClient( $port, "ca2", 
                                               't/certs/trusted/1e415a79.0' );
    };
    like( $@, qr/Unable to create/, 'client does not trust server' );
  } else {
    my $server_sock = $server->accept();
    exit;
  }
  close $server;

  ######### client nor server trust each other ########
  $port++;
  $server = Inca::IO->_startServer( $port, "ca1", "t/certs/trusted/917e65e4.0",
                                    trust_type => "file" );
  ok( $server, "server set up correctly for testing" ) || 
      diag( "Failure was $!\n" );
  if ( $pid = fork() ) {
    eval {
      my $new_client = Inca::IO->_startClient( $port, "ca2", 
                                               't/certs/trusted/1e415a79.0' );
    };
    like( $@, qr/Unable to create/, 'client nor server trust each other' );
  } else {
    my $server_sock = $server->accept();
    exit;
  }
  close $server;

=end testing

=cut
#-----------------------------------------------------------------------------#
sub createSSLWriteStream {
  my $class = shift;

  my ( $host, $port, $cert, $key, $trusted_certs ) = 
     validate_pos( @_, $HOST_EXPR, $PORT_EXPR, $PATH_EXPR, $PATH_EXPR, 
                       $PATH_EXPR );

  my ( $ca_dir, $ca_file );
  if ( -f $trusted_certs ) {
    $ca_file = $trusted_certs;
    $ca_dir = "";
  } elsif ( -d $trusted_certs ) {
    $ca_dir = $trusted_certs;
    $ca_file = "";
  } else {
    croak "'$trusted_certs' is not a file or directory to trusted certificates";
  }

  my $sock = new IO::Socket::SSL( PeerAddr => $host,
                               PeerPort => $port,
                               Proto    => 'tcp',
                               SSL_use_cert => 1,
                               SSL_verify_mode => 0x07,
                               SSL_key_file => $key,
                               SSL_cert_file => $cert,
                               SSL_ca_path => $ca_dir,
                               SSL_ca_file => $ca_file
                             );

  if ( ! defined $sock ) {
    croak "Unable to create Inca::IO socket: $!: ", IO::Socket::SSL::errstr();
  } 

  return $sock;
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# _startServer( $port, $ca, $trusted, trust_type => [file, dir])
#
# Start SSL server on port using the CA certificate $ca and trusted
# cert dir.  Used only for testing.
#
# Arguments:
#
# port     An integer containing the port to start the server on
#
# ca       A string containing the name of the CA in t/certs to use
#  
# trusted  A string containing the path to the trusted CA dir or file
#
# Options:
#
# trust_type  Indicates whether trusted is a file or dir [default: dir]
#
# Returns: 
#
# A new IO::Socket::SSL object
#-----------------------------------------------------------------------------#
sub _startServer {
  my $class = shift;
  my $port = shift;
  my $ca = shift;
  my $trusted = shift;
  my %options = @_;
 
  my ( $ca_file, $ca_dir );
  if ( exists $options{trust_type} and $options{trust_type} eq "file" ) {
    $ca_dir = "";
    $ca_file = $trusted;
  } else {
    $ca_file = '';
    $ca_dir = $trusted; 
  }

  my $server = new IO::Socket::SSL(
                      LocalPort => $port,
                      Proto     => 'tcp',
                      Listen    => 5,
                      Reuse     => 1,
                      SSL_use_cert => 1,
                      SSL_verify_mode => 0x07,
                      SSL_key_file => 't/certs/server_' . $ca . 'keynoenc.pem',
                      SSL_cert_file => 't/certs/server_' . $ca . 'cert.pem',
                      SSL_ca_file => $ca_file,
                      SSL_ca_path => $ca_dir
                           );
  return $server;
}

#-----------------------------------------------------------------------------#
# _startClient( $port, $ca, $trusted )
#
# Try to connect to SSL server on port using the CA certificate $ca and
# trusted cert dir
#
# Arguments:
#
# port     An integer containing the port to start the server on
#
# ca       A string containing the name of the CA in t/certs to use
#  
# trusted  A string containing the path to the trusted CA dir or file
#
# Returns: 
#
# A new IO::Socket::SSL object
#-----------------------------------------------------------------------------#
sub _startClient {
  my $class = shift;
  my $port = shift;
  my $ca = shift;
  my $trusted = shift;

  my $client = Inca::IO->createSSLWriteStream( 'localhost', $port, 
                                      't/certs/client_' . $ca . 'cert.pem',
                                      't/certs/client_' . $ca . 'keynoenc.pem',
                                      $trusted );
}

#-----------------------------------------------------------------------------#
# _readSSLCreds( %creds )
#
# Extract a certificate, key, and trusted certificate directory from the
# hash 'creds'.  The keys it will check for are:
#
# cert     A string containing the path to the certificate file
#
# key      A string containing the path to the private key file
#  
# trusted  A string containing the path to the trusted CA dir or file
#
# If one of these fields is missing, we will croak so calling method
# may want to encapsulate this in an 'eval'.
#
# Returns: 
#
# An array of strings containing the paths to the certificate, key, and
# trusted certificate dir/file.
 
=begin testing

  use Inca::IO;
  use Test::Exception;

  dies_ok { Inca::IO->_readSSLCreds( cert => 't/certs/cert.pem', 
                                     trusted => 't/certs/trusted' ); }
          'dies when not all creds specified';
  my @ssl;
  lives_ok { @ssl = Inca::IO->_readSSLCreds( cert => 't/certs/cert.pem', 
                                      key => 't/certs/key.pem',
                                      trusted => 't/certs/trusted' ); }
          'lives when all creds specified';
  ok( eq_array(\@ssl, [qw(t/certs/cert.pem t/certs/key.pem t/certs/trusted)]),
      'correct array returned from _readSSLCreds' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _readSSLCreds {
  my $class = shift;
  my %creds = @_;

  my @ssl_creds;
  for my $type ( qw(cert key trusted) ) {
    if ( exists $creds{$type} ) {
      push( @ssl_creds, $creds{$type} );
    } else {
      croak "Requested SSL IO stream but missing '$type' for authentication";
    }
  }
  return @ssl_creds;
}

#=============================================================================#
# Return true module load status to true
#=============================================================================#
1;

#=============================================================================#
# The end
#=============================================================================#

__END__

=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=cut

