package Inca::ReporterManager::Scheduler::Cron;
use base qw(Inca::ReporterManager::Scheduler);
@ISA = ( "Inca::ReporterManager::Scheduler" );

################################################################################

=head1 NAME

Inca::ReporterManager::Scheduler::Cron - Executes reporter in sequence

=head1 SYNOPSIS

=for example begin

  use Inca::ReporterManager::Scheduler::Cron;
  use Inca::Subscription::Reporter;
  use Inca::ReporterManager::ReporterCache;
  use Cwd;
  use File::Spec;
  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );

  my $cron = { min => "0-59/2" }; # execute every 2 mins
  my $sched = new Inca::ReporterManager::Scheduler::Cron( 
                    1,
                    [ $file_depot ],
                    new Inca::ReporterManager::ReporterCache( 't',
                      errorReporterPath => "bin/inca-null-reporter" 
                    ),
                    undef, 
                    $cron );
  $sched->start();
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/echo_report" );
  $sched->submit( 'add', $reporter );
  # ...
  $sched->stop();

=for example end

A scheduler for the reporter manager which executes reporters sequentially.
It does not take any additional configuration parameters.

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#
use strict;
use warnings;
use Carp;
use vars qw($VERSION $AUTOLOAD);
use Params::Validate qw(:all);
use Inca::Constants qw(:params);
use Inca::ReporterManager::ReporterInstanceManager;
use Inca::Subscription::Reporter;
use Schedule::Cron;
use Log::Log4perl;
use Log::Log4perl::Level;
use Cwd;
use POSIX ":sys_wait_h";

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $SELF_PARAM_REQ = { isa => __PACKAGE__ };
my $ACTION_PARAM_REQ = { regex => qr/add|delete/ };
my $KILL_WAIT = 1;
sub _execCronEntry;
sub _execNullEntry;


#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 new( $args, $check_period, $credentials, $depots, $reporter_cache, 
            $rim_path, $tmpdir )

Class constructor which returns a new Inca::ReporterManager::Scheduler::Cron
object.  The constructor must be called with the following arguments.

=over 2 

B<Arguments>:

=over 17

=item args

A reference to a hash array containing the schedulers configuration
inforamtion

=item check_period

A positive integer indicating the period in seconds of which to check the
reporter for a timeout. 

=item credentials

A reference to a hash array containing the credential information.

=item depots

A reference to an array of depot uris.  The report will be sent to the first
depot in the list.  If the first depot is unreachable, the next depots in the
list will be tried.

=item reporter_cache 

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=item rim_path

A string containing the path to the reporter-instance-manager program.

=item tmpdir

A string containing a path to a temporary file space that Inca can use while
executing reporters

=back

=back

=begin testing

  use Inca::ReporterManager::Scheduler::Cron;
  use Test::Exception;
  untie *STDOUT;
  untie *STDERR;

  dies_ok { new Inca::ReporterManager::Scheduler::Cron() } 
           'object dies with no args';

  use Inca::ReporterManager::ReporterCache;
  my $rc = new Inca::ReporterManager::ReporterCache( 't',
    errorReporterPath => "bin/inca-null-reporter"
  );
  lives_ok { new Inca::ReporterManager::Scheduler::Cron( 
    undef, 2, {}, [], $rc, "sbin/reporter-instance-manager", "/tmp"
  )  }
  'object created with undef scheduler_args';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $self = $class->SUPER::new( @_ );

  bless ($self, $class);

  my $log_method = sub {
    my ($level,$msg) = @_;
    my $DBG_MAP = { 0 => $INFO, 1 => $WARN, 2 => $ERROR };

    $self->{logger}->log($DBG_MAP->{$level},$msg);
  };
  
  $self->{cron} = new Schedule::Cron( \&_execCronEntry, log => $log_method );
  $self->{cwd} = getcwd();

  return $self;
}

#-----------------------------------------------------------------------------#

=head2 isRunning( )

Check if the cron scheduler is running.

=over 2

B<Returns>:

Returns true if the cron scheduler is running and false otherwise.

=back

=cut
#-----------------------------------------------------------------------------#
sub isRunning {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  if ( exists $self->{cronpid} && defined $self->{cronpid} ) {
    return 1;
  } else {
    return 0;
  }
}

#-----------------------------------------------------------------------------#

=head2 start( )

Starts cron scheduler up.

=over 2

B<Returns>:

Returns true if there were no errors starting the scheduler; returns false
otherwise.

=back

=begin testing

  use Inca::ReporterManager::Scheduler::Cron;
  use Inca::ReporterManager::ReporterCache;
  use Cwd;
  use File::Spec;
  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );

  my $sched = new Inca::ReporterManager::Scheduler::Cron( 
                    undef,
                    1,
                    undef, 
                    [ $file_depot ],
                    new Inca::ReporterManager::ReporterCache( 't',
                      errorReporterPath => "bin/inca-null-reporter"
                    ),
                    "sbin/reporter-instance-manager",
                    "/tmp"
                    );
  ok( $sched->start(), "scheduler started" );
  ok( $sched->isRunning(), "scheduler start verified" );
  ok( $sched->stop(), "scheduler stopped" );
  ok( ! $sched->isRunning(), "scheduler stop verified" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub start {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  # Since Schedule::Cron won't allow you to start without at least one job
  # we add a dummy entry to execute on a holiday July, 4 2:32AM) and then
  # delete it
  my $id = $self->{cron}->add_entry( "23 2 4 7 *", \&_nullCronEntry );
  $self->{cronpid} = $self->{cron}->run( detach => 1 );
  $self->{cron}->delete_entry( $id );
  return 1;
}

#-----------------------------------------------------------------------------#

=head2 stop( )

Stops cron scheduler.

=over 2

B<Returns>:

Returns true if there were no errors starting the scheduler; returns false
otherwise.

=back

=cut
#-----------------------------------------------------------------------------#
sub stop {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  if ( $self->isRunning() ) {
    my $pid;
    do {
      my $procs_signalled = kill( 'KILL', -$self->{cronpid} );
      sleep $KILL_WAIT;
      $pid = waitpid( $self->{cronpid}, WNOHANG);
    } until $pid != 0;
    if ( $pid == $self->{cronpid} || $pid == -1 ) {
      $self->{cronpid} = undef;
      return 1;
    } else {
      $self->{cronpid} = undef;
      return 0;
    }
  }
  return 0;
}

#-----------------------------------------------------------------------------#

=head2 submit( $action, @reporters )

Accepts an action (currently only 'add') and any number of reporters.  These 
reporters will then be executed in a sequential order.

=over 2

B<Arguments>:

=over 13

=item action

A string containing an action (e.g., add, delete) pertaining to the group
of reporters.

=item reporters

An array of Inca::Subscription::Reporter objects.

=back

B<Returns>:

Returns true if at least one reporter is executed; otherwise returns false.

=back

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Inca::ReporterManager::Scheduler::Cron;
  use Inca::Subscription::Reporter;
  use Inca::ReporterManager::ReporterCache;
  use Cwd;
  use File::Spec;

  # test quick reporter
  my $pid = $$;
  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );
  my $sched = new Inca::ReporterManager::Scheduler::Cron( 
                    undef,
                    1,
                    undef, 
                    [ $file_depot ],
                    new Inca::ReporterManager::ReporterCache( 't',
                      errorReporterPath => "bin/inca-null-reporter"
                    ),
                    "sbin/reporter-instance-manager",
                    "/tmp"
                    );
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/echo_report" );
  my $args = { second => "0-59/5" };
  ok( $sched->submit( 'add', $args, $reporter ), 
      'submit returned positive status' );
  ok( $sched->start(), "Scheduler started" );
  ok( sleep(20), "slept for 20 seconds" );
  my $procs_leftover = `ps x | grep "(perl)" | wc -l`;
  chomp( $procs_leftover );
  # 2 for grep command and possibly one extra
  cmp_ok($procs_leftover, "<=", 3, "no more than 3 procs found");
  ok( $sched->stop(), "killed Schedule::Cron" );
  ok( -f "./depot.tmp.$pid", "submit to file - depot file created" );
  local $/;
  open( FD, "<./depot.tmp.$pid" );
  my $content = <FD>;
  close FD;
  unlink "./depot.tmp.$pid";
  like( $content, qr/^<\S*report .*/m, 
        "submit to file - looks like reporter was printed");

  # test benchmark reporter
  my $start_time = time();
  `t/stream`;
  my $elapsed_time = (time() - $start_time) * 2;
  ok( $elapsed_time, "positive time $elapsed_time for stream" );
  $sched = new Inca::ReporterManager::Scheduler::Cron( 
                    undef,
                    1,
                    undef, 
                    [ $file_depot ],
                    new Inca::ReporterManager::ReporterCache( 't',
                      errorReporterPath => "bin/inca-null-reporter"
                    ),
                    "sbin/reporter-instance-manager",
                    "/tmp"
                    );
  $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/stream_report" );
  $reporter->setTimeout( [ { name => 'CPUTime', value => 20 } ] );
  ok( $sched->submit( 'add', $args, $reporter ), 
      'submit returned positive status' );
  ok( $sched->start(), "Scheduler started" );
  ok( sleep($elapsed_time + 10), "slept for " . $elapsed_time+10 . " seconds" );
  ok( $sched->stop(), "killed Schedule::Cron" );
  ok( -f "./depot.tmp.$$", "submit for stream - depot file created" );
  local $/;
  open( FD, "<./depot.tmp.$$" );
  $content = <FD>;
  close FD;
  unlink "./depot.tmp.$$";
  my ($memory) = $content =~ /^memory_mb=(.*)/m;
  cmp_ok( $memory, ">=", 45, "submit for stream - memory is reasonable" );

  $pid = "$$";
  $sched = new Inca::ReporterManager::Scheduler::Cron( 
                    undef,
                    1,
                    undef, 
                    [ $file_depot ],
                    new Inca::ReporterManager::ReporterCache( 't',
                      errorReporterPath => "bin/inca-null-reporter"
                    ),
                    "sbin/reporter-instance-manager",
                    "/tmp"
                    );
  my $gcc_reporter = new Inca::Subscription::Reporter();
  $gcc_reporter->setUri( "file:///usr/local/bin/cluster.compiler.gcc.version");
  $gcc_reporter->addArgument( "verbose", "1" );
  my $gcc_freq = { second => "0-59/20" };
  ok( $sched->submit( 'add', $gcc_freq, $gcc_reporter ),
      "submit returned positive status" );
  my $ssl_reporter = new Inca::Subscription::Reporter();
  $ssl_reporter->setUri("file:///usr/local/bin/cluster.security.openssl.version");
  $ssl_reporter->addArgument( "verbose", "1" );
  my $ssl_freq = { second => "2-59/30" };
  ok( $sched->submit( 'add', $ssl_freq, $ssl_reporter ),
      "submit returned positive status" );;
  ok( $sched->start(), "Scheduler started for mixed" );
  cmp_ok( sleep(61), '>=', 60, "slept for 60 seconds" );
  ok( $sched->stop(), "killed Schedule::Cron" );
  ok( -f "./depot.tmp.$pid", "submit to file - depot file created" );
  open( FD, "<./depot.tmp.$pid" );
  $content = <FD>;
  close FD;
  my @content_array = split( /\n/, $content );
  my @num_gcc_reports = grep( />gcc</, @content_array );
  cmp_ok( scalar(@num_gcc_reports), ">=", 2, "at least 2 gcc reports" );
  cmp_ok( scalar(@num_gcc_reports), "<=", 3, "no more than 3 gcc reports" );
  my @num_ssl_reports = grep( />openssl</, @content_array );
  cmp_ok( scalar(@num_ssl_reports), ">=", 1, "at least 1 ssl reports" );
  cmp_ok( scalar(@num_ssl_reports), "<=", 2, "no more than 2 gcc reports" );
  unlink "./depot.tmp.$pid";

  # delete ssl reporter
  ok( $sched->submit( 'delete', $ssl_freq, $ssl_reporter ),
      "delete submit returned positive status" );;
  ok( $sched->start(), "Scheduler restarted" );
  cmp_ok( sleep(61), '>=', 60, "slept for 60 seconds" );
  ok( $sched->stop(), "killed Schedule::Cron" );
  ok( -f "./depot.tmp.$pid", "submit to file - depot file created" );
  open( FD, "<./depot.tmp.$pid" );
  $content = <FD>;
  close FD;
  @content_array = split( /\n/, $content );
  @num_gcc_reports = grep( />gcc</, @content_array );
  cmp_ok( scalar(@num_gcc_reports), ">=", 2, "at least 2 gcc reports" );
  cmp_ok( scalar(@num_gcc_reports), "<=", 3, "no more than 3 gcc reports" );
  @num_ssl_reports = grep( />openssl</, @content_array );
  is( scalar(@num_ssl_reports), 0, "0 ssl reports" );
  unlink "./depot.tmp.$pid";

=end testing

=cut
#-----------------------------------------------------------------------------#
sub submit {
  my ( $self, $action, $args, @reporters ) = 
    validate_pos( @_, $SELF_PARAM_REQ, 
                      $ACTION_PARAM_REQ, 
                      HASHREF,
                      ($REPORTER_PARAM_REQ) x (@_ - 3) );

  if ( $action eq $Inca::ReporterManager::Scheduler::ADD ) {
    return $self->_addReportersToCron( $args, @reporters );
  } elsif ( $action eq $Inca::ReporterManager::Scheduler::DELETE ) {
    return $self->_deleteReportersFromCron( $args, @reporters );
  } else {
    $self->{logger}->error( 
      "Uknown action '$action' to submit in " . __PACKAGE__ 
    );
    return 0;
  }
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# _addReporterstoCron( $cron_desc, @reporters )
#
# Add the specified reporters to the cron table.
#
# Arguments:
#
#  cron_desc  A reference to a hash array containing cron fields (e.g.,
#             minutes, hours, etc.)
#             executing a reporter
#
#  reporters  An array of Inca::Subscription::Reporter objects containing
#             the reporters to execute.
#

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Inca::ReporterManager::Scheduler::Cron;
  use Cwd;
  use File::Spec;
  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );
  my $cron = new Inca::ReporterManager::Scheduler::Cron( 
                    undef,
                    1,
                    undef, 
                    [ $file_depot ],
                    new Inca::ReporterManager::ReporterCache( 't',
                      errorReporterPath => "bin/inca-null-reporter"
                    ),
                    "sbin/reporter-instance-manager",
                    "/tmp"
                    );
  my $desc = { min => 5 };
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/echo_report" );
  $cron->_addReportersToCron( $desc, $reporter );
  my @entries = $cron->{cron}->list_entries();
  is( @entries, 1, "number of entries correct" );
  ok( $entries[0]->{time} eq "5 * * * *", "add reporter - time correct" );
  ok( ref($entries[0]->{args}[0] ) eq "Inca::ReporterManager::Scheduler::Cron", 
      "added reporter to cron - self correct" );
  ok( ref($entries[0]->{args}[1] ) eq "Inca::Subscription::Reporter", 
      "added reporter to cron - reporter correct" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _addReportersToCron {
  my ( $self, $cron_desc, @reporters ) = 
    validate_pos( @_, $SELF_PARAM_REQ, 
                      HASHREF,
                      ($REPORTER_PARAM_REQ) x (@_ - 2) );

  my $num_reporters_added = 0;
  my $crontime = $self->_convertToCronSyntax( $cron_desc );
  for my $reporter ( @reporters ) {
    my $idx;
    eval {
      $idx = $self->{cron}->add_entry( $crontime, $self, $reporter );
    };
    if ( $@ ) {
      $self->{logger}->error( "Error adding entry $num_reporters_added\n" );
    } else {
      $self->{logger}->info( 
        "Added reporter " . $reporter->getUri() . " to cron $idx: $crontime" 
      );
      $num_reporters_added++;
    }
  }
  $self->{logger}->info( "Added $num_reporters_added reporters to cron" );
  return $num_reporters_added;
}

#-----------------------------------------------------------------------------#
# _deleteReportersFromCron( $cron_desc, @reporters )
#
# Delete the specified reporters with $cron_desc from the cron table.
#
# Arguments:
#
#  cron_desc  A reference to a hash array containing cron fields (e.g.,
#             minutes, hours, etc.)
#             executing a reporter
#
#  reporters  An array of Inca::Subscription::Reporter objects containing
#             the reporters to execute.
#

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Inca::ReporterManager::Scheduler::Cron;
  use Cwd;
  use File::Spec;
  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );
  my $cron = new Inca::ReporterManager::Scheduler::Cron( 
                    undef,
                    1,
                    undef, 
                    [ $file_depot ],
                    new Inca::ReporterManager::ReporterCache( 't',
                      errorReporterPath => "bin/inca-null-reporter"
                    ),
                    "sbin/reporter-instance-manager",
                    "/tmp"
                    );
  my $desc = { min => 5 };
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/echo_report" );
  is( $cron->_addReportersToCron($desc, $reporter), 1,
      "1 reporter added" );
  my @entries = $cron->{cron}->list_entries();
  is( @entries, 1, "number of entries correct" );
  is( $cron->_deleteReportersFromCron($desc, $reporter), 1,
      "1 reporter deleted" );
  @entries = $cron->{cron}->list_entries();
  is( @entries, 0, "number of entries correct" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _deleteReportersFromCron {
  my ( $self, $cron_desc, @reporters ) = 
    validate_pos( @_, $SELF_PARAM_REQ, 
                      HASHREF,
                      ($REPORTER_PARAM_REQ) x (@_ - 2) );

  my $num_reporters_deleted = 0;
  my $crontime = $self->_convertToCronSyntax( $cron_desc );
  for my $reporter ( @reporters ) {
    my $idx = 0;
    my $reporter_found = 0;
    for my $entry ( $self->{cron}->list_entries() ) {
      next if ( ! $entry->{time} eq $crontime );
      my ( $self_entry, $reporter_entry ) = @{$entry->{args}};
      if ( $reporter->equals($reporter_entry) ) {
        $reporter_found = 1;
        my $result = $self->{cron}->delete_entry( $idx );
        if ( ! defined $result ) {
          $self->{logger}->error( "Error deleting entry $idx from cron" );
        } else {
          $self->{logger}->info( 
            "Deleted reporter " . $reporter->getUri() . 
            " from cron $idx: $crontime" 
          );
          $num_reporters_deleted++;
        }
        last;
      }
      $idx++;
    }
    if ( ! $reporter_found ) {
      $self->{logger}->info(  $reporter->getUri() . " @ $crontime not found" );
    }
  }
  $self->{logger}->info( "Deleted $num_reporters_deleted reporters from cron" );
  return $num_reporters_deleted;
}

#-----------------------------------------------------------------------------#
# _convertToCronSyntax( $cron_desc )
#
# Return a string that describes when to execute the cron job using the 
# parameters contained in $cron_desc.
#
# Arguments:
#
#  cron_desc  A reference to a hash array containing cron fields (e.g.,
#             minutes, hours, etc.)
#             executing a reporter
#
# Returns:
# 
# A string containing the time specification for the cron job

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Inca::ReporterManager::Scheduler::Cron;
  my $tm = { min => "0-59/5" };
  my $cron = Inca::ReporterManager::Scheduler::Cron->_convertToCronSyntax($tm);
  is( $cron, "0-59/5 * * * * ", "minutes converted correctly" ); 
  $tm = { hour => "0-23/5" };
  $cron = Inca::ReporterManager::Scheduler::Cron->_convertToCronSyntax($tm);
  is( $cron, "* 0-23/5 * * * ", "hours converted correctly" ); 
  $tm = { mday => "6" };
  $cron = Inca::ReporterManager::Scheduler::Cron->_convertToCronSyntax($tm);
  is( $cron, "* * 6 * * ", "mday converted correctly" ); 
  $tm = { month => "6" };
  $cron = Inca::ReporterManager::Scheduler::Cron->_convertToCronSyntax($tm);
  is( $cron, "* * * 6 * ", "month converted correctly" ); 
  $tm = { wday => "6" };
  $cron = Inca::ReporterManager::Scheduler::Cron->_convertToCronSyntax($tm);
  is( $cron, "* * * * 6 ", "wday converted correctly" ); 
  $tm = { second => "8" };
  $cron = Inca::ReporterManager::Scheduler::Cron->_convertToCronSyntax($tm);
  is( $cron, "* * * * * 8", "second converted correctly" ); 
  $tm = { min => 0, hour => 4, month => 3, wday => "6" };
  $cron = Inca::ReporterManager::Scheduler::Cron->_convertToCronSyntax($tm);
  is( $cron, "0 4 * 3 6 ", "mixed converted correctly" ); 

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _convertToCronSyntax {
  my ( $self, $cron_desc ) = validate_pos( @_, $SELF_PARAM_REQ, HASHREF );

  my $crontab = ""; 
  foreach my $field ( qw( min hour mday month wday ) ) {
    if ( defined $cron_desc->{$field} ) {
      $crontab = $crontab . $cron_desc->{$field} . " ";
    } else {
      $crontab .= "* ";
    }
  }
  if ( exists $cron_desc->{second} ) {
    $crontab .= $cron_desc->{second};
  }
  return $crontab;
}

#-----------------------------------------------------------------------------#
# _execCronEntry( $reporter )
#
# Called by Schedule::Cron when a reporter is scheduled to execute.

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Inca::ReporterManager::ReporterCache;
  use Inca::ReporterManager::Scheduler::Cron;
  use Cwd;
  use File::Spec;
  my $file_depot = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );

  my $sched = new Inca::ReporterManager::Scheduler::Cron( 
                    undef,
                    1,
                    undef, 
                    [ $file_depot ],
                    new Inca::ReporterManager::ReporterCache( 't',
                      errorReporterPath => "bin/inca-null-reporter"
                    ),
                    "sbin/reporter-instance-manager",
                    "/tmp"
                    );
  my $reporter = new Inca::Subscription::Reporter();
  $reporter->setUri( "file:///usr/local/bin/echo_report" );
  my $pid;
  if ( $pid = fork() ) {
    waitpid( $pid, 0 );
    ok( -f "./depot.tmp.$$", "_execCronEntry - depot results created" );
    local $/;
    open( FD, "<./depot.tmp.$$" );
    $content = <FD>;
    close FD;
    unlink "./depot.tmp.$$";
    like( $content, qr/^<\S*report .*/m, 
          "_execCronEntry - looks like reporter was printed");
  } else {
    $sched->_execCronEntry( $reporter );
  }

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _execCronEntry {
  my ( $self, $reporter ) = 
    validate_pos( @_, $SELF_PARAM_REQ, $REPORTER_PARAM_REQ );

  if ( ! chdir( $self->{cwd} ) ) {
    $self->{logger}->error( 
      "Executing reporter: unable to change to " .  $self->{cwd} 
    );
    return;
  }
  my @args = $self->_getRIMCmdArgs( $reporter );
  $self->{logger}->info( $self->{rim_path}, " ",  join(" ", @args) );
  $self->{logger}->info( getcwd() );
  my $cmd = $self->{rim_path} . join( " ", @args );
  exec $self->{rim_path}, @args or 
    $self->{logger}->error( 
      "Error executing " . $self->{rim_path} . " " . join( " ", @args ) .": $!"
    );
}

#-----------------------------------------------------------------------------#
# _nullCronEntry( )
#
# A null function to be called by the null cron entry (needed so that 
# Schedule::Cron doesn't error out when it starts up with no entries)
#-----------------------------------------------------------------------------#
sub _nullCronEntry {
}

#-----------------------------------------------------------------------------#
# empty destructor (needed for test programs)
#-----------------------------------------------------------------------------#
sub DESTROY {
}

1; # need to return a true value from the file

__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

No known problems.

=head1 SEE ALSO

L<Inca::ReporterManager::Scheduler>

=cut
