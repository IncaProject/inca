package Inca::Subscription;

################################################################################

=head1 NAME

Inca::Subscription - Utility class for dealing with Inca subscriptions

=head1 SYNOPSIS

=for example begin

  use Inca::Subscription;
  my $subscription = new Inca::Subscription();
  $subscription->read( "subscription.xml" );
  my $groups = $subscription->getReporterGroups();

=for example end

=head1 DESCRIPTION

An Inca subscription is a request to change (i.e., add or delete) the data
collection on a resource.  It is an XML document that contains a list of
reporter groups.  Each group contains an action (add or delete), a scheduler,
and a list of reporters.  For each reporter, there is a uri and an optional
list of input arguments, timeout, and execution priority.

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#

# pragmas
use strict;
use warnings;
use vars qw($VERSION $AUTOLOAD);

# Inca
use Inca::Constants qw(:params);
use Inca::Logger;
use Inca::Subscription::ReporterGroup;
use Inca::Validate qw(:all);

# Perl standard
use Carp;

# CPAN
use XML::Simple;

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $SELF_PARAM_REQ = { isa => __PACKAGE__ };
my %XML_OPTIONS = ( ForceArray => [ qw(reporterGroup reporter resource arg) ],
                    KeyAttr => { }, 
                    SuppressEmpty => undef );

#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 new( )

Class constructor which returns a new Inca::Subscription object.  

=begin testing

  use Inca::Subscription;
  use Test::Exception;
  lives_ok { new Inca::Subscription() } 'object created';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $self = {};
  
  bless ($self, $class);

  # initialize vars
  $self->{groups} = [];
  $self->{logger} = Inca::Logger->get_logger( $class );

  return $self;
}

#-----------------------------------------------------------------------------#

=head2 read( $file )

Read an Inca subscription file into the object.  The subscription is
structured as follows:

<subscription>
  <reporterGroup>
    <!-- see L<Inca::Subscription::ReporterGroup> for content here -->
  </reporterGroup>
  ...
</subscription>

=over 2

B<Arguments>:

=over 13

=item file

A string containing a path to an XML file containing an Inca subscription

=back

B<Returns>:

Returns 1 if there are no errors reading the subscription file; otherwise 
returns 0.

=back

=begin testing

  use Inca::Subscription;
  use Test::Exception;

  my $subscription = new Inca::Subscription();
  my $result;
  $result = $subscription->read( "t/subscription.xml" ); 
  is( $result, 1, "read on good subscription - returns true" );
  is( (($subscription->getReporterGroups())[0]->getReporters())[0]->getUri(),
      "file:///usr/local/bin/echo_report",
      "read on good subscription - found first uri" );
  my @files = qw( t/subscription_badxml.xml t/subscription_noaction.xml 
                   t/subscription_badgroup.xml);
  for my $file ( @files ) {
    is( $subscription->read( $file ), 0, "read on $file - returns false" );
  }

=end testing

=cut
#-----------------------------------------------------------------------------#
sub read {
  my ( $self, $file ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  my $subscription;
  eval {
    $subscription = XMLin( $file, %XML_OPTIONS );
  };
  if ( $@ ) {
    $self->{logger}->error( "Problem reading subscription: $@" );
    return 0;
  }
  my $success = 1;
  if ( exists $subscription->{reporterGroup} ) {
    my $i = 0;
    for my $group_desc ( @{$subscription->{reporterGroup}} ) {
      my $group = new Inca::Subscription::ReporterGroup();
      if ( $group->read( $group_desc ) ) {
        push( @{$self->{groups}}, $group );
      } else {
        $success = 0;
        $self->{logger}->error( "Error reading group $i from $file" );
      }
      $i++;
    }
  }
  return $success;
}

#-----------------------------------------------------------------------------#

=head2 getReporterGroups( )

Return the list of reporter groups in the subscription.

=over 2

B<Returns>:

An array of Inca::Subscription::ReporterGroup objects.  

=back

=begin testing

  use Inca::Subscription;
  use Test::Exception;

  my $subscription = new Inca::Subscription();
  $subscription->read( "t/subscription.xml" ); 
  my @groups = $subscription->getReporterGroups();
  is( $#groups, 0, "found 1 reporter groups" );
  isa_ok( $groups[0], "Inca::Subscription::ReporterGroup", 
          "reporter group is a group" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub getReporterGroups{
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return @{$self->{groups}};
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# empty destructor (needed for test programs)
#-----------------------------------------------------------------------------#
sub DESTROY {
}

1; # need to return a true value from the file

__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

No known problems.

=head1 SEE ALSO

L<Inca::Subscription::ReporterGroup>
L<Inca::Subscription::Reporter>

=cut
