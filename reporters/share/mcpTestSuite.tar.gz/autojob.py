# convention is for each machine attribute, [ <comparison op>, <value>]
# no, instead assume that each int for float is the minimum for matching
# all resources that exceed these values are accepted.
match_attributes = {
  'CPU_MEMORY_GB' : ['>=', 2],
  'CPU_MHZ' : ['>=', 1300],
  'CPU_SMP' : ['>=', 2],
  'NODECOUNT' : ['>=', 128],
  }
machine_dict_list = [
  { 'HOSTNAME' : 'queenbee.loni-lsu.teragrid.org',
    'substitutes_dict' : {
      'arguments' : ['-t', '100', '-n', '7', '-l', '4000', '-i', '0.03125', '-c', '0', '-s', '0'],
      'wallclock_seconds' : '300',
      '__MCP_SHELL__' : '/bin/ksh',
      '__MCP_PARALLEL_RUN__' : '/usr/local/packages/mvapich2-0.98-intel10.1/bin/mpirun',
      '__MCP_SERIAL_RUN__' : '#',
      '__MCP_NODES__' : '4',
      '__MCP_TOTAL_CPUS__' : '8',
      '__MCP_CPUS_PER_NODE__' : '2',
      '__MCP_USERNAME__' : 'inca',
      '__MCP_SCRATCH_DIR__' : '/tmp',
      '__MCP_JOB_DIR__' : '/tmp',
      '__MCP_EXECUTABLE__' : '/home/inca/mcp/ring26',
      '__MCP_QUEUE__' : 'checkpt',
      },
  },
  { 'HOSTNAME' : 'tg-login.ncsa.teragrid.org',
    'substitutes_dict' : {
      'arguments' : ['-t', '100', '-n', '7', '-l', '4000', '-i', '0.03125', '-c', '0', '-s', '0'],
      'wallclock_seconds' : '300',
      '__MCP_SHELL__' : '/bin/ksh',
      '__MCP_PARALLEL_RUN__' : '/usr/local/mpich/mpich-gm-1.2.6..14b-intel-r2/bin/mpirun',
      '__MCP_SERIAL_RUN__' : '#',
      '__MCP_NODES__' : '4',
      '__MCP_CPUS_PER_NODE__' : '2',
      '__MCP_USERNAME__' : 'inca',
      '__MCP_SCRATCH_DIR__' : '/tmp',
      '__MCP_JOB_DIR__' : '/tmp',
      '__MCP_EXECUTABLE__' : '/home/ncsa/inca/mcp/ring26',
      },
  },
  ]
