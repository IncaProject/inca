/* $Id: suite.java,v 1.1 2007/06/13 17:33:55 rbudden Exp $ */

import org.globus.gsi.*;
import org.globus.gsi.*;
import org.globus.gsi.gssapi.*;
import org.globus.gsi.gssapi.GlobusGSSCredentialImpl.*;
import org.ietf.jgss.*;
import org.ietf.jgss.GSSCredential.*;
import org.ietf.jgss.GSSException.*;
import cogster.auth.*;
import cogster.*;

public class suite
{
	public static void main(String[] args)
	{
		try
		{
			Auth a = new Auth();
			System.out.println("User: "+a.getGSS().getName());
			System.out.println("Lifetime: "+a.getGSS().getRemainingLifetime());
		} catch(Exception e) {
			System.out.println("Error:"+e);
		}
	}
}
