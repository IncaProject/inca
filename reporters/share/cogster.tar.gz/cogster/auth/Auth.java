/* $Id: Auth.java,v 1.3 2007/06/14 15:40:33 rbudden Exp $ */

package cogster.auth;

import org.globus.gsi.*;
import org.globus.gsi.*;
import org.globus.gsi.gssapi.*;
import org.globus.gsi.gssapi.GlobusGSSCredentialImpl.*;
import org.ietf.jgss.*;
import org.ietf.jgss.GSSCredential.*;
import org.ietf.jgss.GSSException.*;
import java.io.*;

public class Auth
{
	private GlobusCredential gc = null;
	private GSSCredential gss = null;
	private Cert file = null;

	public Auth(int uid)
	{
		this.file = new Cert(uid);
		this.create();
	}

	public Auth()
	{
		this.file = new Cert(getUserID());
		this.create();
	}

	private void create()
	{
		try
		{
			/* Create a Globus Credential from the X509 Certificate */
			this.gc = new GlobusCredential(this.file.getX509());

			/* Convert GlobusCredential to GSSCredential. */
			this.gss = new GlobusGSSCredentialImpl(this.gc,
			  GSSCredential.INITIATE_AND_ACCEPT);
		} catch(Exception e) {
			System.out.println("ERROR! Authentication Failed: " + e);
		}
	}

	public GlobusCredential getGC()
	{
		return this.gc;
	}

	public GSSCredential getGSS()
	{
		return this.gss;
	}

	/* User Identification */
	private int getUserID()
	{
		try
		{
			return (getUserID(System.getProperty("user.name")));
		} catch (Exception e) {
			return (-1);
		}
	}

	/* It is sad that there is no way to do this in J2SE. */
	private int getUserID(String username)
	{
		int uid = -1;

		try
		{
			/* An equivalent to getpwent() might be better here... */
			String line;
			String[] fields;
			File f = new File("/etc/passwd");
			BufferedReader r = new BufferedReader(new
			    FileReader(f));
			while ((line = r.readLine()) != null)
			{
				fields = line.split(":");
				if (fields.length > 0 && fields[0].equals(username))
				{ 
					uid = Integer.valueOf(
					    fields[2]).intValue();
					break;
				}
			}
			r.close();
		} catch (Exception e) {
			return (-1);
		}

		return (uid);
	}
};

