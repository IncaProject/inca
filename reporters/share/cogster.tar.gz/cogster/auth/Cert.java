/* $Id: Cert.java,v 1.1 2007/06/13 15:54:41 rbudden Exp $ */

package cogster.auth;

/*
** Class to encapsulate the location for the
** X.509 certificates and Kerberos tickets.
*/
public class Cert
{
	/* Certificates are normally stored in /tmp/x509up_u$UID */
	private String xfile;
	private String kfile;

	public Cert(int uid)
	{
		this.xfile = "/tmp/x509up_u" + Integer.toString(uid);
		this.kfile = "/tmp/krb5cc_"  + Integer.toString(uid);
	}

	public String getX509() { return (this.xfile); }
	public String getKrbTkt() { return (this.kfile); }
};
