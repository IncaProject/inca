/* $ID$ */
package cogster.common;

import java.util.*;

/* 
** Wrapper for a rudimentary timing class/function.
** It's sad there isn't a better way to do this in j2se
*/
public class Cogtime
{
	Date begin = null;
	Date end = null;

	public Cogtime() {}

	public void start()
	{
		this.begin = new Date();
	}

	public void stop()
	{
		this.end = new Date();
	}

	public long time()
	{
		return this.end.getTime() - this.begin.getTime();
	}

	public String toString()
	{
		return String.valueOf(this.time());
	}
}
