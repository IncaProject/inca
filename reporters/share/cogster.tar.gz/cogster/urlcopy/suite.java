/* $Id: suite.java,v 1.8 2008/03/21 20:36:54 rbudden Exp $ */

import org.globus.gsi.*;
import org.globus.gsi.*;
import org.globus.gsi.gssapi.*;
import org.globus.gsi.gssapi.GlobusGSSCredentialImpl.*;
import org.ietf.jgss.*;
import org.ietf.jgss.GSSCredential.*;
import org.ietf.jgss.GSSException.*;
import org.globus.ftp.*;
import org.globus.io.urlcopy.*;
import org.globus.util.*;

import java.lang.*;
import java.util.*;
import java.io.*;

import cogster.common.*;
import cogster.gridftp.*;
import cogster.auth.*;
import cogster.*;

public class suite
{
	private static HashMap conf = new HashMap();
	private static final String CONF = "../config/gridftp.conf";
	private static Cogtime ct = null;
	private static UrlCopy uc = null;

	public static void main(String[] args)
	{
		/* Config File Options */
		final String FILE1 = "File1";
		final String FILE2 = "File2";
		final String HOST1 = "Host1";
		final String HOST2 = "Host2";
		final String PORT_RANGE = "PortRange";
		final String PORT1 = "Port1";
		final String PORT2 = "Port2";
		final String LOCAL_FILE = "LocalFile";
		final String SCRATCH1 = "Scratch1";
		final String SCRATCH2 = "Scratch2";

		ct = new Cogtime();
		uc = new UrlCopy();

		GlobusURL su1 = null;
		GlobusURL su2 = null;
		
		System.out.println("----------------------------------");
		System.out.println("---UrlCopy Test Suite Beginning---");

		/* Read X509 Cert and create Grid Credentials */
		Auth a = null;
		try
		{
			a = new Auth();
			System.out.println("Suite executing as user: "+a.getGSS().getName());
		} catch(Exception e) {
			Log("FAILED", "Auth()", e);
		}
		System.out.println("----------------------------------");

		/* Read the config file */
		config();

		/* Set the port range (firewall) for PSC */
		String port = conf.get(PORT_RANGE).toString();
		java.lang.System.setProperty("org.globus.tcp.port.range", port);
			
		uc.setCredentials(a.getGSS());

		/* read the config options */
		String f1 = conf.get(FILE1).toString();
		String f2 = conf.get(FILE2).toString();
		String h1 = conf.get(HOST1).toString();
		String h2 = conf.get(HOST2).toString();
		String p1 = conf.get(PORT1).toString();
		String p2 = conf.get(PORT2).toString();

		/* add the port numbers */
		h1 += ":" + p1;
		h2 += ":" + p2;

		/* build the globus urls */
		try
		{
			su1 = new GlobusURL("gsiftp://" + h1 + "/" + f1);
			su2 = new GlobusURL("gsiftp://" + h2 + "/" + f2);

		} catch(Exception e) {

			System.out.println("FATAL ERROR - could not created globus urls");
		}

		/* Third party = true */
		copy_test(su1, su2, true, false);
		copy_test(su1, su2, true, true);

	}

	public static void copy_test(GlobusURL src, GlobusURL dst, boolean tp, boolean dcau)
	{
		String tps = tp == true ? "true" : "false";
		String dcaus = dcau == true ? "true" : "false";

		/* try different variations of urlcopies */
		try
		{
			System.out.println("Transfer: " + src.getURL() + " -> " + dst.getURL());
			uc.setSourceUrl(src);
			uc.setDestinationUrl(dst);
			uc.setUseThirdPartyCopy(tp);
			uc.setDCAU(dcau);
			ct.start();
			uc.copy();
			ct.stop();

			Log("SUCCESS", "UrlCopy: ThirdParty=" + tps + " DCAU=" + dcaus + " in " + ct + " milliseconds", null);
		} catch(Exception e) {
			Log("FAILED", "UrlCopy: ThirdParty=" + tps + " DCAU=" + dcaus, e);
		}
		System.out.println("----------------------------------");
	}

	/* Read the config files and prep for test suite */
	public static void config()
	{
		try
		{
			File f = new File(CONF);
			BufferedReader fin = new BufferedReader(new FileReader(f));
			String line;
			String[] field;

			/*
			** Parse the config file and ignore empty
			** lines and lines beginning with #
			*/
			while((line = fin.readLine()) != null)
			{
				if(line.compareTo("") != 0 && !line.startsWith("#"))
				{
					field = line.split(" ");
					conf.put(field[0], field[1]);
				}
			}
		} catch(Exception e) {
			System.out.println("ERROR!! Problems reading config file: " + e);
			System.exit(1);
		}
	}

	public static void Log(String action, String msg, Exception e)
	{
		System.out.println("---" + action + " " + msg);
		if(e != null)
			System.err.println(e);
	}
}


