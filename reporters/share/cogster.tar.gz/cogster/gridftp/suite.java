/* $Id: suite.java,v 1.20 2008/03/21 19:10:12 rbudden Exp $ */

import org.globus.gsi.*;
import org.globus.gsi.*;
import org.globus.gsi.gssapi.*;
import org.globus.gsi.gssapi.GlobusGSSCredentialImpl.*;
import org.ietf.jgss.*;
import org.ietf.jgss.GSSCredential.*;
import org.ietf.jgss.GSSException.*;
import org.globus.ftp.*;

import java.lang.*;
import java.util.*;
import java.io.*;

import cogster.common.*;
import cogster.gridftp.*;
import cogster.auth.*;
import cogster.*;

public class suite
{
	private static HashMap conf = new HashMap();
	private static final String FILE = "../config/gridftp.conf";
	/* BUF_SIZE = Mbps * rtt * 1000 / 8 */
	private static final int BUF_SIZE = (int)(1000 * 0.342 * 1000 / 8);
	private static Gridftp ftp = null;
	private static Cogtime ct = null; 

	public static void main(String[] args)
	{
		/* Config File Options */
		final String SRCHOST = "Host1";
		final String DSTHOST = "Host2";
		final String SRCFILE = "File1";
		final String DSTFILE = "File2";
		final String PORT_RANGE = "PortRange";
		final String SRCPORT = "Port1";
		final String DSTPORT = "Port2";
		final String STREAMS = "Streams";
		final String LOCALFILE = "LocalFile";
		final String SCRATCH1 = "Scratch1";
		final String SCRATCH2 = "Scratch2";

		ct = new Cogtime();
		
		System.out.println("----------------------------------");
		System.out.println("---GridFTP Test Suite Beginning---");

		/* Read X509 Cert and create Grid Credentials */
		Auth a = null;
		try
		{
			a = new Auth();
			System.out.println("GridFTP suite executing as user: "+a.getGSS().getName());
		} catch(Exception e) {
			Log("FAILED", "Auth()", e);
		}
		System.out.println("----------------------------------");

		/* Read the config file */
		config();

		/* Set the port range (firewall) */
		String port = conf.get(PORT_RANGE).toString();
		java.lang.System.setProperty("org.globus.tcp.port.range", port);
			
		/* Test connections to GridFTP Servers */
		ftp = new Gridftp(a);
		String srch = conf.get(SRCHOST).toString();
		String dsth = conf.get(DSTHOST).toString();

		String sport = conf.get(SRCPORT).toString();
		String dport = conf.get(DSTPORT).toString();

		String srcf = conf.get(SRCFILE).toString();
		String dstf = conf.get(DSTFILE).toString();

		String lfile = conf.get(LOCALFILE).toString();
		String sc1 = conf.get(SCRATCH1).toString();
		String sc2 = conf.get(SCRATCH2).toString();

		System.out.println("#################");
		System.out.println("### TESTING HOST: " + srch);
		System.out.println("#################");
		auth_test(srch, sport);
		try
		{
			ftp.connect(srch, Integer.parseInt(sport));
			nlist_test(list_test(srch));
			ftp.close();
		} catch(Exception e) {
			System.out.println("Unknown error: " + e);
		}
		put_test(srch, sport, lfile, sc1 + "/put");
		get_test(srch, sport, sc1 + "/put", lfile + "-get");

		System.out.println("#################");
		System.out.println("### TESTING HOST: " + dsth);
		System.out.println("#################");
		auth_test(dsth, dport);
		try
		{
			ftp.connect(dsth, Integer.parseInt(dport));
			nlist_test(list_test(dsth));
			ftp.close();
		} catch(Exception e) {
			System.out.println("Unknown error: " + e);
		}
		put_test(dsth, dport, lfile, sc2 + "/put");
		get_test(dsth, dport, sc2 + "/put", lfile + "-get");

		Log("COMPLETED", "GridFTP Test Suite", null);
		System.out.println("----------------------------------");
	}

	public static void auth_test(String srch, String sport)
	{
		/* Test authentication to SrcHost */
		try
		{
			/* GSSCredential authentication */
			ftp.connect(srch, Integer.parseInt(sport));
			Log("SUCCESS", "GridFTP.authenticate(GSS) on SrcHost: "+srch, null);
			ftp.close();
		} catch(Exception e) {
			Log("FAILED", "GridFTP.authenticate(GSS) on SrcHost: "+srch, e);
			Log("FATAL ERROR", "Connection to GridFTP Server Failed", null);
			System.exit(1);
		}
		System.out.println("----------------------------------");
	}
	
	public static String list_test(String srch)
	{
		/* GridFTP.list test */
		String dir = null;
		try
		{
			Vector v = null;
			v = ftp.list();
			listing(v, "~ on " + srch);
			Log("SUCCESS", "GridFTP.list()", null);

			/* Save a directory if there is one found */
			dir = find_dir(v);
		} catch(Exception e) {
			Log("FAILED", "GridFTP.list()", e);
		}
		System.out.println("----------------------------------");
		return dir;
	}

	public static void nlist_test(String dir)
	{

		/* GridFTP.nlist() */
		try
		{
			if(dir != null)
				ftp.nlist(dir);
			else
				ftp.nlist(null);
			Log("SUCCESS", "GridFTP.nlist(" + dir + ")", null);
		} catch(Exception e) {
			Log("FAILED", "GridFTP.nlist(" + dir + ")", e);
		}
		System.out.println("----------------------------------");
	}

	public static void put_test(String host, String port, String srcf, String dstf)
	{
		/* test put */
		try
		{
			ftp.connect(host, Integer.parseInt(port));
			System.out.println("Trying: put(" + srcf + " -> " + dstf + ")");
			ct.start();
			ftp.put(srcf, dstf);
			ct.stop();

			ftp.close();
			Log("SUCCESS", "GridFTP.put() - completed in " + ct + " milliseconds", null);
		} catch(Exception e) {
			Log("FAILED", "GridFTP.put()", e);
		}
		System.out.println("----------------------------------");
	}

	public static void get_test(String host, String port, String remotef, String localf)
	{
		/* Get the file we just transfered */
		try
		{
			ftp.connect(host, Integer.parseInt(port));
			System.out.println("Tryin: get(" + localf + " <- " + remotef);

			ct.start();
			// tack on -ret for we don't destroy the original file
			ftp.get(remotef, localf);
			ct.stop();

			ftp.close();
			Log("SUCCESS", "GridFTP.get() - completed in " + ct + " milliseconds", null);
		} catch(Exception e) {
			Log("FAILED", "GridFTP.get()", e);
		}
		System.out.println("----------------------------------");
	}

	/* Read the GridFTP config files and prep for test suite */
	public static void config()
	{
		try
		{
			File f = new File(FILE);
			BufferedReader fin = new BufferedReader(new FileReader(f));
			String line;
			String[] field;

			/*
			** Parse the config file and ignore empty
			** lines and lines beginning with #
			*/
			while((line = fin.readLine()) != null)
			{
				if(line.compareTo("") != 0 && !line.startsWith("#"))
				{
					field = line.split(" ");
					conf.put(field[0], field[1]);
				}
			}
		} catch(Exception e) {
			System.out.println("ERROR!! Problems reading gridftp config file: " + e);
			System.exit(1);
		}
	}

	/* Print the contents of a directory listing (FileInfo) vector */
	public static void listing(Vector v, String dir)
	{
		FileInfo f;

		System.out.println("\t\tDirectory Listing for '"+dir+"':");
		for(int i = 0; i < v.size(); i++)
		{
			f = (FileInfo)(v.get(i));
			System.out.println("\t\t" + f.getName());
		}
		System.out.println("\n");
	}

	/* Find the first directory in a FileInfo Vector */
	public static String find_dir(Vector v)
	{
		FileInfo f;
		String dir = null;

		for(int i = 0; i < v.size(); i++)
		{
			f = (FileInfo)(v.get(i));

			/* Make sure we don't get . or .. as directories */
			if(f.isDirectory() && f.getName() != "." && f.getName() != "..")
			{
				dir = f.getName();
				break;
			}
		}

		return dir;
	}

	public static void Log(String action, String msg, Exception err)
	{
		System.out.println("---" + action + " " + msg);
		if(err != null)
			System.err.println(err);
	}
}


