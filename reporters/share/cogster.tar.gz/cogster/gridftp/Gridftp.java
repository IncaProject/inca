/* $Id: Gridftp.java,v 1.10 2008/01/21 18:55:23 rbudden Exp $ */

package cogster.gridftp;

import org.globus.gsi.*;
import org.globus.gsi.*;
import org.globus.gsi.gssapi.*;
import org.globus.gsi.gssapi.GlobusGSSCredentialImpl.*;
import org.ietf.jgss.*;
import org.ietf.jgss.GSSCredential.*;
import org.ietf.jgss.GSSException.*;
import java.io.*;

import org.globus.ftp.*;
import cogster.auth.*;
import java.util.*;
import org.globus.ftp.exception.*;

public class Gridftp
{
	private Auth cred = null;
	private GridFTPClient client = null;

	/* default client to active transfers */
	private boolean mode = true;
	private boolean smode = true;
	private int pbuf = 16384;
	private int buf = 0;

	public Gridftp(Auth cred)
	{
		this.cred = cred;
	}

	/* XXX - This class should probably extend to avoid this */
	public GridFTPClient getClient()
	{
		return this.client;
	}

	/* Connection/Authentication */
	public void connect(String host, int port)
		throws IOException, ServerException
	{
		this.client = new GridFTPClient(host, port);
		this.client.authenticate(this.cred.getGSS());
	}

	/* Alternate authentication - XXX from experience this doesn't really seem to work */
	public void connect(String host, int port, String user)
		throws IOException, ServerException
	{
		this.client = new GridFTPClient(host, port);
		this.client.authenticate(this.cred.getGSS(), user);
	}

	public void close()
		throws IOException, ServerException
	{
		this.client.close();
	}

	/* sets whether the local client is active(true) or passive(false) */
	public void setMode(boolean mode, boolean smode)
	{
		this.mode = mode;
		this.smode = smode;
	}

	private void setMode()
		throws IOException, ClientException, ServerException
	{
		this.setMode(this.mode);
	}

	private void setMode(boolean mode)
		throws IOException, ClientException, ServerException
	{
		if(mode)
		{
			this.client.setPassive();
			this.client.setLocalActive();
		}
		else
		{
			this.client.setLocalPassive();
			this.client.setActive();
		}
	}

	private void setStripedMode()
		throws IOException, ClientException, ServerException
	{
		this.setStripedMode(this.smode);
	}

	private void setStripedMode(boolean smode)
		throws IOException, ClientException, ServerException
	{
		if(smode)
		{
			this.client.setStripedPassive();
			this.client.setLocalStripedActive();
		}
		else
		{
			HostPortList hpl;
			hpl = this.client.setLocalStripedPassive();
			this.client.setStripedActive(hpl);
		}
	}

	/* Buffer size settings */
	public void setpbuf(int buf)
	{
		this.pbuf = buf;
	}

	/* Set buf to 0 to use the default buffer sizes */
	public void setbuf(int buf)
	{
		this.buf = buf;
	}

	/* Directory Listing */
	public Vector list()
		throws ServerException, ClientException, IOException
	{
		Vector v = null;
		FileInfo f;

		/* ---------- LIST Commands ---------- */
		/* These essentially do the same thing */
//		v = this.client.list();
		v = this.client.list("*", "-d");
		
		return v;
	}

	public Vector nlist(String dir)
		throws IOException, ClientException, ServerException
	{
		FileInfo f;
		Vector v = null;

		/* ---------- NLST Commands ---------- */
		if(dir != null)
		{
			/* This must be set before calling nlist!!! */
			this.setMode();

			v = this.client.nlist(dir);	
		}

		return v;
	}

	public Vector mlsd(String dir)
		throws ClientException, ServerException, IOException
	{
		Vector v;
//		this.client.setPassive();
//		this.client.setLocalActive();

		v = this.client.mlsd(dir);	

		return v;
	}

	/* Simple file transfer */
	public void put(String path, String dst)
		throws IOException, ServerException, ClientException
	{
		File f = new File(path);

		/* Set client/server to proper passive/active mode */
		this.setMode();

		/* PUT - Gridftp our local file */
		this.client.put(f, dst, false);
	}

	/* Simple get file - path = remote file name, dst - local file destination */
	public void get(String path, String dst)
		throws IOException, ServerException, ClientException
	{
		/* Set client/server to proper passive/active mode */
		this.setMode();

		/* GET - Retrieve the file we just transfered */
		File f = new File(dst);

		this.client.setType(GridFTPSession.TYPE_ASCII);
		this.client.setMode(GridFTPSession.MODE_STREAM);
		this.client.get(path, f);
	}

	/* Extended Block put file transfer */
	public void eput(String path, String dst)
		throws IOException, ServerException, ClientException
	{
		eput(path, dst, 1);
	}

	public void eput(String path, String dst, int par_streams)
		throws IOException, ServerException, ClientException
	{
		/* Extended block requires Image transfer type */
		this.client.setType(GridFTPSession.TYPE_IMAGE);
		this.client.setMode(GridFTPSession.MODE_EBLOCK);

		/* Set the buffer size, authentication, and data protection */
		this.client.setProtectionBufferSize(this.pbuf);
		this.client.setDataChannelAuthentication(DataChannelAuthentication.SELF); 	
		this.client.setDataChannelProtection(GridFTPSession.PROTECTION_SAFE);
			
		/* Parallel Transfer (Number of streams) */
		this.client.setOptions(new RetrieveOptions(par_streams));

		if(this.buf != 0)
		{
			this.client.setTCPBufferSize(this.buf);
			this.client.setLocalTCPBufferSize(this.buf);
		}

		/* This must be set right before calling extendedPut!! */
		this.setStripedMode();

		this.client.extendedPut(dst, new FileRandomIO(new RandomAccessFile(path, "r")), null);
	}

	/* Extended Block get file transfer */
	public void eget(String path, String dst)
		throws IOException, ServerException, ClientException
	{
		eget(path, dst, 1);
	}

	public void eget(String path, String dst, int par_streams)
		throws IOException, ServerException, ClientException
	{
		long size;

		/* Extended block requires Image transfer type */
		this.client.setType(GridFTPSession.TYPE_IMAGE);
		this.client.setMode(GridFTPSession.MODE_EBLOCK);

		/* Set the buffer size, authentication, and data protection */
		this.client.setProtectionBufferSize(this.pbuf);
		this.client.setDataChannelAuthentication(DataChannelAuthentication.SELF); 	
		this.client.setDataChannelProtection(GridFTPSession.PROTECTION_SAFE);
			
		/* Parallel Transfer (Number of Streams) */
		this.client.setOptions(new RetrieveOptions(par_streams));

		/* Grab the size of the file */
		size = this.client.getSize(path);

		if(this.buf != 0)
		{
			this.client.setTCPBufferSize(this.buf);
			this.client.setLocalTCPBufferSize(this.buf);
		}

		/* This must be set right before calling extendedPut!! */
		this.setStripedMode();

		/* We want the whole file perform the transfer offset=0 */
		this.client.extendedGet(path, size, new FileRandomIO(new RandomAccessFile(dst, "rw")), null);
	}

	/* Extended transfer third party style */
	public void transfer(Gridftp dclient, String path, String dst, int par_streams)
		throws IOException, ServerException, ClientException
	{
		long size;

		/* Extended block requires Image transfer type */
		this.client.setType(GridFTPSession.TYPE_IMAGE);
		dclient.client.setType(GridFTPSession.TYPE_IMAGE);

		this.client.setMode(GridFTPSession.MODE_EBLOCK);
		dclient.client.setMode(GridFTPSession.MODE_EBLOCK);

		/* Set the buffer size, authentication, and data protection */
		this.client.setProtectionBufferSize(this.pbuf);
		dclient.client.setProtectionBufferSize(this.pbuf);

		this.client.setDataChannelAuthentication(DataChannelAuthentication.SELF); 	
		dclient.client.setDataChannelAuthentication(DataChannelAuthentication.SELF); 	

		this.client.setDataChannelProtection(GridFTPSession.PROTECTION_SAFE);
		dclient.client.setDataChannelProtection(GridFTPSession.PROTECTION_SAFE);
			
		/* Parallel Transfer (Number of Streams) */
		this.client.setOptions(new RetrieveOptions(par_streams));
		dclient.client.setOptions(new RetrieveOptions(par_streams));

		if(this.buf != 0)
		{
			this.client.setTCPBufferSize(this.buf);
			dclient.client.setTCPBufferSize(this.buf);

			this.client.setLocalTCPBufferSize(this.buf);
			dclient.client.setLocalTCPBufferSize(this.buf);
		}

		/* Set this manually for third party transfers */
		if(this.smode)
		{
			HostPortList hpl = dclient.client.setStripedPassive();
			this.client.setStripedActive(hpl);
		}
		else
		{
			HostPortList hpl = this.client.setStripedPassive();
			dclient.client.setStripedActive(hpl);
		}

		/* We want the whole file perform the transfer offset=0 */
		this.client.extendedTransfer(path, dclient.client, dst, null);
	}
}










