#!/bin/sh

FLAVOR=$1;
JM=$2;

if [ x$FLAVOR == "x" -o x$JM == "x" ]; then
   echo "Usage: $0 <flavor> <jm contact string> "
   echo "Where <flavor> is the flavor to test, and <jm contact string>"
   echo "is a JobManager contact string."
   exit 1;
fi

if [ x$GLOBUS_LOCATION == "x" ]; then
   echo "ERROR: GLOBUS_LOCATION is not set.  Please set GLOBUS_LOCATION to"
   echo "an installation containing your flavor to test."
   exit 2;
fi

if [ x$MPICH_G2_HOME == "x" ]; then
   echo "ERROR: MPICH_G2_HOME is not set.  TG mpich-g2 installations should"
   echo "       have this variable set."
   exit 10;
fi



echo Compiling ring program, output goes to make.out
make > make.out 2>&1
if [ $? -ne 0 ]; then
   echo "ERROR: There was an error compiling the ring program."
   exit 5
fi

echo Running the ring submit script...
./submit.sh $FLAVOR "$JM"
