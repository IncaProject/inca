#!/bin/sh

###########
# set these
###########

# set to control this run
export REMOVERSLFILES=0
export DORUNS=1
export FLAVOR=$1

# set for local machine
export GATEKEEPERJM=$2
export EXTRA_RSL=
export EXTRA_ENV=

export HOSTCOUNTSUFFIX=":ia64-compute"
export USERDIR=`pwd`
export EXECUTABLESUFFIX=$FLAVOR

# probably do not have to change these
export DATE=/bin/date
export ENV=/usr/bin/env
export RM=/bin/rm

################################################
# the rest of the file should remain unchanged
################################################

if [ x$FLAVOR == "x" -o x$GATEKEEPERJM == "x" ]; then
   echo "Usage: $0 <flavor> <gatekeeper> "
   echo "Where <flavor> is the Globus flavor to test"
   echo "and <gatekeeper> is the contact string for the jobmanager."
   exit 1
fi


### ring test
$RM -f $$.ring.rsl
cat > $$.ring.rsl <<EOF
+
( &(resourceManagerContact="$GATEKEEPERJM")
   (count=4)
   (host_count="1$HOSTCOUNTSUFFIX")
   (jobtype=mpi)
   (label="subjob 0")
   (environment=(GLOBUS_DUROC_SUBJOB_INDEX 0))
   (executable=$USERDIR/ring.$EXECUTABLESUFFIX)
   (maxwalltime=1)
   $EXTRA_RSL
)
EOF

if [ $DORUNS == "1" ]; then
    echo "attempting $USERDIR/ring.$EXECUTABLESUFFIX ... "
    globusrun -w -f $$.ring.rsl
    echo "  "
fi

if [ $REMOVERSLFILES == "1" ]; then
    $RM -f $$.ring.rsl
fi
