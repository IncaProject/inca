Globus SAML Library Readme

This library is the Globus Java SAML library derived directly from the 
OpenSAML Java 1.1 codebase (which is henceforth only being maintained 
for security patches) and the SAML2 metadata parsing libraries distributed 
as part of the Shibboleth Java 1.3c codebase.

It is availabe from CVS:
  CVSROOT=:pserver:anonymous@cvs.globus.org:/home/globdev/CVS/globus-packages
  cvs co gridshib/saml/library

For more information, see:
  http://gridshib.globus.org/
  http://www.globus.org/
  http://www.opensaml.org/
  http://shibboleth.internet2.edu/

For a detailed CHANGELOG of how it differs from OpenSAML 1.1, see:
  http://viewcvs.globus.org/viewcvs.cgi/gridshib/saml/library/java/doc/CHANGELOG.txt

For discussion, join one of the gridshib mailing lists:
  http://gridshib.globus.org/support.html

