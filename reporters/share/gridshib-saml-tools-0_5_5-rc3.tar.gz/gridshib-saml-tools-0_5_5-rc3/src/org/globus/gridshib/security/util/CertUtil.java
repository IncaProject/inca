/*
 * Copyright 1999-2007 University of Chicago
 * Copyright 2007-2009 University of Illinois
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

package org.globus.gridshib.security.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.security.auth.Subject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.globus.gridshib.security.SecurityContext;
import org.globus.gridshib.security.SecurityContextFactory;
import org.globus.gridshib.security.x509.NonCriticalX509Extension;
import org.globus.gridshib.security.x509.SAMLX509Extension;

import org.globus.gsi.bc.BouncyCastleUtil;
import org.globus.util.Util;

/**
 * GridShib certificate utilities
 */
public class CertUtil {

    static Log logger = LogFactory.getLog(CertUtil.class.getName());

    /**
     * @return true if and only if the given certificate is an
     *         impersonation proxy
     * @see org.globus.gsi.CertUtil#isImpersonationProxy(int)
     */
    public static boolean isImpersonationProxy(X509Certificate cert)
                                        throws CertificateException {

        if (cert == null) {
            String msg = "Null X509Certificate argument";
            logger.error(msg);
            throw new IllegalArgumentException(msg);
        }

        int certType = BouncyCastleUtil.getCertificateType(cert);
        String msg = "Certificate is " +
            org.globus.gsi.CertUtil.getProxyTypeAsString(certType);
        logger.debug(msg);
        return org.globus.gsi.CertUtil.isImpersonationProxy(certType);
    }

    /**
     * @return true if and only if the given certificate contains
     *         the non-critical extension indicated by the given OID
     *
     * @deprecated This method will be removed in the next
     *             version of the GridShib Security Framework. Use
     * org.globus.gridshib.security.x509.NonCriticalX509Extension.hasNonCriticalExtension(X509Certificate, String)
     * instead
     */
    public static boolean hasNonCriticalExtension(X509Certificate cert,
                                                  String oid) {

        return NonCriticalX509Extension.hasNonCriticalExtension(cert, oid);
    }

    /**
     * @return true if and only if the given certificate contains
     *         the non-critical SAML extension
     *
     * @deprecated This method will be removed in the next
     *             version of the GridShib Security Framework. Use
     * org.globus.gridshib.security.x509.SAMLX509Extension.hasSAMLExtension(X509Certificate)
     * instead
     */
    public static boolean hasSAMLExtension(X509Certificate cert) {

        return SAMLX509Extension.hasSAMLExtension(cert);
    }

    /**
     * Print the DER-encoded octet string for the SAML extension
     * value to stdout.  If the given certificate does not
     * contain such an extension, this method does nothing.
     *
     * @param cert a non-null <code>X509Certificate</code> instance
     *
     * @see #printExtension(X509Certificate, String)
     *
     * @deprecated This method will be removed in the next
     *             version of the GridShib Security Framework.
     */
    public static void printSAMLExtension(X509Certificate cert)
                                   throws IOException {

        printExtension(cert, SAMLX509Extension.OID);
    }

    /**
     * Write the DER-encoded octet string for the SAML extension
     * value to a file with the given filename.  If the given
     * certificate does not contain a SAML extension, this
     * method does nothing.
     *
     * @param cert a non-null <code>X509Certificate</code> instance
     * @param outputFilename a non-null, platform-dependent filename
     *
     * @return true if and only if this method successfully
     *         sets file permissions on the resulting file
     *
     * @see #writeExtensionToFile(X509Certificate, String, String)
     *
     * @deprecated This method will be removed in the next
     *             version of the GridShib Security Framework.
     */
    public static boolean writeSAMLExtensionToFile(X509Certificate cert,
                                                   String outputFilename)
                                            throws SecurityException,
                                                   IOException,
                                                   FileNotFoundException {

        String oid = SAMLX509Extension.OID;
        return writeExtensionToFile(cert, oid, outputFilename);
    }

    /**
     * Write the DER-encoded octet string for the SAML extension
     * value to the given file.  If the given certificate does
     * not contain a SAML extension, this method does nothing.
     *
     * @param cert a non-null <code>X509Certificate</code> instance
     * @param outputFile a non-null, platform-independent
     *        <code>File</code> instance
     *
     * @return true if and only if this method successfully
     *         sets file permissions on the resulting file
     *
     * @see #writeExtensionToFile(X509Certificate, String, File)
     *
     * @deprecated This method will be removed in the next
     *             version of the GridShib Security Framework.
     */
    public static boolean writeSAMLExtensionToFile(X509Certificate cert,
                                                   File outputFile)
                                            throws SecurityException,
                                                   IOException,
                                                   FileNotFoundException {

        String oid = SAMLX509Extension.OID;
        return writeExtensionToFile(cert, oid, outputFile);
    }

    /**
     * Print the DER-encoded octet string for the extension
     * value with the given OID to stdout.  If the given
     * certificate does not contain such an extension, this
     * method does nothing.
     *
     * @param cert a non-null <code>X509Certificate</code> instance
     * @param oid a non-null OID
     *
     * @deprecated This method will be removed in the next
     *             version of the GridShib Security Framework.
     */
    public static void printExtension(X509Certificate cert,
                                      String oid)
                               throws IOException {

        if (cert == null) {
            String msg = "Null argument: X509Certificate cert";
            throw new IllegalArgumentException(msg);
        }
        if (oid == null) {
            String msg = "Null argument: String oid";
            throw new IllegalArgumentException(msg);
        }

        byte[] bytes = cert.getExtensionValue(oid);
        if (bytes == null) { return; }
        System.out.write(bytes);
        System.out.flush();
    }

    /**
     * Write the DER-encoded octet string for the extension
     * value with the given OID to a file with the given filename.
     * If the given certificate does not contain such an extension,
     * this method does nothing.
     *
     * @param cert a non-null <code>X509Certificate</code> instance
     * @param oid a non-null OID
     * @param outputFilename a non-null, platform-dependent filename
     *
     * @return true if and only if this method successfully
     *         sets file permissions on the resulting file
     *
     * @see #writeExtensionToFile(X509Certificate, String, File)
     *
     * @deprecated This method will be removed in the next
     *             version of the GridShib Security Framework.
     */
    public static boolean writeExtensionToFile(X509Certificate cert,
                                               String oid,
                                               String outputFilename)
                                        throws SecurityException,
                                               IOException,
                                               FileNotFoundException {

        if (outputFilename == null) {
            String msg = "Null argument: String outputFilename";
            throw new IllegalArgumentException(msg);
        }

        File outputFile = Util.createFile(outputFilename);
        return writeExtensionToFile(cert, oid, outputFile);
    }

    /**
     * Write the DER-encoded octet string for the extension
     * value with the given OID to the given file.  If the
     * given certificate does not contain such an extension,
     * this method does nothing.
     * <p>
     * For security reasons, this method attempts to set
     * permissions on the resulting file.  If this is
     * successful, the method returns true, otherwise it
     * returns false.  On Windows systems, this method
     * always returns false.
     *
     * @param cert a non-null <code>X509Certificate</code> instance
     * @param oid a non-null OID
     * @param outputFile a non-null, platform-independent
     *        <code>File</code> instance
     *
     * @return true if and only if this method successfully
     *         sets file permissions on the resulting file
     *
     * @deprecated This method will be removed in the next
     *             version of the GridShib Security Framework.
     */
    public static boolean writeExtensionToFile(X509Certificate cert,
                                               String oid,
                                               File outputFile)
                                        throws SecurityException,
                                               IOException,
                                               FileNotFoundException {

        if (cert == null) {
            String msg = "Null argument: X509Certificate cert";
            throw new IllegalArgumentException(msg);
        }
        if (oid == null) {
            String msg = "Null argument: String oid";
            throw new IllegalArgumentException(msg);
        }
        if (outputFile == null) {
            String msg = "Null argument: File outputFile";
            throw new IllegalArgumentException(msg);
        }

        String path = outputFile.getPath();
        boolean result = Util.setOwnerAccessOnly(path);
        if (!result) {
            String str = "Unable to set file permissions: " + path;
            logger.warn(str);
        }

        byte[] bytes = cert.getExtensionValue(oid);
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(outputFile);
            out.write(bytes);
            out.flush();
        } finally {
            if (out != null) {
                try { out.close(); } catch (IOException e) { }
            }
        }

        return result;
    }

    /**
     * Retrieves the X.509 certificate chain of the authenticated user.
     *
     * @param subject a non-null Subject argument
     * @return the certificate chain, possibly null
     */
    public static X509Certificate[] getCertificateChain(Subject subject) {

        if (subject == null) {
            String msg = "Subject is null";
            logger.error(msg);
            throw new IllegalArgumentException(msg);
        }

        SecurityContext secCtx = SecurityContextFactory.getInstance(subject);
        assert (secCtx != null);

        return secCtx.getCertificateChain();
    }

    /**
     * Gets the certificate chain from the security context
     * associated with the given subject and then calls
     * {@link #getEEC(X509Certificate[])}.
     *
     * @param subject the authenticated subject
     * @return an end entity certificate, possibly null
     *
     * @exception java.security.cert.CertificateException
     *            If unable to determine if a certificate is
     *            an impersonation proxy
     */
    public static X509Certificate getEEC(Subject subject)
                                  throws CertificateException {

        X509Certificate[] certs = getCertificateChain(subject);
        if (certs == null) {
            logger.warn("No certificate chain found");
            return null;
        }

        return getEEC(certs);
    }

    /**
     * Gets the End Entity Certificate (EEC) from the given
     * certificate chain.  Actually, this is somewhat of a
     * misnomer since this method returns the first
     * non-impersonation proxy in the chain, which is either
     * an EEC, an independent proxy, or a restricted proxy.
     *
     * @param certs a certificate chain
     * @return an end entity certificate, possibly null
     *
     * @exception java.security.cert.CertificateException
     *            If unable to determine if a certificate is
     *            an impersonation proxy
     */
    public static X509Certificate getEEC(X509Certificate[] certs)
                                  throws CertificateException {

        if (certs == null) {
            String msg = "X509Certificate[] is null";
            logger.error(msg);
            throw new IllegalArgumentException(msg);
        }

        for (int i = 0; i < certs.length; i++) {
            logger.debug("Checking certs[" + i + "]");
            if (!CertUtil.isImpersonationProxy(certs[i])) {
                logger.debug("EEC index is " + i);
                return certs[i];
            }
        }
        logger.warn("Certificate chain did not contain a " +
                    "non-impersonation proxy");
        return null;
    }
}


