A SAML Query Client will be integrated into a future release of the GridShib SAML Tools.

---------------------------
The GridShib Project
http://gridshib.globus.org/
