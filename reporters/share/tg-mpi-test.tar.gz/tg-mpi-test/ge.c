#include <globus_common.h>
#ifdef MPI
#include <mpi.h>
#endif

int main(int argc, char **argv)
{
    char *val;

#ifdef MPI
    MPI_Init(&argc, &argv);
#endif

    if (val = globus_libc_getenv("FOO"))
    {
        globus_libc_printf("env var FOO = %s\n", val);
    }
    else
    {
        globus_libc_printf("ERROR: env var FOO is not set\n");
    }

#ifdef MPI
    MPI_Finalize();
#endif

}
