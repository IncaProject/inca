#include <unistd.h>
#include <globus_duroc_runtime.h>
#include <globus_common.h>

int main(int argc, char **argv)
{
    char hostname[1024];
#if defined(GLOBUS_CALLBACK_GLOBAL_SPACE)
    globus_module_set_args(&argc, &argv);
#endif
    globus_module_activate(GLOBUS_DUROC_RUNTIME_MODULE);
    globus_duroc_runtime_barrier();
    globus_module_deactivate(GLOBUS_DUROC_RUNTIME_MODULE);

    if (globus_libc_gethostname(hostname, 1024))
    {
        globus_libc_fprintf(stderr, 
            "ERROR: failed globus_libc_gethostname()");
        exit(1);
    } /* endif */
    globus_libc_fprintf(stdout, 
	"hello, world: globus_libc_gethostname >%s<\n", 
	hostname);

    if (gethostname(hostname, 1024))
    {
        globus_libc_fprintf(stderr, "ERROR: failed gethostname()");
        exit(1);
    } /* endif */
    globus_libc_fprintf(stdout, "hello, world: gethostname >%s<\n", hostname);
}
