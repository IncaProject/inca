#include <unistd.h>
#include <globus_common.h>

int main(int argc, char **argv)
{
    char hostname[1024];
    if (globus_libc_gethostname(hostname, 1024))
    {
        globus_libc_fprintf(stderr, 
            "ERROR: failed globus_libc_gethostname()");
        exit(1);
    } /* endif */
    globus_libc_fprintf(stdout, "globus_libc_gethostname >%s<\n", hostname);
    if (gethostname(hostname, 1024))
    {
        globus_libc_fprintf(stderr, "ERROR: failed gethostname()");
        exit(1);
    } /* endif */
    globus_libc_fprintf(stdout, "gethostname >%s<\n", hostname);
}
