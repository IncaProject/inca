/* $Id: shmseed.c,v 1.44 2004/12/09 19:05:14 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies.
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office
 * 9500 Gilman Drive
 * 411 University Center
 * University of California
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 */


#include "config.h"
#include "oshseed.h"
#include <stdio.h>  /* sprintf */
#include <stdlib.h> /* free malloc */
#include <string.h> /* memcpy memset strdup */
#define ASSHM_SHORT_NAMES
#include "shmseed.h"


#ifdef ASSHM_HAVE_SHM_H


/*
 * This is an implementation of shmseed using the SysV shm{at,get} functions.
 * The locking mechanism uses F_SETLKW fcntl calls on a unique (named using the
 * client-supplied id) /tmp file.
 */


#include <fcntl.h>    /* fcntl open */
#include <signal.h>   /* signal */
#include <sys/ipc.h>  /* ftok shmat shmget */
#include <sys/shm.h>  /* shmat shmget */
#include <sys/stat.h> /* fchmod open */
#include <sys/time.h> /* setitimer */


/* Permission values for group, others, and owner. */
#define GROUP_READ   0040
#define GROUP_WRITE  0020
#define OTHERS_READ  0004
#define OTHERS_WRITE 0002
#define OWNER_READ   0400
#define OWNER_WRITE  0200
static const mode_t READ_PERMIT[] = {GROUP_READ, OTHERS_READ, OWNER_READ};
static const mode_t WRITE_PERMIT[] = {GROUP_WRITE, OTHERS_WRITE, OWNER_WRITE};


/*
 * #name# is the client-supplied shared memory name.  #lockFileFd# is a file
 * descriptor used to lock memory regions.  #id# is the segment id returned by
 * shmget, #key# the IPC resource key returned by ftok, and #base# the address
 * returned by shmat.
 */
struct ASSHM__SharedMemory {
  char *name;
  int lockFileFd;
  int id;
  key_t key;
  void *base;
};


void
CloseMemory(SharedMemory sm) {

  char *lockFilePath;
  struct shmid_ds shmState;

  shmdt(sm->base);
  close(sm->lockFileFd);
  if(shmctl(sm->id, IPC_STAT, &shmState) == 0 && shmState.shm_nattch == 0) {
    /*
     * All processes have detached, so delete the segment and lock file.  We
     * have a race condition here; a process could attach while we're deleting.
     */
    shmctl(sm->id, IPC_RMID, NULL);
    lockFilePath = (char *)malloc(8 + strlen(sm->name) + 1);
    sprintf(lockFilePath, "/tmp/shm%s", sm->name);
    unlink(lockFilePath);
    free(lockFilePath);
  }
  free(sm->name);
  free(sm);

}


void *
GetBase(SharedMemory sm) {
  return sm->base;
}


int
LockMemory(SharedMemory sm,
           unsigned offset,
           AS_LockTypes how,
           int waitForIt) {
  struct flock flockLock;
  UnlockMemory(sm, offset);
  /* Lock 1 byte #offset# bytes from the beginning of the file. */
  memset(&flockLock, 0, sizeof(flockLock)); /* Make purify happy. */
  flockLock.l_type   = how == AS_READ_LOCK ? F_RDLCK : F_WRLCK;
  flockLock.l_start  = offset;
  flockLock.l_whence = SEEK_SET;
  flockLock.l_len    = 1;
  return fcntl(sm->lockFileFd, waitForIt ? F_SETLKW : F_SETLK, &flockLock) >= 0;
}


SharedMemory
OpenMemory(const char *name,
           unsigned size) {

  char *lockFilePath;
  const int shmgetCreateFlags = OWNER_READ | OWNER_WRITE | IPC_CREAT;
  struct ASSHM__SharedMemory sm;
  SharedMemory result;

  lockFilePath = (char *)malloc(8 + strlen(name) + 1);
  sprintf(lockFilePath, "/tmp/shm%s", name);

  /*
   * In order, try to open the lock file, use its path to create a resource
   * key, use the key to get the shared memory identifier, and attach the
   * shared memory to local memory.
   */
  sm.lockFileFd = open(lockFilePath, O_RDWR, S_IRWXU);
  if(size > 0 && sm.lockFileFd >= 0) {
    close(sm.lockFileFd);
    sm.lockFileFd = -1; /* Duplicate memory */
  }
  else if(size > 0)
    sm.lockFileFd = open(lockFilePath, O_RDWR | O_CREAT, S_IRWXU);
  if(sm.lockFileFd < 0) {
    free(lockFilePath);
    return NULL;
  }
  sm.key = ftok(lockFilePath, 1);
  free(lockFilePath);
  if(sm.key < 0 ||
     (sm.id = shmget(sm.key, size, size > 0 ? shmgetCreateFlags : 0)) < 0 ||
     (sm.base = shmat(sm.id, NULL, 0)) == (void *)-1) {
    close(sm.lockFileFd);
    return NULL;
  }

  sm.name = strdup(name);
  result = (SharedMemory)malloc(sizeof(sm));
  *result = sm;
  return result;

}


int
SetMemoryPermission(SharedMemory sm,
                    AS_Entities who,
                    int allowReading,
                    int allowWriting) {
  struct shmid_ds ds;
  if(shmctl(sm->id, IPC_STAT, &ds) < 0)
    return 0;
  if((allowReading != 0) != ((ds.shm_perm.mode & READ_PERMIT[who])) != 0)
    ds.shm_perm.mode ^= READ_PERMIT[who];
  if((allowWriting != 0) != ((ds.shm_perm.mode & WRITE_PERMIT[who])) != 0)
    ds.shm_perm.mode ^= WRITE_PERMIT[who];
  ds.shm_perm.mode |= READ_PERMIT[AS_OWNER];
  return fchmod(sm->lockFileFd, ds.shm_perm.mode) >= 0 &&
         shmctl(sm->id, IPC_SET, &ds) >= 0;
}


void
UnlockMemory(SharedMemory sm,
             unsigned offset) {
  struct flock flockUnlock;
  /* Unlock 1 byte #offset# bytes from the beginning of the file. */
  memset(&flockUnlock, 0, sizeof(flockUnlock));
  flockUnlock.l_type   = F_UNLCK;
  flockUnlock.l_start  = offset;
  flockUnlock.l_whence = SEEK_SET;
  flockUnlock.l_len    = 1;
  (void)fcntl(sm->lockFileFd, F_SETLK, &flockUnlock);
}


#else
#ifdef WIN32


#define ASV_SHORT_NAMES
#include "vectorseed.h"


/* We use WINAPI over semseed to get to some extended semaphore services. */
typedef HANDLE Semaphore;
const long MAX_READERS = 999; /* Arbitrary limit on concurrent read locks. */
const long MAX_USERS = 2000;  /* ... and on attached processes. */

/*
 * Information about a memory lock.  #how# indicates a read or write lock;
 * #offset# is the memory offset of the locked byte; #readerLock# and
 * #writerLock# govern reader and writer access to the locked memory.
 */
typedef struct {
  AS_LockTypes how;
  unsigned offset;
  Semaphore readerLock;
  Semaphore writerLock;
} LockInfo;

/*
 * #name# is the client-supplied shared memory name.  #lock# is used to
 * serialize the use of the semaphores associated with the memory, avoiding
 * race conditions.  #file# is the shared file, #mapping# the mapping returned
 * by {Create,Open}FileMapping, and #base# the address returned by
 * MapViewOfFile.  #users# contains the count of processes that have the memory
 * open.  #heldLocks# holds information about locks held by this process.
 */
struct ASSHM__SharedMemory {
  char *name;
  Semaphore lock;
  HANDLE file;
  HANDLE mapping;
  void *base;
  Semaphore users;
  LockInfo *heldLocks;
};


void
CloseMemory(SharedMemory sm) {
  int lastUser;
  while(Size(sm->heldLocks) > 0)
    UnlockMemory(sm, sm->heldLocks->offset);
  WaitForSingleObject(sm->lock, INFINITE);
  WaitForSingleObject(sm->users, 0);
  lastUser = WaitForSingleObject(sm->users, 0) != WAIT_OBJECT_0;
  if(!lastUser)
    ReleaseSemaphore(sm->users, 1, NULL);
  UnmapViewOfFile(sm->base);
  CloseHandle(sm->mapping);
  CloseHandle(sm->file);
  CloseHandle(sm->users);
  VectorFree(sm->heldLocks);
  if(lastUser) {
    char *fileName = (char *)malloc(strlen(sm->name) + 6 + 1);
    sprintf(fileName, "%s__file", sm->name);
    DeleteFile(fileName);
    free(fileName);
  }
  free(sm->name);
  ReleaseSemaphore(sm->lock, 1, NULL);
  CloseHandle(sm->lock);
  free(sm);
}


void *
GetBase(SharedMemory sm) {
  return sm->base;
}


int
LockMemory(SharedMemory sm,
           unsigned offset,
           AS_LockTypes how,
           int waitForIt) {

  Semaphore mySem;
  LockInfo newLock;
  char offsetImage[32 + 1];
  char *semName;

  UnlockMemory(sm, offset);
  newLock.how = how;
  newLock.offset = offset;
  WaitForSingleObject(sm->lock, INFINITE);
  sprintf(offsetImage, "%d", offset);
  semName = (char *)malloc(strlen(sm->name) + strlen(offsetImage) + 6 + 1);
  sprintf(semName, "%s%s__read", sm->name, offsetImage);
  if((newLock.readerLock =
        OpenSemaphore(SEMAPHORE_ALL_ACCESS, FALSE, semName)) == NULL &&
     (newLock.readerLock =
        CreateSemaphore(NULL, MAX_READERS, MAX_READERS, semName)) == NULL) {
    ReleaseSemaphore(sm->lock, 1, NULL);
    free(semName);
    return 0;
  }
  free(semName);
  semName = (char *)malloc(strlen(sm->name) + strlen(offsetImage) + 7 + 1);
  sprintf(semName, "%s%d__write", sm->name, offset);
  if((newLock.writerLock =
        OpenSemaphore(SEMAPHORE_ALL_ACCESS, FALSE, semName)) == NULL &&
     (newLock.writerLock = CreateSemaphore(NULL, 1, 1, semName)) == NULL) {
    CloseHandle(newLock.readerLock);
    ReleaseSemaphore(sm->lock, 1, NULL);
    free(semName);
    return 0;
  }
  free(semName);

  mySem = how == AS_READ_LOCK ? newLock.readerLock : newLock.writerLock;
  while(WaitForSingleObject(mySem, 0) != WAIT_OBJECT_0) {
    ReleaseSemaphore(sm->lock, 1, NULL);
    if(WaitForSingleObject(mySem, waitForIt ? INFINITE : 0) == WAIT_TIMEOUT) {
      CloseHandle(newLock.readerLock);
      CloseHandle(newLock.writerLock);
      return 0;
    }
    ReleaseSemaphore(mySem, 1, NULL);
    WaitForSingleObject(sm->lock, INFINITE);
  }

  /* Readers prohibit writer access; writers, reader access. */
  if(how == AS_READ_LOCK)
    WaitForSingleObject(newLock.writerLock, 0);
  else
    while(WaitForSingleObject(newLock.readerLock, 0) == WAIT_OBJECT_0)
      ; /* empty */

  ReleaseSemaphore(sm->lock, 1, NULL);
  Append(sm->heldLocks, newLock);
  return 1;

}


SharedMemory
OpenMemory(const char *name,
           unsigned size) {

  char *fileName;
  char *mapName;
  SharedMemory result;
  struct ASSHM__SharedMemory sm;
  char *semName;

  /* Grab the memory lock long enough to increment the user count. */
  memset(&sm, 0, sizeof(sm));
  semName = (char *)malloc(strlen(name) + 6 + 1);
  sprintf(semName, "%s__lock", name);
  sm.lock = OpenSemaphore(SEMAPHORE_ALL_ACCESS, FALSE, semName);
  if(size > 0) {
    if(sm.lock != NULL) {
      CloseHandle(sm.lock);
      free(semName);
      return NULL; /* Duplicate memory. */
    }
    sm.lock = CreateSemaphore(NULL, 0, 1, semName);
  }
  free(semName);
  if(sm.lock == NULL)
    return NULL;
  if(size == 0)
    WaitForSingleObject(sm.lock, INFINITE);
  semName = (char *)malloc(strlen(name) + 7 + 1);
  sprintf(semName, "%s__users", name);
  sm.users = size > 0 ? CreateSemaphore(NULL, 0, MAX_USERS, semName) :
                        OpenSemaphore(SEMAPHORE_ALL_ACCESS, FALSE, semName);
  free(semName);
  if(sm.users == NULL) {
    ReleaseSemaphore(sm.lock, 1, NULL);
    CloseHandle(sm.lock);
    return NULL;
  }
  ReleaseSemaphore(sm.users, 1, NULL);
  ReleaseSemaphore(sm.lock, 1, NULL);

  fileName = (char *)malloc(strlen(name) + 6 + 1);
  sprintf(fileName, "%s__file", name);
  sm.file = CreateFile
    (fileName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
     NULL, size > 0 ? CREATE_NEW : OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  free(fileName);
  mapName = (char *)malloc(strlen(name) + 5 + 1);
  sprintf(mapName, "%s__map", name);
  sm.mapping = size > 0 ?
    CreateFileMapping(sm.file, NULL, PAGE_READWRITE, 0, size, mapName) :
    OpenFileMapping(FILE_MAP_ALL_ACCESS, FALSE, mapName);
  free(mapName);
  sm.base = MapViewOfFile(sm.mapping, FILE_MAP_ALL_ACCESS, 0, 0, size);
  sm.name = strdup(name);
  sm.heldLocks = VectorNew(LockInfo);

  result = (SharedMemory)malloc(sizeof(sm));
  *result = sm;
  if(sm.file == INVALID_HANDLE_VALUE || sm.mapping == NULL || sm.base == NULL) {
    CloseMemory(result);
    return NULL;
  }
  return result;

}


int
SetMemoryPermission(SharedMemory sm,
                    AS_Entities who,
                    int allowReading,
                    int allowWriting) {
  return 0; /* TODO */
}


void
UnlockMemory(SharedMemory sm,
             unsigned offset) {

  long readerLockValue;
  unsigned i;
  LockInfo lock;

  for(i = 0; i < Size(sm->heldLocks) && sm->heldLocks[i].offset != offset; i++)
    ; /* empty */
  if(i == Size(sm->heldLocks))
    return;

  lock = sm->heldLocks[i];
  WaitForSingleObject(sm->lock, INFINITE);
  if(lock.how == AS_READ_LOCK) {
    /* Allow another reader.  If no readers, allow writer. */
    ReleaseSemaphore(lock.readerLock, 1, &readerLockValue);
    if(readerLockValue + 1 >= MAX_READERS)
      ReleaseSemaphore(lock.writerLock, 1, NULL);
  }
  else {
    /* Allow reader group or another writer. */
    ReleaseSemaphore(lock.readerLock, MAX_READERS, NULL);
    ReleaseSemaphore(lock.writerLock, 1, NULL);
  }

  ReleaseSemaphore(sm->lock, 1, NULL);
  CloseHandle(lock.readerLock);
  CloseHandle(lock.writerLock);
  Remove(sm->heldLocks, i);

}


#else


void
CloseMemory(SharedMemory sm) {
}


void *
GetBase(SharedMemory sm) {
  return NULL;
}


int
LockMemory(SharedMemory sm,
           unsigned offset,
           AS_LockTypes how,
           int waitForIt) {
  return 0;
}


SharedMemory
OpenMemory(const char *name,
           unsigned size) {
  return NULL;
}


int
SetMemoryPermission(SharedMemory sm,
                    AS_Entities who,
                    int allowReading,
                    int allowWriting) {
  return 0;
}


void
UnlockMemory(SharedMemory sm,
             unsigned offset) {
}


#endif
#endif


/*
 * This shared heap implementation links all of the heap into an intermixed
 * list of free and allocated blocks.  Each block begins with a unsigned int
 * size field, which means that, on machines with four-byte ints, blocks cannot
 * exceed 2^32 - 1 bytes, of which 2^32 - 5 is available to the user.  (Since
 * the entire heap is initially a single free block, this limit also applies to
 * the total memory size, although this restriction could be removed by
 * initially dividing the memory into multiple blocks.)  Every block contains
 * an even number of bytes (reducing the maximum block size by 1); this allows
 * the least-significant bit in the size field to indicate whether the block is
 * allocated (set) or free (clear).  Block allocation is done on a first-fit
 * basis, and merging of adjacent free blocks is done during block allocation.
 */


#define BLOCK_TO_DATA(b) ((char *)b + blockOverhead)
#define DATA_TO_BLOCK(d) ((BlockSizeType *)((char *)d - blockOverhead))
#define HEAP_TO_BLOCK(b,o) ((BlockSizeType *)((char *)b + o))
#define IN_USE(b) ODD(*b)
#define NEXT_BLOCK(b) ((BlockSizeType *)((char *)b + *b - ODD(*b)))
#define ODD(n) ((n) & 1)
typedef unsigned BlockSizeType;


/*
 * Determine CPU alignment requirements/preferences by testing how much padding
 * the compiler adds to a struct in order to force double alignment.
 */
struct AlignmentChecker {
  double aligned;
  char excess;
};
#define PADDING (sizeof(struct AlignmentChecker)-sizeof(double)-sizeof(char))
static const unsigned int alignment = PADDING + 1;
static const unsigned int blockOverhead =
  sizeof(BlockSizeType) + sizeof(BlockSizeType) % (PADDING + 1);


/*
 * Tries to allocate room for #size# total bytes from #block# and subsequent
 * free blocks.  Returns 1 if successful, else 0.
 */
static int
AllocateBlock(BlockSizeType *block,
              unsigned size) {

  BlockSizeType *nextBlock;
  BlockSizeType remnantSize;

  while(*block < size) {
    nextBlock = NEXT_BLOCK(block);
    if(IN_USE(nextBlock))
      return 0;
    *block += *nextBlock;
  }

  /* Split the block unless the remnant is too small for a size field. */
  remnantSize = *block - size;
  if(remnantSize > blockOverhead) {
    *block = (BlockSizeType)size;
    *NEXT_BLOCK(block) = remnantSize;
  }

  *block |= 1; /* Set in-use bit. */
  return 1;

}


/* Returns the number of bytes needed to hold overhead and #size# data bytes. */
static unsigned
AllocationSize(unsigned size) {
  /*
   * Leave room for the size indicator, reserve the low-order bit as a used
   * flag, and make sure the next block is properly aligned.
   */
  unsigned remainder;
  size += blockOverhead;
  if(ODD(size))
    size++;
  remainder = alignment - size % alignment;
  if(remainder != alignment)
    size += remainder;
  return size;
}


void *
CopyIntoHeap(SharedHeap heap,
             const void *data,
             unsigned size) {

  unsigned allocSize = AllocationSize(size);
  BlockSizeType *block;
  void *returnValue;

  LockMemory(heap.sm, heap.offset, AS_READ_WRITE_LOCK, 1);
  for(block = HEAP_TO_BLOCK(GetBase(heap.sm), heap.offset);
      IN_USE(block) || !AllocateBlock(block, allocSize);
      block = NEXT_BLOCK(block))
    ; /* empty */
  UnlockMemory(heap.sm, heap.offset);
  returnValue = BLOCK_TO_DATA(block);
  if(data != NULL)
    memcpy(returnValue, data, size);
  return returnValue;

}


void
FreeInHeap(SharedHeap heap,
           void *garbage) {
  (*DATA_TO_BLOCK(garbage))--; /* Clear in-use bit. */
}


SharedHeap
OpenHeap(SharedMemory sm,
         unsigned offset,
         unsigned size) {
  SharedHeap returnValue;
  returnValue.sm = sm;
  returnValue.offset = offset;
  if(size > 0)
    *HEAP_TO_BLOCK(GetBase(sm), offset) = size;
  return returnValue;
}


void *
ReallocateInHeap(SharedHeap heap,
                 void *data,
                 unsigned size) {

  BlockSizeType *block;
  void *returnValue;

  if(data == NULL)
    return size == 0 ? NULL : AllocateInHeap(heap, size);
  else if(size == 0) {
    FreeInHeap(heap, data);
    return NULL;
  }

  block = DATA_TO_BLOCK(data);
  LockMemory(heap.sm, heap.offset, AS_READ_WRITE_LOCK, 1);
  returnValue = AllocateBlock(block, AllocationSize(size)) ? data : NULL;
  UnlockMemory(heap.sm, heap.offset);

  if(returnValue == NULL) {
    returnValue = AllocateInHeap(heap, size);
    memcpy(returnValue, data, *block - blockOverhead);
    (*block)--; /* Free old block. */
  }

  return returnValue;

}
