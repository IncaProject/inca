/* $Id: oshseed.h,v 1.15 2003/12/04 18:58:47 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#ifndef OSHSEED_H
#define OSHSEED_H


/*
 * This package attempts to encapsulate the different #include requirements
 * of Unix, Windows and their various flavors.  It is by no means complete;
 * new items are added as the need arises.  #include this file instead of
 * either <unistd.h> or <windows.h>.
 */


#ifdef __cplusplus
extern "C" {
#endif


#ifdef WIN32

#  include <windows.h>
#  include <io.h>
#  include <process.h>
#  include <direct.h>

#  define pipe(ints) _pipe(ints, 1024, 0)
#  define sleep(secs) Sleep((secs) * 1000)
#  define pid_t int
#  define strcasecmp _stricmp
#  define strncasecmp _strnicmp
#  define bcmp(s1,s2,n) memcmp((s1), (s2), (n))
#  define bcopy(src,dest,n) memcpy((dest), (src), (n))
#  define bzero(s,n) memset((s), 0, (n))
#  define pclose _pclose
#  define popen _popen
#  define ASOSH_FILE_PATH_SEPARATOR "\\"
#  define ASOSH_PATH_LIST_SEPARATOR ";"
#  define ASOSH_SWITCH_CHARACTER "/"

#else

#  include <sys/types.h>
#  include <unistd.h>
#  include <strings.h>
#  define ASOSH_FILE_PATH_SEPARATOR "/"
#  define ASOSH_PATH_LIST_SEPARATOR ":"
#  define ASOSH_SWITCH_CHARACTER "-"

#endif


#ifndef NULL
#  define NULL 0
#endif


#ifdef __cplusplus
}
#endif


#endif
