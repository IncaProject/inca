/* $Id: xmlseed.h,v 1.32 2003/12/16 14:11:13 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#ifndef XMLSEED_H
#define XMLSEED_H


/*
 * This package defines a minimal, lightweight XML parser that implements the
 * DOM Level 2 Core and XML modules as well as the Level 2 Traversal module.
 * In the descriptions below, declarations that implement a feature specified
 * in the DOM Level 1 Core or XML modules are marked [DOM], those that
 * implement a feature added in the DOM Level 2 Core or XML modules are marked
 * [DOM2], those from the Traversal module are marked [DOMT] and those included
 * for convenience or extensions are marked [nonDOM] and [nonDOMT].
 */


#ifdef __cplusplus
extern "C" {
#endif


/* [DOM] A character string. */
typedef char *ASXML_DOMString;
/*
 * [DOM2] A number of milliseconds.  Defined in the DOM core but referenced
 * only in modules (like Events) not implemented by this package, so it really
 * doesn't matter what definition we use.
 */
typedef struct {
  char bytes[8];
} ASXML_DOMTimeStamp;

/*
 * [DOM] Exceptions raised by DOM functions.  Currently unused by this package
 * but defined for future use.
 */
typedef enum {
  ASXML_INDEX_SIZE_ERR = 1, ASXML_DOMSTRING_SIZE_ERR,
  ASXML_HIERARCHY_REQUEST_ERR, ASXML_WRONG_DOCUMENT_ERR,
  ASXML_INVALID_CHARACTER_ERR, ASXML_NO_DATA_ALLOWED_ERR,
  ASXML_NO_MODIFICATION_ALLOWED_ERR, ASXML_NOT_FOUND_ERR,
  ASXML_NOT_SUPPORTED_ERR, ASXML_INUSE_ATTRIBUTE_ERR,
  /* [DOM2] */
  ASXML_INVALID_STATE_ERR, ASXML_SYNTAX_ERR, ASXML_INVALID_MODIFICATION_ERR,
  ASXML_NAMESPACE_ERR, ASXML_INVALID_ACCESS_ERR
} ASXML_DOMException;

/* [nonDOM] Errors returned by ASXML_XmlFromStream when something goes wrong. */
typedef enum {
  ASXML_INVALID_CLOSING_TAG = 1,   /* Opening/closing name mismatch */
  ASXML_MISSING_CLOSE,             /* Markup closer (e.g. "-->") expected */
  ASXML_MISSING_CLOSING_TAG,       /* </ expected */
  ASXML_MISSING_EQ,                /* = expected after attribute name */
  ASXML_MISSING_NAME,              /* XML name expected */
  ASXML_MISSING_STRING,            /* Quoted string expected */
  ASXML_MISSING_TOP_TAG,           /* Empty document */
  ASXML_MULTIPLE_TOP_TAGS,         /* More than 1 top level tag */
  ASXML_UNKNOWN_CONTENT,           /* Unrecognized item in <!ELEMENT */
  ASXML_UNKNOWN_TAG                /* Unrecognized tag after <! */
} ASXML_XmlParseErrorCodes;

/*
 * [DOM] Different types of XML nodes.  A quick rundown for newbies: element
 * nodes represent tags like <p>; attribute nodes are the attributes of element
 * nodes; text nodes contain everything in between tags--everything that's not
 * within <>; cdata section nodes are another way of specifying text; entity
 * reference and entity nodes are a sort of XML macro facility; processing
 * instruction nodes contain parameterization for the XML parser and/or client;
 * comment nodes contain XML comments; the single document node sits at the top
 * of a parsed XML tree; the single document type node contains information
 * about the DTD for the document; document fragment nodes provide a way of
 * breaking an XML tree into subtrees and replacing pieces of it; notation
 * nodes contains processing information for the XML parser or application.
 */
typedef enum {
  ASXML_ELEMENT_NODE = 1, ASXML_ATTRIBUTE_NODE, ASXML_TEXT_NODE,
  ASXML_CDATA_SECTION_NODE, ASXML_ENTITY_REFERENCE_NODE, ASXML_ENTITY_NODE,
  ASXML_PROCESSING_INSTRUCTION_NODE, ASXML_COMMENT_NODE, ASXML_DOCUMENT_NODE,
  ASXML_DOCUMENT_TYPE_NODE, ASXML_DOCUMENT_FRAGMENT_NODE, ASXML_NOTATION_NODE
} ASXML_XmlNodeTypes;

/* [DOM] Basic data type. */
typedef void *ASXML_XmlImplementation;
/* [DOM] Basic data type. */
typedef struct ASXML__XmlNodeStruct *ASXML_XmlNode;

/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlAttr;
/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlCharacterData;
/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlDocument;
/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlDocumentFragment;
/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlDocumentType;
/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlElement;
/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlEntity;
/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlEntityReference;
/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlNotation;
/* [DOM] "Child class" of ASXML_XmlNode. */
typedef ASXML_XmlNode ASXML_XmlProcessingInstruction;

/* [DOM] "Child class" of ASXML_XmlCharacterData */
typedef ASXML_XmlCharacterData ASXML_XmlComment;
/* [DOM] "Child class" of ASXML_XmlCharacterData */
typedef ASXML_XmlCharacterData ASXML_XmlText;
/* [DOM] "Child class" of ASXML_XmlCharacterData */
typedef ASXML_XmlText ASXML_XmlCdataSection;

/*
 * [nonDOM] Entity/DTD reader for ASXML_XmlFromStream.  External reading is not
 * currently supported; this declaration is a placeholder.
 */
typedef void (*ASXML_XmlExternalReader)(void);

/*
 * [nonDOM] A callback function for ASXML_XmlFromStream.  Returns the next byte
 * from the input stream #stream#, or a value <= 0 if no more bytes are
 * available.  Note that the system function fgetc conforms to this signature,
 * so it can be used directly in a call to ASXML_XmlFromStream.
 */
typedef int (*ASXML_XmlGet)(void *stream);

/* [DOMT] Return values for ASXML_XmlNodeFilter. */
typedef enum {
  ASXML_FILTER_ACCEPT = 1, ASXML_FILTER_REJECT, ASXML_FILTER_SKIP
} ASXML_XmlNodeFilterResultTypes;
/* [DOMT] Filter function for ASXML_XmlNodeInterator. */
typedef ASXML_XmlNodeFilterResultTypes(*ASXML_XmlNodeFilter)(ASXML_XmlNode);

/* [DOMT] Filter type bit values for ASXML_XmlNodeIterator. */
typedef enum {
  ASXML_SHOW_ELEMENT = 1, ASXML_SHOW_ATTRIBUTE = 2, ASXML_SHOW_TEXT = 4,
  ASXML_SHOW_CDATA_SECTION = 8, ASXML_SHOW_ENTITY_REFERENCE = 0x10,
  ASXML_SHOW_ENTITY = 0x20, ASXML_SHOW_PROCESSING_INSTRUCTION = 0x40,
  ASXML_SHOW_COMMENT = 0x80, ASXML_SHOW_DOCUMENT = 0x100,
  ASXML_SHOW_DOCUMENT_TYPE = 0x200, ASXML_SHOW_DOCUMENT_FRAGMENT = 0x400,
  ASXML_SHOW_NOTATION = 0x800 } ASXML_XmlNodeFilterShowTypes;
const static unsigned long ASXML_SHOW_ALL = 0xFFFFFFFF;

/* [DOMT] Traversal type. */
typedef struct ASXML__XmlNodeIteratorStruct *ASXML_XmlNodeIterator;
/* [DOMT] Traversal type. */
typedef ASXML_XmlNodeIterator ASXML_XmlTreeWalker;
/* [DOM] Collection type. */
typedef struct ASXML__XmlNamedNodeMapStruct *ASXML_XmlNamedNodeMap;
/* [DOM] Collection type. */
typedef ASXML_XmlNodeIterator ASXML_XmlNodeList;


/* === Node/Tree creation/destruction === */


/*
 * [nonDOM] Returns a new #type# node owned by #doc# that contains copies of
 * #name# and #value#.  #uri#, if non-NULL, is the namespace URI for the node.
 * The returned node is not part of the XML tree, but it can be made part of
 * the tree via, e.g., ASXML_NodeAppendChild.
 */
ASXML_XmlNode
ASXML_DocumentCreateNode(ASXML_XmlDocument doc,
                         ASXML_XmlNodeTypes type,
                         ASXML_DOMString uri,
                         ASXML_DOMString name,
                         ASXML_DOMString value);

/* [DOM] Creation methods for individual node types. */
#define ASXML_DocumentCreateAttribute(doc,name) \
  ASXML_DocumentCreateNode(doc, ASXML_ATTRIBUTE_NODE, 0, name, "")
#define ASXML_DocumentCreateCdataSection(doc,data) \
  ASXML_DocumentCreateNode \
    (doc, ASXML_CDATA_SECTION_NODE, 0, "#cdata-section", data)
#define ASXML_DocumentCreateComment(doc,data) \
  ASXML_DocumentCreateNode(doc, ASXML_COMMENT_NODE, 0, "#comment", data)
#define ASXML_DocumentCreateDocumentFragment(doc) \
  ASXML_DocumentCreateNode \
    (doc, ASXML_DOCUMENT_FRAGMENT_NODE, 0, "#document-fragment", 0)
#define ASXML_DocumentCreateElement(doc,tagname) \
  ASXML_DocumentCreateNode(doc, ASXML_ELEMENT_NODE, 0, tagname, 0)
#define ASXML_DocumentCreateEntityReference(doc,name) \
  ASXML_DocumentCreateNode(doc, ASXML_ENTITY_REFERENCE_NODE, 0, name, 0)
#define ASXML_DocumentCreateProcessingInstruction(doc,target,data) \
  ASXML_DocumentCreateNode \
    (doc, ASXML_PROCESSING_INSTRUCTION_NODE, 0, target, data)
#define ASXML_DocumentCreateTextNode(doc,data) \
  ASXML_DocumentCreateNode(doc, ASXML_TEXT_NODE, 0, "#text", data)

/* [DOM2] Document creation methods added in DOM level 2. */
#define ASXML_DocumentCreateAttributeNS(doc,uri,qualified) \
  ASXML_DocumentCreateNode(doc, ASXML_ATTRIBUTE_NODE, uri, qualified, "")
#define ASXML_DocumentCreateElementNS(doc,uri,qualified) \
  ASXML_DocumentCreateNode(doc, ASXML_ELEMENT_NODE, uri, qualified, 0)


/*
 * [DOMT] Creates a node iterator to traverse the subtree of #doc# rooted at
 * #root#.  The iterator will return from the subtree those nodes that have a
 * type included in #whatToShow# that pass a call to #filter# (if #filter# is
 * not NULL).  #whatToShow# is constructed by bitwise-ORing values from
 * ASXML_XmlFilterShowTypes.  #expand# indicates whether or not entity
 * reference nodes are expanded when traversing the subtree.
 */
ASXML_XmlNodeIterator
ASXML_DocumentCreateNodeIterator(ASXML_XmlDocument doc,
                                 ASXML_XmlNode root,
                                 unsigned long whatToShow,
                                 ASXML_XmlNodeFilter filter,
                                 int expand);


/*
 * [DOMT] Creates a tree walker to traverse the subtree of #doc# rooted at
 * #root#.  The walker will return from the subtree those nodes that have a
 * type included in #whatToShow# that pass a call to #filter# (if #filter# is
 * not NULL).  #whatToShow# is constructed by bitwise-ORing values from
 * ASXML_XmlFilterShowTypes.  #expand# indicates whether or not entity
 * reference nodes are expanded when traversing the subtree.
 */
ASXML_XmlTreeWalker
ASXML_DocumentCreateTreeWalker(ASXML_XmlDocument doc,
                               ASXML_XmlNode root,
                               unsigned long whatToShow,
                               ASXML_XmlNodeFilter filter,
                               int expand);

/*
 * [DOM2] Returns a copy of #node# that is owned by #doc#.  Any attributes of
 * the node are copied as well.  If #deep# is true, any children of #node# are
 * recursively cloned and attached as children of the copy.
 */
ASXML_XmlNode
ASXML_DocumentImportNode(ASXML_XmlDocument doc,
                         ASXML_XmlNode node,
                         int deep);


/* [DOM2] Creates and returns a new document node. */
ASXML_XmlDocument
ASXML_ImplementationCreateDocument(ASXML_XmlImplementation imp,
                                   ASXML_DOMString uri,
                                   ASXML_DOMString qualified,
                                   ASXML_XmlDocumentType doctype);


/* [DOM2] Creates and returns a new document type node. */
ASXML_XmlDocumentType
ASXML_ImplementationCreateDocumentType(ASXML_XmlImplementation imp,
                                       ASXML_DOMString qualified,
                                       ASXML_DOMString publicId,
                                       ASXML_DOMString systemId);


/*
 * [DOM] Returns a copy of #node#.  Any attributes of the node are copied as
 * well.  If #deep# is true, any children of #node# are recursively cloned and
 * attached as children of the copy.
 */
ASXML_XmlNode
ASXML_NodeCloneNode(ASXML_XmlNode node,
                    int deep);


/*
 * [nonDOM] Frees the space occupied by #node# and its descendents after first
 * removing any references to it in the document.
 */
void
ASXML_NodeFree(ASXML_XmlNode node);


/*
 * [nonDOM] Attempts to create an XML node tree from the bytes returned by
 * successive calls to #get# passing #getParam#.  If successful, returns the
 * document node at the head of the tree.  If #s# contains a syntax error,
 * returns NULL and stores the error and its offset into #s# in #error# and
 * #errorOffset#, if these are not NULL.  DOMStrings within the returned
 * document are stored in #encoding# form. If #discardComments# is true,
 * comment nodes are discarded during parsing.  If #discardWhitespace# is true,
 * leading and trailing whitespace is discarded from text nodes, and text nodes
 * consisting of nothing but whitespace are discarded entirely.  If #reader# is
 * non-NULL, it will be called to retrieve external portions of the DTD;
 * otherwise, a default reader is used.
 */
ASXML_XmlDocument
ASXML_XmlFromStream(ASXML_XmlGet get,
                    void *getParam,
                    char *encoding,
                    int discardComments,
                    int discardWhitespace,
                    ASXML_XmlExternalReader reader,
                    ASXML_XmlParseErrorCodes *error,
                    unsigned long *errorOffset);


/*
 * A convenience function for parsing XML in memory.  Sets up a stream to read
 * the contents of #s# and calls #ASXML_XmlFromStream#.
 */
ASXML_XmlDocument
ASXML_XmlFromString(ASXML_DOMString s,
                    char *encoding,
                    int discardComments,
                    int discardWhitespace,
                    ASXML_XmlExternalReader reader,
                    ASXML_XmlParseErrorCodes *error,
                    unsigned long *errorOffset);


/*
 * [nonDOM] Returns in an allocated string text representing the contents of
 * #node#.  If #indent# is not NULL, "pretty-prints" the output by putting tags
 * on new lines and using repetitions of #indent# to indicate nesting.
 */
ASXML_DOMString 
ASXML_XmlToString(ASXML_XmlNode node,
                  ASXML_DOMString indent);


/* === Information about nodes === */


/* [DOM2] Returns 1 if #node# has at least one attribute, else 0. */
int
ASXML_NodeHasAttributes(ASXML_XmlNode node);


/*
 * [DOM2] Returns 1 if the implementation that generated #node# supports
 * version #version# of #feature#, else 0.
 */
#define ASXML_NodeIsSupported(node,feature,version) \
  ASXML_ImplementationHasFeature(ASXML_DocumentImplementation( \
    ASXML_NodeOwnerDocument(node)),feature,version)


/*
 * [DOM2] Returns the local portion of the name of #node#, or NULL if #node#'s
 * name is not qualified.
 */
ASXML_DOMString
ASXML_NodeLocalName(ASXML_XmlNode node);


/* [DOM] Returns the name property of #node#. */
ASXML_DOMString 
ASXML_NodeName(ASXML_XmlNode node);


/* [DOM2] Returns the namespace associated with #node#; NULL if none. */
ASXML_DOMString
ASXML_NodeNamespaceUri(ASXML_XmlNode node);


/* [DOM2] Returns the prefix portion of #node#'s name; NULL if none. */
ASXML_DOMString
ASXML_NodePrefix(ASXML_XmlNode node);


/* [DOM] Returns the type property of #node#. */
ASXML_XmlNodeTypes
ASXML_NodeType(ASXML_XmlNode node);


/*
 * [DOM] Returns the value property of #node#.  Only attribute, cdata section,
 * comment, processing instruction and text nodes have a value; the function
 * returns NULL for other node types.
 */
ASXML_DOMString 
ASXML_NodeValue(ASXML_XmlNode node);


/* [DOM] Returns the name of #attr#. */
#define ASXML_AttrName(attr) ASXML_NodeName(attr)


/* [DOM2] Returns the element that owns #attr#, NULL if none. */
ASXML_XmlElement
ASXML_AttrOwnerElement(ASXML_XmlAttr attr);


/* [DOM] Returns 0 if #attr# appears because of a DTD default value, else 1. */
int
ASXML_AttrSpecified(ASXML_XmlAttr attr);


/* [DOM] Returns the value of #attr#. */
#define ASXML_AttrValue(attr) ASXML_NodeValue(attr)


/* [DOM] Returns the data (value) of #cd#. */
#define ASXML_CharacterDataData(cd) ASXML_NodeValue(cd)


/* [DOM] Returns the number of characters in the data of #cd#. */
unsigned long
ASXML_CharacterDataLength(ASXML_XmlCharacterData cd);


/*
 * [DOM] A convenience function that returns #count# characters from #cd#'s
 * value beginning at position #offset# in an allocated string.
 */
ASXML_DOMString 
ASXML_CharacterDataSubstringData(ASXML_XmlCharacterData cd,
                                 unsigned long offset,
                                 unsigned long count);


/* [nonDOM] Returns the character encoding used in #doc#. */
char *
ASXML_DocumentEncoding(ASXML_XmlDocument doc);


/* [nonDOM] Returns 1 if #doc# has been validated, else 0. */
int
ASXML_DocumentIsValid(ASXML_XmlDocument doc);


/* [nonDOM] Convert all DOMStrings in #doc# to #e#. */
void
ASXML_DocumentSetEncoding(ASXML_XmlDocument doc,
                          char *encoding);


/* [DOM] Returns the internal subset of #dtd#. */
ASXML_DOMString
ASXML_DocumentTypeInternalSubset(ASXML_XmlDocumentType dtd);


/* [DOM] Returns the name of #dtd#. */
#define ASXML_DocumentTypeName(dtd) ASXML_NodeName(dtd)


/* [DOM2] Returns the public id of #dtd#. */
ASXML_DOMString
ASXML_DocumentTypePublicId(ASXML_XmlDocumentType dtd);


/* [DOM2] Returns the system id of #dtd#. */
ASXML_DOMString
ASXML_DocumentTypeSystemId(ASXML_XmlDocumentType dtd);


/*
 * [DOM] Shorthand for ASXML_AttrValue(ASXML_ElementGetAttributeNode
 * (elem, name)).  Returns "" if #node# has no attribute named #name#.
 */
#define ASXML_ElementGetAttribute(elem,name) \
  ASXML_ElementGetAttributeNS(elem, 0, name)


/*
 * [DOM2] Shorthand for ASXML_AttrValue(ASXML_ElementGetAttributeNodeNS
 * (elem, uri, local)).  Returns "" if #node# has no attribute with local name
 * #local# and namespace URI #uri#.
 */
ASXML_DOMString 
ASXML_ElementGetAttributeNS(ASXML_XmlElement elem,
                            ASXML_DOMString uri,
                            ASXML_DOMString local);


/* [DOM] Returns the attribute of #elem# that has name #name#; NULL if none. */
#define ASXML_ElementGetAttributeNode(elem,name) \
  ASXML_ElementGetAttributeNodeNS(elem, 0, name)


/*
 * [DOM2] Returns the attribute of #elem# that has local name #local# and
 * namespace #uri#, NULL if none.
 */
#define ASXML_ElementGetAttributeNodeNS(elem,uri,local) \
  ASXML_NamedNodeMapGetNamedItemNS(ASXML_NodeAttributes(elem), uri, local)


/* [DOM2] Returns 1 if #elem# has a #name# attribute, else 0. */
#define ASXML_ElementHasAttribute(elem,name) \
  ASXML_ElementHasAttributeNS(elem, 0, name)


/*
 * [DOM2] Returns 1 if #elem# has an attribute with local name #name# and
 * namespace #uri#, else 0.
 */
#define ASXML_ElementHasAttributeNS(elem,uri,local) \
  (ASXML_ElementGetAttributeNodeNS(elem, uri, local) != 0)


/* [DOM] Returns the name of #elem#. */
#define ASXML_ElementTagName(elem) ASXML_NodeName(elem)


/* [DOM] Returns the notation name of #ent#, NULL if none. */
ASXML_DOMString
ASXML_EntityNotationName(ASXML_XmlEntity ent);


/* [DOM] Returns the public id of #ent#, NULL if none. */
ASXML_DOMString
ASXML_EntityPublicId(ASXML_XmlEntity ent);


/* [DOM] Returns the system id of #ent#, NULL if none. */
ASXML_DOMString
ASXML_EntitySystemId(ASXML_XmlEntity ent);


/* [DOM] Returns 1 if version #version# of #feature# is supported, else 0. */
int
ASXML_ImplementationHasFeature(ASXML_XmlImplementation imp,
                               ASXML_DOMString feature,
                               ASXML_DOMString version);


/* [DOM] Returns the public id of #notation#, NULL if none. */
ASXML_DOMString
ASXML_NotationPublicId(ASXML_XmlNotation notation);


/* [DOM] Returns the system id of #notation#, NULL if none. */
ASXML_DOMString
ASXML_NotationSystemId(ASXML_XmlNotation notation);


/* [DOM] Returns the data of #pi#--everything between the target and ?>. */
#define ASXML_ProcessingInstructionData(pi) ASXML_NodeValue(pi)


/* [DOM] Returns the target of #pi#--the first word after the <?. */
#define ASXML_ProcessingInstructionTarget(pi) ASXML_NodeName(pi)


/* === Tree traversal === */


/* [DOM] Returns the first child of #node#; NULL if none. */
#define ASXML_NodeFirstChild(node) \
  ASXML_NodeFirstChildByType(node, ASXML_SHOW_ALL)


/*
 * [nonDOM] Returns the first child of #node# that is of one of the types
 * included in #whatTypes#, NULL if none.  #whatType# is constructed by
 * bitwise-ORing values from ASXML_XmlFilterShowTypes.
 */
ASXML_XmlNode
ASXML_NodeFirstChildByType(ASXML_XmlNode node,
                           unsigned long whatTypes);


/* [DOM] Returns 1 if #node# has at least one child, else 0. */
#define ASXML_NodeHasChildNodes(node) ASXML_NodeFirstChild(node) != 0


/* [DOM] Returns the last child of #node#; NULL if none. */
ASXML_XmlNode
ASXML_NodeLastChild(ASXML_XmlNode node);


/* [DOM] Returns the next (right) sibling of #node#; NULL if none. */
#define ASXML_NodeNextSibling(node) \
  ASXML_NodeNextSiblingByType(node, ASXML_SHOW_ALL)


/*
 * [nonDOM] Returns the first right sibling of #node# that is of one of the
 * types included in #whatTypes#, NULL if none.  #whatType# is constructed by
 * bitwise-ORing values from ASXML_XmlFilterShowTypes.
 */
ASXML_XmlNode
ASXML_NodeNextSiblingByType(ASXML_XmlNode node,
                            unsigned long whatTypes);


/* [DOM] Returns the document associated with #node#. */
ASXML_XmlDocument
ASXML_NodeOwnerDocument(ASXML_XmlNode node);


/* [DOM] Returns the parent of #node#; NULL if none. */
ASXML_XmlNode
ASXML_NodeParentNode(ASXML_XmlNode node);


/* [DOM] Returns the prior (left) sibling of #node#; NULL if none. */
ASXML_XmlNode
ASXML_NodePreviousSibling(ASXML_XmlNode node);


/* [DOM] Returns the DTD for #doc#, NULL if none. */
#define ASXML_DocumentDoctype(doc) \
  ASXML_NodeFirstChildByType(doc, ASXML_SHOW_DOCUMENT_TYPE)


/* [DOM] Returns the element child of #doc# that heads the XML tree. */
#define ASXML_DocumentElement(doc) \
  ASXML_NodeFirstChildByType(doc, ASXML_SHOW_ELEMENT)


/* [DOM] Returns the XmlImplementation object associated with this document. */
#define ASXML_DocumentImplementation(doc) 0


/* === Node collections === */


/* [DOM] Returns the #n#th element from #map#, NULL if #map# isn't that long. */
ASXML_XmlNode
ASXML_NamedNodeMapItem(ASXML_XmlNamedNodeMap map,
                       unsigned long n);


/* [DOM] Returns the number of items in #map#. */
unsigned long
ASXML_NamedNodeMapLength(ASXML_XmlNamedNodeMap map);


/* [DOM] Returns the element from #map# that has name #name#, NULL if none. */
#define ASXML_NamedNodeMapGetNamedItem(map,name) \
  ASXML_NamedNodeMapGetNamedItemNS(map, 0, name)


/*
 * [DOM2] Returns the element from #map# that has local name #local# and
 * namespace #uri#, NULL if none.
 */
ASXML_XmlNode
ASXML_NamedNodeMapGetNamedItemNS(ASXML_XmlNamedNodeMap map,
                                 ASXML_DOMString uri,
                                 ASXML_DOMString local);


/* [DOM] Returns a map that contains the attributes of #node#. */
ASXML_XmlNamedNodeMap
ASXML_NodeAttributes(ASXML_XmlNode node);


/* [DOM] Returns a list that contains the children of #node#. */
ASXML_XmlNodeList
ASXML_NodeChildNodes(ASXML_XmlNode node);


/*
 * [nonDOM] Returns a list of all element descendants of #node# named #name#.
 * If #name# is "*", the list contains element descendants with all tag names.
 */
#define ASXML_NodeGetElementsByTagName(node,name) \
  ASXML_NodeGetElementsByTagNameNS(node, 0, name)


/*
 * [nonDOM] Returns a list of all element decendants of #node# named #local#
 * that are within namespace #uri#.  If #uri# is "*", the list contains element
 * decendants from all namespaces; if #local# is "*", the list contains element
 * decendants with all tag names.
 */
ASXML_XmlNodeList
ASXML_NodeGetElementsByTagNameNS(ASXML_XmlNode node,
                                 ASXML_DOMString uri,
                                 ASXML_DOMString local);


/* [DOM2] Returns the element node within #doc# whose id is #elementId#. */
ASXML_XmlElement
ASXML_DocumentGetElementById(ASXML_DOMString id);


/*
 * [DOM] Returns a list of all element descendants of #doc# named #name#.  If
 * #name# is "*", the list contains element descendants with all tag names.
 */
#define ASXML_DocumentGetElementsByTagName(doc,name) \
  ASXML_DocumentGetElementsByTagNameNS(doc, 0, name)
                                              

/*
 * [DOM2] Returns a list of all element decendants of #doc# named #local# that
 * are within namespace #uri#.  If #uri# is "*", the list contains element
 * decendants from all namespaces; if #local# is "*", the list contains element
 * decendants with all tag names.
 */
#define ASXML_DocumentGetElementsByTagNameNS(doc,uri,local) \
  ASXML_NodeGetElementsByTagNameNS(doc, uri, local)


/* [DOM] Returns the general entities defined in #dtd#. */
ASXML_XmlNamedNodeMap
ASXML_DocumentTypeEntities(ASXML_XmlDocumentType dtd);


/* [DOM] Returns the notations defined in #dtd#. */
ASXML_XmlNamedNodeMap
ASXML_DocumentTypeNotations(ASXML_XmlDocumentType dtd);


/*
 * [DOM] Returns a list of all element descendants of #elem# named #name#.  If
 * #name# is "*", the list contains element descendants with all tag names.
 */
#define ASXML_ElementGetElementsByTagName(elem,name) \
  ASXML_ElementGetElementsByTagNameNS(elem, 0, name)


/*
 * [DOM2] Returns a list of all element decendants of #elem# named #local#
 * that are within namespace #uri#.  If #uri# is "*", the list contains element
 * decendants from all namespaces; if #local# is "*", the list contains element
 * decendants with all tag names.
 */
#define ASXML_ElementGetElementsByTagNameNS(elem,uri,local) \
  ASXML_NodeGetElementsByTagNameNS(elem, uri, local)


/* [DOMT] Frees the resources used by #it#. */
#define ASXML_NodeIteratorDetach(it) ASXML_NodeIteratorFree(it)


/* [DOMT] Returns the expand parameter passed when #it# was created. */
int
ASXML_NodeIteratorExpandEntityReferences(ASXML_XmlNodeIterator it);


/* [DOMT] Returns the filter parameter passed when #it# was created. */
ASXML_XmlNodeFilter
ASXML_NodeIteratorFilter(ASXML_XmlNodeIterator it);


/* [nonDOMT] Frees the resources used by #it#. */
void
ASXML_NodeIteratorFree(ASXML_XmlNodeIterator it);


/* [nonDOMT] Returns the #n#th item in #it#, NULL if none. */
ASXML_XmlNode
ASXML_NodeIteratorItem(ASXML_XmlNodeIterator it,
                       unsigned long n);


/* [nonDOMT] Returns the number of items in #it#. */
unsigned long
ASXML_NodeIteratorLength(ASXML_XmlNodeIterator it);


/*
 * [DOMT] Returns the next node from #it# that passes its whatToShow value and
 * filter function; NULL if none.
 */
ASXML_XmlNode
ASXML_NodeIteratorNextNode(ASXML_XmlNodeIterator it);


/*
 * [DOMT] Returns the prior node from #it# that passes its whatToShow value and
 * filter function; NULL if none.
 */
ASXML_XmlNode
ASXML_NodeIteratorPreviousNode(ASXML_XmlNodeIterator it);


/* [DOMT] Returns the root parameter passed when #it# was created. */
ASXML_XmlNode
ASXML_NodeIteratorRoot(ASXML_XmlNodeIterator it);


/* [DOMT] Returns the whatToShow parameter passed when #it# was created. */
unsigned long
ASXML_NodeIteratorWhatToShow(ASXML_XmlNodeIterator it);


/* [nonDOM] Frees resources used by #list#. */
#define ASXML_NodeListFree(list) ASXML_NodeIteratorFree(list)


/* [DOM] Returns the #n#th item in #list#, NULL if #list# isn't that long. */
#define ASXML_NodeListItem(list,n) ASXML_NodeIteratorItem(list, n)


/* [DOM] Returns the number of items in #list#. */
#define ASXML_NodeListLength(list) ASXML_NodeIteratorLength(list)


/* [DOMT] Returns the current node of #tw#. */
ASXML_XmlNode
ASXML_TreeWalkerCurrentNode(ASXML_XmlTreeWalker tw);


/* [DOMT] Returns the expand parameter passed when #tw# was created. */
#define ASXML_TreeWalkerExpandEntityReferences(tw) \
  ASXML_NodeIteratorExpandEntityReferences(tw)


/* [DOMT] Returns the filter parameter passed when #tw# was created. */
#define ASXML_TreeWalkerFilter(tw) ASXML_NodeIteratorFilter(tw)


/*
 * [DOMT] Advances #tw# to the first child of its current node that passes its
 * filters and returns that node.  Returns NULL and leaves the current node
 * unchanged if no child passes the filters.
 */
ASXML_XmlNode
ASXML_TreeWalkerFirstChild(ASXML_XmlTreeWalker tw);


/* [nonDOMT] Frees the resources used by #tw#. */
#define ASXML_TreeWalkerFree(tw) ASXML_NodeIteratorFree(tw)


/* [nonDOMT] Returns the #n#th item in #tw#, NULL if none. */
#define ASXML_TreeWalkerItem(tw,n) ASXML_NodeIteratorItem(tw, n)


/*
 * [DOMT] Advances #tw# to the last child of its current node that passes its
 * filters and returns that node.  Returns NULL and leaves the current node
 * unchanged if no child passes the filters.
 */
ASXML_XmlNode
ASXML_TreeWalkerLastChild(ASXML_XmlTreeWalker tw);


/* [nonDOMT] Returns the number of items in #tw#. */
#define ASXML_TreeWalkerLength(tw) ASXML_NodeIteratorLength(tw)


/*
 * [DOMT] Returns the next node from #tw# that passes its whatToShow value and
 * filter function; NULL if none.
 */
#define ASXML_TreeWalkerNextNode(tw) ASXML_NodeIteratorNextNode(tw)


/*
 * [DOMT] Advances #tw# to the next sibling of its current node that passes
 * its filters and returns that node.  Returns NULL and leaves the current node
 * unchanged if no subsequent sibling passes the filters.
 */
ASXML_XmlNode
ASXML_TreeWalkerNextSibling(ASXML_XmlTreeWalker tw);


/*
 * [DOMT] Advances #tw# to the first ancestor of its current node that passes
 * its filters and returns that node.  Returns NULL and leaves the current node
 * unchanged if no ancestor passes the filters.
 */
ASXML_XmlNode
ASXML_TreeWalkerParentNode(ASXML_XmlTreeWalker tw);


/*
 * [DOMT] Returns the prior node from #tw# that passes its whatToShow value and
 * filter function; NULL if none.
 */
#define ASXML_TreeWalkerPreviousNode(tw) ASXML_NodeIteratorPreviousNode(tw)


/*
 * [DOMT] Advances #tw# to the prior sibling of its current node that passes
 * its filters and returns that node.  Returns NULL and leaves the current node
 * unchanged if no prior sibling passes the filters.
 */
ASXML_XmlNode
ASXML_TreeWalkerPreviousSibling(ASXML_XmlTreeWalker tw);


/* [DOMT] Returns the root parameter passed when #tw# was created. */
#define ASXML_TreeWalkerRoot(tw) ASXML_NodeIteratorRoot(tw)


/* [DOMT] Sets the current node of #tw# to #node#. */
void
ASXML_TreeWalkerSetCurrentNode(ASXML_XmlTreeWalker tw,
                               ASXML_XmlNode node);


/* [DOMT] Returns the whatToShow parameter passed when #tw# was created. */
#define ASXML_TreeWalkerWhatToShow(tw) ASXML_NodeIteratorWhatToShow(tw)


/* === Node/Tree editing === */


/* [nonDOM] Removes #node# from #map#. */
ASXML_XmlNode
ASXML_NamedNodeMapRemoveItem(ASXML_XmlNamedNodeMap map,
                             ASXML_XmlNode node);


/* [DOM] Removes and returns any item named #name# from #map#. */
#define ASXML_NamedNodeMapRemoveNamedItem(map,name) \
  ASXML_NamedNodeMapRemoveNamedItemNS(map, 0, name)


/* [DOM2] Returns and returns any item named #local# within #uri# from #map#. */
ASXML_XmlNode
ASXML_NamedNodeMapRemoveNamedItemNS(ASXML_XmlNamedNodeMap map,
                                    ASXML_DOMString uri,
                                    ASXML_DOMString local);


/* [DOM] Adds #node# as an item in #map#, associated with its name. */
#define ASXML_NamedNodeMapSetNamedItem(map,node) \
  ASXML_NamedNodeMapSetNamedItemNS(map, node)


/* [DOM2] Adds #node# as an item in #map#, associated with its name and URI. */
ASXML_XmlNode
ASXML_NamedNodeMapSetNamedItemNS(ASXML_XmlNamedNodeMap map,
                                 ASXML_XmlNode node);


/* [DOM] Appends #newChild# to the end of #node#'s child list. */
#define ASXML_NodeAppendChild(node,newChild) \
  ASXML_NodeInsertBefore(node, newChild, 0)


/*
 * [nonDOM] Inserts #newChild# after #oldChild# in #node#'s list of children,
 * or at the beginning of the list of #oldChild# is NULL.  Returns #newChild#.
 */
ASXML_XmlNode
ASXML_NodeInsertAfter(ASXML_XmlNode node,
                      ASXML_XmlNode newChild,
                      ASXML_XmlNode oldChild);


/*
 * [DOM] Inserts #newChild# before #oldChild# in #node#'s list of children, or
 * at the end of the list if #oldChild# is NULL.  Returns #newChild#.
 */
ASXML_XmlNode
ASXML_NodeInsertBefore(ASXML_XmlNode node,
                       ASXML_XmlNode newChild,
                       ASXML_XmlNode oldChild);


/* [DOM2] Combines adjacent pairs of text descendants of #node#. */
void
ASXML_NodeNormalize(ASXML_XmlNode node);


/* [DOM] Removes #child# from #node#'s list of children.  Returns #child#. */
ASXML_XmlNode
ASXML_NodeRemoveChild(ASXML_XmlNode node,
                      ASXML_XmlNode child);


/*
 * [DOM] Replaces #oldChild# in #node#'s list of children with #newChild#.
 * Returns #oldChild#.
 */
ASXML_XmlNode
ASXML_NodeReplaceChild(ASXML_XmlNode node,
                       ASXML_XmlNode newChild,
                       ASXML_XmlNode oldChild);


/* [DOM2] Replaces the prefix portion of #node#'s name with #prefix#. */
void
ASXML_NodeSetPrefix(ASXML_XmlNode node,
                    ASXML_DOMString prefix);


/*
 * [nonDOM] Replaces the namespace URI of #node#, if any, with #uri#.  Deletes
 * #node#'s namespace URI if #uri# is NULL.
 */
void
ASXML_NodeSetNamespaceUri(ASXML_XmlNode node,
                          ASXML_DOMString uri);


/* [DOM] Replaces the value of #node# with #s#. */
void
ASXML_NodeSetValue(ASXML_XmlNode node,
                   ASXML_DOMString s);


/* [DOM] Replaces the value of #attr# with #s#. */
#define ASXML_AttrSetValue(attr,s) ASXML_NodeSetValue(attr, s)


/* [DOM] Appends #s# to the value of #cd#. */
void
ASXML_CharacterDataAppendData(ASXML_XmlCharacterData cd,
                              ASXML_DOMString s);


/*
 * [DOM] Deletes #count# characters from #cd#'s value beginning at #offset#.
 * The range to be deleted may extend past the end of the value, in which case
 * all characters from #offset# onward are deleted.
 */
void
ASXML_CharacterDataDeleteData(ASXML_XmlCharacterData cd,
                              unsigned long offset,
                              unsigned long count);


/* [DOM] Inserts #s# into #cd#'s value at position #offset#. */
void
ASXML_CharacterDataInsertData(ASXML_XmlCharacterData cd,
                              unsigned long offset,
                              ASXML_DOMString s);


/*
 * [DOM] Replaces #count# characters of #cd#'s value starting at #offset# with
 * #s#.
 */
void
ASXML_CharacterDataReplaceData(ASXML_XmlCharacterData cd,
                               unsigned long offset,
                               unsigned long count,
                               ASXML_DOMString s);


/* [DOM] Replaces #cd#'s value with #s#. */
#define ASXML_CharacterDataSetData(cd,s) ASXML_NodeSetValue(cd, s)


/* [DOM] Removes any attribute named #name# from #elem#'s attributes. */
#define ASXML_ElementRemoveAttribute(elem,name) \
  ASXML_ElementRemoveAttributeNS(elem, 0, name)


/*
 * [DOM2] Removes any attribute named #name# in namespace #uri# from #elem#'s
 * attributes.
 */
#define ASXML_ElementRemoveAttributeNS(elem,uri,local) \
  ASXML_NamedNodeMapRemoveNamedItemNS(ASXML_NodeAttributes(elem), uri, local)


/* [DOM] Removes #attr# from #elem#'s attributes; returns #attr#. */
#define ASXML_ElementRemoveAttributeNode(elem,attr) \
  ASXML_NamedNodeMapRemoveItem(ASXML_NodeAttributes(elem), attr)


/* [DOM] Adds a pairing for #name# and #value# to #elem#'s attributes. */
#define ASXML_ElementSetAttribute(elem,name,value) \
  ASXML_ElementSetAttributeNS(elem, 0, name, value)


/*
 * [DOM2] Adds a pairing for #qualified# within namespace #uri# and #value#
 * to #elem#'s attributes.
 */
void
ASXML_ElementSetAttributeNS(ASXML_XmlElement elem,
                            ASXML_DOMString uri,
                            ASXML_DOMString qualified,
                            ASXML_DOMString value);


/*
 * [DOM] Adds #attr# to #elem#'s attributes.  If an old attribute exists with
 * the same name, returns it.  Otherwise returns NULL.
 */
#define ASXML_ElementSetAttributeNode(elem,attr) \
  ASXML_ElementSetAttributeNodeNS(elem, attr)


/*
 * [DOM2] Adds #attr# to #elem#'s attributes.  If an old attribute exists with
 * the same name and namespace, returns it.  Otherwise returns NULL.
 */
#define ASXML_ElementSetAttributeNodeNS(elem,attr) \
  ASXML_NamedNodeMapSetNamedItemNS(ASXML_NodeAttributes(elem), attr)


/* [DOM] Replaces the data of #pi# with #data#. */
#define ASXML_ProcessingInstructionSetData(pi,data) ASXML_NodeSetValue(pi, data)


/*
 * [DOM] Moves the characters of #text#'s value, beginning at position #offset#
 * into a new node, which becomes #text#'s right sibling.  Returns the new node.
 * Note that this function can be applied to a cdata section node, in which
 * case the new node is also of type cdata section.  Returns the new node.
 */
ASXML_XmlText
ASXML_TextSplitText(ASXML_XmlText text,
                    unsigned long offset);


#ifdef ASXML_SHORT_NAMES

#define DOMString ASXML_DOMString
#define UTF_8 ASXML_UTF_8
#define UTF_16 ASXML_UTF_16
#define DOMTimeStamp ASXML_DOMTimeStamp

#define INDEX_SIZE_ERR ASXML_INDEX_SIZE_ERR
#define DOMSTRING_SIZE_ERR ASXML_DOMSTRING_SIZE_ERR
#define HIERARCHY_REQUEST_ERR ASXML_HIERARCHY_REQUEST_ERR
#define WRONG_DOCUMENT_ERR ASXML_WRONG_DOCUMENT_ERR
#define INVALID_CHARACTER_ERR ASXML_INVALID_CHARACTER_ERR
#define NO_DATA_ALLOWED_ERR ASXML_NO_DATA_ALLOWED_ERR
#define NO_MODIFICATION_ALLOWED_ERR ASXML_NO_MODIFICATION_ALLOWED_ERR
#define NOT_FOUND_ERR ASXML_NOT_FOUND_ERR
#define NOT_SUPPORTED_ERR ASXML_NOT_SUPPORTED_ERR
#define INUSE_ATTRIBUTE_ERR ASXML_INUSE_ATTRIBUTE_ERR
#define INVALID_STATE_ERR ASXML_INVALID_STATE_ERR
#define SYNTAX_ERR ASXML_SYNTAX_ERR
#define INVALID_MODIFICATION_ERR ASXML_INVALID_MODIFICATION_ERR
#define NAMESPACE_ERR ASXML_NAMESPACE_ERR
#define INVALID_ACCESS_ERR ASXML_INVALID_ACCESS_ERR
#define DOMException ASXML_DOMException

#define INVALID_CLOSING_TAG ASXML_INVALID_CLOSING_TAG
#define MISSING_CLOSE ASXML_MISSING_CLOSE
#define MISSING_CLOSING_TAG ASXML_MISSING_CLOSING_TAG
#define MISSING_EQ ASXML_MISSING_EQ
#define MISSING_MARKUP ASXML_MISSING_MARKUP
#define MISSING_NAME ASXML_MISSING_NAME
#define MISSING_STRING ASXML_MISSING_STRING
#define MISSING_TOP_TAG ASXML_MISSING_TOP_TAG
#define MULTIPLE_TOP_TAGS ASXML_MULTIPLE_TOP_TAGS
#define UNKNOWN_CONTENT ASXML_UNKNOWN_CONTENT
#define UNKNOWN_TAG ASXML_UNKNOWN_TAG
#define XmlParseErrorCodes ASXML_XmlParseErrorCodes

#define ELEMENT_NODE ASXML_ELEMENT_NODE
#define ATTRIBUTE_NODE ASXML_ATTRIBUTE_NODE
#define TEXT_NODE ASXML_TEXT_NODE
#define CDATA_SECTION_NODE ASXML_CDATA_SECTION_NODE
#define ENTITY_REFERENCE_NODE ASXML_ENTITY_REFERENCE_NODE
#define ENTITY_NODE ASXML_ENTITY_NODE
#define PROCESSING_INSTRUCTION_NODE ASXML_PROCESSING_INSTRUCTION_NODE
#define COMMENT_NODE ASXML_COMMENT_NODE
#define DOCUMENT_NODE ASXML_DOCUMENT_NODE
#define DOCUMENT_TYPE_NODE ASXML_DOCUMENT_TYPE_NODE
#define DOCUMENT_FRAGMENT_NODE ASXML_DOCUMENT_FRAGMENT_NODE
#define NOTATION_NODE ASXML_NOTATION_NODE
#define XmlNodeTypes ASXML_XmlNodeTypes

#define XmlImplementation ASXML_XmlImplementation
#define XmlNode ASXML_XmlNode
#define XmlAttr ASXML_XmlAttr
#define XmlCharacterData ASXML_XmlCharacterData
#define XmlDocument ASXML_XmlDocument
#define XmlDocumentFragment ASXML_XmlDocumentFragment
#define XmlDocumentType ASXML_XmlDocumentType
#define XmlElement ASXML_XmlElement
#define XmlEntity ASXML_XmlEntity
#define XmlEntityReference ASXML_XmlEntityReference
#define XmlNotation ASXML_XmlNotation
#define XmlProcessingInstruction ASXML_XmlProcessingInstruction
#define XmlComment ASXML_XmlComment
#define XmlText ASXML_XmlText
#define XmlCdataSection ASXML_XmlCdataSection

#define FILTER_ACCEPT ASXML_FILTER_ACCEPT
#define FILTER_REJECT ASXML_FILTER_REJECT
#define FILTER_SKIP ASXML_FILTER_SKIP
#define XmlNodeFilterResultTypes ASXML_XmlNodeFilterResultTypes
#define XmlNodeFilter ASXML_XmlNodeFilter

#define XmlExternalReader ASXML_XmlExternalReader
#define XmlGet ASXML_XmlGet

#define SHOW_ELEMENT ASXML_SHOW_ELEMENT
#define SHOW_ATTRIBUTE ASXML_SHOW_ATTRIBUTE
#define SHOW_TEXT ASXML_SHOW_TEXT
#define SHOW_CDATA_SECTION ASXML_SHOW_CDATA_SECTION
#define SHOW_ENTITY_REFERENCE ASXML_SHOW_ENTITY_REFERENCE
#define SHOW_ENTITY ASXML_SHOW_ENTITY
#define SHOW_PROCESSING_INSTRUCTION ASXML_SHOW_PROCESSING_INSTRUCTION
#define SHOW_COMMENT ASXML_SHOW_COMMENT
#define SHOW_DOCUMENT ASXML_SHOW_DOCUMENT
#define SHOW_DOCUMENT_TYPE ASXML_SHOW_DOCUMENT_TYPE
#define SHOW_DOCUMENT_FRAGMENT ASXML_SHOW_DOCUMENT_FRAGMENT
#define SHOW_NOTATION ASXML_SHOW_NOTATION
#define SHOW_ALL ASXML_SHOW_ALL
#define XmlFilterShowTypes ASXML_XmlFilterShowTypes

#define XmlNamedNodeMap ASXML_XmlNamedNodeMap
#define XmlNodeIterator ASXML_XmlNodeIterator
#define XmlNodeList ASXML_XmlNodeList
#define XmlTreeWalker ASXML_XmlTreeWalker

#define DocumentCreateNode ASXML_DocumentCreateNode
#define DocumentCreateAttribute ASXML_DocumentCreateAttribute
#define DocumentCreateCdataSection ASXML_DocumentCreateCdataSection
#define DocumentCreateComment ASXML_DocumentCreateComment
#define DocumentCreateDocumentFragment ASXML_DocumentCreateDocumentFragment
#define DocumentCreateElement ASXML_DocumentCreateElement
#define DocumentCreateEntityReference ASXML_DocumentCreateEntityReference
#define DocumentCreateProcessingInstruction \
  ASXML_DocumentCreateProcessingInstruction
#define DocumentCreateTextNode ASXML_DocumentCreateTextNode
#define DocumentCreateAttributeNS ASXML_DocumentCreateAttributeNS
#define DocumentCreateElementNS ASXML_DocumentCreateElementNS
#define DocumentCreateNodeIterator ASXML_DocumentCreateNodeIterator
#define DocumentCreateTreeWalker ASXML_DocumentCreateTreeWalker
#define DocumentImportNode ASXML_DocumentImportNode
#define ImplementationCreateDocument ASXML_ImplementationCreateDocument
#define ImplementationCreateDocumentType ASXML_ImplementationCreateDocumentType
#define NodeCloneNode ASXML_NodeCloneNode
#define NodeFree ASXML_NodeFree
#define XmlFromStream ASXML_XmlFromStream
#define XmlFromString ASXML_XmlFromString
#define XmlToString ASXML_XmlToString

#define NodeHasAttributes ASXML_NodeHasAttributes
#define NodeIsSupported ASXML_NodeIsSupported
#define NodeLocalName ASXML_NodeLocalName
#define NodeName ASXML_NodeName
#define NodeNamespaceUri ASXML_NodeNamespaceUri
#define NodePrefix ASXML_NodePrefix
#define NodeType ASXML_NodeType
#define NodeValue ASXML_NodeValue
#define AttrName ASXML_AttrName
#define AttrOwnerElement ASXML_AttrOwnerElement
#define AttrSpecified ASXML_AttrSpecified
#define AttrValue ASXML_AttrValue
#define CharacterDataData ASXML_CharacterDataData
#define CharacterDataLength ASXML_CharacterDataLength
#define CharacterDataSubstringData ASXML_CharacterDataSubstringData
#define DocumentEncoding ASXML_DocumentEncoding
#define DocumentIsValid ASXML_DocumentIsValid
#define DocumentSetEncoding ASXML_DocumentSetEncoding
#define DocumentTypeInternalSubset ASXML_DocumentTypeInternalSubset
#define DocumentTypeName ASXML_DocumentTypeName
#define DocumentTypePublicId ASXML_DocumentTypePublicId
#define DocumentTypeSystemId ASXML_DocumentTypeSystemId
#define ElementGetAttribute ASXML_ElementGetAttribute
#define ElementGetAttributeNS ASXML_ElementGetAttributeNS
#define ElementGetAttributeNode ASXML_ElementGetAttributeNode
#define ElementGetAttributeNodeNS ASXML_ElementGetAttributeNodeNS
#define ElementHasAttribute ASXML_ElementHasAttribute
#define ElementHasAttributeNS ASXML_ElementHasAttributeNS
#define ElementTagName ASXML_ElementTagName
#define EntityNotationName ASXML_EntityNotationName
#define EntityPublicId ASXML_EntityPublicId
#define EntitySystemId ASXML_EntitySystemId
#define ImplementationHasFeature ASXML_ImplementationHasFeature
#define NotationPublicId ASXML_NotationPublicId
#define NotationSystemId ASXML_NotationSystemId
#define ProcessingInstructionData ASXML_ProcessingInstructionData
#define ProcessingInstructionTarget ASXML_ProcessingInstructionTarget

#define NodeFirstChild ASXML_NodeFirstChild
#define NodeFirstChildByType ASXML_NodeFirstChildByType
#define NodeHasChildNodes ASXML_NodeHasChildNodes
#define NodeLastChild ASXML_NodeLastChild
#define NodeNextSibling ASXML_NodeNextSibling
#define NodeNextSiblingByType ASXML_NodeNextSiblingByType
#define NodeOwnerDocument ASXML_NodeOwnerDocument
#define NodeParentNode ASXML_NodeParentNode
#define NodePreviousSibling ASXML_NodePreviousSibling
#define DocumentDoctype ASXML_DocumentDoctype
#define DocumentElement ASXML_DocumentElement
#define DocumentImplementation ASXML_DocumentImplementation

#define NamedNodeMapItem ASXML_NamedNodeMapItem
#define NamedNodeMapLength ASXML_NamedNodeMapLength
#define NamedNodeMapGetNamedItem ASXML_NamedNodeMapGetNamedItem
#define NamedNodeMapGetNamedItemNS ASXML_NamedNodeMapGetNamedItemNS
#define NodeAttributes ASXML_NodeAttributes
#define NodeChildNodes ASXML_NodeChildNodes
#define NodeGetElementsByTagName ASXML_NodeGetElementsByTagName
#define NodeGetElementsByTagNameNS ASXML_NodeGetElementsByTagNameNS
#define DocumentGetElementById ASXML_DocumentGetElementById
#define DocumentGetElementsByTagName ASXML_DocumentGetElementsByTagName
#define DocumentGetElementsByTagNameNS ASXML_DocumentGetElementsByTagNameNS
#define DocumentTypeEntities ASXML_DocumentTypeEntities
#define DocumentTypeNotations ASXML_DocumentTypeNotations
#define ElementGetElementsByTagName ASXML_ElementGetElementsByTagName
#define ElementGetElementsByTagNameNS ASXML_ElementGetElementsByTagNameNS
#define NodeIteratorDetach ASXML_NodeIteratorDetach
#define NodeIteratorExpandEntityReferences \
  ASXML_NodeIteratorExpandEntityReferences
#define NodeIteratorFilter ASXML_NodeIteratorFilter
#define NodeIteratorFree ASXML_NodeIteratorFree
#define NodeIteratorItem ASXML_NodeIteratorItem
#define NodeIteratorLength ASXML_NodeIteratorLength
#define NodeIteratorNextNode ASXML_NodeIteratorNextNode
#define NodeIteratorPreviousNode ASXML_NodeIteratorPreviousNode
#define NodeIteratorRoot ASXML_NodeIteratorRoot
#define NodeIteratorWhatToShow ASXML_NodeIteratorWhatToShow
#define NodeListFree ASXML_NodeListFree
#define NodeListItem ASXML_NodeListItem
#define NodeListLength ASXML_NodeListLength
#define TreeWalkerCurrentNode ASXML_TreeWalkerCurrentNode
#define TreeWalkerExpandEntityReferences ASXML_TreeWalkerExpandEntityReferences
#define TreeWalkerFilter ASXML_TreeWalkerFilter
#define TreeWalkerFirstChild ASXML_TreeWalkerFirstChild
#define TreeWalkerFree ASXML_TreeWalkerFree
#define TreeWalkerItem ASXML_TreeWalkerItem
#define TreeWalkerLastChild ASXML_TreeWalkerLastChild
#define TreeWalkerLength ASXML_TreeWalkerLength
#define TreeWalkerNextNode ASXML_TreeWalkerNextNode
#define TreeWalkerNextSibling ASXML_TreeWalkerNextSibling
#define TreeWalkerParentNode ASXML_TreeWalkerParentNode
#define TreeWalkerPreviousNode ASXML_TreeWalkerPreviousNode
#define TreeWalkerPreviousSibling ASXML_TreeWalkerPreviousSibling
#define TreeWalkerRoot ASXML_TreeWalkerRoot
#define TreeWalkerSetCurrentNode ASXML_TreeWalkerSetCurrentNode
#define TreeWalkerWhatToShow ASXML_TreeWalkerWhatToShow

#define NamedNodeMapRemoveItem ASXML_NamedNodeMapRemoveItem
#define NamedNodeMapRemoveNamedItem ASXML_NamedNodeMapRemoveNamedItem
#define NamedNodeMapRemoveNamedItemNS ASXML_NamedNodeMapRemoveNamedItemNS
#define NamedNodeMapSetNamedItem ASXML_NamedNodeMapSetNamedItem
#define NamedNodeMapSetNamedItemNS ASXML_NamedNodeMapSetNamedItemNS
#define NodeAppendChild ASXML_NodeAppendChild
#define NodeInsertAfter ASXML_NodeInsertAfter
#define NodeInsertBefore ASXML_NodeInsertBefore
#define NodeNormalize ASXML_NodeNormalize
#define NodeRemoveChild ASXML_NodeRemoveChild
#define NodeReplaceChild ASXML_NodeReplaceChild
#define NodeSetPrefix ASXML_NodeSetPrefix
#define NodeSetNamespaceUri ASXML_NodeSetNamespaceUri
#define NodeSetValue ASXML_NodeSetValue
#define AttrSetValue ASXML_AttrSetValue
#define CharacterDataAppendData ASXML_CharacterDataAppendData
#define CharacterDataDeleteData ASXML_CharacterDataDeleteData
#define CharacterDataInsertData ASXML_CharacterDataInsertData
#define CharacterDataReplaceData ASXML_CharacterDataReplaceData
#define CharacterDataSetData ASXML_CharacterDataSetData
#define ElementRemoveAttribute ASXML_ElementRemoveAttribute
#define ElementRemoveAttributeNS ASXML_ElementRemoveAttributeNS
#define ElementRemoveAttributeNode ASXML_ElementRemoveAttributeNode
#define ElementSetAttribute ASXML_ElementSetAttribute
#define ElementSetAttributeNS ASXML_ElementSetAttributeNS
#define ElementSetAttributeNode ASXML_ElementSetAttributeNode
#define ElementSetAttributeNodeNS ASXML_ElementSetAttributeNodeNS
#define ProcessingInstructionSetData ASXML_ProcessingInstructionSetData
#define TextSplitText ASXML_TextSplitText

#endif


#ifdef __cplusplus
}
#endif


#endif
