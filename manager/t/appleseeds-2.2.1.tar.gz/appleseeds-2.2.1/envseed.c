/* $Id: envseed.c,v 1.49 2004/12/07 23:48:01 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#include "config.h"
#include "oshseed.h"
#include <ctype.h>      /* isspace */
#include <stdlib.h>     /* free malloc strtol */
#include <string.h>     /* string functions */
#include "appleseeds.h" /* AS_Entities */
#define ASSTR_SHORT_NAMES
#include "strseed.h"
#define ASENV_SHORT_NAMES
#include "envseed.h"


/*
 * #args# is a string containing a copy of argv in "normalized" form, where
 * each element has the form -name=[value] (no value appears for null
 * switches).  Individual elements are separated by nul characters, and an
 * extra nul character marks the end of argv.
 */
struct ASENV__ParsedArgv {
  char *args;
};


/*
 * Returns 1 or 0 depending on whether or not #word1# and #word2# are identical
 * up to the first whitespace character in each or the end of the string.
 */
static int
CompareWord(const char *word1,
            const char *word2) {
  while(!isspace((int)*word1) && *word1 != '\0' && *word1++ == *word2++)
    ; /* empty */
  return (isspace((int)*word1) || *word1 == '\0') &&
         (isspace((int)*word2) || *word2 == '\0');
}


/*
 * Searches #valid# for a switch specification for the #nameLen#-long #name#.
 * Returns a pointer to the specification if found, else NULL.
 */
static const char *
FindSpec(const char *valid,
         const char *name,
         int nameLen) {
  while(1) {
    if(*valid != ' ')
      valid++; /* Skip switch char */
    if(strncmp(valid, name, nameLen) == 0 && isspace((int)valid[nameLen]))
      return valid;
    if((valid = strchr(valid, '\n')) == NULL)
      break;
    valid++; /* Advance to next switch */
  }
  return NULL;
}


/* Returns the type specification from the switch specification #spec#. */
static const char *
FindType(const char *spec) {
  while(!isspace((int)*spec)) /* Skip switch name. */
    spec++;
  while(isspace((int)*spec) && *spec != '\n')
    spec++;
  return spec;
}


/* Returns 1 iff #value# is valid for the type given in #spec#. */
static int
IsValidValue(const char *spec,
             const char *value) {
  const char *c;
  const char *type = FindType(spec);
  int valueLen;
  const char *valueEnd;
  if(value == NULL)
    return CompareWord(type, "void");
  else if(CompareWord(type, "char"))
    return value[1] == '\0';
  else if(CompareWord(type, "double")) {
    (void)strtod(value, (char **)&valueEnd);
    return *valueEnd == '\0';
  }
  else if(CompareWord(type, "int")) {
    (void)strtol(value, (char **)&valueEnd, 10);
    return *valueEnd == '\0';
  }
  else if(CompareWord(type, "void"))
    return 0;
  for(c = type; *c != '|' && !isspace((int)*c) && *c != '\0'; c++)
    ; /* empty */
  if(*c != '|')
    return 1; /* uninterpreted string value */
  valueLen = strlen(value);
  while(c - type != valueLen || strncmp(value, type, valueLen) != 0) {
    if(*c != '|')
      return 0;
    for(type = ++c; *c != '|' && !isspace((int)*c) && *c != '\0'; c++)
      ; /* empty */
  }
  return 1;
}


ParsedArgv
ParseArgv(const char *const *argv,
          const char *valid,
          ErrorHandler handler) {

  const char *arg;
  char *args = strdup("");
  const char *badArg = NULL;
  char *c;
  ParseErrors error = (ParseErrors)0;
  unsigned i;
  int noMoreSwitches = 0;
  ParsedArgv result;
  const char *spec;
  const char *value;

  for(i = argv[0] == NULL ? 0 : 1; (arg = argv[i]) != NULL; i++) {

#ifdef WIN32
    if(!noMoreSwitches && (strcmp(arg, "--") == 0 || strcmp(arg, "//") == 0)) {
#else
    if(!noMoreSwitches && strcmp(arg, "--") == 0) {
#endif
      noMoreSwitches = 1;
      continue;
    }

    value = NULL;
#ifdef WIN32
    if(noMoreSwitches || (*arg != '-' && *arg != '/') || *(arg + 1) == '\0') {
#else
    if(noMoreSwitches || *arg != '-' || *(arg + 1) == '\0') {
#endif
      /* Program argument. */
      if((spec = FindSpec(valid, "", 0)) == NULL) {
        badArg = arg;
        error = ARGUMENTS_NOT_ALLOWED;
      }
      else
        args = StrAppend(args, "=", arg, "\01", NULL);
    }
    else if((spec = FindSpec(valid, arg + 1, strlen(arg + 1))) != NULL) {
      /* The whole word is a single switch name. */
      if(CompareWord(FindType(spec), "void"))
        args = StrAppend(args, arg, "=\01", NULL);
      else {
        if((value = argv[i + 1]) != NULL)
          i++;
        if(!IsValidValue(spec, value)) {
          badArg = arg;
          error = value == NULL ? MISSING_VALUE : INVALID_VALUE;
        }
        else
          args = StrAppend(args, arg, "=", value, "\01", NULL);
      }
    }
    else if((value = strchr(arg, '=')) != NULL &&
            (spec = FindSpec(valid, arg + 1, value - arg - 1)) != NULL) {
      if(!IsValidValue(spec, ++value)) {
        badArg = arg;
        error = INVALID_VALUE;
      }
      else
        args = StrAppend(args, arg, "\01", NULL);
    }
    else {
      /* Single-char switch list? */
      const char *single;
      char singleStr[2] = {0, 0};
      char switchStr[2] = {0, 0};
      switchStr[0] = *arg;
      for(single = arg + 1; *single != '\0'; single++) {
        if((spec = FindSpec(valid, single, 1)) == NULL) {
          badArg = single == arg + 1 ? arg : single;
          error = UNKNOWN_SWITCH;
          break;
        }
        singleStr[0] = *single;
        if(CompareWord(FindType(spec), "void")) {
          args = StrAppend(args, switchStr, singleStr, "=\01", NULL);
          continue;
        }
        if(*(value = single + 1) == '\0' && (value = argv[i + 1]) != NULL)
          i++;
        if(!IsValidValue(spec, value)) {
          badArg = single;
          error = value == NULL ? MISSING_VALUE : INVALID_VALUE;
        }
        else
          args = StrAppend(args, switchStr, singleStr, "=", value, "\01", NULL);
        break;
      }
    }

    if(badArg != NULL &&
       (handler == NULL ||
        !handler(error, arg, badArg - arg, badArg == arg ? strlen(badArg) : 1,
                 value == NULL ? "" : value))) {
      free(args);
      return NULL;
    }

  }

  for(c = strchr(args, '\01'); c != NULL; c = strchr(c + 1, '\01'))
    *c = '\0';
  result = (ParsedArgv)malloc(sizeof(struct ASENV__ParsedArgv));
  result->args = args;
  return result;

}


void
ParsedArgvFree(ParsedArgv pa) {
  free(pa->args);
  free(pa);
}


char *
SwitchValueN(const ParsedArgv pa,
             const char *switchName,
             unsigned instance,
             const char *defaultValue) {
  char *c;
  char *result = (char *)defaultValue;
  unsigned switchLen = strlen(switchName);
  for(c = pa->args; *c != '\0'; c += strlen(c) + 1) {
    if(strncmp(c, switchName, switchLen) == 0 && c[switchLen] == '=') {
      if(instance == SWITCH_VALUE_LAST)
        result = c + switchLen + 1;
      else if(--instance == 0)
        return c + switchLen + 1;
    }
  }
  return result;
}
