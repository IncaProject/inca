/* $Id: strseed.c,v 1.13 2004/12/07 23:48:02 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#include "config.h"
#include "oshseed.h"
#include <stdarg.h>  /* va_* */
#include <stdlib.h>  /* calloc malloc realloc */
#include <string.h>  /* string functions */
#define ASSTR_SHORT_NAMES
#include "strseed.h"


void *
ASSTR_Realloc(void *ptr,
              unsigned size) {
  if(size > 0)
    return ptr == NULL ? malloc(size) : realloc(ptr, size);
  if(ptr != NULL)
    free(ptr);
  return NULL;
}


char *
StrAppend(char *s,
          ...) {

  char *c;
  unsigned long len;
  char *source;
  va_list sources;

  len = s == NULL ? 0 : strlen(s);
  va_start(sources, s);
  while((source = va_arg(sources, char *)) != NULL)
    len += strlen(source);
  va_end(sources);

  s = (char *)(s == NULL ? calloc(len + 1, 1) : Realloc(s, len + 1));
  va_start(sources, s);
  for(source = va_arg(sources, char *), c = s + strlen(s);
      source != NULL;
      source = va_arg(sources, char *), c += strlen(c))
    strcpy(c, source);
  va_end(sources);

  return s;

}


int
StrArrayFind(const char **s,
             const char *target,
             unsigned long *where) {
  return StrArrayNFind(s, StrArrayLen(s), target, strlen(target), where);
}


unsigned long
StrArrayLen(const char **s) {
  const char **end;
  for(end = s; *end != NULL; end++)
    ; /* empty */
  return end - s;
}


int
StrArrayNFind(const char **s,
              unsigned long len,
              const char *target,
              unsigned long targetLen,
              unsigned long *where) {
  unsigned long i;
  for(i = 0; i < len && strncmp(s[i], target, targetLen) != 0; i++)
    ; /* empty */
  if(i == len)
    return 0;
  if(where != NULL)
    *where = i;
  return 1;
}


int
StrArrayNFnMatch(const char **s,
                 unsigned long len,
                 const char *pattern,
                 unsigned long *where) {
  unsigned long i;
  for(i = 0; i < len && !StrFnMatch(s[i], pattern); i++)
    ; /* empty */
  if(i == len)
    return 0;
  if(where != NULL)
    *where = i;
  return 1;
}


void
StrArrayNFree(char **s,
              unsigned long len) {
  unsigned long i;
  for(i = 0; i < len; i++)
    free(s[i]);
  free(s);
}


char *
StrArrayNJoin(const char **s,
              unsigned long len,
              const char *sep) {
  
  char *c;
  const char **sLast = s + len - 1;
  unsigned long totalLen = 0;
  char *result;
  unsigned long sepLen = sep == NULL ? 0 : strlen(sep);

  for( ; s <= sLast; s++)
    totalLen += strlen(*s) + sepLen;
  result = (char *)malloc(totalLen - sepLen + 1);
  if(sepLen == 0) {
    for(s -= len, c = result; s <= sLast; s++, c += strlen(c))
      strcpy(c, *s);
  }
  else {
    for(s -= len, c = result; s < sLast; s++, c += strlen(c)) {
      strcpy(c, *s);
      c += strlen(c);
      strcpy(c, sep);
    }
    strcpy(c, *s);
  }
  return result;

}


char *
StrCase(char *s,
        CaseTypes caseType) {
  return StrNCase(s, strlen(s), caseType);
}


int
StrFnMatch(const char *s,
           const char *pattern) {
  return StrNFnMatch(s, strlen(s), pattern);
}


char *
StrNCase(char *s,
         unsigned long len,
         CaseTypes caseType) {
  char *c;
  int wordStart = 1;
  for(c = s; len > 0; len--, c++) {
    if(*c >= 'A' && *c <= 'Z') {
      if(caseType == ALL_LOWER || (caseType == INITIAL_LOWER && wordStart))
        *c += 'a' - 'A';
      wordStart = 0;
    }
    else if(*c >= 'a' && *c <= 'z') {
      if(caseType == ALL_UPPER || (caseType == INITIAL_UPPER && wordStart))
        *c += 'A' - 'a';
      wordStart = 0;
    }
    else
      wordStart = 1;
  }
  return s;
}


char *
StrNDup(const char *s,
        unsigned long len) {
  char *result = (char *)calloc(len + 1, sizeof(char));
  strncpy(result, s, len);
  return result;
}


int
StrNFnMatch(const char *s,
            unsigned long len,
            const char *pattern) {

  for( ; *pattern != '\0'; s++, len--, pattern++) {
    if(*pattern == '*') {
      do pattern++; while(*pattern == '*');
      if(*pattern == '\0')
        return 1; /* Trailing '*'. */
      while(len > 0 && !StrNFnMatch(s, len, pattern)) {
        s++;
        len--;
      }
      return len > 0;
    }
    else if(len == 0)
      return 0; /* All non-* pattern characters consume a character. */
    if(*pattern == '?')
      ; /* empty */
    else if(*pattern == '[') {
      int charInSet;
      int negate = *(++pattern) == '!';
      if(negate)
        pattern++;
      charInSet = (*pattern == ']' || *pattern == '-') && *pattern++ == *s;
      while(*pattern != ']' && *pattern != '\0' && !charInSet) {
        charInSet = *pattern == '-' && *(pattern + 1) != ']' ?
                    (*s >= *(pattern - 1) && *s <= *(pattern + 1)) :
                    (*s == *pattern);
        pattern++;
      }
      if(charInSet == negate || (pattern = strchr(pattern, ']')) == NULL)
        return 0;
    }
    else {
      if(*pattern == '\\')
        pattern++;
      if(*s != *pattern)
        return 0;
    }
  }

  return len == 0;

}


char *
StrNRepeat(const char *s,
           unsigned long len,
           unsigned long count){
  char *c;
  char *result;
  result = (char *)malloc(count * len + 1);
  for(c = result; count > 0; count--, c += len)
    strncpy(c, s, len);
  *c = '\0';
  return result;
}


char *
StrNReplace(char **s,
            unsigned long offset,
            unsigned long count,
            const char *rep,
            unsigned long len) {

  unsigned long sLen = strlen(*s);
  unsigned long newLen;

  /* Adjust offset and count values that refer past the end of the string. */
  if(offset > sLen)
    offset = sLen;
  if(offset + count > sLen)
    count = sLen - offset;

  newLen = sLen - count + len;
  if(newLen > sLen)
    *s = (char *)Realloc(*s, newLen + 1); /* Expand string. */

  /* Shift any characters after the section to be replaced, then insert. */
  if(offset + count < sLen)
    memmove(*s + offset + len, *s + offset + count, sLen - offset - count);
  if(len > 0)
    memcpy(*s + offset, rep, len);

  if(count > len)
    *s = (char *)Realloc(*s, newLen + 1); /* Shrink string. */
  (*s)[newLen] = '\0';
  return *s;

}


char *
StrNReplaceAll(char **s,
               const char *before,
               unsigned long beforeLen,
               const char *after,
               unsigned long afterLen) {
  char *c = *s;
  unsigned offset;
  for(c = strchr(*s, *before); c != NULL; c = strchr(c, *before)) {
    if(strncmp(c, before, beforeLen) != 0)
      c++;
    else {
      offset = c - *s;
      *s = StrNReplace(s, offset, beforeLen, after, afterLen);
      c = *s + offset + afterLen;
    }
  }
  return *s;
}


char **
StrNSplit(const char *s,
          unsigned long len,
          const char *delimiter) {

  const char *c;
  unsigned i;
  char **result = NULL;
  char *word;

  if(delimiter == NULL)
    delimiter = "[ \f\n\r\t\v]";
  for(i = 0; ; i++) {
    for( ; len > 0 && StrNFnMatch(s, 1, delimiter); s++, len--)
      ; /* empty */
    if(len == 0)
      break;
    for(c = s + 1, len--; len > 0 && !StrNFnMatch(c, 1, delimiter); c++, len--)
      ; /* empty */
    word = (char *)calloc(c - s + 1, sizeof(char));
    strncpy(word, s, c - s);
    result = (char **)Realloc(result, (i + 1) * sizeof(char *));
    result[i] = word;
    s = c;
  }
  result = (char **)Realloc(result, (i + 1) * sizeof(char *));
  result[i] = NULL;
  return result;

}


char *
StrRepeat(const char *s,
          unsigned long count) {
  return StrNRepeat(s, strlen(s), count);
}


char *
StrReplace(char **s,
           unsigned long offset,
           unsigned long count,
           const char *rep) {
  return StrNReplace(s, offset, count, rep, rep == NULL ? 0 : strlen(rep));
}


char *
StrReplaceAll(char **s,
              const char *before,
              const char *after) {
 return StrNReplaceAll(s, before, strlen(before), after, strlen(after));
}


char **
StrSplit(const char *s,
         const char *delimiter) {
  return StrNSplit(s, strlen(s), delimiter);
}
