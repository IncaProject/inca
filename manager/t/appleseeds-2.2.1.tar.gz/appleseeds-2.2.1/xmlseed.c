/* $Id: xmlseed.c,v 1.50 2004/12/07 23:48:02 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#include "config.h"
#include "oshseed.h"
#include <ctype.h>  /* is* */
#include <stdlib.h> /* calloc free strtol */
#include <string.h> /* string functions */
#define ASSTR_SHORT_NAMES
#include "strseed.h"
#define ASXML_SHORT_NAMES
#include "xmlseed.h"


/*
 * An XML tree node.  #owner# is the containing node (maintained even when
 * ASXML_ParentNode(node) returns NULL, e.g., attributes); #next# the right
 * sibling; #type# the node type; #uri# the namespace URI; #name# the qualified
 * name; #children# the child list. #data# stores type-specific data: the
 * attribute map for ELEMENT_NODE (created on demand to avoid lots of useless
 * memory allocation); a string for ATTRIBUTE_NODE, TEXT_NODE,
 * PROCESSING_INSTRUCTION_NODE, CDATA_SECTION_NODE, and COMMENT_NODE;
 * type-specific structs (see below) for DOCUMENT_NODE, DOCUMENT_TYPE_NODE,
 * ENTITY_NODE, and NOTATION_NODE; null for ENTITY_REFERENCE_NODE and
 * DOCUMENT_FRAGMENT_NODE.  To save space, the #uri# and #name# fields point to
 * elements of arrays contained in the document node.  The sole exception to
 * this is DOCUMENT_TYPE_NODE nodes, which need not belong to a document.
 */
struct ASXML__XmlNodeStruct {
  XmlNode owner;
  XmlNode next;
  XmlNodeTypes type;
  DOMString uri;
  DOMString name;
  XmlNode children;
  void *data;
};

/*
 * data field value for DOCUMENT_NODE.  #namePool#, #prefixPool# and #uriPool#
 * are NULL-terminated arrays containing the names of all the nodes in the
 * document, the known prefixes, and the namespace URIs, respectively, owned by
 * document; #orphans# is a list of unattached nodes owned by the document;
 * #iterators# is a list of node iterators active within the document; #valid#
 * indicates whether or not the document has been validated; #encoding#
 * indicates the character encoding of strings in the document.
 */
typedef struct DocumentDataStruct {
  DOMString *namePool;
  DOMString *prefixPool;
  DOMString *uriPool;
  XmlNode orphans;
  XmlNodeIterator iterators;
  int valid;
  char *encoding;
} *DocumentData;

/*
 * data field for DOCUMENT_TYPE_NODE.  #internalSubset# is the unparsed
 * internal subset; #publicId#, and #systemId# those ids, if specified;
 * #entities# and #notations# lists of items defined within the DTD.
 */
typedef struct DocumentTypeDataStruct {
  DOMString internalSubset;
  DOMString publicId;
  DOMString systemId;
  XmlNamedNodeMap entities;
  XmlNamedNodeMap notations;
} *DocumentTypeData;

/*
 * data field for ENTITY_NODE.  #parameterEntity# is a boolean indicating
 * whether or not this item is a parameter entity.  (Parameter entities are
 * retained only during the parsing process.)  #notationName#, #publicId#, and
 * #systemId# hold these items, if specified.
 */
typedef struct EntityDataStruct {
  int parameterEntity;
  DOMString notationName;
  DOMString publicId;
  DOMString systemId;
} *EntityData;

/*
 * Data field for NOTATION_NODE.  #publicId# and #systemId# hold those ids, if
 * specified.
 */
typedef struct NotationDataStruct {
  DOMString publicId;
  DOMString systemId;
} *NotationData;

/* Structure that represents a named node mapping as a simple linked list. */
struct ASXML__XmlNamedNodeMapStruct {
  XmlNode owner;
  XmlNode head;
};

/*
 * A node iterator/list.  The first four fields hold the creation parameters.
 * #type# indicates what group of nodes may be elements; #uri# and #name#, used
 * by TAG_LIST iterators, hold the namespace and name to be matched; #current#
 * is the node before the iterator position pointer; #doc# holds the owner
 * document and #next# the next active iterator that belongs to #doc#.
 */
typedef enum {
  CHILD_LIST, ITERATOR, TAG_LIST, WALKER
} IteratorTypes;
struct ASXML__XmlNodeIteratorStruct {
  XmlNode root;
  unsigned long whatToShow;
  XmlNodeFilter filter;
  int expand;
  IteratorTypes type;
  DOMString uri;
  DOMString name;
  XmlNode current;
  XmlNode doc;
  XmlNodeIterator next;
};


/* Boolean arrays of properties of the 12 node types (type 0 is unused). */
static const char TYPE_HAS_LINKS[] = {
  0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0
};
static const char TYPE_HAS_VALUE[] = {
  0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0
};


/* If *map is NULL, sets it to a newly-allocated map.  Returns *map. */
static XmlNamedNodeMap
GetNamedNodeMap(XmlNode owner,
                XmlNamedNodeMap *map) {
  XmlNamedNodeMap m = *map;
  if(m == NULL) {
    m = (XmlNamedNodeMap)calloc(1, sizeof(struct ASXML__XmlNamedNodeMapStruct));
    m->owner = owner;
    *map = m;
  }
  return m;
}


/*
 * Looks through the NULL-terminated array *#pool# for an entry matching
 * #item#; appends a copy of #item# to the array if no existing entry matches.
 * Returns the matching entry.
 */
static DOMString
GetPoolEntry(DOMString **pool,
             DOMString item) {
  char c = *item;
  DOMString *s;
  for(s = *pool; *s != NULL && (**s != c || strcmp(*s, item) != 0); s++)
    ; /* empty */
  if(*s == NULL) {
    int index = s - *pool;
    *pool = (DOMString *)Realloc(*pool, (index + 2) * sizeof(DOMString));
    s = *pool + index;
    *s = strdup(item);
    *(s + 1) = NULL;
  }
  return *s;
}


/*
 * Returns an allocated #type# node, including any associated data struct,
 * owned by #doc#.  Copies of #uri#, and #name# are placed in the node.
 */
static XmlNode
AllocNode(XmlDocument doc,
          XmlNodeTypes type,
          DOMString uri,
          DOMString name) {
  XmlNode result = (XmlNode)calloc(1, sizeof(struct ASXML__XmlNodeStruct));
  result->type = type;
  if(type == DOCUMENT_NODE) {
    DocumentData docData =
      (DocumentData)calloc(1, sizeof(struct DocumentDataStruct));
    docData->namePool = (DOMString *)calloc(1, sizeof(DOMString));
    docData->prefixPool = (DOMString *)calloc(1, sizeof(DOMString));
    docData->uriPool= (DOMString *)calloc(1, sizeof(DOMString));
    docData->encoding = NULL;
    result->data = docData;
    doc = result;
  }
  else if(type == DOCUMENT_TYPE_NODE)
    result->data = calloc(1, sizeof(struct DocumentTypeDataStruct));
  else if(type == ENTITY_NODE)
    result->data = calloc(1, sizeof(struct EntityDataStruct));
  else if(type == NOTATION_NODE)
    result->data = calloc(1, sizeof(struct NotationDataStruct));
  /* Set the uri and name fields to point to pool entries. */
  if(uri == NULL)
    ; /* empty */
  else if(type == DOCUMENT_TYPE_NODE)
    result->uri = strdup(uri);
  else
    result->uri = GetPoolEntry(&((DocumentData)doc->data)->uriPool, uri);
  if(type == DOCUMENT_TYPE_NODE)
    result->name = strdup(name);
  else
    result->name = GetPoolEntry(&((DocumentData)doc->data)->namePool, name);
  return result;
}


/*
 * Returns an allocated node linked to #doc# that contains a copy of #node#.
 * If #deep# is true, child nodes of #node# are recursively copied; if #wide#
 * is true, sibling nodes are recursively copied.  #owner# is stored in the
 * owner field of the copy.
 */
static XmlNode
CopyNode(XmlNode node,
         XmlDocument doc,
         int deep,
         int wide,
         XmlNode owner) {
  XmlNode result = AllocNode(doc, node->type, node->uri, node->name);
  if(wide && node->next != NULL)
    result->next = CopyNode(node->next, doc, deep, wide, owner);
  if((deep || node->type == ATTRIBUTE_NODE) && node->children != NULL)
    result->children = CopyNode(node->children, doc, deep, 1, result);
  if(NodeHasAttributes(node))
    GetNamedNodeMap(result, (XmlNamedNodeMap *)&result->data)->head =
      CopyNode(((XmlNamedNodeMap)node->data)->head, doc, 0, 1, result);
  else if(TYPE_HAS_VALUE[node->type])
    result->data = strdup((char *)node->data);
  else if(node->type == ENTITY_NODE) {
    EntityData newData = (EntityData)result->data;
    EntityData oldData = (EntityData)node->data;
    newData->parameterEntity = oldData->parameterEntity;
    if(oldData->notationName != NULL)
      newData->notationName = strdup(oldData->notationName);
    if(oldData->publicId != NULL)
      newData->publicId = strdup(oldData->publicId);
    if(oldData->systemId != NULL)
      newData->systemId = strdup(oldData->systemId);
  }
  else if(node->type == NOTATION_NODE) {
    NotationData newData = (NotationData)result->data;
    NotationData oldData = (NotationData)node->data;
    if(oldData->publicId != NULL)
      newData->publicId = strdup(oldData->publicId);
    if(oldData->systemId != NULL)
      newData->systemId = strdup(oldData->systemId);
  }
  /* NOTE: The DOM prohibits copying DOCUMENT_NODE and DOCUMENT_TYPE_NODE. */
  result->owner = owner;
  return result;
}


/* Returns true iff #node# is part of the subtree headed by #root#. */
static int
IsInSubtree(XmlNode root,
            XmlNode node) {
  while(node != NULL && node != root)
    node = node->owner;
  return node != NULL;
}


/* Returns true iff #node# is a member of its document's orphan list. */
static int
IsOrphan(XmlNode node) {
  XmlNode x = node->owner;
  if(x == NULL || x->type != DOCUMENT_NODE)
    return 0;
  for(x = ((DocumentData)x->data)->orphans; x != NULL && x != node; x = x->next)
    ; /* empty */
  return x == node;
}


/* Returns the disposition of #node# under #it#. */
static XmlNodeFilterResultTypes
IteratorDisposition(XmlNodeIterator it,
                    XmlNode node) {
  if(((it->whatToShow << 1) & (1 << node->type)) == 0)
    return FILTER_SKIP;
  if(it->type == TAG_LIST) {
    if((it->uri == NULL) != (node->uri == NULL))
      return FILTER_SKIP;
    if(it->uri != NULL) {
      if(*it->uri != '*' && strcmp(it->uri, node->uri) != 0)
        return FILTER_SKIP;
      if(*it->name != '*' && strcmp(it->name, NodeLocalName(node)) != 0)
        return FILTER_SKIP;
    }
    else if(*it->name != '*' && strcmp(it->name, node->name) != 0)
      return FILTER_SKIP;
  }
  return it->filter == NULL ? FILTER_ACCEPT : it->filter(node);
}


/*
 * Advances the position of #it# past its next element and returns the element.
 * Returns NULL if #it# is already past its last element.
 */
static XmlNode
IteratorAdvance(XmlNodeIterator it) {
  XmlNodeFilterResultTypes disposition = FILTER_ACCEPT;
  XmlNode x;
  x = it->current;
  do {
    if(x == NULL) {
      x = it->type == ITERATOR || it->type == WALKER ?
          it->root : it->root->children;
      if(x == NULL)
        return NULL;
    }
    else if(it->type != CHILD_LIST &&
            x->children != NULL &&
            disposition != FILTER_REJECT)
      x = x->children;
    else {
      while(x != NULL && x != it->root && x->next == NULL)
        x = x->owner;
      if(x == NULL || x == it->root)
        return NULL;
      x = x->next;
    }
    disposition = IteratorDisposition(it, x);
  } while(disposition != FILTER_ACCEPT);
  it->current = x;
  return x;
}


/* Returns the document ancestor of #node#. */
static XmlNode
NodeDocument(XmlNode node) {
  while(node != NULL && node->type != DOCUMENT_NODE)
    node = node->owner;
  return node;
}


/* Pulls #node# from the list headed by #list#. Returns 1 on success, else 0. */
static int
RemoveNode(XmlNode *list,
           XmlNode node) {
  XmlNode doc;
  XmlNodeIterator it;
  while(*list != NULL && *list != node)
    list = &(*list)->next;
  if(*list == NULL)
    return 0;
  /* Fix any iterators that point to a decendant of #node#. */
  if((doc = NodeDocument(node)) != NULL) {
    for(it = ((DocumentData)doc->data)->iterators; it != NULL; it = it->next) {
      if(it->type == WALKER)
        continue;
      while(IsInSubtree(node, it->current))
        NodeIteratorPreviousNode(it);
    }
  }
  *list = node->next;
  return 1;
}


/*
 * Removes any relationship between #node# and its owner, then sets its owner
 * to #newOwner#.  If #sib# is not NULL, *#sib# becomes the right sibling of
 * #node# and *#sib# is set to point to #node#.
 */
static void
TransferNode(XmlNode node,
             XmlNode newOwner,
             XmlNode *sib) {
  XmlNode owner = node->owner;
  if(owner == NULL)
    ; /* empty */
  else if(RemoveNode(&owner->children, node))
    ; /* empty */
  else if(owner->type == ELEMENT_NODE &&
          owner->data != NULL &&
          RemoveNode(&((XmlNamedNodeMap)owner->data)->head, node))
    ; /* empty */
  else if(owner->type == DOCUMENT_NODE &&
          RemoveNode(&((DocumentData)owner->data)->orphans, node))
    ; /* empty */
  else if(owner->type == DOCUMENT_TYPE_NODE &&
          ((DocumentTypeData)owner->data)->entities != NULL &&
          RemoveNode(&((DocumentTypeData)owner->data)->entities->head, node))
    ; /* empty */
  else if(owner->type == DOCUMENT_TYPE_NODE &&
          ((DocumentTypeData)owner->data)->notations != NULL &&
          RemoveNode(&((DocumentTypeData)owner->data)->notations->head, node))
    ; /* empty */
  node->owner = newOwner;
  if(sib != NULL) {
    node->next = *sib;
    *sib = node;
  }
}


XmlElement
AttrOwnerElement(XmlAttr attr) {
  return IsOrphan(attr) ? NULL : attr->owner;
}


int
AttrSpecified(XmlAttr attr) {
  return 1; /* TODO DTD-related. */
}


void
CharacterDataAppendData(XmlCharacterData cd,
                        DOMString s) {
  StrReplace((char **)&cd->data, strlen((char *)cd->data), 0, s);
}


void
CharacterDataDeleteData(XmlCharacterData cd,
                        unsigned long offset,
                        unsigned long count) {
  StrReplace((char **)&cd->data, offset, count, NULL);
}


void
CharacterDataInsertData(XmlCharacterData cd,
                        unsigned long offset,
                        DOMString s) {
  StrReplace((char **)&cd->data, offset, 0, s);
}


unsigned long
CharacterDataLength(XmlCharacterData cd) {
  return strlen((char *)cd->data);
}


void
CharacterDataReplaceData(XmlCharacterData cd,
                         unsigned long offset,
                         unsigned long count,
                         DOMString s) {
  StrReplace((char **)&cd->data, offset, count, s);
}


DOMString
CharacterDataSubstringData(XmlCharacterData cd,
                           unsigned long offset,
                           unsigned long count) {
  unsigned long sLen = strlen((char *)cd->data);
  if(offset > sLen)
    offset = sLen;
  if(offset + count > sLen)
    count = sLen - offset;
  return StrNDup((char *)cd->data + offset, count);
}


XmlNode
DocumentCreateNode(XmlDocument doc,
                   XmlNodeTypes type,
                   DOMString uri,
                   DOMString name,
                   DOMString value) {
  XmlNode result = AllocNode(doc, type, uri, name);
  if(value != NULL) {
    result->data = strdup(value);
    if(type == ATTRIBUTE_NODE) {
      result->children = AllocNode(doc, TEXT_NODE, NULL, "#text");
      result->children->data = strdup(value);
      result->children->owner = result;
    }
  }
  if(type != DOCUMENT_NODE)
    TransferNode(result, doc, &((DocumentData)doc->data)->orphans);
  return result;
}


XmlNodeIterator
DocumentCreateNodeIterator(XmlDocument doc,
                           XmlNode root,
                           unsigned long whatToShow,
                           XmlNodeFilter filter,
                           int expand) {
  DocumentData data = (DocumentData)doc->data;
  XmlNodeIterator result =
    (XmlNodeIterator)calloc(1, sizeof(struct ASXML__XmlNodeIteratorStruct));
  result->root = root;
  result->whatToShow = whatToShow;
  result->filter = filter;
  result->expand = expand;
  result->type = ITERATOR;
  result->doc = doc;
  result->next = data->iterators;
  data->iterators = result;
  return result;
}


XmlTreeWalker
DocumentCreateTreeWalker(XmlDocument doc,
                         XmlNode root,
                         unsigned long whatToShow,
                         XmlNodeFilter filter,
                         int expand) {
  XmlTreeWalker result =
    DocumentCreateNodeIterator(doc, root, whatToShow, filter, expand);
  result->current = root;
  result->type = WALKER;
  return result;
}


char *
DocumentEncoding(XmlDocument doc) {
  return ((DocumentData)doc->data)->encoding;
}


XmlElement
DocumentGetElementById(DOMString id) {
  return NULL; /* TODO DTD-related. */
}


XmlNode
DocumentImportNode(XmlDocument doc,
                   XmlNode node,
                   int deep) {
  XmlNode result = CopyNode(node, doc, deep, 0, NULL);
  if(node->type != DOCUMENT_NODE)
    TransferNode(result, doc, &((DocumentData)doc->data)->orphans);
  return result;
}


int
DocumentIsValid(XmlDocument doc) {
  return ((DocumentData)doc->data)->valid;
}


void
DocumentSetEncoding(XmlDocument doc,
                    char *encoding) {
  DocumentData data = (DocumentData)doc->data;
  if(data->encoding != NULL && strcmp(data->encoding, encoding) == 0)
    return;
  /* TODO convert all the strings in #doc#. */
  if(data->encoding != NULL)
    free(data->encoding);
  data->encoding = strdup(encoding);
}


XmlNamedNodeMap
DocumentTypeEntities(XmlDocumentType dtd) {
  DocumentTypeData data = (DocumentTypeData)dtd->data;
  return GetNamedNodeMap(dtd, &data->entities);
}


DOMString
DocumentTypeInternalSubset(XmlDocumentType dtd) {
  return ((DocumentTypeData)dtd->data)->internalSubset;
}


XmlNamedNodeMap
DocumentTypeNotations(XmlDocumentType dtd) {
  DocumentTypeData data = (DocumentTypeData)dtd->data;
  return GetNamedNodeMap(dtd, &data->notations);
}


DOMString
DocumentTypePublicId(XmlDocumentType dtd) {
  return ((DocumentTypeData)dtd->data)->publicId;
}


DOMString
DocumentTypeSystemId(XmlDocumentType dtd) {
  return ((DocumentTypeData)dtd->data)->systemId;
}


DOMString
ElementGetAttributeNS(XmlElement elem,
                      DOMString uri,
                      DOMString local) {
  XmlAttr attr = ElementGetAttributeNodeNS(elem, uri, local);
  return attr == NULL ? (DOMString)"" : (DOMString)attr->data;
}


void
ElementSetAttributeNS(XmlElement elem,
                      DOMString uri,
                      DOMString qualified,
                      DOMString value) {
  XmlNode attr;
  char *colon = strchr(qualified, ':');
  char *local = uri != NULL && colon != NULL ? colon + 1 : qualified;
  attr = ElementGetAttributeNodeNS(elem, uri, local);
  if(attr == NULL) {
    attr = DocumentCreateNode
      (NodeDocument(elem), ATTRIBUTE_NODE, uri, qualified, value);
    ElementSetAttributeNodeNS(elem, attr);
  }
  else {
    AttrSetValue(attr, value);
    if(strcmp(qualified, AttrName(attr)) != 0) {
      DocumentData data = (DocumentData)NodeOwnerDocument(elem)->data;
      attr->name = GetPoolEntry(&data->namePool, qualified);
    }
  }
}


DOMString
EntityNotationName(XmlEntity ent) {
  return ((EntityData)ent->data)->notationName;
}


DOMString
EntityPublicId(XmlEntity ent) {
  return ((EntityData)ent->data)->publicId;
}


DOMString
EntitySystemId(XmlEntity ent) {
  return ((EntityData)ent->data)->systemId;
}


XmlDocument
ImplementationCreateDocument(XmlImplementation imp,
                             DOMString uri,
                             DOMString qualified,
                             XmlDocumentType doctype) {
  XmlDocument result = AllocNode(NULL, DOCUMENT_NODE, uri, qualified);
  if(doctype != NULL)
    NodeAppendChild(result, doctype);
  return result;
}


XmlDocumentType
ImplementationCreateDocumentType(XmlImplementation imp,
                                 DOMString qualified,
                                 DOMString publicId,
                                 DOMString systemId) {
  XmlDocumentType result =
    AllocNode(NULL, DOCUMENT_TYPE_NODE, NULL, qualified);
  DocumentTypeData data = (DocumentTypeData)result->data;
  if(publicId != NULL)
    data->publicId = strdup(publicId);
  if(systemId != NULL)
    data->systemId = strdup(systemId);
  return result;
}


int
ImplementationHasFeature(XmlImplementation imp,
                         DOMString feature,
                         DOMString version) {
  DOMString f = strdup(feature);
  int result;
  StrCase(f, ALL_LOWER);
  result = strcmp(f, "core") == 0 || strcmp(f, "traversal") == 0 ?
           version == NULL || *version == '\0' ||
           strcmp(version, "1.0") == 0 || strcmp(version, "2.0") == 0 : 0;
  free(f);
  return result;
}


XmlNode
NamedNodeMapGetNamedItemNS(XmlNamedNodeMap map,
                           DOMString uri,
                           DOMString local) {
  XmlAttr x;
  for(x = map->head; x != NULL; x = x->next) {
    if((uri == NULL) != (x->uri == NULL) ||
       (uri != NULL && strcmp(x->uri, uri) != 0))
      continue;
    if(strcmp(local, uri == NULL ? x->name : NodeLocalName(x)) == 0)
      break;
  }
  return x;
}


XmlNode
NamedNodeMapItem(XmlNamedNodeMap map,
                 unsigned long n) {
  XmlNode x;
  for(x = map->head; n > 0 && x != NULL; n--, x = x->next)
    ; /* empty */
  return x;
}


unsigned long
NamedNodeMapLength(XmlNamedNodeMap map) {
  unsigned long result;
  XmlNode x;
  for(result = 0, x = map->head; x != NULL; result++, x = x->next)
    ; /* empty */
  return result;
}


XmlNode
NamedNodeMapRemoveNamedItemNS(XmlNamedNodeMap map,
                              DOMString uri,
                              DOMString local) {
  XmlNode x = NamedNodeMapGetNamedItemNS(map, uri, local);
  if(x != NULL)
    NamedNodeMapRemoveItem(map, x);
  return x;
}


XmlNode
NamedNodeMapRemoveItem(XmlNamedNodeMap map,
                       XmlNode node) {
  XmlNode doc = NodeDocument(node);
  TransferNode(node, doc, &((DocumentData)doc->data)->orphans);
  return node;
}


XmlNode
NamedNodeMapSetNamedItemNS(XmlNamedNodeMap map,
                           XmlNode node) {
  XmlNode old;
  XmlNode x;
  if((old = NamedNodeMapGetNamedItemNS(map, node->uri, node->name)) != NULL)
    NamedNodeMapRemoveItem(map, old);
  for(x = map->head; x != NULL && x->next != NULL; x = x->next)
    ; /* empty */
  TransferNode(node, map->owner, x == NULL ? &map->head : &x->next);
  return old;
}


XmlNamedNodeMap
NodeAttributes(XmlNode node) {
  if(node->type != ELEMENT_NODE)
    return NULL;
  return GetNamedNodeMap(node, (XmlNamedNodeMap *)&node->data);
}


XmlNodeList
NodeChildNodes(XmlNode node) {
  XmlNodeList result =
    DocumentCreateNodeIterator(NodeDocument(node), node, SHOW_ALL, NULL, 0);
  result->type = CHILD_LIST;
  return result;
}


XmlNode
NodeCloneNode(XmlNode node,
              int deep) {
  return DocumentImportNode(NodeDocument(node), node, deep);
}


XmlNode
NodeFirstChildByType(XmlNode node,
                     unsigned long whatTypes) {
  return node->children == NULL ? NULL :
         ((whatTypes<<1) & (1<<node->children->type)) != 0 ? node->children :
         NodeNextSiblingByType(node->children, whatTypes);
}


void
NodeFree(XmlNode node) {
  while(node->children != NULL)
    NodeFree(node->children);
  if(node->type == DOCUMENT_NODE) {
    DocumentData data = (DocumentData)node->data;
    unsigned i;
    for(i = 0; data->namePool[i] != NULL; i++)
      free(data->namePool[i]);
    free(data->namePool);
    for(i = 0; data->prefixPool[i] != NULL; i++)
      free(data->prefixPool[i]);
    free(data->prefixPool);
    for(i = 0; data->uriPool[i] != NULL; i++)
      free(data->uriPool[i]);
    free(data->uriPool);
    while(data->iterators != NULL)
      NodeIteratorFree(data->iterators);
    while(data->orphans != NULL)
      NodeFree(data->orphans);
    if(data->encoding != NULL)
      free(data->encoding);
    free(data);
  }
  else if(node->type == DOCUMENT_TYPE_NODE) {
    DocumentTypeData data = (DocumentTypeData)node->data;
    if(data->internalSubset != NULL)
      free(data->internalSubset);
    if(data->publicId != NULL)
      free(data->publicId);
    if(data->systemId != NULL)
      free(data->systemId);
    if(data->entities != NULL) {
      while(data->entities->head != NULL)
        NodeFree(data->entities->head);
      free(data->entities);
      data->entities = NULL;
    }
    if(data->notations != NULL) {
      while(data->notations->head != NULL)
        NodeFree(data->notations->head);
      free(data->notations);
      data->notations = NULL;
    }
    free(data);
  }
  else if(node->type == ELEMENT_NODE) {
    if(node->data != NULL) {
      while(((XmlNamedNodeMap)node->data)->head != NULL)
        NodeFree(((XmlNamedNodeMap)node->data)->head);
      free(node->data);
    }
  }
  else if(node->type == ENTITY_NODE) {
    EntityData data = (EntityData)node->data;
    if(data->notationName != NULL)
      free(data->notationName);
    if(data->publicId != NULL)
      free(data->publicId);
    if(data->systemId != NULL)
      free(data->systemId);
    free(data);
  }
  else if(node->type == NOTATION_NODE) {
    NotationData data = (NotationData)node->data;
    if(data->publicId != NULL)
      free(data->publicId);
    if(data->systemId != NULL)
      free(data->systemId);
    free(data);
  }
  else if(node->data != NULL)
    free(node->data);
  TransferNode(node, NULL, NULL);
  if(node->type == DOCUMENT_TYPE_NODE) {
    free(node->name);
    if(node->uri != NULL)
      free(node->uri);
  }
  free(node);
}


XmlNodeList
NodeGetElementsByTagNameNS(XmlElement node,
                           DOMString uri,
                           DOMString local) {
  XmlNodeList result =
    DocumentCreateNodeIterator(NodeDocument(node), node, SHOW_ELEMENT, NULL, 0);
  result->type = TAG_LIST;
  if(uri != NULL)
    result->uri = strdup(uri);
  result->name = strdup(local);
  return result;
}


int
NodeHasAttributes(XmlNode node) {
  return node->type == ELEMENT_NODE &&
         node->data != NULL &&
         ((XmlNamedNodeMap)node->data)->head != NULL;
}


XmlNode
NodeInsertAfter(XmlNode node,
                XmlNode newChild,
                XmlNode oldChild) {
  if(newChild->type == DOCUMENT_FRAGMENT_NODE)
    while(newChild->children != NULL)
      NodeInsertAfter(node, newChild->children, oldChild);
  else
    TransferNode
      (newChild, node, oldChild == NULL ? &node->children : &oldChild->next);
  return newChild;
}


XmlNode
NodeInsertBefore(XmlNode node,
                 XmlNode newChild,
                 XmlNode oldChild) {
  return NodeInsertAfter
    (node, newChild,
     oldChild == NULL ? NodeLastChild(node) : NodePreviousSibling(oldChild));
}


XmlNode
NodeLastChild(XmlNode node) {
  XmlNode next;
  XmlNode x = NodeFirstChild(node);
  if(x == NULL)
    return NULL;
  while((next = NodeNextSibling(x)) != NULL)
    x = next;
  return x;
}


DOMString
NodeLocalName(XmlNode node) {
  char *colon = strchr(node->name, ':');
  return node->uri == NULL ? NULL : colon != NULL ? colon + 1 : node->name;
}


DOMString
NodeName(XmlNode node) {
  return node->name;
}


DOMString
NodeNamespaceUri(XmlNode node) {
  return node->uri;
}


XmlNode
NodeNextSiblingByType(XmlNode node,
                      unsigned long whatTypes) {
  XmlNode x;
  if(!TYPE_HAS_LINKS[node->type] || IsOrphan(node))
    return NULL;
  whatTypes <<= 1;
  for(x = node->next; x != NULL && (whatTypes & (1<<x->type)) == 0; x = x->next)
    ; /* empty */
  return x;
}


void
NodeNormalize(XmlNode node) {
  XmlNode next;
  XmlNode x;
  for(x = NodeFirstChild(node); x != NULL; x = next) {
    next = NodeNextSibling(x);
    if(x->type == TEXT_NODE) {
      while(next != NULL && next->type == TEXT_NODE) {
        x->data = StrAppend((char *)x->data, (char *)next->data, NULL);
        NodeFree(next);
        next = NodeNextSibling(x);
      }
      if(*(char *)x->data == '\0')
        NodeFree(x);
    }
    else if(x->type == ELEMENT_NODE)
      NodeNormalize(x);
  }
}


XmlDocument
NodeOwnerDocument(XmlNode node) {
  return node->type == DOCUMENT_NODE ? NULL : NodeDocument(node);
}


XmlNode
NodeParentNode(XmlNode node) {
  return !TYPE_HAS_LINKS[node->type] || IsOrphan(node) ? NULL : node->owner;
}


DOMString
NodePrefix(XmlNode node) {
  char *colon = strchr(node->name, ':');
  XmlNode doc = NodeDocument(node);
  DOMString result;
  if(colon == NULL || doc == NULL || NodeNamespaceUri(node) == NULL)
    return NULL;
  *colon = '\0';
  result = GetPoolEntry(&((DocumentData)doc->data)->prefixPool, node->name);
  *colon = ':';
  return result;
}


XmlNode
NodePreviousSibling(XmlNode node) {
  XmlNode next;
  XmlNode x = NodeParentNode(node);
  if(x == NULL)
    return NULL;
  for(x = NodeFirstChild(x);
      x != NULL && (next = NodeNextSibling(x)) != node;
      x = next)
    ; /* empty */
  return x;
}


XmlNode
NodeRemoveChild(XmlNode node,
                XmlNode child) {
  XmlNode doc = NodeDocument(node);
  TransferNode(child, doc, &((DocumentData)doc->data)->orphans);
  return child;
}


XmlNode
NodeReplaceChild(XmlNode node,
                 XmlNode newChild,
                 XmlNode oldChild) {
  NodeInsertAfter(node, newChild, oldChild);
  return NodeRemoveChild(node, oldChild);
}


void
NodeSetPrefix(XmlNode node,
              DOMString prefix) {
  XmlNode doc = NodeDocument(node);
  char *newName;
  if(doc == NULL || NodeNamespaceUri(node) == NULL)
    return;
  newName = StrAppend(NULL, prefix, ":", NodeLocalName(node), NULL);
  node->name = GetPoolEntry(&((DocumentData)doc->data)->namePool, newName);
  free(newName);
}


void
NodeSetNamespaceUri(XmlNode node,
                    DOMString uri) {
  XmlNode doc;
  if(uri == NULL)
    node->uri = NULL;
  else if(node->type == DOCUMENT_TYPE_NODE)
    node->uri = strdup(uri);
  else if(node->type == ATTRIBUTE_NODE || node->type == ELEMENT_NODE) {
    doc = NodeOwnerDocument(node);
    node->uri = GetPoolEntry(&((DocumentData)doc->data)->uriPool, uri);
  }
}


void
NodeSetValue(XmlNode node,
             DOMString value) {
  if(!TYPE_HAS_VALUE[node->type])
    return;
  if(node->data != NULL)
    free(node->data);
  node->data = strdup(value);
  if(node->type == ATTRIBUTE_NODE) {
    while(node->children != NULL)
      NodeRemoveChild(node, node->children);
    node->children = AllocNode(NodeDocument(node), TEXT_NODE, NULL, "#text");
    node->children->data = strdup(value);
    node->children->owner = node;
  }
}


XmlNodeTypes
NodeType(XmlNode node) {
  return node->type;
}


DOMString
NodeValue(XmlNode node) {
  return TYPE_HAS_VALUE[node->type] ? (DOMString)node->data : NULL;
}


int
NodeIteratorExpandEntityReferences(XmlNodeIterator it) {
  return it->expand;
}


XmlNodeFilter
NodeIteratorFilter(XmlNodeIterator it) {
  return it->filter;
}


void
NodeIteratorFree(XmlNodeIterator it) {
  DocumentData data = (DocumentData)it->doc->data;
  XmlNodeIterator it2;
  if(data->iterators == it)
    data->iterators = it->next;
  else {
    for(it2 = data->iterators; it2->next != it; it2 = it2->next)
      ; /* empty */
    it2->next = it->next;
  }
  if(it->uri != NULL)
    free(it->uri);
  if(it->name != NULL)
    free(it->name);
  free(it);
}


XmlNode
NodeIteratorItem(XmlNodeIterator it,
                 unsigned long n) {
  XmlNode current = it->current;
  XmlNode x;
  for(it->current = NULL; (x = IteratorAdvance(it)) != NULL && n > 0; n--)
    ; /* empty */
  it->current = current;
  return x;
}


unsigned long
NodeIteratorLength(XmlNodeIterator it) {
  XmlNode current = it->current;
  unsigned i;
  for(i = 0, it->current = NULL; IteratorAdvance(it) != NULL; i++)
    ; /* empty */
  it->current = current;
  return i;
}


XmlNode
NodeIteratorNextNode(XmlNodeIterator it) {
  return IteratorAdvance(it);
}


XmlNode
NodeIteratorPreviousNode(XmlNodeIterator it) {
  XmlNode current = it->current;
  XmlNode initial = it->type == WALKER ? it->root : NULL;
  XmlNode prior = NULL;
  for(it->current = initial; it->current != current; IteratorAdvance(it))
    prior = it->current;
  it->current = prior;
  return it->type == WALKER ? prior : current;
}


XmlNode
NodeIteratorRoot(XmlNodeIterator it) {
  return it->root;
}


unsigned long
NodeIteratorWhatToShow(XmlNodeIterator it) {
  return it->whatToShow;
}


DOMString
NotationPublicId(XmlNotation notation) {
  return ((NotationData)notation->data)->publicId;
}


DOMString
NotationSystemId(XmlNotation notation) {
  return ((NotationData)notation->data)->systemId;
}


XmlText
TextSplitText(XmlText text,
              unsigned long offset) {
  unsigned long len = strlen((char *)text->data);
  XmlText result;
  if(offset > len)
    offset = len;
  result = AllocNode(NodeDocument(text), text->type, NULL, text->name);
  result->data = strdup((char *)text->data + offset);
  result->owner = text->owner;
  result->next = text->next;
  text->next = result;
  CharacterDataDeleteData(text, offset, len - offset);
  return result;
}


XmlNode
TreeWalkerCurrentNode(XmlTreeWalker tw) {
  return tw->current;
}


XmlNode
TreeWalkerFirstChild(XmlTreeWalker tw) {
  XmlNode x;
  for(x = NodeFirstChild(tw->current);
      x != NULL && IteratorDisposition(tw, x) != FILTER_ACCEPT;
      x = NodeNextSibling(x))
    ; /* empty */
  if(x != NULL)
    tw->current = x;
  return x;
}


XmlNode
TreeWalkerLastChild(XmlTreeWalker tw) {
  XmlNode x;
  for(x = NodeLastChild(tw->current);
      x != NULL && IteratorDisposition(tw, x) != FILTER_ACCEPT;
      x = NodePreviousSibling(x))
    ; /* empty */
  if(x != NULL)
    tw->current = x;
  return x;
}


XmlNode
TreeWalkerNextSibling(XmlTreeWalker tw) {
  XmlNode x;
  for(x = NodeNextSibling(tw->current);
      x != NULL && IteratorDisposition(tw, x) != FILTER_ACCEPT;
      x = NodeNextSibling(x))
    ; /* empty */
  if(x != NULL)
    tw->current = x;
  return x;
}


XmlNode
TreeWalkerParentNode(XmlTreeWalker tw) {
  XmlNode x;
  if(tw->current == tw->root)
    return NULL;
  for(x = NodeParentNode(tw->current);
      x != NULL && IteratorDisposition(tw, x) != FILTER_ACCEPT;
      x = NodeParentNode(x)) {
    if(x == tw->root)
      return NULL;
  }
  if(x != NULL)
    tw->current = x;
  return x;
}


XmlNode
TreeWalkerPreviousSibling(XmlTreeWalker tw) {
  XmlNode x;
  for(x = NodePreviousSibling(tw->current);
      x != NULL && IteratorDisposition(tw, x) != FILTER_ACCEPT;
      x = NodePreviousSibling(x))
    ; /* empty */
  if(x != NULL)
    tw->current = x;
  return x;
}


void
TreeWalkerSetCurrentNode(XmlTreeWalker tw,
                         XmlNode node) {
  tw->current = node;
}


/* === Translation to/from string === */


/*
 * NOTE: The goal is to implement these functions using only the public API,
 * so that translation could be moved to a separate module if desired.  Because
 * the API defines no methods for manipulating DTD elements, we have to add
 * a few supplementary functions to achieve this goal.
 */


static XmlEntity
DocumentCreateEntity(XmlDocument doc,
                     DOMString name,
                     int parameterEntity,
                     DOMString publicId,
                     DOMString systemId,
                     DOMString notationName) {
  XmlNode result = DocumentCreateNode(doc, ENTITY_NODE, NULL, name, NULL);
  ((EntityData)result->data)->parameterEntity = parameterEntity;
  if(publicId != NULL)
    ((EntityData)result->data)->publicId = strdup(publicId);
  if(systemId != NULL)
    ((EntityData)result->data)->systemId = strdup(systemId);
  if(notationName != NULL)
    ((EntityData)result->data)->notationName = strdup(notationName);
  return result;
}


static XmlNotation
DocumentCreateNotation(XmlDocument doc,
                       DOMString name,
                       DOMString publicId,
                       DOMString systemId) {
  XmlNode result = DocumentCreateNode(doc, NOTATION_NODE, NULL, name, NULL);
  if(publicId != NULL)
    ((NotationData)result->data)->publicId = strdup(publicId);
  if(systemId != NULL)
    ((NotationData)result->data)->systemId = strdup(systemId);
  return result;
}


static void
DocumentTypeSetInternalSubset(XmlDocumentType dtd,
                              DOMString internal) {
  ((DocumentTypeData)dtd->data)->internalSubset = strdup(internal);
}


/*
 * Follows the parent chain of #scope# looking for an attribute that defines
 * the prefix of #qualified#.  #allowDefault# indicates whether a default
 * namespace is allowed if #qualified# has no prefix.  Returns the URI of
 * the namespace, NULL if none.
 */
static DOMString
LookupNS(XmlNode scope,
         DOMString qualified,
         int allowDefault) {

  XmlAttr attr;
  char *attrName;

  if(scope == NULL)
    return NULL;
  if(strchr(qualified, ':') != NULL) {
    attrName = StrAppend(NULL, "xmlns:", qualified, NULL);
    *strchr(attrName + 6, ':') = '\0';
  }
  else if(!allowDefault)
    return NULL;
  else
    attrName = strdup("xmlns");
  attr = NULL;
  while(scope != NULL &&
        NodeType(scope) == ELEMENT_NODE &&
        (attr = ElementGetAttributeNode(scope, attrName)) == NULL)
    scope = NodeParentNode(scope);
  free(attrName);
  return attr == NULL ? NULL : NodeValue(attr);

}


static DOMString
NodeImage(XmlNode node);


/*
 * Returns images of all of #node#'s subordinate nodes, separated by #sep#, in
 * an allocated string.  If #children# is true, the images are those of
 * #node#'s child nodes; otherwise, it is that of #node#'s attributes.
 */
static DOMString
NodeContentImage(XmlNode node,
                 int children,
                 DOMString sep) {
  DOMString *contents;
  unsigned i;
  DOMString result;
  XmlNode x;
  if(children)
    for(i = 0, x = NodeFirstChild(node); x != NULL; i++, x = NodeNextSibling(x))
      ; /* empty */
  else
    for(i = 0; NamedNodeMapItem(NodeAttributes(node), i) != NULL; i++)
      ; /* empty */
  contents = (DOMString *)calloc(i, sizeof(DOMString));
  if(children)
    for(i = 0, x = NodeFirstChild(node); x != NULL; i++, x = NodeNextSibling(x))
      contents[i] = NodeImage(x);
  else
    for(i = 0; (x = NamedNodeMapItem(NodeAttributes(node), i)) != NULL; i++)
      contents[i] = NodeImage(x);
  result = StrArrayNJoin((const char **)contents, i, sep);
  while(i-- > 0)
    free(contents[i]);
  free(contents);
  return result;
}


/* Returns an image of #node# and its subordinates in an allocated string. */
static DOMString
NodeImage(XmlNode node) {

  DOMString content;
  DOMString result;

  if(NodeType(node) == ATTRIBUTE_NODE || NodeType(node) == TEXT_NODE) {
    char *value = strdup(NodeValue(node));
    StrReplaceAll(&value, "&", "&amp;");
    StrReplaceAll(&value, "'", "&apos;");
    StrReplaceAll(&value, "<", "&lt;");
    StrReplaceAll(&value, ">", "&gt;");
    StrReplaceAll(&value, "\"", "&quot;");
    if(NodeType(node) == TEXT_NODE)
      return value;
    result = StrAppend(NULL, NodeName(node), "='", value, "'", NULL);
    free(value);
    return result;
  }

  if(NodeType(node) == CDATA_SECTION_NODE)
    result = StrAppend(NULL, "<![CDATA[", NodeValue(node), "]]>", NULL);
  else if(NodeType(node) == COMMENT_NODE)
    result = StrAppend(NULL, "<!--", NodeValue(node), "-->", NULL);
  else if(NodeType(node) == DOCUMENT_NODE ||
          NodeType(node) == DOCUMENT_FRAGMENT_NODE)
    result = NodeContentImage(node, 1, NULL);
  else if(NodeType(node) == DOCUMENT_TYPE_NODE) {
    result = StrAppend(NULL, "<!DOCTYPE ", NodeName(node), NULL);
    if(DocumentTypePublicId(node) != NULL)
      result = StrAppend
        (result, " PUBLIC '", DocumentTypePublicId(node), "'", NULL);
    else if(DocumentTypeSystemId(node) != NULL)
      result = StrAppend(result, " SYSTEM", NULL);
    if(DocumentTypeSystemId(node) != NULL)
      result =
        StrAppend(result, " '", DocumentTypeSystemId(node), "'", NULL);
    if(DocumentTypeInternalSubset(node) != NULL)
      result = StrAppend
        (result, " [", DocumentTypeInternalSubset(node), "]", NULL);
    result = StrAppend(result, ">", NULL);
  }
  else if(NodeType(node) == ENTITY_NODE) {
  }
  else if(NodeType(node) == ENTITY_REFERENCE_NODE)
    result = StrAppend(NULL, "&", NodeName(node), ";", NULL);
  else if(NodeType(node) == NOTATION_NODE) {
  }
  else if(NodeType(node) == PROCESSING_INSTRUCTION_NODE)
    result =
      StrAppend(NULL, "<?", ProcessingInstructionTarget(node), " ",
                ProcessingInstructionData(node), "?>", NULL);
  else { /* ELEMENT_NODE */
    result = StrAppend(NULL, "<", NodeName(node), NULL);
    if(NodeHasAttributes(node)) {
      content = NodeContentImage(node, 0, " ");
      result = StrAppend(result, " ", content, NULL);
      free(content);
    }
    if(!NodeHasChildNodes(node))
      result = StrAppend(result, "/>", NULL);
    else {
      content = NodeContentImage(node, 1, NULL);
      result = StrAppend(result, ">", content, "</", NodeName(node), ">", NULL);
      free(content);
    }
  }

  return result;

}


/*
 * Parsing state.  #get# is the function used to retrieve bytes; #param# its
 * parameter; #peek# the next byte to be retrieved; #offset# the number of
 * bytes that have been consumed; #collectBuffer#, #collectBufferSize# and
 * #collectBufferUsed# manage a character collection stack and #ungetBuffer#,
 * #ungetSize# and #ungetUsed# a pushback stack.
 */
typedef struct {
  XmlGet get;
  void *param;
  unsigned offset;
  int peek;
  char *collectBuffer;
  unsigned collectBufferSize;
  unsigned collectBufferUsed;
  char *ungetBuffer;
  unsigned ungetSize;
  unsigned ungetUsed;
} ParseInfo;


/* Begin collecting characters as they are returned from #pi#. */
static void
ParseInfoCollectBegin(ParseInfo *pi) {
  if(pi->collectBuffer != NULL)
    free(pi->collectBuffer);
  pi->collectBufferSize = 100;
  pi->collectBuffer = (char *)calloc(pi->collectBufferSize, sizeof(char));
  pi->collectBufferUsed = 0;
}


/*
 * Stop collecting characters as they are returned from #pi#.  Returns the
 * characters collected since the most recent call to ParseInfoCollectBegin(pi)
 * in an allocated string.
 */
static DOMString
ParseInfoCollectEnd(ParseInfo *pi) {
  DOMString result = pi->collectBuffer;
  pi->collectBuffer = NULL;
  return result;
}


/* Returns the next byte from the stream of #pi#, 0 if none. */
static int
ParseInfoGetc(ParseInfo *pi) {
  int c;
  int result = pi->peek;
  if(result != 0) {
    pi->peek = pi->ungetUsed > 0 ? pi->ungetBuffer[--pi->ungetUsed] :
               (c = pi->get(pi->param)) < 0 ? 0 : c;
    pi->offset++;
    if(pi->collectBuffer != NULL) {
      if(++pi->collectBufferUsed == pi->collectBufferSize) {
        pi->collectBufferSize += 100;
        pi->collectBuffer =
          (char *)Realloc(pi->collectBuffer, pi->collectBufferSize);
        memset(pi->collectBuffer + pi->collectBufferUsed, 0, 100);
      }
      pi->collectBuffer[pi->collectBufferUsed - 1] = result;
    }
  }
  return result;
}


/* Initializes #pi# to read bytes by passing #param# to #get#. */
static void
ParseInfoInit(ParseInfo *pi,
              XmlGet get,
              void *param) {
  memset(pi, 0, sizeof(ParseInfo));
  pi->get = get;
  pi->param = param;
  pi->peek = get(param);
}


/*
 * Returns #c# into the stream for #pi# so it will be returned by the next call
 * to ParseInfoGetc.  May be called repeatedly.
 */
static void
ParseInfoUngetc(ParseInfo *pi,
                int c) {
  if(c == 0)
    return;
  if(pi->ungetUsed == pi->ungetSize) {
    pi->ungetSize += 100;
    pi->ungetBuffer = (char *)Realloc(pi->ungetBuffer, pi->ungetSize);
  }
  pi->offset--;
  pi->ungetBuffer[pi->ungetUsed++] = pi->peek;
  pi->peek = c;
  if(pi->collectBuffer != NULL && pi->collectBufferUsed > 0)
    pi->collectBuffer[--pi->collectBufferUsed] = '\0';
}


/*
 * Returns the characters in #s# into the stream for #pi# so that they will be
 * returned in reverse order by subsequent calls to ParseInfoGetc.
 */
static void
ParseInfoUngets(ParseInfo *pi,
                DOMString s) {
  char *c;
  unsigned sLen = strlen(s);
  if(sLen == 0)
    return;
  while(pi->ungetUsed + sLen > pi->ungetSize) {
    pi->ungetSize += 100;
    pi->ungetBuffer = (char *)Realloc(pi->ungetBuffer, pi->ungetSize);
  }
  pi->offset -= sLen;
  pi->ungetBuffer[pi->ungetUsed++] = pi->peek;
  for(c = s + sLen - 1; c > s; c--)
    pi->ungetBuffer[pi->ungetUsed++] = *c;
  pi->peek = *s;
  if(pi->collectBuffer != NULL && pi->collectBufferUsed > 0) {
    pi->collectBufferUsed -=
      pi->collectBufferUsed > sLen ? sLen : pi->collectBufferUsed;
    pi->collectBuffer[pi->collectBufferUsed] = '\0';
  }
}


/*
 * Returns 1 and consumes the next strlen(#s#) characters from #s# if they
 * match #s#; otherwise, returns 0.
 */
static int
SkipOver(ParseInfo *pi,
         DOMString s) {
  DOMString current;
  for(current = s; *current != '\0' && pi->peek == *current; current++)
    ParseInfoGetc(pi);
  if(*current == '\0')
    return 1;
  while(current > s)
    ParseInfoUngetc(pi, *(--current));
  return 0;
}


/*
 * If #s# appears in #pi#, advances #pi# to point beyond the first occurence
 * and returns an allocated string that contains any preceding characters;
 * otherwise, returns 0.
 */
static DOMString
SkipPast(ParseInfo *pi,
         DOMString s) {
  char c;
  DOMString result = NULL;
  unsigned resultLen = 0;
  char sLast;
  unsigned sLen = strlen(s);
  sLast = s[sLen - 1];
  do {
    c = ParseInfoGetc(pi);
    if(c == '\0') {
      if(result != NULL) {
        ParseInfoUngets(pi, result);
        free(result);
      }
      return 0;
    }
    result = (DOMString)Realloc(result, resultLen + 2);
    result[resultLen++] = c;
    result[resultLen] = '\0';
  } while(c != sLast ||
          resultLen < sLen ||
          strcmp(result + resultLen - sLen, s) != 0);
  result = (DOMString)Realloc(result, resultLen - sLen + 1);
  result[resultLen - sLen] = '\0';
  return result;
}


/* Advances *c to point beyond any whitespace characters. */
static void
SkipSpace(ParseInfo *pi) {
  while(pi->peek == ' ' || pi->peek == '\t' ||
        pi->peek == '\n' || pi->peek == '\r')
    ParseInfoGetc(pi);
}


/* A convenience.  Sets #err# to #e#, frees #x# and #s#, then returns NULL. */
static XmlNode
ParseError(XmlParseErrorCodes e,
           XmlNode x,
           DOMString s,
           XmlParseErrorCodes *err) {
  *err = e;
  if(x != NULL)
    NodeFree(x);
  if(s != NULL)
    free(s);
  return NULL;
}


/* Parses a quoted string and returns its contents, NULL on failure. */
static DOMString
ParseQuoted(ParseInfo *pi) {
  char quote[2] = {0, 0};
  DOMString quoted;
  if(pi->peek != '\'' && pi->peek != '"')
    return NULL;
  quote[0] = ParseInfoGetc(pi);
  if((quoted = SkipPast(pi, quote)) == NULL)
    return NULL;
  return quoted;
}


/* Parses and returns a name.  Returns NULL on failure. */ 
static DOMString
ParseName(ParseInfo *pi) {
  DOMString result = NULL;
  unsigned resultLen;
  if(!isalpha((int)pi->peek) && pi->peek != '_' && pi->peek != ':')
    return NULL;
  resultLen = 0;
  while(isalnum((int)pi->peek) || pi->peek == '.' || pi->peek == '-' ||
        pi->peek == '_' || pi->peek == ':') {
    result = (DOMString)Realloc(result, resultLen + 2);
    result[resultLen] = ParseInfoGetc(pi);
    result[++resultLen] = '\0';
  }
  return result;
}


/* Replaces any entity references in *#s# with their values. */
static void
ResolveEntities(XmlDocument doc,
                DOMString *s) {

  XmlEntity entity;
  XmlDocumentType dtd = DocumentDoctype(doc);
  DOMString ref;
  DOMString refEnd;
  unsigned scanOffset = 0;
  DOMString refName;
  DOMString sub;
  unsigned subLen;
  char subChr[2] = {' ', '\0'};

  while((ref = strchr(*s + scanOffset, '&')) != NULL) {
    scanOffset = ref - *s;
    refEnd = ref + 1;
    if(*refEnd == '#') /* Character reference */
      subChr[0] = *(refEnd + 1) == 'x' ?
                  (char)strtol(refEnd + 2, &refEnd, 16) :
                  (char)strtol(refEnd + 1, &refEnd, 10);
    else if((refEnd = strchr(ref + 1, ';')) == NULL) {
      scanOffset++;
      continue;
    }
    refName = ref + 1;
    *refEnd = '\0';
    entity = NULL;
    if(*refName == '#')
      sub = subChr;
    else if(dtd != NULL &&
            (entity = NamedNodeMapGetNamedItem
                        (DocumentTypeEntities(dtd), refName)) != NULL) {
      /* NOTE: The original text of the entity is stored as its only child. */
      sub = strdup(NodeValue(NodeFirstChild(entity)));
      ResolveEntities(doc, &sub);
    }
    else
      sub = strcmp(refName, "amp") == 0 ? (DOMString)"&" :
            strcmp(refName, "apos") == 0 ? (DOMString)"'" :
            strcmp(refName, "gt") == 0 ? (DOMString)">" :
            strcmp(refName, "lt") == 0 ? (DOMString)"<" :
            strcmp(refName, "quot") == 0 ? (DOMString)"\"" : NULL;
    *refEnd = ';';
    if(sub == NULL) {
      scanOffset++;
      continue;
    }
    subLen = strlen(sub);
    StrNReplace(s, ref - *s, refEnd - ref + 1, sub, subLen);
    scanOffset += subLen;
    if(entity != NULL)
      free(sub);
  }

}


/*
 * Parses an attribute name and value and returns them in an ATTRIBUTE_NODE.
 * Returns NULL on failure.
 */
static XmlAttr
ParseAttribute(ParseInfo *pi,
               XmlDocument doc,
               XmlParseErrorCodes *err) {
  DOMString name;
  DOMString value;
  XmlAttr result;
  if((name = ParseName(pi)) == NULL)
    return ParseError(MISSING_NAME, NULL, NULL, err);
  SkipSpace(pi);
  if(pi->peek != '=')
    return ParseError(MISSING_EQ, NULL, name, err);
  ParseInfoGetc(pi);
  SkipSpace(pi);
  if((value = ParseQuoted(pi)) == NULL)
    return ParseError(MISSING_STRING, NULL, name, err);
  ResolveEntities(doc, &value);
  result = DocumentCreateNode(doc, ATTRIBUTE_NODE, NULL, name, value);
  free(name);
  free(value);
  return result;
}


/*
 * Parses a choice (|) or sequence (,) in a DTD element.  #allowPcdata#
 * indicates whether or not #PCDATA is allowed as the first item.  Returns
 * NULL (for now); any error is stored in #err#.
 */
static XmlNode
ParseChoiceOrSeq(ParseInfo *pi,
                 int allowPcdata,
                 XmlParseErrorCodes *err) {
  DOMString choiceName;
  int havePcData = 0;
  unsigned initialOffset;
  ParseInfoGetc(pi); /* Skip open paren */
  SkipSpace(pi);
  initialOffset = pi->offset;
  while(1) {
    if(allowPcdata && pi->offset == initialOffset && SkipOver(pi, "#PCDATA"))
      havePcData = 1;
    else if(!havePcData && pi->peek == '(') {
      ParseChoiceOrSeq(pi, 0, err);
      if(*err != 0)
        return ParseError(*err, NULL, NULL, err);
    }
    else if((choiceName = ParseName(pi)) == NULL)
      return ParseError(MISSING_NAME, NULL, NULL, err);
    else
      free(choiceName);
    SkipSpace(pi);
    if(pi->peek != '|' && (havePcData || pi->peek != ','))
      break;
    ParseInfoGetc(pi);
    SkipSpace(pi);
  }
  if(pi->peek != ')')
    return ParseError(MISSING_CLOSE, NULL, NULL, err);
  else if(pi->offset == initialOffset)
    return ParseError(MISSING_NAME, NULL, NULL, err);
  ParseInfoGetc(pi);
  if(pi->peek == '*')
    ParseInfoGetc(pi);
  else if(havePcData)
    return ParseError(MISSING_CLOSE, NULL, NULL, err);
  else if(pi->peek == '?' || pi->peek == '+')
    ParseInfoGetc(pi);
  return NULL;
}


static void
ParseContent(XmlDocument doc,
             ParseInfo *pi,
             DOMString terminator,
             XmlNode scope,
             XmlNode parent,
             int discardComments,
             int discardWhitespace,
             XmlExternalReader reader,
             XmlParseErrorCodes *err);


/*
 * Parses a public/system id pair and returns them in #publik# and #system#.
 * Returns 1 on success, else 0.
 */
static int
ParseIds(ParseInfo *pi,
         DOMString *publik,
         DOMString *system,
         XmlParseErrorCodes *err) {
  int isPublik;
  DOMString id;
  *publik = *system = NULL;
  if(SkipOver(pi, "PUBLIC"))
    isPublik = 1;
  else if(SkipOver(pi, "SYSTEM"))
    isPublik = 0;
  else
    return 0;
  SkipSpace(pi);
  if((id = ParseQuoted(pi)) == NULL) {
    *err = MISSING_STRING;
    return 0;
  }
  if(isPublik) {
    *publik = id;
    SkipSpace(pi);
    *system = ParseQuoted(pi);
  }
  else
    *system = id;
  return 1;
}


/*
 * Parses an XML markup item (i.e., '<>' and its contents).  Returns the
 * subtree headed by the item, NULL on error.  Note: a document fragment that
 * contains the content is returned for the <![INCLUDE[]]> directive.
 */
static XmlNode
ParseMarkup(ParseInfo *pi,
            XmlDocument doc,
            XmlNode scope,
            int discardComments,
            int discardWhitespace,
            XmlExternalReader reader,
            XmlParseErrorCodes *err) {

  XmlNamedNodeMap attrs;
  DOMString endTag;
  unsigned i;
  DOMString name;
  DOMString publicId;
  DOMString systemId;
  XmlNode result;
  DOMString value;
  XmlNode x;

  ParseInfoGetc(pi); /* Skip '<' */

  if(SkipOver(pi, "?")) {
    if((name = ParseName(pi)) == NULL)
      return ParseError(MISSING_NAME, NULL, NULL, err);
    SkipSpace(pi);
    if((value = SkipPast(pi, "?>")) == NULL)
      return ParseError(MISSING_CLOSE, NULL, name, err);
    result = DocumentCreateProcessingInstruction(doc, name, value);
    free(name);
    free(value);
    return result;
  }
  else if(SkipOver(pi, "!")) {
    if(SkipOver(pi, "--")) {
      if((value = SkipPast(pi, "-->")) == NULL)
        return ParseError(MISSING_CLOSE, NULL, NULL, err);
      if(discardComments) {
        free(value);
        return NULL;
      }
      result = DocumentCreateComment(doc, value);
      free(value);
    }
    else if(SkipOver(pi, "[CDATA[")) {
      if((value = SkipPast(pi, "]]>")) == NULL)
        return ParseError(MISSING_CLOSE, NULL, NULL, err);
      result = DocumentCreateCdataSection(doc, value);
      free(value);
    }
    else if(SkipOver(pi, "DOCTYPE")) {
      DOMString internalSubset;
      SkipSpace(pi);
      if((name = ParseName(pi)) == NULL)
        return ParseError(MISSING_NAME, NULL, NULL, err);
      SkipSpace(pi);
      ParseIds(pi, &publicId, &systemId, err);
      result = ImplementationCreateDocumentType(NULL, name, publicId, systemId);
      free(name);
      if(publicId != NULL)
        free(publicId);
      if(systemId != NULL)
        free(systemId);
      if(*err != 0)
        return ParseError(*err, result, NULL, err);
      SkipSpace(pi);
      if(SkipOver(pi, "[")) {
        ParseInfoCollectBegin(pi);
        ParseContent(doc, pi, "]", scope, result, 1, 1, reader, err);
        internalSubset = ParseInfoCollectEnd(pi);
        if(*err != 0)
          return ParseError(*err, result, internalSubset, err);
        internalSubset[strlen(internalSubset) - 1] = '\0'; /* Trim ']' */
        DocumentTypeSetInternalSubset(result, internalSubset);
        free(internalSubset);
        SkipSpace(pi);
      }
      if(!SkipOver(pi, ">"))
        return ParseError(MISSING_CLOSE, result, NULL, err);
      if(reader != NULL && (publicId != NULL || systemId != NULL)) {
        /* TODO Read the external subset */
      }
    }
    else if(SkipOver(pi, "ATTLIST")) {
      /* TODO Save this information somewhere for validation. */
      DOMString attrName;
      DOMString defaultType;
      DOMString defaultValue;
      DOMString elementName;
      int fixedDefault;
      DOMString valueName;
      SkipSpace(pi);
      if((elementName = ParseName(pi)) == NULL)
        return ParseError(MISSING_NAME, NULL, NULL, err);
      free(elementName);
      SkipSpace(pi);
      while((attrName = ParseName(pi)) != NULL) {
        free(attrName);
        SkipSpace(pi);
        if((valueName = ParseName(pi)) != NULL) {
          free(valueName);
          SkipSpace(pi);
        }
        if(SkipOver(pi, "(")) {
          SkipSpace(pi);
          if((valueName = ParseName(pi)) == NULL)
            return ParseError(MISSING_NAME, NULL, NULL, err);
          free(valueName);
          SkipSpace(pi);
          while(SkipOver(pi, "|")) {
            SkipSpace(pi);
            if((valueName = ParseName(pi)) == NULL)
              return ParseError(MISSING_NAME, NULL, NULL, err);
            free(valueName);
            SkipSpace(pi);
          }
          if(!SkipOver(pi, ")"))
            return ParseError(MISSING_CLOSE, NULL, NULL, err);
          SkipSpace(pi);
        }
        if(SkipOver(pi, "#")) {
          if((defaultType = ParseName(pi)) == NULL)
            return ParseError(MISSING_NAME, NULL, NULL, err);
          fixedDefault = strcmp(defaultType, "FIXED") == 0;
          free(defaultType);
          SkipSpace(pi);
        }
        else
          fixedDefault = 1;
        if(fixedDefault) {
          if((defaultValue = ParseQuoted(pi)) == NULL)
            return ParseError(MISSING_STRING, NULL, NULL, err);
          free(defaultValue);
          SkipSpace(pi);
        }
      }
      if(!SkipOver(pi, ">"))
        return ParseError(MISSING_CLOSE, NULL, NULL, err);
      return NULL;
    }
    else if(SkipOver(pi, "ELEMENT")) {
      /* TODO Save this information somewhere for validation. */
      DOMString elementName;
      SkipSpace(pi);
      if((elementName = ParseName(pi)) == NULL)
        return ParseError(MISSING_NAME, NULL, NULL, err);
      free(elementName);
      SkipSpace(pi);
      if(SkipOver(pi, "ANY") || SkipOver(pi, "EMPTY"))
        ; /* empty */
      else if(pi->peek == '(') {
        ParseChoiceOrSeq(pi, 1, err);
        if(*err != 0)
          return ParseError(*err, NULL, NULL, err);
      }
      else
        return ParseError(UNKNOWN_CONTENT, NULL, NULL, err);
      SkipSpace(pi);
      if(!SkipOver(pi, ">"))
        return ParseError(MISSING_CLOSE, NULL, NULL, err);
      return NULL;
    }
    else if(SkipOver(pi, "ENTITY")) {
      int parameterEntity = 0;
      DOMString notationName;
      SkipSpace(pi);
      if(SkipOver(pi, "%")) {
        parameterEntity = 1;
        SkipSpace(pi);
      }
      if((name = ParseName(pi)) == NULL)
        return ParseError(MISSING_NAME, NULL, NULL, err);
      SkipSpace(pi);
      if(ParseIds(pi, &publicId, &systemId, err))
        value = NULL;
      else if(*err != 0)
        return ParseError(*err, NULL, name, err);
      else if((value = ParseQuoted(pi)) == NULL)
        return ParseError(MISSING_STRING, NULL, name, err);
      SkipSpace(pi);
      if(SkipOver(pi, "NDATA")) {
        SkipSpace(pi);
        if((notationName = ParseQuoted(pi)) == NULL) {
          if(publicId != NULL)
            free(publicId);
          if(systemId != NULL)
            free(publicId);
          if(value != NULL)
            free(publicId);
          return ParseError(MISSING_STRING, NULL, name, err);
        }
      }
      else
        notationName = NULL;
      result = DocumentCreateEntity
        (doc, name, parameterEntity, publicId, systemId, notationName);
      free(name);
      if(publicId != NULL)
        free(publicId);
      if(systemId != NULL)
        free(systemId);
      if(notationName != NULL)
        free(notationName);
      if(value != NULL) {
        NodeAppendChild(result, DocumentCreateTextNode(doc, value));
        free(value);
      }
      SkipSpace(pi);
      if(!SkipOver(pi, ">"))
        return ParseError(MISSING_CLOSE, result, NULL, err);
    }
    else if(SkipOver(pi, "NOTATION")) {
      SkipSpace(pi);
      if((name = ParseName(pi)) == NULL)
        return ParseError(MISSING_NAME, NULL, NULL, err);
      SkipSpace(pi);
      if(!ParseIds(pi, &publicId, &systemId, err))
        return ParseError(*err, NULL, name, err);
      result = DocumentCreateNotation(doc, name, publicId, systemId);
      free(name);
      if(publicId != NULL)
        free(publicId);
      if(systemId != NULL)
        free(systemId);
      SkipSpace(pi);
      if(!SkipOver(pi, ">"))
        return ParseError(MISSING_CLOSE, result, NULL, err);
    }
    else if(SkipOver(pi, "[")) {
      int tossIt;
      SkipSpace(pi);
      if(SkipOver(pi, "IGNORE"))
        tossIt = 1;
      else if(SkipOver(pi, "INCLUDE"))
        tossIt = 0;
      else
        return ParseError(UNKNOWN_TAG, NULL, NULL, err);
      SkipSpace(pi);
      if(!SkipOver(pi, "["))
        return ParseError(UNKNOWN_TAG, NULL, NULL, err);
      result = DocumentCreateDocumentFragment(doc);
      ParseContent(doc, pi, "]]>", scope, result, 1, 1, reader, err);
      if(*err != 0)
        return ParseError(*err, result, NULL, err);
      if(tossIt) {
        NodeFree(result);
        return NULL;
      }
    }
    else
      return ParseError(UNKNOWN_TAG, NULL, NULL, err);
    return result;
  }

  if((name = ParseName(pi)) == NULL)
    return ParseError(MISSING_NAME, NULL, NULL, err);

  result = DocumentCreateElement(doc, name);
  free(name);

  /* Attribute parsing */
  for(SkipSpace(pi); pi->peek != '>' && pi->peek != '/'; SkipSpace(pi)) {
    if((x = ParseAttribute(pi, doc, err)) == NULL)
      return ParseError(*err, result, NULL, err);
    ElementSetAttributeNode(result, x);
    if(scope != result && strncmp(NodeName(x), "xmlns", 5) == 0) {
      /*
       * This element defines a namespace.  Add it to the namespace lookup
       * chain by temporarily making it a child node of #scope#; we'll remove
       * it before returning.
       */
      if(scope != NULL)
        NodeInsertAfter(scope, result, NULL);
      scope = result;
    }
  }
  /* Add namespaces to attributes and result as needed. */
  if(scope != NULL) {
    if(NodeHasAttributes(result)) {
      attrs = NodeAttributes(result);
      for(i = 0; (x = NamedNodeMapItem(attrs, i)) != NULL; i++)
        NodeSetNamespaceUri(x, LookupNS(scope, NodeName(x), 0));
    }
    NodeSetNamespaceUri(result, LookupNS(scope, NodeName(result), 1));
  }

  if(pi->peek == '/') {
    if(!SkipOver(pi, "/>"))
      return ParseError(MISSING_CLOSE, result, NULL, err);
    /* Remove temporary parent assignment. */
    if(scope == result && NodeParentNode(result) != NULL)
      NodeRemoveChild(NodeParentNode(result), result);
    return result;
  }
  ParseInfoGetc(pi); /* Skip '>' */

  /* Child parsing */
  ParseContent
    (doc, pi, "</", scope, result, discardComments, discardWhitespace, reader,
     err);
  if(*err != 0)
    return ParseError(*err, result, NULL, err);

  /* End tag parsing */
  endTag = ParseName(pi);
  if(endTag == NULL || strcmp(endTag, NodeName(result)) != 0)
    return ParseError(INVALID_CLOSING_TAG, result, endTag, err);
  free(endTag);
  SkipSpace(pi);
  if(!SkipOver(pi, ">"))
    return ParseError(MISSING_CLOSE, result, NULL, err);
  /* Remove temporary parent assignment. */
  if(scope == result && NodeParentNode(result) != NULL)
    NodeRemoveChild(NodeParentNode(result), result);
  return result;

}


/*
 * As appropriate, either discards #owned# or makes it a child of #node# by
 * adding it as the right sibling of #lastChild# (the latter parameter is for
 * efficiency) and setting #lastChild# to #owned#.
 */
static void
NodeTakeOwnership(XmlNode node,
                  XmlNode owned,
                  XmlNode *lastChild) {
  if(NodeType(node) == DOCUMENT_TYPE_NODE && NodeType(owned) == TEXT_NODE)
    NodeFree(owned); /* Discard whitespace inside DTD. */
  else if(NodeType(node) == DOCUMENT_TYPE_NODE &&
          (NodeType(owned)==ENTITY_NODE || NodeType(owned)==NOTATION_NODE)) {
    XmlNamedNodeMap map = NodeType(owned) == ENTITY_NODE ?
      DocumentTypeEntities(node) : DocumentTypeNotations(node);
    if(NamedNodeMapGetNamedItem(map, NodeName(owned)) == NULL)
      NamedNodeMapSetNamedItem(map, owned);
    else
      NodeFree(owned);
  }
  else {
    NodeInsertAfter(node, owned, *lastChild);
    *lastChild = owned;
  }
}


/*
 * Parses the content of an XML tag or the document as a whole. #doc# is the
 * owning document; #terminator# the tag termination text, if any; #scope# the
 * head of the URI scope chain, #parent# the XML node under which the parsed
 * content should be stored.
 */
static void
ParseContent(XmlDocument doc,
             ParseInfo *pi,
             DOMString terminator,
             XmlNode scope,
             XmlNode parent,
             int discardComments,
             int discardWhitespace,
             XmlExternalReader reader,
             XmlParseErrorCodes *err) {

  XmlNode last = NULL;
  DOMString value;
  XmlNode x;

  while(pi->peek != *terminator || !SkipOver(pi, terminator)) {
    if(pi->peek == '\0') {
      ParseError(MISSING_CLOSING_TAG, NULL, NULL, err);
      break;
    }
    if(pi->peek == '<') {
      x = ParseMarkup
        (pi, doc, scope, discardComments, discardWhitespace, reader, err);
    }
    else {
      /* Text */
      char termLast;
      unsigned termLen = strlen(terminator);
      char valueLast = '\0';
      unsigned valueLen = 0;
      termLast = termLen == 0 ? '\0' : terminator[termLen - 1];
      if(discardWhitespace)
        SkipSpace(pi);
      value = strdup("");
      while(pi->peek != '\0' && pi->peek != '<') {
        value = (DOMString)Realloc(value, valueLen + 2);
        value[valueLen++] = valueLast = ParseInfoGetc(pi);
        value[valueLen] = '\0';
        if(valueLen >= termLen &&
           valueLast == termLast &&
           strcmp(value + valueLen - termLen, terminator) == 0) {
          valueLen -= termLen;
          value[valueLen] = '\0';
          ParseInfoUngets(pi, terminator);
          break;
        }
      }
      if(discardWhitespace) {
        while(valueLen > 0 && strchr(" \t\r\n", value[valueLen - 1]) != NULL)
          valueLen--;
        value[valueLen] = '\0';
      }
      if(valueLen == 0) {
        free(value);
        continue; /* Discard text consisting of nothing but whitespace. */
      }
      ResolveEntities(doc, &value);
      x = DocumentCreateTextNode(doc, value);
      free(value);
    }
    if(*err != 0)
      break;
    else if(x == NULL)
      continue;
    if(NodeType(x) == DOCUMENT_FRAGMENT_NODE) { /* <![INCLUDE[]]> */
      while(NodeHasChildNodes(x))
        NodeTakeOwnership(parent, NodeFirstChild(x), &last);
      NodeFree(x);
    }
    else if(parent == doc && (NodeType(x) == TEXT_NODE ||
            NodeType(x) == CDATA_SECTION_NODE))
      NodeFree(x); /* Doc-level text is ignored. */
    else
      NodeTakeOwnership(parent, x, &last);
  }

}


XmlDocument
XmlFromStream(XmlGet get,
              void *getParam,
              char *encoding,
              int discardComments,
              int discardWhitespace,
              XmlExternalReader reader,
              XmlParseErrorCodes *error,
              unsigned long *errorOffset) {
  XmlNode doc = ImplementationCreateDocument(NULL, NULL, "#document", NULL);
  XmlParseErrorCodes err = (XmlParseErrorCodes)0;
  ParseInfo pi;
  XmlNode x;
  DocumentSetEncoding(doc, encoding == NULL ? (char *)"UTF-8" : encoding);
  ParseInfoInit(&pi, get, getParam);
  ParseContent
    (doc, &pi, "", NULL, doc, discardComments, discardWhitespace, reader, &err);
  if(pi.collectBuffer != NULL)
    free(pi.collectBuffer);
  if(pi.ungetBuffer != NULL)
    free(pi.ungetBuffer);
  if(err == 0) {
    if((x = DocumentElement(doc)) == NULL)
      err = MISSING_TOP_TAG;
    else if(NodeNextSiblingByType(x, SHOW_ELEMENT) != NULL)
      err = MULTIPLE_TOP_TAGS;
  }
  if(err != 0) {
    if(error != NULL)
      *error = err;
    if(errorOffset != NULL)
      *errorOffset = pi.offset;
    NodeFree(doc);
    return NULL;
  }
  return doc;
}


static int
DOMStringGet(void *param) {
  DOMString *s = (DOMString *)param;
  return **s == '\0' ? 0 : *((*s)++);
}


XmlDocument
XmlFromString(DOMString s,
              char *encoding,
              int discardComments,
              int discardWhitespace,
              XmlExternalReader reader,
              XmlParseErrorCodes *error,
              unsigned long *errorOffset) {
  return XmlFromStream
    (&DOMStringGet, &s, encoding, discardComments, discardWhitespace, reader,
     error, errorOffset);
}


DOMString
XmlToString(XmlNode node,
            DOMString indent) {

  DOMString c;
  DOMString d;
  DOMString image = NodeImage(node);
  DOMString insert;
  unsigned level;
  char next;
  unsigned offset;
  DOMString spacing;

  if(indent == NULL)
    return image;
  for(level = 0, c = strchr(image, '<'); c != NULL; c = strchr(c + 1, '<')) {
    next = *(c + 1);
    if(next == '/')
      level--;
    for(d = c - 1; d >= image && *d != '\n' && isspace((int)*d); d--)
      ; /* empty */
    if(d >= image && *d != '\n') {
      spacing = StrRepeat(indent, level);
      insert = StrAppend(NULL, "\n", spacing, NULL);
      offset = c - image;
      StrReplace(&image, offset, 0, insert);
      c = image + offset + strlen(insert);
      free(insert);
      free(spacing);
    }
    if(isalpha((int)next) || next == '_' || next == ':')
      level++;
    c = strchr(c + 1, '>');
    if(*(c - 1) == '/')
      level--;
  }
  return image;

}
