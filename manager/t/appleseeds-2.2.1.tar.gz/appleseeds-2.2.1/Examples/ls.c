/* $Id: ls.c,v 1.15 2003/09/05 16:51:45 jhayes Exp $ */
/*
 * Copyright � 2002 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


/*
 * This is a simple test program for the directory and file attribute functions
 * in the appleseed library.  It implements a simplified version of ls.
 * Usage:
 *   ls [-SXalrt1] [<path> ...]
 */


#include "oshseed.h"
#include <stddef.h>     /* offsetof */
#include <stdio.h>      /* fprintf sprintf */
#include <stdlib.h>     /* free malloc */
#include <string.h>     /* strlen strrchr */
#include <time.h>       /* ctime */
#include "appleseeds.h" /* AS_Entities */
#define ASENV_SHORT_NAMES
#include "envseed.h"
#define ASFILE_SHORT_NAMES
#include "fileseed.h"
#define ASV_SHORT_NAMES
#include "vectorseed.h"


/* Ways of sorting a list of files. */
typedef enum {
  BY_EXTENSION, BY_NAME, BY_SIZE, BY_TIME
} SortCriteria;


/* Information about a particular file. */
typedef struct {
  char name[256 + 1]; /* File name */
  FileFacts facts;    /* Info returned from ASENV_GetFileFacts */
} FileInfo;


/* Returns the text after the last "." in #fileName#, or "" if there is none. */
static const char *
Extension(const char *fileName) {
  const char *dot = strrchr(fileName, '.');
  return (dot == NULL) ? "" : (dot + 1);
}


/*
 * Looks at the member #offset# bytes into each element of the vector #files#
 * and returns the print length of the longest value.  #integer# indicates
 * whether or not the member is an integer, instead of a char array.
 */
static unsigned
Longest(FileInfo *files,
        unsigned offset,
        int integer) {

  FileInfo *file;
  unsigned i;
  char image[63 + 1];
  unsigned returnValue = 0;

  for(i = 0, file = files; i < Size(files); i++, file++) {
    if(integer)
      sprintf(image, "%d", *(unsigned int *)((char *)file + offset));
    else
      sprintf(image, "%s", (char *)file + offset);
    if(strlen(image) > returnValue)
      returnValue = strlen(image);
  }

  return returnValue;

}


/*
 * Displays each file in the vector #files# to the user.  The other parameters
 * indicate: whether hidden files should be included in the display; whether
 * details should be included; the sorting criteria; whether the sort should be
 * in reverse order, whether only one file should be listed per line (as
 * opposed to as many as will fit).
 */
static void
DisplayFiles(const FileInfo *files,
             int displayHidden,
             int longDisplay,
             SortCriteria sort,
             int reverseSort,
             int onePerLine) {

  FileInfo *copy;
  unsigned i;
  unsigned j;
  FileInfo info;
  unsigned longestGroup, longestName, longestOwner, longestSize;
  int swap;
  char timeImage[31 + 1];
  time_t timeWritten;
  unsigned widthLeft;

  copy = VectorNew(FileInfo);
  for(i = 0; i < Size(files); i++) {
    if(displayHidden || !files[i].facts.isHidden)
      Append(copy, files[i]);
  }

  /* Sort the files using a really inefficient algorithm. */
  for(i = 0; i < Size(copy); i++) {
    for(j = i + 1; j < Size(copy); j++) {
      swap = (sort == BY_EXTENSION) ?
               (strcmp(Extension(copy[j].name), Extension(copy[i].name)) < 0) :
             (sort == BY_SIZE) ? (copy[j].facts.size < copy[i].facts.size) :
             (sort == BY_TIME) ?
                (copy[j].facts.lastWrite < copy[i].facts.lastWrite) :
             /* BY_NAME */ (strcmp(copy[j].name, copy[i].name) < 0);
      if(reverseSort)
        swap = !swap;
      if(swap) {
        info = copy[i];
        copy[i] = copy[j];
        copy[j] = info;
      }
    }
  }

  if(Size(copy) > 0) {
    if(longDisplay) {
      longestGroup =
        Longest(copy, offsetof(FileInfo,facts) + offsetof(FileFacts,group), 0);
      longestOwner =
        Longest(copy, offsetof(FileInfo,facts) + offsetof(FileFacts,owner), 0);
      longestSize =
        Longest(copy, offsetof(FileInfo,facts) + offsetof(FileFacts,size), 1);
      /* Add spacing if we have group and owner information. */
      if(longestGroup > 0)
        longestGroup += 2;
      if(longestOwner > 0)
        longestOwner += 2;
      for(i = 0; i < Size(copy); i++) {
        /* Dump day of week and trailing \n from image of time modified. */
        timeWritten = copy[i].facts.lastWrite;
        strncpy(timeImage, ctime(&timeWritten) + 4, sizeof(timeImage));
        timeImage[strlen(timeImage) - 1] = '\0';
        fprintf(stdout, "%c%c%c%c%c%c%c%c%c%c",
                copy[i].facts.isADirectory ? 'd' : ' ',
                copy[i].facts.readPermission[AS_OWNER] ? 'r' : '-',
                copy[i].facts.writePermission[AS_OWNER] ? 'w' : '-',
                copy[i].facts.execPermission[AS_OWNER] ? 'x' : '-',
                copy[i].facts.readPermission[AS_GROUP] ? 'r' : '-',
                copy[i].facts.writePermission[AS_GROUP] ? 'w' : '-',
                copy[i].facts.execPermission[AS_GROUP] ? 'x' : '-',
                copy[i].facts.readPermission[AS_OTHERS] ? 'r' : '-',
                copy[i].facts.writePermission[AS_OTHERS] ? 'w' : '-',
                copy[i].facts.execPermission[AS_OTHERS] ? 'x' : '-');
        fprintf(stdout, "  %-*s%-*s%-*ld  %s  ",
                longestOwner, copy[i].facts.owner,
                longestGroup, copy[i].facts.group,
                longestSize, copy[i].facts.size,
                timeImage);
        fprintf(stdout, "%s\n", copy[i].name);
      }
    }
    else if(onePerLine) {
      for(i = 0; i < Size(copy); i++)
        fprintf(stdout, "%s\n", copy[i].name);
    }
    else {
      longestName = Longest(copy, offsetof(FileInfo, name), 0);
      widthLeft = 80;
      for(i = 0; i < Size(copy); i++) {
        fprintf(stdout, "%-*s", longestName, copy[i].name);
        if((widthLeft -= longestName + 1) < longestName) {
          fprintf(stdout, "\n");
          widthLeft = 80;
        }
        else
          fprintf(stdout, " ");
      }
      if(widthLeft != 80)
        fprintf(stdout, "\n");
    }
  }

  VectorFree(copy);

}


/* Returns a vector of info for files accessed by #path#, or NULL on error. */
static FileInfo *
GetFiles(const char *path) {

  char *dir;
  FileInfo info;
  char **fileNames;
  char *filePath;
  unsigned i;
  char *pattern;
  FileInfo *returnValue;

  dir = strdup(path);
  if((pattern = strrchr(dir, ASOSH_FILE_PATH_SEPARATOR[0])) == NULL)
    pattern = dir;
  else
    pattern++;
  if(strchr(pattern, '*') == NULL && strchr(pattern, '?') == NULL &&
     strchr(pattern, '[') == NULL)
    pattern = NULL;
  else if(pattern == dir)
    dir = strdup(".");
  else
    *(pattern - 1) = '\0';
  if((fileNames = DirectoryContents(dir, pattern)) == NULL) {
    free(dir);
    return NULL;
  }

  returnValue = VectorNew(FileInfo);

  for(i = 0; fileNames[i] != NULL; i++) {
    memset(&info, 0, sizeof(info));
    strncpy(info.name, fileNames[i], sizeof(info.name));
    filePath = (char *)malloc
      (strlen(dir)+strlen(ASOSH_FILE_PATH_SEPARATOR)+strlen(fileNames[i])+1);
    sprintf(filePath, "%s" ASOSH_FILE_PATH_SEPARATOR "%s", dir, fileNames[i]);
    if(!GetFileFacts(filePath, &info.facts))
      fprintf(stderr, "Unable to get info for %s\n", filePath);
    free(filePath);
    Append(returnValue, info); 
    free(fileNames[i]);
  }

  free(fileNames);
  free(dir);
  return returnValue;

}


int
main(int argc,
     const char *const *argv) {

  FileInfo *files;
  unsigned i;
  ParsedArgv pa;
  SortCriteria sort;
  const char *validSwitches =
    "-S void   sort by file size\n"
    "-X void   sort by file extension\n"
    "-a void   include all files in display\n"
    "-l void   long display\n"
    "-r void   reverse sort\n"
    "-t void   sort by modification time\n"
    "-1 void   list 1 file per line\n"
    "   string path to list";

  if((pa = ParseArgv(argv, validSwitches, NULL)) == NULL) {
    fprintf(stderr, "%s\n", validSwitches);
    return 1;
  }
  sort = SwitchPresent(pa, "-S") ? BY_SIZE :
         SwitchPresent(pa, "-X") ? BY_EXTENSION :
         SwitchPresent(pa, "-t") ? BY_TIME : BY_NAME;
  for(i = 1; i < 2 || SwitchValueN(pa, "", i, NULL) != NULL; i++) {
    if((files = GetFiles(SwitchValueN(pa, "", i, "."))) == NULL)
      fprintf(stderr, "Unable to read %s\n", SwitchValueN(pa, "", i, "."));
    else {
      DisplayFiles
        (files, SwitchPresent(pa, "-a"), SwitchPresent(pa, "-l"), sort,
         SwitchPresent(pa, "-r"), SwitchPresent(pa, "-1"));
      printf("\n");
      VectorFree(files);
    }
  }
  ParsedArgvFree(pa);
  return 0;

}
