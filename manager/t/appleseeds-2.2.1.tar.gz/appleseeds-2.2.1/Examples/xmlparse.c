/* $Id: xmlparse.c,v 1.10 2004/12/07 18:01:38 jhayes Exp $ */
/*
 * Copyright � 2002 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


/*
 * This is a simple test program for the XML functions in the appleseed
 * library. Usage:
 *   xmlparse [-p] [-v] [<file> ...]
 */


#include <stdio.h>  /* file functions */
#include <stdlib.h> /* free getenv */
#include <string.h> /* strcmp */
#define ASFILE_SHORT_NAMES
#include "fileseed.h"
#define ASSTR_SHORT_NAMES
#include "strseed.h"
#define ASXML_SHORT_NAMES
#include "xmlseed.h"


static const char *ERROR_MESSAGES[] = {
  "",
  "Invalid closing tag",
  "Missing closer",
  "Missing closing tag",
  "'=' expected",
  "XML name expected",
  "Quoted string expected",
  "Missing top tag",
  "Multiple top tags",
  "Unknown content",
  "Unknown tag"
};


#define DISPLAY_FREQUENCY 100000
static int charCount, charsUntilDisplay;
static int
FileGet(void *f) {
  charCount++;
  if(--charsUntilDisplay == 0) {
    fprintf(stdout, "%d\n", charCount);
    charsUntilDisplay = DISPLAY_FREQUENCY;
  }
  return fgetc((FILE *)f);
}


int
main(int argc,
     char **argv) {

  char buffer[256 + 1];
  char *c;
  XmlDocument doc;
  ASXML_XmlParseErrorCodes err;
  char *errLine;
  unsigned long errOffset;
  FILE *f;
  int line;
  int print = 0;
  int validate = 0;

  for(argv++; *argv != NULL && **argv == '-'; argv++) {
    if(strcmp(*argv, "-p") == 0)
      print = 1;
    else if(strcmp(*argv, "-v") == 0)
      validate = 1;
  }
  do {
    err = (ASXML_XmlParseErrorCodes)0;
    if(*argv == NULL) {
      char *contents = NULL;
      while(fgets(buffer, sizeof(buffer), stdin) != NULL)
        contents = StrAppend(contents, buffer, NULL);
      doc = XmlFromString(contents, NULL, 0, 1, NULL, &err, &errOffset);
      if(err != 0) {
        for(line = 1, errLine = contents;
            (c = strchr(errLine, '\n')) != NULL && c - contents < errOffset;
            line++, errLine = c + 1)
          ; /* empty */
        if(c != NULL)
          *c = '\0';
        errOffset -= errLine - contents;
        fprintf(stderr, "%s\n", errLine);
        fprintf(stderr, "%*s\n", (int)errOffset + 1, "^");
        fprintf(stderr, "Line %d: %s\n", line, ERROR_MESSAGES[err]);
      }
      free(contents);
    }
    else if((f = fopen(*argv, "r")) == NULL) {
      fprintf(stderr, "Unable to open %s\n", *argv);
      continue;
    }
    else {
      charCount = 0;
      charsUntilDisplay = DISPLAY_FREQUENCY;
      doc = XmlFromStream(&FileGet, f, NULL, 0, 1, NULL, &err, &errOffset);
      if(err != 0) {
        for(line = 1, rewind(f);
            fgets(buffer, sizeof(buffer), f) != NULL &&
            errOffset > strlen(buffer);
            errOffset -= strlen(buffer))
          if(strchr(buffer, '\n') != NULL)
            line++;
        fprintf(stderr, strchr(buffer, '\n') == NULL ? "%s\n" : "%s", buffer);
        fprintf(stderr, "%*s\n", (int)errOffset + 1, "^");
        fprintf(stderr, "Line %d: %s\n", line, ERROR_MESSAGES[err]);
      }
      fclose(f);
    }
    if(err != 0)
      ; /* empty */
    else if(validate) {
      /* TODO */
    }
    else if(print) {
      c = XmlToString(doc, "  ");
      printf("%s\n", c);
      free(c);
    }
    else
      fprintf(stdout, "%s is well-formed\n", *argv == NULL ? "xml" : *argv);
    if(doc != NULL)
      NodeFree(doc);
  } while(*argv != NULL && *(++argv) != NULL);

  return 0;

}
