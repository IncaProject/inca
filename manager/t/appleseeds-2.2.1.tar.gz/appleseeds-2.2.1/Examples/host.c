/* $Id: host.c,v 1.7 2003/09/05 16:51:45 jhayes Exp $ */
/*
 * Copyright � 2002 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


/*
 * This is a simple test program for the DNS functions in the appleseed
 * library.  It emulates the "host" program found on many Unix machines.
 * Usage:
 *   host <ip or dns name> [<ip or dns name> ...]
 */


#include <stdio.h>  /* fprintf */
#include <stdlib.h> /* free */
#define ASIP_SHORT_NAMES
#include "ipseed.h"


#define MAX_ADDRESSES 20


int
main(int argc,
     char **argv) {

  int addrCount;
  Address addresses[MAX_ADDRESSES];
  int i;
  int j;
  char *s;

  if(argc < 1) {
    fprintf(stderr, "usage: host <ip or dns name> [<ip or dns name> ...]\n");
    return 1;
  }

  for(i = 1; i < argc; i++) {
    addrCount = AddressValues(argv[i], addresses, MAX_ADDRESSES);
    if(addrCount == 0) {
      fprintf(stdout, "%s ?", argv[i]);
    }
    else {
      s = AddressMachine(addresses[0]);
      fprintf(stdout, "%s", s == NULL ? "?" : s);
      if(s != NULL)
        free(s);
      for(j = 0; j < addrCount; j++) {
        s = AddressImage(addresses[j]);
        fprintf(stdout, " %s", s == NULL ? "?" : s);
        if(s != NULL)
          free(s);
      }
    }
    fprintf(stdout, "\n");
  }

  return 0;

}
