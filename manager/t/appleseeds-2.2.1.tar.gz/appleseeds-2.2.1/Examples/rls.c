/* $Id: rls.c,v 1.32 2003/09/30 17:32:54 jhayes Exp $ */
/*
 * Copyright � 2002 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


/*
 * This is test code for the socket and data transmission functions in the
 * appleseed library; it also uses diagnosticseed, envseed, and vectorseed.
 * The code implements a "remote ls" service that takes directory paths and
 * returns info about files in the directories.  For ease of reference, this
 * file contains the code for both the client and server programs.  Compile
 * with -DCLIENT to produce the client object and -DSERVER for the server.
 */


#include <stddef.h>     /* offsetof */
#define ASFMT_SHORT_NAMES
#include "formatseed.h" /* DataDescriptor */
#define ASENV_SHORT_NAMES
#include "envseed.h"    /* ParseArgv */
#include "execseed.h"   /* ThreadStart */
#define ASFILE_SHORT_NAMES
#include "fileseed.h"   /* FileFacts */


#define NO_SUCH_PATH (-1)


/* Information about a particular file. */
typedef struct {
  char name[256 + 1];
  FileFacts facts;
} FileInfo;


/*
 * Data descriptor for ASENV_FileFacts.  Since the struct contains no nested
 * structures, the SIMPLE_MEMBER macro can be used for each member.  This macro
 * takes the member base type, the number of repetitions (for arrays), and the
 * beginning offset of the member in the structure.  The latter deals with
 * internal padding added by the compiler between structure members.
 */
static const DataDescriptor fileFactsDescriptor[] = {
  SIMPLE_MEMBER(CHAR_TYPE,          3, offsetof(FileFacts, readPermission)),
  SIMPLE_MEMBER(CHAR_TYPE,          3, offsetof(FileFacts, writePermission)),
  SIMPLE_MEMBER(CHAR_TYPE,          3, offsetof(FileFacts, execPermission)),
  SIMPLE_MEMBER(CHAR_TYPE,          1, offsetof(FileFacts, isADirectory)),
  SIMPLE_MEMBER(CHAR_TYPE,          1, offsetof(FileFacts, isALink)),
  SIMPLE_MEMBER(CHAR_TYPE,          1, offsetof(FileFacts, isHidden)),
  SIMPLE_MEMBER(CHAR_TYPE,         65, offsetof(FileFacts, owner)),
  SIMPLE_MEMBER(CHAR_TYPE,         65, offsetof(FileFacts, group)),
  SIMPLE_MEMBER(UNSIGNED_LONG_TYPE, 1, offsetof(FileFacts, size)),
  SIMPLE_MEMBER(UNSIGNED_LONG_TYPE, 1, offsetof(FileFacts, lastAccess)),
  SIMPLE_MEMBER(UNSIGNED_LONG_TYPE, 1, offsetof(FileFacts, lastWrite))
};
#define FILE_FACTS_MEMBER_COUNT \
  (sizeof(fileFactsDescriptor) / sizeof(DataDescriptor))
/* Data descriptor for FileInfo, with a nested struct description. */
static const DataDescriptor fileInfoDescriptor[] = {
  SIMPLE_MEMBER(CHAR_TYPE, 257,  offsetof(FileInfo, name)),
  {STRUCT_TYPE, 1, offsetof(FileInfo, facts),
   (DataDescriptor *)fileFactsDescriptor, FILE_FACTS_MEMBER_COUNT,
   PAD_BYTES(FileFacts, lastWrite, unsigned long, 1)}
};
#define FILE_INFO_MEMBER_COUNT \
  (sizeof(fileInfoDescriptor) / sizeof(DataDescriptor))


#ifdef SERVER


/*
 * This program implements a remote ls server.  It takes newline-terminated
 * directory paths from its clients and returns a set of FileInfo structures,
 * preceded by an integer indicating the file count.  If given a non-existent
 * directory path, the server returns a count value of NO_SUCH_PATH and no
 * structures.  Usage:
 *   rlsserver <port>
 */


#include "oshseed.h"
#include <stdio.h>   /* fprintf sprintf */
#include <stdlib.h>  /* atoi free malloc */
#include <string.h>  /* strchr strncpy */
#define ASIP_SHORT_NAMES
#include "ipseed.h"
#define ASV_SHORT_NAMES
#include "vectorseed.h"


/* Returns a vector of info for files accessed by #path#, or NULL on error. */
static FileInfo *
GetFiles(const char *path) {

  char *dir;
  FileInfo info;
  char **fileNames;
  char *filePath;
  unsigned i;
  char *pattern;
  FileInfo *returnValue;

  dir = strdup(path);
  if((pattern = strrchr(dir, ASOSH_FILE_PATH_SEPARATOR[0])) == NULL)
    pattern = dir;
  else
    pattern++;
  if(strchr(pattern, '*') == NULL && strchr(pattern, '?') == NULL &&
     strchr(pattern, '[') == NULL)
    pattern = NULL;
  else if(pattern == dir)
    dir = strdup(".");
  else
    *(pattern - 1) = '\0';
  if((fileNames = DirectoryContents(dir, pattern)) == NULL) {
    free(dir);
    return NULL;
  }

  returnValue = VectorNew(FileInfo);

  for(i = 0; fileNames[i] != NULL; i++) {
    memset(&info, 0, sizeof(info));
    strncpy(info.name, fileNames[i], sizeof(info.name));
    filePath = (char *)malloc
      (strlen(dir)+strlen(ASOSH_FILE_PATH_SEPARATOR)+strlen(fileNames[i])+1);
    sprintf(filePath, "%s" ASOSH_FILE_PATH_SEPARATOR "%s", dir, fileNames[i]);
    if(!GetFileFacts(filePath, &info.facts))
      fprintf(stderr, "Unable to get info for %s\n", filePath);
    free(filePath);
    Append(returnValue, info); 
    free(fileNames[i]);
  }

  free(fileNames);
  free(dir);
  return returnValue;

}


/* Converts and transmits the vector #files# on #sock# */
static void
SendFiles(Socket sock,
          const FileInfo *files) {

  int count;
  /* A DataDescriptor for the contents of #files#. */
  static DataDescriptor filesDescriptor =
    {STRUCT_TYPE, 0, 0, (DataDescriptor *)fileInfoDescriptor,
     FILE_INFO_MEMBER_COUNT, PAD_BYTES(FileInfo, facts, FileFacts, 1)};
  void *toSend;
  unsigned toSendSize;

  count = (files == NULL) ? NO_SUCH_PATH : (int)Size(files);
  /*
   * Typical sender use of the format conversion routines.  Find out how much
   * space the converted data requires; allocate the space; convert the data;
   * send the data; free the space.  Since network data sizes are fixed, we
   * could determine the sizes statically, but calling DataSize is cleaner.
   */
  toSendSize = HomogenousNetworkDataSize(INT_TYPE, 1);
  toSend = malloc(toSendSize);
  HomogenousConvertHostToNetwork(toSend, &count, INT_TYPE, 1);
  Send(sock, toSend, toSendSize);
  free(toSend);

  if(count > 0) {
    /*
     * Transmitting structs is slightly more complicated; we need a STRUCT_TYPE
     * data descriptor to specify the member fields.  Since we're sending an
     * array of structs, we set the repetitions field to its length.
     */
    filesDescriptor.repetitions = count;
    toSendSize = NetworkDataSize(&filesDescriptor, 1);
    toSend = malloc(toSendSize);
    ConvertHostToNetwork(toSend, files, &filesDescriptor, 1);
    Send(sock, toSend, toSendSize);
    free(toSend);
  }

}


/* Interacts with the client connected to #client# to provide remote ls info. */
static void *
ServiceClient(void *param) {
  Socket client = (Socket)param;
  FileInfo *files;
  char *machine = AddressMachine(PeerAddress(client));
  char path[1024 + 1];
  fprintf(stdout, "Servicing requests from client %s:%d\n",
          machine, PeerPort(client));
  free(machine);
  while(ReceiveTerminated(client, path, sizeof(path), "\n") > 0) {
    *strchr(path, '\n') = '\0';
    files = GetFiles(path);
    SendFiles(client, files);
    if(files == NULL)
      fprintf(stdout, "Unable to open path %s\n", path);
    else
      VectorFree(files);
  }
  return NULL;
}


int
main(int argc,
     const char *const *argv) {

  Socket newClient;
  Socket portSocket;

  if(argc != 2) {
    fprintf(stderr, "usage: rlsserver <port>\n");
    return 1;
  }
  else if((portSocket = OpenTcpPort(ANY_ADDRESS, (Port)atoi(argv[1]))) ==
          NO_SOCKET) {
    fprintf(stderr, "unable to open port %s\n", argv[1]);
    return 1;
  }

  /*
   * Boilerplate server code.  Iteratively wait for a client to connect, then
   * spawn a new thread to service it.
   */
  while(CheckIfReadable(portSocket, -1)) {
    if((newClient = Accept(portSocket)) == NO_SOCKET)
      continue;
    if(!ASEXEC_ThreadStart(&ServiceClient, (void *)newClient, NULL))
      Disconnect(&newClient);
  }

  return 0;

}


#else /* CLIENT */


/*
 * This program implements a remote ls client.  Usage:
 *   rlsclient [-SXalrt1] host:port [path ...]
 */


#include "oshseed.h"
#include <stdio.h>      /* fprintf sprintf */
#include <stdlib.h>     /* atoi */
#include <string.h>     /* strchr strlen strncpy strrchr */
#include <time.h>       /* ctime */
#include "appleseeds.h" /* AS_Entities */
#define ASIP_SHORT_NAMES
#include "ipseed.h"
#define ASV_SHORT_NAMES
#include "vectorseed.h"


/* Ways of sorting a list of files. */
typedef enum {
  BY_EXTENSION, BY_NAME, BY_SIZE, BY_TIME
} SortCriteria;


/* Returns the text after the last "." in #fileName#, or "" if there is none. */
static const char *
Extension(const char *fileName) {
  const char *dot = strrchr(fileName, '.');
  return (dot == NULL) ? "" : (dot + 1);
}


/*
 * Looks at the member #offset# bytes into each element of the vector #files#
 * and returns the print length of the longest value.  #integer# indicates
 * whether or not the member is an integer, instead of a char array.
 */
static unsigned
Longest(FileInfo *files,
        unsigned offset,
        int integer) {

  FileInfo *file;
  unsigned i;
  char image[63 + 1];
  unsigned returnValue = 0;

  for(i = 0, file = files; i < Size(files); i++, file++) {
    if(integer)
      sprintf(image, "%d", *(unsigned int *)((char *)file + offset));
    else
      sprintf(image, "%s", (char *)file + offset);
    if(strlen(image) > returnValue)
      returnValue = strlen(image);
  }

  return returnValue;

}


/*
 * Displays each file in the vector #files# to the user.  The other parameters
 * indicate: whether hidden files should be included in the display; whether
 * details should be included; the sorting criteria; whether the sort should be
 * in reverse order, whether only one file should be listed per line (as
 * opposed to as many as will fit).
 */
static void
DisplayFiles(const FileInfo *files,
             int displayHidden,
             int longDisplay,
             SortCriteria sort,
             int reverseSort,
             int onePerLine) {

  FileInfo *copy;
  unsigned i;
  unsigned j;
  FileInfo info;
  unsigned longestGroup, longestName, longestOwner, longestSize;
  int swap;
  char timeImage[31 + 1];
  time_t timeWritten;
  unsigned widthLeft;

  copy = VectorNew(FileInfo);
  for(i = 0; i < Size(files); i++) {
    if(displayHidden || !files[i].facts.isHidden)
      Append(copy, files[i]);
  }

  /* Sort the files using a really inefficient algorithm. */
  for(i = 0; i < Size(copy); i++) {
    for(j = i + 1; j < Size(copy); j++) {
      swap = (sort == BY_EXTENSION) ?
               (strcmp(Extension(copy[j].name), Extension(copy[i].name)) < 0) :
             (sort == BY_SIZE) ? (copy[j].facts.size < copy[i].facts.size) :
             (sort == BY_TIME) ?
                (copy[j].facts.lastWrite < copy[i].facts.lastWrite) :
             /* BY_NAME */ (strcmp(copy[j].name, copy[i].name) < 0);
      if(reverseSort)
        swap = !swap;
      if(swap) {
        info = copy[i];
        copy[i] = copy[j];
        copy[j] = info;
      }
    }
  }

  if(Size(copy) > 0) {
    if(longDisplay) {
      longestGroup =
        Longest(copy, offsetof(FileInfo,facts) + offsetof(FileFacts,group), 0);
      longestOwner =
        Longest(copy, offsetof(FileInfo,facts) + offsetof(FileFacts,owner), 0);
      longestSize =
        Longest(copy, offsetof(FileInfo,facts) + offsetof(FileFacts,size), 1);
      /* Add spacing if we have group and owner information. */
      if(longestGroup > 0)
        longestGroup += 2;
      if(longestOwner > 0)
        longestOwner += 2;
      for(i = 0; i < Size(copy); i++) {
        /* Dump day of week and trailing \n from image of time modified. */
        timeWritten = copy[i].facts.lastWrite;
        strncpy(timeImage, ctime(&timeWritten) + 4, sizeof(timeImage));
        timeImage[strlen(timeImage) - 1] = '\0';
        fprintf(stdout, "%c%c%c%c%c%c%c%c%c%c",
                copy[i].facts.isADirectory ? 'd' : ' ',
                copy[i].facts.readPermission[AS_OWNER] ? 'r' : '-',
                copy[i].facts.writePermission[AS_OWNER] ? 'w' : '-',
                copy[i].facts.execPermission[AS_OWNER] ? 'x' : '-',
                copy[i].facts.readPermission[AS_GROUP] ? 'r' : '-',
                copy[i].facts.writePermission[AS_GROUP] ? 'w' : '-',
                copy[i].facts.execPermission[AS_GROUP] ? 'x' : '-',
                copy[i].facts.readPermission[AS_OTHERS] ? 'r' : '-',
                copy[i].facts.writePermission[AS_OTHERS] ? 'w' : '-',
                copy[i].facts.execPermission[AS_OTHERS] ? 'x' : '-');
        fprintf(stdout, "  %-*s%-*s%-*ld  %s  ",
                longestOwner, copy[i].facts.owner,
                longestGroup, copy[i].facts.group,
                longestSize, copy[i].facts.size,
                timeImage);
        fprintf(stdout, "%s\n", copy[i].name);
      }
    }
    else if(onePerLine) {
      for(i = 0; i < Size(copy); i++)
        fprintf(stdout, "%s\n", copy[i].name);
    }
    else {
      longestName = Longest(copy, offsetof(FileInfo, name), 0);
      widthLeft = 80;
      for(i = 0; i < Size(copy); i++) {
        fprintf(stdout, "%-*s", longestName, copy[i].name);
        if((widthLeft -= longestName + 1) < longestName) {
          fprintf(stdout, "\n");
          widthLeft = 80;
        }
        else
          fprintf(stdout, " ");
      }
      if(widthLeft != 80)
        fprintf(stdout, "\n");
    }
  }

  VectorFree(copy);

}


/* Receives a FileInfo vector on #sock#. Returns the vector; NULL on error. */
static FileInfo *
RecvFiles(Socket sock) {

  int count;
  static DataDescriptor filesDescriptor =
    {STRUCT_TYPE, 0, 0, (DataDescriptor *)fileInfoDescriptor,
     FILE_INFO_MEMBER_COUNT, PAD_BYTES(FileInfo, facts, FileFacts, 1)};
  FileInfo *returnValue;
  void *toRecv;
  unsigned toRecvSize;

  /*
   * Typical receiver use of the format conversion routines.  Find out how much
   * space space the converted data requires; allocate the space; receive the
   * data; convert the data; free the space.
   */
  toRecvSize = HomogenousNetworkDataSize(INT_TYPE, 1);
  toRecv = malloc(toRecvSize);
  if(!Receive(sock, toRecv, toRecvSize))
    return NULL;
  HomogenousConvertNetworkToHost(&count, toRecv, INT_TYPE, 1);
  free(toRecv);

  if(count == NO_SUCH_PATH)
    return NULL;

  if(count == 0)
    returnValue = VectorNew(FileInfo);
  else {
    filesDescriptor.repetitions = count;
    toRecvSize = NetworkDataSize(&filesDescriptor, 1);
    toRecv = malloc(toRecvSize);
    if(!Receive(sock, toRecv, toRecvSize)) {
      free(toRecv);
      return NULL;
    }
    returnValue = VectorNew(FileInfo);
    GrowCapacity(returnValue, (unsigned)count);
    ConvertNetworkToHost(returnValue, toRecv, &filesDescriptor, 1);
    free(toRecv);
    Size(returnValue) = count;
  }

  return returnValue;

}


int
main(int argc,
     const char *const *argv) {

  char *colonPlace;
  FileInfo *files;
  unsigned i;
  ParsedArgv pa;
  char path[1024 + 1];
  Address serverAddress;
  char serverName[255 + 1] = "";
  Port serverPort;
  Socket serverSock;
  SortCriteria sort;
  const char *validSwitches =
    "-S void   sort by file size\n"
    "-X void   sort by file extension\n"
    "-a void   include all files in display\n"
    "-l void   long display\n"
    "-r void   reverse sort\n"
    "-t void   sort by modification time\n"
    "-1 void   list 1 file per line\n"
    "   machine:port [path ...] server to contact and path(s) to display";

  if((pa = ParseArgv(argv, validSwitches, NULL)) == NULL) {
    fprintf(stderr, "%s\n", validSwitches);
    return 1;
  }
  else if(SwitchValueN(pa, "", 1, NULL) == NULL) {
    fprintf(stderr, "%s\n", validSwitches);
    ParsedArgvFree(pa);
    return 1;
  }

  strncpy(serverName, SwitchValueN(pa, "", 1, ""), sizeof(serverName));
  if((colonPlace = strchr(serverName, ':')) == NULL) {
    fprintf(stderr, "%s is missing a port\n", serverName);
    ParsedArgvFree(pa);
    return 1;
  }

  *colonPlace = '\0';
  serverPort = (Port)atoi(colonPlace + 1);

  if(!AddressValue(serverName, &serverAddress)) {
    fprintf(stderr, "unable to convert %s to an address\n", serverName);
    ParsedArgvFree(pa);
    return 1;
  }
  else if((serverSock = ConnectToTcpPort(serverAddress, serverPort)) ==
          NO_SOCKET) {
    fprintf(stderr, "unable to connect to %s\n", SwitchValueN(pa, "", 1, ""));
    ParsedArgvFree(pa);
    return 1;
  }

  sort = SwitchPresent(pa, "-S") ? BY_SIZE :
         SwitchPresent(pa, "-X") ? BY_EXTENSION :
         SwitchPresent(pa, "-t") ? BY_TIME : BY_NAME;
  for(i = 2; i < 3 || SwitchValueN(pa, "", i, NULL) != NULL; i++) {
    sprintf(path, "%s\n", SwitchValueN(pa, "", i, "."));
    if(!Send(serverSock, path, strlen(path)))
      fprintf(stderr, "send failed\n");
    else if((files = RecvFiles(serverSock)) == NULL)
      fprintf(stderr, "No such path %s\n", path);
    else {
      DisplayFiles
        (files, SwitchPresent(pa, "-a"), SwitchPresent(pa, "-l"), sort,
         SwitchPresent(pa, "-r"), SwitchPresent(pa, "-1"));
      VectorFree(files);
      printf("\n");
    }
  }

  Disconnect(&serverSock);
  ParsedArgvFree(pa);
  return 0;

}

#endif
