/* $Id: getprop.c,v 1.9 2003/09/23 15:46:05 jhayes Exp $ */
/*
 * Copyright � 2002 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


/*
 * This is a simple test program for the property list functions in the
 * appleseed library.  It prints the values associated with a list of property
 * names, either from a property list file or the user's environment.  Usage:
 *   getprop [-f <file>] [name ...]
 */


#include <stdio.h>  /* fclose fopen fprintf */
#include <string.h> /* strcmp */
#define ASPROP_SHORT_NAMES
#include "propertyseed.h"


int
main(int argc,
     const char **argv) {

  const char **firstName;
  PropertyList properties;
  Property property;
  FILE *propertyFile;
  Property *propertyPtr;

  if(argc < 2 || strcmp(argv[1], "-f") != 0) {
    firstName = &argv[1];
    properties = EnvironToPropertyList(NULL);
  }
  else if((propertyFile = fopen(argv[2], "r")) == NULL) {
    fprintf(stderr, "Unable to open '%s'\n", argv[2]);
    return 1;
  }
  else if((properties = ReadPropertyList(propertyFile)) == NO_PROPERTY_LIST) {
    fclose(propertyFile);
    fprintf(stderr, "Error in reading from '%s'\n", argv[2]);
    return 1;
  }
  else {
    fclose(propertyFile);
    firstName = &argv[3];
  }

  ResolveReferencesInList(&properties, NULL);

  if(*firstName == NULL) {
    ForEachProperty(properties, propertyPtr)
      fprintf(stdout, "%s = %s\n",
              PropertyName(*propertyPtr), PropertyValue(*propertyPtr));
  }
  else {
    for( ; *firstName != NULL; firstName++) {
      property = FindPropertyByName(properties, *firstName);
      fprintf(stdout, "%s = %s\n",
             *firstName, (property == NO_PROPERTY) ?
                         "(undefined)" : PropertyValue(property));
    }
  }

  PropertyListFree(&properties);
  return 0;

}
