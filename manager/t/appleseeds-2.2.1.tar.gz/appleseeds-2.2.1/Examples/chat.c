/* $Id: chat.c,v 1.18 2004/04/22 17:35:36 jhayes Exp $ */
/*
 * Copyright � 2002 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


/*
 * This is a simple test program for the semaphore and shared memory functions
 * in the appleseed library.  It emulates a chat room, allowing multiple users
 * on the same machine to share typed messages -- somewhat like the standard
 * Unix write utility with broadcast abilities.  Usage:
 *   chat [-c] <room name> <your name>
 */


#include "oshseed.h"
#include <stdio.h>       /* fgets fprintf sprintf */
#include <string.h>      /* strcmp strlen */
#include "execseed.h"
#define AS_SHORT_NAMES
#define ASSEM_SHORT_NAMES
#include "semseed.h"
#define ASSHM_SHORT_NAMES
#include "shmseed.h"


#define MEMORY_SIZE 10000
/*
 * Storing pointers in a shared memory won't work--if two processes map the
 * shared memory to different addresses, a valid pointer stored by one process
 * will be bogus in the other.  Instead, we store offsets into the memory, with
 * offset 0 defined to be NULL.
 */
typedef unsigned long SharedOffset;

/* A chat message: the sender's id, the text, a link to the next. */
typedef struct MessageStruct {
  SharedOffset /* char * */ sender;
  SharedOffset /* char * */ text;
  SharedOffset /* struct MessageStruct * */ next;
} Message;

/* A mailbox: the owner's id, a received message list, a link to the next. */
typedef struct MailBoxStruct {
  SharedOffset /* char * */ owner;
  SharedOffset /* Message */ messages;
  SharedOffset /* struct MailBoxStruct * */ next;
} MailBox;


static int exiting = 0;
static SharedHeap heap;
static MailBox *myBox;
static Semaphore myCounter;
static SharedOffset *postOffice;
static SharedMemory sm;
static void *smBase;


#define LockMailBox(box,how) LockMemory(sm, Off(box), how, 1)
#define LockPostOffice(how) LockMemory(sm, 0, how, 1)
#define UnlockMailBox(box) UnlockMemory(sm, Off(box))
#define UnlockPostOffice() UnlockMemory(sm, 0)


/* Converts the local address #ptr# into an offset into the shared memory. */
static SharedOffset
Off(void *ptr) {
  return ptr == NULL ? 0 : ((char *)ptr - (char *)smBase);
}


/* Converts the shared memory offset #off# into a local address. */
static void *
Ptr(SharedOffset off) {
  return off == 0 ? NULL : ((char *)smBase + off);
}


/* Frees #toFree# and all of its fields. */
static void
FreeMessage(Message *toFree) {
  FreeInHeap(heap, Ptr(toFree->sender));
  FreeInHeap(heap, Ptr(toFree->text));
  FreeInHeap(heap, toFree);
}


/* Removes #toFree# from the postOffice and frees it and all of its fields. */
static void
FreeMailBox(MailBox *toFree) {

  SharedOffset box = Off(toFree);
  Message *msg;
  Message *next;
  SharedOffset *off;

  LockPostOffice(READ_WRITE_LOCK);
  for(off = postOffice; *off != box; off = &(((MailBox *)Ptr(*off)))->next)
    ; /* empty */
  *off = toFree->next;
  UnlockPostOffice();
  for(msg = (Message *)Ptr(toFree->messages); msg != NULL; msg = next) {
    next = (Message *)Ptr(msg->next);
    FreeMessage(msg);
  }
  FreeInHeap(heap, toFree);

}


/* Handles the reading and display of messages sent to this process. */
static void *
PrintIncomingMessages(void *ignored) {
  Message *msg;
  while(1) {
    Down(myCounter);
    if(exiting)
      break;
    LockMailBox(myBox, READ_WRITE_LOCK);
    if((msg = (Message *)Ptr(myBox->messages)) == NULL)
      break; /* Fatal error: myCounter > 0 but no message there. */
    fprintf(stdout, "%s: %s", (char *)Ptr(msg->sender), (char *)Ptr(msg->text));
    myBox->messages = msg->next;
    FreeMessage(msg);
    UnlockMailBox(myBox);
  }
  return NULL;
}


/* Handles the writing of messages sent from this process. */
static void
SendOutgoingMessages(void) {

  MailBox *box;
  Message *msg;
  char *myId = (char *)Ptr(myBox->owner);
  SharedOffset *off;
  Semaphore receiverCounter;
  char userInput[255 + 1];

  while(fgets(userInput, sizeof(userInput), stdin) != NULL) {
    LockPostOffice(READ_LOCK);
    for(box = (MailBox *)Ptr(*postOffice);
        box != NULL;
        box = (MailBox *)Ptr(box->next)) {
      if(box == myBox ||
         (receiverCounter = OpenSemaphore((char *)Ptr(box->owner), 0)) ==
         NO_SEMAPHORE)
        continue;
      msg = (Message *)AllocateInHeap(heap, sizeof(Message));
      msg->sender = Off(CopyIntoHeap(heap, myId, strlen(myId) + 1));
      msg->text = Off(CopyIntoHeap(heap, userInput, strlen(userInput) + 1));
      msg->next = Off(NULL);
      LockMailBox(box, READ_WRITE_LOCK);
      for(off = &box->messages;
          *off != Off(NULL);
          off = &(((Message *)Ptr(*off))->next))
        ; /* empty */
      *off = Off(msg);
      Up(receiverCounter);
      CloseSemaphore(receiverCounter);
      UnlockMailBox(box);
    }
    UnlockPostOffice();
  }

}


int
main(int argc,
     char **argv) {

  int create;
  const char *myName;
  void *reader;
  const char *roomName;
  char resourceName[255 + 1];

  create = argc > 2 && strcmp(argv[1], "-c") == 0;
  roomName = argv[create ? 2 : 1];
  myName = argv[create ? 3 : 2];

  if(roomName == NULL || myName == NULL) {
    fprintf(stderr, "usage: chat [-c] <room name> <your name>\n");
    return 1;
  }

  /* Attach or create the message sm and create a message counter. */
  sprintf(resourceName, "%sMemory", roomName);
  if((sm = OpenMemory(resourceName, create ? MEMORY_SIZE : 0)) == NULL) {
    fprintf(stderr, create ? "A room named '%s' already exists; try another\n" :
                             "No room named '%s' exists; try -c\n", roomName);
    return 1;
  }
  if(create) {
    SetMemoryPermission(sm, GROUP, 1, 1);
    SetMemoryPermission(sm, OTHERS, 1, 1);
  }
  sprintf(resourceName, "%s.%s", roomName, myName);
  if((myCounter = OpenSemaphore(resourceName, 1)) == NO_SEMAPHORE) {
    fprintf(stderr, "Unable to allocate a message counter\n");
    CloseMemory(sm);
    return 1;
  }
  SetSemaphorePermission(myCounter, GROUP, 1);
  SetSemaphorePermission(myCounter, OTHERS, 1);

  /* The postoffice is at the beginning of sm; the rest is heap. */
  smBase = GetBase(sm);
  postOffice = (SharedOffset *)smBase;
  heap = OpenHeap
    (sm, sizeof(SharedOffset), create?MEMORY_SIZE-sizeof(SharedOffset):0);

  /* Stick a new mailbox for this process at the head of the postoffice list. */
  myBox = (MailBox *)AllocateInHeap(heap, sizeof(struct MailBoxStruct));
  myBox->owner = Off(CopyIntoHeap(heap, resourceName, strlen(resourceName)+1));
  myBox->messages = Off(NULL);
  LockPostOffice(READ_WRITE_LOCK);
  myBox->next = create ? Off(NULL) : *postOffice;
  *postOffice = Off(myBox);
  UnlockPostOffice();

  if(!ASEXEC_ThreadStart(&PrintIncomingMessages, NULL, &reader)) {
    fprintf(stderr, "Thread create failed\n");
    FreeMailBox(myBox);
    CloseSemaphore(myCounter);
    CloseMemory(sm);
    return 1;
  }

  SendOutgoingMessages();
  exiting = 1;
  Up(myCounter);
  ASEXEC_ThreadStopped(reader, 1, NULL);
  FreeMailBox(myBox);
  CloseSemaphore(myCounter);
  CloseMemory(sm);
  return 0;

}
