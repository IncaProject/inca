/* $Id: parseargs.c,v 1.11 2003/09/30 20:42:31 jhayes Exp $ */
/*
 * Copyright � 2002 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


/*
 * This is a simple test program for command line parsing functions in the
 * appleseed library.  It prints out the values of its command line arguments.
 *
 * Usage:
 *   parseargs
 *     [-c <char>] [-d <double>] [-i <int>] [-s <text>] [-v]
 *     [-char <char>] [-double <double>] [-int <int>] [-string <text>] [-void]
 *     [--char <char>] [--double <double>] [--int <int>] [--string <text>] [--void]
 */


#include <stdio.h>  /* fprintf */
#include <string.h> /* strchr strncpy */
#include "oshseed.h"
#define ASENV_SHORT_NAMES
#include "envseed.h"


#define SC ASOSH_SWITCH_CHARACTER
static int badSwitchSeen = 0;


/*
 * A switch error handler.  Passed the error, the element of argv that contains
 * the bad switch, the offset into that element of the switch name, the length
 * of the switch name, and the bad value, if appropriate.
 */
static int
BadSwitchHandler(ParseErrors error,
                 const char *badWord,
                 unsigned badSwitchOffset,
                 unsigned badSwitchLen,
                 const char *badValue) {

  int intLen = (int)badSwitchLen;

  if(error == ARGUMENTS_NOT_ALLOWED)
    fprintf(stderr, "This program takes no program arguments\n");
  else if(error == INVALID_VALUE)
    fprintf(stderr, "The value '%s' is invalid for switch '%*.*s'\n",
            badValue, intLen, intLen, badWord + badSwitchOffset);
  else if(error == MISSING_VALUE)
    fprintf(stderr, "The switch '%*.*s' requires a value\n",
            intLen, intLen, badWord + badSwitchOffset);
  else if(error == UNKNOWN_SWITCH)
    fprintf(stderr, "'%*.*s' is not a known switch\n",
            intLen, intLen, badWord + badSwitchOffset);

  badSwitchSeen = 1;
  return 1; /* Allow argv parsing to continue. */

}


int
main(int argc,
     const char *const *argv) {

  /*
   * A typical valid switch specification.  Each of the newline-separated
   * elements specifies the switch name and the type of parameter it takes.
   * Any text after the type is ignored, making it easy to reuse the spec to
   * print switch help.  Note that "string" is not a recognized type, but
   * ParseArgv matches any unrecognized type to any text value.
   */
  const char *validSwitches =
    SC    "c       char   short char-valued switch\n"
    SC    "d       double short double-valued switch\n"
    SC    "i       int    short int-valued switch\n"
    SC    "s       string short string-valued switch\n"
    SC    "v       void   short void-valued switch\n"
    SC    "char    char   long char-valued switch\n"
    SC    "double  double long double-valued switch\n"
    SC    "int     int    long int-valued switch\n"
    SC    "string  string long string-valued switch\n"
    SC    "void    void   long void-valued switch\n"
    SC SC "char   char   two-dash char-valued switch\n"
    SC SC "double double two-dash double-valued switch\n"
    SC SC "int    int    two-dash int-valued switch\n"
    SC SC "string string two-dash string-valued switch\n"
    SC SC "void   void   two-dash void-valued switch\n"
          "         string program argument";
  const char *c;
  int i;
  const char *next;
  ParsedArgv pa;
  char switchName[20];
  const char *value;

  if((pa = ParseArgv(argv, validSwitches, &BadSwitchHandler)) == NULL ||
     badSwitchSeen) {
    fprintf(stderr, "\n%s\n", validSwitches);
    return 1;
  }

  for(c = validSwitches, next = c; next != NULL; c = next + 1) {
    next = strchr(c, '\n');
    if(*c == '\n' || *c == '\0')
      continue; /* Ignore any empty lines or trailing newlines. */
    strncpy(switchName, c, sizeof(switchName));
    *strchr(switchName, ' ') = '\0';
    if(*switchName == '\0')
      fprintf(stdout, "Value(s) of program arguments:");
    else
      fprintf(stdout, "Value(s) of switch '%s':", switchName);
    if(SwitchPresent(pa, switchName)) {
      for(i = 1; (value = SwitchValueN(pa, switchName, i, NULL)) != NULL; i++)
        fprintf(stdout, " '%s'", value);
    }
    else {
      fprintf(stdout, " <none>");
    }
    fprintf(stdout, "\n");
  }

  ParsedArgvFree(pa);
  return 0;

}
