/* $Id: sort.c,v 1.13 2003/09/27 13:37:29 jhayes Exp $ */
/*
 * Copyright � 2002 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


/*
 * This is a simple test program for the vector functions in the appleseed
 * library.  It sorts its input lexically and prints the result.  The algorithm
 * used is intended to be illustrative rather than efficient.
 */


#include <stdio.h>  /* fgets fprintf */
#include <string.h> /* strdup */
#define ASV_SHORT_NAMES
#include "vectorseed.h"


typedef char **StringVector;


int
main(int argc,
     char **argv) {

  StringVector bucket;
  StringVector *buckets = VectorNew(StringVector);
  unsigned i;
  unsigned j;
  unsigned least;
  char line[1023 + 1];
  char *toBeat;
  char *toTest;

  /*
   * Drop each line of input into a bucket based on the first character.  The
   * bucket list itself is sorted via insertion sort.
   */
  while(fgets(line, sizeof(line), stdin) != NULL) {
    for(i = 0;
        i < Size(buckets) && *buckets[i][0] < line[0];
        i++)
      ; /* empty */
    if(i == Size(buckets) || *buckets[i][0] != line[0]) {
      StringVector newVector = VectorNew(char *);
      Insert(buckets, newVector, i);
    }
    Append(buckets[i], strdup(line));
  }

  /* Use selection sort to print the contents of the individual buckets. */
  for(i = 0; i < Size(buckets); i++) {

    bucket = buckets[i];

    while(Size(bucket) > 0) {
      least = 0;
      toBeat = bucket[0];
      for(j = 1; j < Size(bucket); j++) {
        toTest = bucket[j];
        if(strcmp(toTest, toBeat) < 0) {
          toBeat = toTest;
          least = j;
        }
      }
      fprintf(stdout, "%s", toBeat);
      free(toBeat);
      Remove(bucket, least);
    }

    VectorFree(bucket);

  }

  VectorFree(buckets);
  return 0;

}
