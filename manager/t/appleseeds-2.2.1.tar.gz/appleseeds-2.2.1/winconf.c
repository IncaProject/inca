/* $Id: winconf.c,v 1.34 2004/12/06 20:30:45 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


/*
 * This file performs Windows-specific configuration for this directory and the
 * Examples and Tests subdirectories.  usage:
 *   winconf.exe [--prefix=<path>]
 */


#include "oshseed.h"
#include <stdio.h>  /* file functions */
#include <stdlib.h> /* getenv */
#include <string.h> /* string functions */


/* config.h.in and Makefile.in substitution values. */
static const char *hSubstitutions[] = {
  "#undef ASFMT_HOST_USES_IEEE754_FP", "#define ASFMT_HOST_USES_IEEE754_FP 1",
  "#undef ASIP_NO_WILD_ADDRESSES",     "#define ASIP_NO_WILD_ADDRESSES 1",
  "#undef ASIP_SOCKLEN_T",             "#define ASIP_SOCKLEN_T int",
  NULL, NULL, /* Leave room for ASFILE_HAVE_WIN32_SECURITY */
  NULL, NULL
};
static const char *makeSubstitutions[] = {
  " ; ",                     "\n\t",
  " && ",                    "\n\t",
  "/",                       ASOSH_FILE_PATH_SEPARATOR,
  "= cp",                    "= copy",
  "$(CP) $(EXECS)",          "$(CP) *.exe",
  "= rm -fr",                "= del",
  "$(RM) $(EXECS)",          "$(RM) *.exe",
  "= tar cvf",               "= rem", /* N/A on Windows */
  "@APPLESEEDS_DIR@",        "",
  "@C_DEBUG@",               "/ZI",
  "@C_FLAGS@",               "/nologo /c /D WIN32 /GX /GZ /W3",
  "@C_INC@",                 "/I",
  "@C_OPT@",                 "/O2 /Ob2",
  "@C_PROFILE@",             "",
  "@CC@",                    "cl",
  "@DISTRIBUTION@",          "",
  "@EXE@",                   ".exe",
  "@LIBRARY@",               "appleseeds.lib",
  "@LINKER@",                "link /nologo",
  "@LINKER_LIBS@",           "advapi32.lib ws2_32.lib",
  "@LINKER_OUTPUT@",         "/out:",
  "$(LINKER_OUTPUT) ",       "$(LINKER_OUTPUT)",
  "@LINKER_PATH@",           "/libpath:",
  "@LINKER_PROFILE@",        "",
  "@LINKER_SHARED@",         "/dll /def:appleseeds.def advapi32.lib ws2_32.lib",
  "@LINKER_USE_APPLESEEDS@", "appleseeds.lib",
  "@MAKELIB@",               "lib",
  "@MAKELIB_OUTPUT@",        "/out:",
  "$(MAKELIB_OUTPUT) ",      "$(MAKELIB_OUTPUT)",
  "@OBJ@",                   ".obj",
  "@prefix@",                "",
  "@PROFILE@",               "",
  "@SHARED_LIBRARY@",        "appleseeds.dll",
  NULL, NULL
};


/*
 * Replaces #count# characters in the allocated string pointed to by #s#,
 * starting with the #offset#'th one, with the #len#-long string #rep#.
 * Returns the modified string for convenience.  If #count# is zero, #rep# is
 * inserted; if #len# is zero, #count# characters are deleted.  An #offset# or
 * #count# value that references a position past the end of the string is
 * taken to reference the end of the string.
 */
static char *
StrNReplace(char **s,
            unsigned long offset,
            unsigned long count,
            const char *rep,
            unsigned long len) {

  unsigned long sLen = strlen(*s);
  unsigned long newLen;

  /* Adjust offset and count values that refer past the end of the string. */
  if(offset > sLen)
    offset = sLen;
  if(offset + count > sLen)
    count = sLen - offset;

  newLen = sLen - count + len;
  if(newLen > sLen)
    *s = (char *)realloc(*s, newLen + 1); /* Expand string. */

  /* Shift any characters after the section to be replaced, then insert. */
  if(offset + count < sLen)
    memmove(*s + offset + len, *s + offset + count, sLen - offset - count);
  if(len > 0)
    memcpy(*s + offset, rep, len);

  if(count > len)
    *s = (char *)realloc(*s, newLen + 1); /* Shrink string. */
  (*s)[newLen] = '\0';
  return *s;

}


/*
 * Replaces all occurrences in the allocated string pointed to by #s# of the
 * #beforeLen#-long string #before# with the #afterLen#-long string #after#.
 * Returns the modified string for convenience.
 */
static char *
StrNReplaceAll(char **s,
               const char *before,
               unsigned long beforeLen,
               const char *after,
               unsigned long afterLen) {
  char *c = *s;
  unsigned offset;
  for(c = strchr(*s, *before); c != NULL; c = strchr(c, *before)) {
    if(strncmp(c, before, beforeLen) != 0)
      c++;
    else {
      offset = c - *s;
      *s = StrNReplace(s, offset, beforeLen, after, afterLen);
      c = *s + offset + afterLen;
    }
  }
  return *s;
}


/*
 * Copies #inputFile# to #outputFile#, replacing every occurrence of each even-
 * indexed element of #substituions# by the following element.  Returns 1 if
 * successful, else 0.
 */
static int
ConfigureFile(const char *inputFile,
              const char *outputFile,
              const char *const *substitutions) {

  int i;
  char inLine[256 + 1];
  FILE *input;
  char *outLine;
  FILE *output;

  fprintf(stderr, "Configuring %s\n", outputFile);
  if((input = fopen(inputFile, "r")) == NULL ||
     (output = fopen(outputFile, "w")) == NULL) {
    fprintf(stderr, "Unable to open %s\n",
            input == NULL ? inputFile : outputFile);
    if(input != NULL)
      fclose(input);
    return 0;
  }
  while(fgets(inLine, sizeof(inLine), input) != NULL) {
    outLine = strdup(inLine);
    for(i = 0; substitutions[i] != NULL; i += 2)
      StrNReplaceAll(&outLine, substitutions[i], strlen(substitutions[i]),
                     substitutions[i + 1], strlen(substitutions[i + 1]));
    fprintf(output, "%s", outLine);
    free(outLine);
  }
  fclose(output);
  return 1;

}


int
main(int argc,
     const char **argv) {

  const char *argName;
  const char *argPrefix = NULL;
  const char **c;
  char defaultPrefix[1024 + 1] = "";
  char varName[32 + 1] = "";
  const char *varValue;
  const char *USAGE =
    "configure\n"
    "  --prefix dir installation directory";

  /* Parse arguments. */
  for(c = argv + 1; *c != NULL; c++) {
    if(strncmp(*c, "--", 2) == 0)
      argName = *c + 2;
#ifdef WIN32
    else if(**c == '/')
      argName = *c + 1;
#endif
    else {
      fprintf(stderr, "%s\n", USAGE);
      return 1;
    }
    if(strncmp(argName, "prefix", 6) == 0)
      argPrefix = argName[6] == '=' ? (argName + 7) : *(++c);
  }

  /* Plug environment variables into the substitution list. */
  for(c = makeSubstitutions; *c != NULL; c += 2) {
    if(**c != '@')
      continue;
    strncpy(varName, *c + 1, sizeof(varName) - 1);
    varName[strlen(varName) - 1] = '\0';
    if((strcmp(varName, "prefix") == 0 ||
        strcmp(varName, "APPLESEEDS_DIR") == 0) &&
       argPrefix != NULL)
      *(c + 1) = argPrefix;
    else if((varValue = getenv(varName)) != NULL)
      *(c + 1) = strdup(varValue);
    else if(strcmp(varName, "prefix") == 0 ||
            strcmp(varName, "APPLESEEDS_DIR") == 0) {
      getcwd(defaultPrefix, sizeof(defaultPrefix));
      strncat(defaultPrefix, ASOSH_FILE_PATH_SEPARATOR "appleseeds",
              sizeof(defaultPrefix) - strlen(defaultPrefix) - 1);
      *(c + 1) = defaultPrefix;
    }
  }

#ifdef WIN32
  {
    unsigned i;
    HINSTANCE lib = LoadLibrary("advapi32");
    FARPROC proc;
    if(lib != NULL) {
      if((proc = GetProcAddress(lib, "GetEffectiveRightsFromAclA")) != NULL) {
        for(i = 0; hSubstitutions[i] != NULL; i++)
          ; /* empty */
        hSubstitutions[i] = "#undef ASFILE_HAVE_WIN32_SECURITY";
        hSubstitutions[i + 1] = "#define ASFILE_HAVE_WIN32_SECURITY 1";
      }
      FreeLibrary(lib);
    }
  }
#endif

  return
    ConfigureFile("config.h.in", "config.h", hSubstitutions) &&
    ConfigureFile("Makefile.in", "Makefile", makeSubstitutions) &&
    ConfigureFile("appleseeds.make.in","appleseeds.make",makeSubstitutions) &&
    ConfigureFile
      ("Examples" ASOSH_FILE_PATH_SEPARATOR "Makefile.in",
       "Examples" ASOSH_FILE_PATH_SEPARATOR "Makefile", makeSubstitutions) &&
    ConfigureFile
      ("Tests" ASOSH_FILE_PATH_SEPARATOR "Makefile.in",
       "Tests" ASOSH_FILE_PATH_SEPARATOR "Makefile", makeSubstitutions) ?
    0 : 1;

}
