/* $Id: fileseed.c,v 1.17 2004/12/07 23:48:01 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#include "config.h"
#include "oshseed.h"
#include <sys/stat.h>   /* lstat stat */
#include <stdio.h>      /* file functions */
#include <stdlib.h>     /* free malloc */
#include <string.h>     /* string functions */
#ifdef WIN32
#  include <accctrl.h>
#  include <aclapi.h>
#else
#  include <dirent.h>   /* {close,open,read}dir */
#  include <grp.h>      /* getgrgid */
#  include <pwd.h>      /* getpwuid */
#endif
#include "strseed.h"
#define ASFILE_SHORT_NAMES
#include "fileseed.h"


#define LISTSEP ASOSH_PATH_LIST_SEPARATOR
#define PATHSEP ASOSH_FILE_PATH_SEPARATOR


#ifdef WIN32


/* Returns the seconds since 1/1/1970 represented by #f#. */
static unsigned long
WIN32_FiletimeToEpochSecs(FILETIME f) {
  static const __int64 EPOCH_ADJUSTMENT =
    ((280i64 * 365i64) + (89i64 * 366i64)) * 86400i64;
  __int64 veryLong = f.dwHighDateTime;
  veryLong <<= 32;
  veryLong |= f.dwLowDateTime;
  veryLong /= 10000000;
  veryLong -= EPOCH_ADJUSTMENT;
  return (unsigned long)veryLong;
}


/*
 * Copies the name associated with #sid# into the #nameSize#-long string
 * #name#.  Returns 1 if successful, else 0.
 */
static int
WIN32_GetAccountName(PSID sid,
                     char *name,
                     DWORD nameSize) {
#ifdef ASFILE_HAVE_WIN32_SECURITY
  char domain[256 + 1];
  DWORD domainSize = sizeof(domain);
  SID_NAME_USE sidUse;
  return LookupAccountSid
    (NULL, sid, name, &nameSize, domain, &domainSize, &sidUse);
#else
  return 0;
#endif
}


/*
 * Retrieves security info for the file (directory if #dir# is non-zero)
 * accessed by #path# and Fills in the Dacl, Group, and Owner fields of #desc#
 * appropriately.  Returns 1 if successful, else 0.
 */
static int
WIN32_GetFileSecurity(const char *path,
                      int dir,
                      SECURITY_DESCRIPTOR *desc) {

#ifdef ASFILE_HAVE_WIN32_SECURITY
  /*
   * This is excruciating.  We should use the relatively convenient
   * GetNamedSecurityInfo, but it's SSLLOOWW.  Instead, we have to use
   * GetKernelObjectSecurity, which returns its value in "self-relative" format
   * of unknown size (the fields are offsets, rather than pointers), then call
   * other functions to get the actual values.  Barf!
   */
  HANDLE fileHandle;
  BOOL ignored;
  SECURITY_INFORMATION infoIWant =
    DACL_SECURITY_INFORMATION |
    OWNER_SECURITY_INFORMATION | GROUP_SECURITY_INFORMATION;
  SECURITY_DESCRIPTOR *localDesc;
  DWORD sizeNeeded;

  if((fileHandle = CreateFile
      (path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
       FILE_ATTRIBUTE_NORMAL | (dir?FILE_FLAG_BACKUP_SEMANTICS:0), NULL)) ==
     INVALID_HANDLE_VALUE)
    return 0;
  GetKernelObjectSecurity(fileHandle, infoIWant, NULL, 0, &sizeNeeded);
  localDesc = (SECURITY_DESCRIPTOR *)malloc(sizeNeeded);
  if(!GetKernelObjectSecurity
        (fileHandle, infoIWant, localDesc, sizeNeeded, &sizeNeeded)) {
    free(localDesc);
    CloseHandle(fileHandle);
    return 0;
  }
  CloseHandle(fileHandle);
  GetSecurityDescriptorDacl(localDesc, &ignored, &desc->Dacl, &ignored);
  GetSecurityDescriptorGroup(localDesc, &desc->Group, &ignored);
  GetSecurityDescriptorOwner(localDesc, &desc->Owner, &ignored);
  free(localDesc);
  return 1;
#else
  return 0;
#endif

}


/* Sets #exec#, #read#, and #write# to the permissions for #who# in #acl#. */
static void
WIN32_GetPermissions(PACL acl,
                     PSID who,
                     unsigned char *exec,
                     unsigned char *read,
                     unsigned char *write) {
#ifdef ASFILE_HAVE_WIN32_SECURITY
  ACCESS_MASK rights;
  TRUSTEE trustee =
    {NULL,NO_MULTIPLE_TRUSTEE,TRUSTEE_IS_SID,TRUSTEE_IS_UNKNOWN,(LPTSTR)(who)};
  if(GetEffectiveRightsFromAcl(acl, &trustee, &rights) != ERROR_SUCCESS)
    return;
  *exec = (rights & FILE_EXECUTE)!= 0;
  *read = (rights & FILE_READ_DATA) != 0;
  *write = (rights & FILE_WRITE_DATA) != 0;
#endif
}

#else

/* Unix permission values for group, other, owner, read, write, execute. */
static const int PERMIT_VALUES[3][3] = {
  {S_IRGRP, S_IWGRP, S_IXGRP},
  {S_IROTH, S_IWOTH, S_IXOTH},
  {S_IRUSR, S_IWUSR, S_IXUSR}
};

#endif


char **
DirectoryContents(const char *path,
                  const char *pattern) {

#ifdef WIN32
  HANDLE handle;
  WIN32_FIND_DATA info;
  char *pathSlashStar;
#else
  DIR *dir;
  struct dirent *dirEntry;
#endif
  unsigned fileCount;
  char **returnValue = NULL;

  fileCount = 0;
#ifdef WIN32
  pathSlashStar = ASSTR_StrAppend(NULL, path, "\\*", NULL);
  handle = FindFirstFile(pathSlashStar, &info);
  free(pathSlashStar);
  if(handle == INVALID_HANDLE_VALUE)
    return NULL;
  do {
    if(pattern == NULL || ASSTR_StrFnMatch(info.cFileName, pattern)) {
      returnValue =
        (char **)ASSTR_Realloc(returnValue, (fileCount + 1) * sizeof(char *));
      returnValue[fileCount++] = strdup(info.cFileName);
    }
  } while(FindNextFile(handle, &info));
  FindClose(handle);
#else
  if((dir = opendir(path)) == NULL)
    return NULL;
  while((dirEntry = readdir(dir)) != NULL) {
    if(pattern == NULL || ASSTR_StrFnMatch(dirEntry->d_name, pattern)) {
      returnValue =
        (char **)ASSTR_Realloc(returnValue, (fileCount + 1) * sizeof(char *));
      returnValue[fileCount++] = strdup(dirEntry->d_name);
    }
  }
  closedir(dir);
#endif
  returnValue =
    (char **)ASSTR_Realloc(returnValue, (fileCount + 1) * sizeof(char *));
  returnValue[fileCount] = NULL;
  return returnValue;

}


char *
FileContents(const char *path) {
  char *contents;
  FILE *file;
  struct stat stats;
  if((file = fopen(path, "r")) == NULL)
    return NULL;
  fstat(fileno(file), &stats);
  contents = (char *)malloc(stats.st_size + 1);
  contents[fread(contents, sizeof(char), stats.st_size, file)] = '\0';
  fclose(file);
  return contents;
}


char *
FindFile(const char *dirs,
         const char *names) {

  char **dir;
  struct stat ignored;
  char **name;
  char *path;
  char **splitDirs = ASSTR_StrSplit(dirs, LISTSEP);
  char **splitNames = ASSTR_StrSplit(names, LISTSEP);

  for(dir = splitDirs; *dir != NULL; dir++) {
    for(name = splitNames; *name != NULL; name++) {
      path = ASSTR_StrAppend
        (NULL, *dir, strcmp(*dir + strlen(*dir) - strlen(PATHSEP),
                            PATHSEP) == 0 ? "" : PATHSEP, *name, NULL);
      if(stat(path, &ignored) == 0) {
        ASSTR_StrArrayFree(splitDirs);
        ASSTR_StrArrayFree(splitNames);
        return path;
      }
      free(path);
    }
  }
  ASSTR_StrArrayFree(splitDirs);
  ASSTR_StrArrayFree(splitNames);
  return NULL;

}


int
GetFileFacts(const char *path,
             FileFacts *facts) {

  AS_Entities entity;

#ifdef WIN32

  HANDLE findHandle;
  WIN32_FIND_DATA info;
  SECURITY_DESCRIPTOR security;

  if((findHandle = FindFirstFile(path, &info)) == INVALID_HANDLE_VALUE)
    return 0;
  FindClose(findHandle);
  memset(facts, 0, sizeof(FileFacts));
  facts->isADirectory = (info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
  facts->isALink =
    strlen(path) > 4 && strcmp(path + strlen(path) - 4, ".lnk") == 0;
  facts->isHidden = (info.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN) != 0;
  facts->size = info.nFileSizeLow;
  facts->lastAccess = WIN32_FiletimeToEpochSecs(info.ftLastAccessTime);
  facts->lastWrite = WIN32_FiletimeToEpochSecs(info.ftLastWriteTime);
  for(entity = AS_GROUP; entity <= AS_OWNER; entity++) {
    facts->readPermission[entity] = facts->execPermission[entity] = 1;
    facts->writePermission[entity] =
      (info.dwFileAttributes & FILE_ATTRIBUTE_READONLY) == 0;
  }

  if(WIN32_GetFileSecurity(path, facts->isADirectory, &security)) {
    SID_IDENTIFIER_AUTHORITY otherAuth = SECURITY_WORLD_SID_AUTHORITY;
    PSID sidOfOthers;
    WIN32_GetAccountName(security.Owner, facts->owner, sizeof(facts->owner));
    WIN32_GetAccountName(security.Group, facts->group, sizeof(facts->group));
    WIN32_GetPermissions
      (security.Dacl, security.Group, &facts->execPermission[AS_GROUP],
       &facts->readPermission[AS_GROUP], &facts->writePermission[AS_GROUP]);
    WIN32_GetPermissions
      (security.Dacl, security.Owner, &facts->execPermission[AS_OWNER],
       &facts->readPermission[AS_OWNER], &facts->writePermission[AS_OWNER]);
      AllocateAndInitializeSid(&otherAuth, 1, 0, 0,0,0,0,0,0,0, &sidOfOthers);
    WIN32_GetPermissions
      (security.Dacl, sidOfOthers, &facts->execPermission[AS_OTHERS],
       &facts->readPermission[AS_OTHERS], &facts->writePermission[AS_OTHERS]);
    /* TODO Close sidOfOthers? */
  }

#else

  const char *c;
  const struct group *group;
  const struct passwd *owner;
  struct stat status;

  if(lstat(path, &status) < 0)
    return 0;

  memset(facts, 0, sizeof(FileFacts));
  for(entity = AS_GROUP;
      entity <= AS_OWNER;
      entity = (AS_Entities)((int)entity + 1)) {
    facts->readPermission[entity] =
      (status.st_mode & PERMIT_VALUES[entity][0]) != 0;
    facts->writePermission[entity] =
      (status.st_mode & PERMIT_VALUES[entity][1]) != 0;
    facts->execPermission[entity] =
      (status.st_mode & PERMIT_VALUES[entity][2]) != 0;
  }
  facts->isADirectory = (status.st_mode & S_IFDIR) == S_IFDIR;
  facts->isALink = (status.st_mode & S_IFLNK) == S_IFLNK;
  facts->isHidden =
    (c = strrchr(path, '/')) == NULL ? (*path == '.') : (*(c + 1) == '.');
  if((owner = getpwuid(status.st_uid)) == NULL)
    sprintf(facts->owner, "%d", (int)status.st_uid);
  else
    strncpy(facts->owner, owner->pw_name, sizeof(facts->owner) - 1);
  if((group = getgrgid(status.st_gid)) == NULL)
    sprintf(facts->group, "%d", (int)status.st_gid);
  else
    strncpy(facts->group, group->gr_name, sizeof(facts->group) - 1);
  facts->size = status.st_size;
  facts->lastAccess = status.st_atime;
  facts->lastWrite = status.st_mtime;

#endif

  return 1;

}


char *
MinimizeFilePath(char *s) {

  char *c;
  char *parent;

  /* Remove duplicate path separators. */
  while((c = strstr(s, PATHSEP PATHSEP)) != NULL)
    memmove(c, c + 1, strlen(c + 1) + 1);
  /* Remove leading, embedded, and trailing current directory references. */
  while(strncmp(s, "." PATHSEP, 2) == 0)
    memmove(s, s + 2, strlen(s + 2) + 1);
  while((c = strstr(s, PATHSEP "." PATHSEP)) != NULL)
    memmove(c, c + 2, strlen(c + 2) + 1);
  c = s + strlen(s) - 2;
  if(c > s && strcmp(c, PATHSEP ".") == 0)
    *c = '\0';
  /* Remove embedded and trailing parent directory references. */
  while((c = strstr(s, PATHSEP ".." PATHSEP)) != NULL) {
    for(parent = c - 1; parent >= s && *parent != *PATHSEP; parent--)
      ; /* empty */
    memmove(parent + 1, c + 4, strlen(c + 4) + 1);
  }
  c = s + strlen(s) - 3;
  if(c > s && strcmp(c, PATHSEP "..") == 0) {
    for(parent = c - 1; parent >= s && *parent != '/'; parent--)
      ; /* empty */
    if(parent < s)
      strcpy(s, ".");
    else
      *(parent + 1) = '\0';
  }
  return s;

}


int
ASFILE_SetFilePermission(const char *path,
                         AS_Entities who,
                         int allowReading,
                         int allowWriting,
                         int allowExecing) {
#ifdef WIN32
  return 0; /* TODO */
#else
  struct stat status;
  if(lstat(path, &status) < 0)
    return 0;
  if(allowReading)
    status.st_mode |= PERMIT_VALUES[who][0];
  else
    status.st_mode &= ~PERMIT_VALUES[who][0];
  if(allowWriting)
    status.st_mode |= PERMIT_VALUES[who][1];
  else
    status.st_mode &= ~PERMIT_VALUES[who][1];
  if(allowExecing)
    status.st_mode |= PERMIT_VALUES[who][2];
  else
    status.st_mode &= ~PERMIT_VALUES[who][2];
  return chmod(path, status.st_mode) >= 0;
#endif
}


#ifdef WIN32
#  define DEFAULT_TEMP_PREFIX ".\\"
#else
#  include <sys/time.h>
#  define DEFAULT_TEMP_PREFIX "./"
#endif

char *
UniqueFilePath(const char *prefix) {
  /*
   * Generating a unique file name is harder than it sounds. We use the process
   * id to distinguish between processes, the time of day to distinguish 
   * between calls, and the result of malloc(3) (which, with any luck, is
   * thread-safe) to distinguish between threads that happen to call the
   * function simultaneously.
   */
  char image[128 + 1];
  void *p = malloc(1);
  unsigned long secs;
  unsigned long usecs;
#ifdef WIN32
  SYSTEMTIME now;
  GetSystemTime(&now);
  secs = (unsigned long)now.wSecond;
  usecs = (unsigned long)now.wMilliseconds * 1000;
#else
  struct timeval now;
  gettimeofday(&now, NULL);
  secs = (unsigned long)now.tv_sec;
  usecs = (unsigned long)now.tv_usec;
#endif
  sprintf(image, "%d%lx%lx%p", (int)getpid(), secs, usecs, p);
  free(p);
  return ASSTR_StrAppend
    (NULL, prefix == NULL ? DEFAULT_TEMP_PREFIX : prefix, image, NULL);
}


