/* $Id: fileseed.h,v 1.9 2003/12/04 18:58:47 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#ifndef FILESEED_H
#define FILESEED_H


/* This package provides facilities for examining the file system. */


#include "appleseeds.h" /* AS_Entities */


#ifdef __cplusplus
extern "C" {
#endif


/* File information returned by GetFileFacts. */
typedef struct {
  unsigned char readPermission[3];  /* Group, other, and owner permissions */
  unsigned char writePermission[3]; /* ... */
  unsigned char execPermission[3];  /* ... */
  unsigned char isADirectory;   /* Is it a directory? */
  unsigned char isALink;        /* Is it a link? */
  unsigned char isHidden;       /* Is it suppressed from normal listing? */
  char owner[64 + 1];           /* Name of owner */
  char group[64 + 1];           /* Name of group */
  unsigned long size;           /* File size, in bytes */
  unsigned long lastAccess;     /* Last read/write (secs since 1/1/1970) */
  unsigned long lastWrite;      /* Last write (secs since 1/1/1970) */
} ASFILE_FileFacts;


/*
 * Returns as a NULL-terminated string array the names of all files contained
 * in the directory accessed via #path#; returns NULL if #path# is invalid.  If
 * #pattern# is not NULL, only matching filenames are returned.  See
 * ASSTR_StrNFnMatch in strseed.h for the syntax of #pattern#. The value
 * returned and its elements are allocated and should be freed after use.
 */
char **
ASFILE_DirectoryContents(const char *path,
                         const char *pattern);


/*
 * Returns the contents of the file accessed via #path# in an allocated,
 * nul-terminated string, or NULL on error.
 */
char *
ASFILE_FileContents(const char *path);


/*
 * Returns the full path to a file in an allocated string, or NULL if the file
 * does not exist.  Searches each of the colon-delimited directories #dirs# for
 * each of the colon-delimited file names #names#. (The delimiter on Windows is
 * a semicolon.)
 */
char *
ASFILE_FindFile(const char *dirs,
                const char *names);


/*
 * Places information about the file accessed via #path# in #facts#.  Returns
 * 1 if successful, else 0.
 */
int
ASFILE_GetFileFacts(const char *path,
                    ASFILE_FileFacts *facts);


/*
 * Removes from #s# references to the current directory ("."), duplicate path
 * separators, and references to the parent directory ("..") along with the
 * preceding directory.  Returns #s# for convenience.
 */
char *
ASFILE_MinimizeFilePath(char *s);


/*
 * Determines whether #who# is allowed read, write and/or exec access to the
 * file #path#, depending on whether #allowReading#, #allowWriting# and
 * #allowExecing# are non-zero.  Returns 1 if successful, else 0.
 */
int
ASFILE_SetFilePermission(const char *path,
                         AS_Entities who,
                         int allowReading,
                         int allowWriting,
                         int allowExecing);


/*
 * Returns an allocated string containing a unique file path.  If #prefix# is
 * not NULL, it will appear at the beginning of the returned path.
 */
char *
ASFILE_UniqueFilePath(const char *prefix);


#ifdef ASFILE_SHORT_NAMES

#define READ_PERMISSION ASFILE_READ_PERMISSION
#define WRITE_PERMISSION ASFILE_WRITE_PERMISSION
#define EXEC_PERMISSION ASFILE_EXEC_PERMISSION
#define FilePermissions ASFILE_FilePermissions
#define FileFacts ASFILE_FileFacts

#define DirectoryContents ASFILE_DirectoryContents
#define FileContents ASFILE_FileContents
#define FindFile ASFILE_FindFile
#define GetFileFacts ASFILE_GetFileFacts
#define MinimizeFilePath ASFILE_MinimizeFilePath
#define SetFilePermission ASFILE_SetFilePermission
#define UniqueFilePath ASFILE_UniqueFilePath

#endif


#ifdef __cplusplus
}
#endif


#endif
