/* $Id: hashseed.h,v 1.10 2003/12/04 18:58:47 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#ifndef HASHSEED_H
#define HASHSEED_H


/* This package provides facilities for manipulating hash tables. */


#ifdef __cplusplus
extern "C" {
#endif


/*
 * Declarations for hash tables and the key/value mappings they contain.  Any
 * type that can be cast to a (void *) can serve as a hash key or value.
 */
typedef struct ASH__HashTable *ASH_HashTable;
typedef void *ASH_KeyType;
typedef void *ASH_ValueType;

/*
 * An iterator for the mappings in a hash table.  #valid# indicates whether
 * or not the iterator refers to a valid mapping.  The other fields are for
 * internal use.
 */
typedef struct {
  int valid;
  ASH_HashTable table;
  unsigned long bucket;
  unsigned long mapping;
} ASH_HashIterator;

/* Returns a hash value for #key#. */
typedef unsigned long (*ASH_HashFunction)(ASH_KeyType key);
/* Returns 1 if #key1# and #key2# are equal, 0 otherwise. */
typedef int (*ASH_KeyCompareFunction)(ASH_KeyType key1, ASH_KeyType key2);
/* Returns 1 if #inTable# should be selected, given #item#, 0 otherwise. */
typedef int (*ASH_KeySelectFunction)(ASH_KeyType inTable, ASH_KeyType item);
/* Passed #key# and #value# from a removed mapping. */
typedef void (*ASH_ReclaimFunction)(ASH_KeyType key, ASH_ValueType value);
/* Returns 1 if #inTable# should be selected, given #item#, 0 otherwise. */
typedef int
  (*ASH_ValueSelectFunction)(ASH_ValueType inTable, ASH_ValueType item);


/* A convenience macro; sets #iterator# to each mapping in #table# in turn. */
#define ASH_ForEachMapping(table,iterator) \
  for(iterator = ASH_IteratorFirst(table); \
      iterator.valid; \
      iterator = ASH_IteratorNext(iterator))


/* Returns the number of buckets in #table#. */
unsigned long
ASH_GetBucketCount(ASH_HashTable table);


/* Returns the ASH_HashFunction #table# uses. */
ASH_HashFunction
ASH_GetHashFunction(ASH_HashTable table);


/*
 * Returns the first key mapped to a value in #table# for which a call to
 * #selector# passing the value and #value# returns non-zero.  #selector# may
 * be NULL, in which case == is used to select.  Returns NULL if #selector#
 * returns zero every time.  NOTE: this function sequentially tests all values
 * in #table#.
 */
ASH_KeyType
ASH_GetKey(ASH_HashTable table,
           ASH_ValueType value,
           ASH_ValueSelectFunction selector);


/* Returns the ASH_KeyCompareFunction #table# uses. */
ASH_KeyCompareFunction
ASH_GetKeyCompareFunction(ASH_HashTable table);


/* Returns the number of key/value mappings in #table#. */
unsigned long
ASH_GetMappingCount(ASH_HashTable table);


/* Returns the ASH_ReclaimFunction #table# uses. */
ASH_ReclaimFunction
ASH_GetReclaimFunction(ASH_HashTable table);


/*
 * Sets #keys# to a #len#-long array containing all keys from #table# for which
 * a call to #selector# passing the key and #key# returns non-zero.  All keys
 * are returned if #key# is NULL; the table KeyCompareFunction is used if
 * #selector# is NULL.  The array is allocated and should be freed after use.
 */
void
ASH_GetSelectedKeys(ASH_HashTable table,
                    ASH_KeyType key,
                    ASH_KeySelectFunction selector,
                    ASH_KeyType **keys,
                    unsigned long *len);
#define ASH_GetAllKeys(table,keys,len) \
  ASH_GetSelectedKeys(table, 0, 0, keys, len)


/*
 * Sets #values# to a #len#-long array containing all values from #table# for
 * which a call to #selector# passing the value and #value# returns non-zero.
 * All values are returned if #value# is NULL; == is used if #selector# is
 * NULL.  The array is allocated and should be freed after use.
 */
void
ASH_GetSelectedValues(ASH_HashTable table,
                      ASH_ValueType value,
                      ASH_ValueSelectFunction selector,
                      ASH_ValueType **values,
                      unsigned long *len);
#define ASH_GetAllValues(table,values,len) \
  ASH_GetSelectedValues(table, 0, 0, values, len)


/*
 * Returns the first value mapped to a key in #table# for which a call to
 * #selector# passing the key and #key# returns non-zero.  #selector# may be
 * NULL, in which case the table KeyCompareFunction is used to select.  Returns
 * NULL if #selector# returns zero every time.  NOTE: only those keys with the
 * same hash value as #key# are tested.
 */
ASH_ValueType
ASH_GetValue(ASH_HashTable table,
             ASH_KeyType key,
             ASH_KeySelectFunction selector);


/*
 * Returns a measurement of the efficiency of the hash function used with
 * #table#.  A value of 1.0 indicates a perfect hash function; a value of 0
 * indicates a constant one.
 */
double
ASH_HashEfficiency(ASH_HashTable table);


/* Frees space allocated for #table# after first removing all mappings. */
void
ASH_HashTableFree(ASH_HashTable table);


/*
 * Returns a hash table with #buckets# buckets.  The table must be passed to
 * ASH_FreeHashTable after use.  #comparer# is used by ASH_PutMapping to
 * determine whether a key/value pair is new or replaces an existing one; it is
 * also the default selector function for ASH_GetKey, ASH_GetSelectedKeys, and
 * ASH_RemoveMapping.  == is used if it is NULL.  #hasher# is used to generate
 * hash values from keys; the keys themselves (i.e., the void * values) are
 * used if it is NULL.  #reclaimer# is used to reclaim any space allocated for
 * the table's keys and values; no reclamation is done if it is NULL.
 */
ASH_HashTable
ASH_HashTableNew(unsigned long buckets,
                 ASH_KeyCompareFunction comparer,
                 ASH_HashFunction hasher,
                 ASH_ReclaimFunction reclaimer);


/* Returns the first mapping from #table#. */
ASH_HashIterator
ASH_IteratorFirst(ASH_HashTable table);


/* Returns the key from the mapping to which #iterator# refers. */
ASH_KeyType
ASH_IteratorKey(ASH_HashIterator iterator);


/* Returns to the mapping that follows #iterator#. */
ASH_HashIterator
ASH_IteratorNext(ASH_HashIterator iterator);


/* Returns the value from the mapping to which #iterator# refers. */
ASH_ValueType
ASH_IteratorValue(ASH_HashIterator iterator);


/*
 * Maps #key# to #value# in the table, replacing any existing mapping for a key
 * that compares equal to #key#.  NOTE: #key# and #value# are retained in the
 * table, so they must not be freed until the mapping is removed.
 */
void
ASH_PutMapping(ASH_HashTable table,
               ASH_KeyType key,
               ASH_ValueType value);


/* Removes all key/value mappings from #table#. */
void
ASH_RemoveAllMappings(ASH_HashTable table);


/*
 * Removes the mapping for the first key in #table# for which a call to
 * #selector# passing the key and #key# returns non-zero.  #selector# may be
 * NULL, in which case the table KeyCompareFunction is used.  NOTE: only those
 * keys with the same hash value as #key# are tested.
 */
void
ASH_RemoveMapping(ASH_HashTable table,
                  ASH_KeyType key,
                  ASH_KeySelectFunction selector);


/*
 * A ASH_KeyCompareFunction/ASH_KeySelectFunction/ASH_ValueSelectFunction for
 * comparing two string values.  Returns 1 or 0 depending on whether or not
 * #s1# and #s2# contain the same characters.
 */
int
ASH_StringCompare(void *s1,
                  void *s2);


/* A ASH_HashFunction that returns a hash value for #s#. */
unsigned long
ASH_StringHash(void *s);


#ifdef ASH_SHORT_NAMES

#define HashIterator ASH_HashIterator
#define HashTable ASH_HashTable
#define KeyType ASH_KeyType
#define ValueType ASH_ValueType

#define HashFunction ASH_HashFunction
#define KeyCompareFunction ASH_KeyCompareFunction
#define KeySelectFunction ASH_KeySelectFunction
#define ReclaimFunction ASH_ReclaimFunction
#define ValueSelectFunction ASH_ValueSelectFunction

#define ForEachMapping ASH_ForEachMapping
#define GetBucketCount ASH_GetBucketCount
#define GetHashFunction ASH_GetHashFunction
#define GetKey ASH_GetKey
#define GetKeyCompareFunction ASH_GetKeyCompareFunction
#define GetMappingCount ASH_GetMappingCount
#define GetReclaimFunction ASH_GetReclaimFunction
#define GetSelectedKeys ASH_GetSelectedKeys
#define GetAllKeys ASH_GetAllKeys
#define GetSelectedValues ASH_GetSelectedValues
#define GetAllValues ASH_GetAllValues
#define GetValue ASH_GetValue
#define HashEfficiency ASH_HashEfficiency
#define HashTableFree ASH_HashTableFree
#define HashTableNew ASH_HashTableNew
#define IteratorFirst ASH_IteratorFirst
#define IteratorKey ASH_IteratorKey
#define IteratorNext ASH_IteratorNext
#define IteratorValue ASH_IteratorValue
#define PutMapping ASH_PutMapping
#define RemoveAllMappings ASH_RemoveAllMappings
#define RemoveMapping ASH_RemoveMapping

#define StringCompare ASH_StringCompare
#define StringHash ASH_StringHash

#endif


#ifdef __cplusplus
}
#endif


#endif
