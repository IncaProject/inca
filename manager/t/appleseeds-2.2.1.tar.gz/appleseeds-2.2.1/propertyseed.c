/* $Id: propertyseed.c,v 1.34 2004/12/07 23:48:02 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#include "config.h"
#include "oshseed.h"
#include <ctype.h>  /* isspace */
#include <stdio.h>  /* file functions */
#include <stdlib.h> /* free malloc {un}setenv */
#include <string.h> /* string manipulation functions */
#include "strseed.h"
#include "vectorseed.h"
#define ASPROP_SHORT_NAMES
#include "propertyseed.h"


/* Basic PropertyList manipulation. */
extern char **environ;


/*
 * Searches #list# for a property with a name matching the first #nameLen#
 * characters of #name#.  Returns a pointer to the property if found, else NULL.
 */
static Property *
PropertySearch(const PropertyList list,
               const char *name,
               unsigned nameLen) {
  Property *property;
  ForEachProperty(list, property) {
    if(strncmp(*property, name, nameLen) == 0 && strlen(*property) == nameLen)
      return property;
  }
  return NULL;
}

            
char **
EnvironFromPropertyList(const PropertyList list) {
  char **p;
  char **result = PropertySublistByPrefix(list, "", 0);
  for(p = result; *p != NULL; p++)
    *(*p + strlen(*p)) = '=';
  return result;
}


PropertyList
EnvironToPropertyList(const char *const *env) {
  unsigned i;
  PropertyList result;
  if(env == NULL)
    env = (const char *const *)environ;
  for(i = 0; env[i] != NULL; i++)
    ; /* empty */
  result = (PropertyList)malloc((i + 1) * sizeof(Property));
  for(i = 0; env[i] != NULL; i++) {
    result[i] = strdup(env[i]);
    *strchr(result[i], '=') = '\0';
  }
  result[i] = NO_PROPERTY;
  return result;
}


Property
FindPropertyByName(const PropertyList list,
                   const char *name) {
  return FindPropertyByNameSized(list, name, strlen(name));
}


Property
FindPropertyByNameSized(const PropertyList list,
                        const char *name,
                        unsigned size) {
  Property *property = PropertySearch(list, name, size);
  return property == NULL ? NO_PROPERTY : *property;
}


unsigned
PropertyCount(const PropertyList list) {
  Property *property;
  ForEachProperty(list, property)
    ; /* empty */
  return property - list;
}


void
PropertyListFree(PropertyList *list) {
  Property *property;
  ForEachProperty(*list, property)
    free(*property);
  free(*list);
  *list = NO_PROPERTY_LIST;
}


PropertyList
PropertyListNew(void) {
  PropertyList result;
  result = (PropertyList)malloc(sizeof(Property));
  *result = NO_PROPERTY;
  return result;
}


char *
PropertyName(const Property property) {
  return property;
}


char *
PropertyValue(const Property property) {
  return property == NO_PROPERTY ? NULL : (property + strlen(property) + 1);
}


void
RemoveProperty(PropertyList *list,
               const char *name) {
  Property *property;
  if((property = PropertySearch(*list, name, strlen(name))) != NULL) {
    free(*property);
    for( ; *property != NO_PROPERTY; property++)
      *property = *(property + 1);
  }
}


void
SetProperty(PropertyList *list,
            const char *name,
            const char *value) {
  unsigned listLen;
  Property newProperty;
  Property *oldProperty;
  newProperty = (Property)malloc(strlen(name) + 1 + strlen(value) + 1);
  strcpy(newProperty, name);
  strcpy(newProperty + strlen(name) + 1, value);
  if((oldProperty = PropertySearch(*list, name, strlen(name))) == NULL) {
    listLen = PropertyCount(*list);
    *list = (PropertyList)ASSTR_Realloc(*list, (listLen+2) * sizeof(Property));
    (*list)[listLen] = newProperty;
    (*list)[listLen + 1] = NO_PROPERTY;
  }
  else {
    free(*oldProperty);
    *oldProperty = newProperty;
  }
}


/* PropertyList manipulation. */


PropertyList
PropertySublistByPrefix(const PropertyList list,
                        const char *prefix,
                        int trimPrefix) {
  unsigned prefixLen = strlen(prefix);
  const Property *property;
  PropertyList result = PropertyListNew();
  ForEachProperty(list, property) {
    if(strncmp(PropertyName(*property), prefix, prefixLen) == 0)
      SetProperty(&result,
                  PropertyName(*property) + (trimPrefix ? prefixLen : 0),
                  PropertyValue(*property));
  }
  return result;
}


char *
StringFromPropertyList(const PropertyList list) {

  const char *c;
  char *p;
  const Property *property;
  char *result;
  unsigned totalSize = 0;

  ForEachProperty(list, property) {
    for(c = PropertyName(*property); *c != '\0'; c++) {
      totalSize++;
      if(*c == '\\' || *c == '\n')
        totalSize++;
    }
    totalSize++;
    for(c = PropertyValue(*property); *c != '\0'; c++) {
      totalSize++;
      if(*c == '\\' || *c == '\n')
        totalSize++;
    }
    totalSize++;
  }

  result = (char *)malloc(totalSize + 1);
  p = result;

  ForEachProperty(list, property) {
    for(c = PropertyName(*property); *c != '\0'; c++) {
      if(*c == '\\' || *c == '\n')
        *p++ = '\\';
      *p++ = *c;
    }
    *p++ = '=';
    for(c = PropertyValue(*property); *c != '\0'; c++) {
      if(*c == '\\' || *c == '\n')
        *p++ = '\\';
      *p++ = *c;
    }
    *p++ = '\n';
  }

  *p = '\0';
  return result;

}


PropertyList
StringToPropertyList(const char *s) {

  const char *endProperty;
  char *equals;
  char *p;
  char *property = (char *)malloc(1);
  PropertyList result = PropertyListNew();

  while(*s != '\0') {
    for(endProperty = strchr(s, '\n');
        *(endProperty - 1) == '\\';
        endProperty = strchr(endProperty + 1, '\n'))
      ; /* empty */
    property = (char *)ASSTR_Realloc(property, endProperty - s + 1);
    for(p = property; s < endProperty; p++, s++) {
      if(*s == '\\' && (*(s + 1) == '\\' || *(s + 1) == '\n'))
        s++;
      *p = *s;
    }
    *p = '\0';
    equals = strchr(property, '=');
    *equals = '\0';
    SetProperty(&result, property, equals + 1);
    s++;
  }

  free(property);
  return result;

}


/* Property reference resolution. */


/*
 * Reallocates #s# in order to append the #len#-long text #toAppend# to it and
 * returns the result.
 */
static char *
ExtendString(char *s,
             const char *toAppend,
             unsigned len) {
  int oldLen = strlen(s);
  char *result = (char *)ASSTR_Realloc(s, oldLen + len + 1);
  strncpy(result + oldLen, toAppend, len);
  result[oldLen + len] = '\0';
  return result;
}


char *
ResolveReferences(PropertyList properties,
                  const char *text,
                  const char *defaultValue) {

  unsigned nameLen;
  const char *nameStart;
  const char *refEnd;
  const char *refStart;
  char *result = strdup("");
  const char *value;

  for(refStart = strchr(text, '$'), refEnd = text;
      refStart != NULL;
      refStart = strchr(refEnd, '$')) {

    /* Copy any interspersed non-reference text. */
    if(refStart > refEnd)
      result = ExtendString(result, refEnd, refStart - refEnd);

    /* Find the end of the reference and the start and length of the name. */
    if(*(refStart + 1) == '{' || *(refStart + 1) == '(') {
      nameStart = refStart + 2;
      refEnd = strchr(nameStart, *(refStart + 1) == '{' ? '}' : ')');
      if(refEnd == NULL)
        break; /* Bad reference. */
      refEnd++;
      nameLen = refEnd - nameStart - 1;
    }
    else {
      nameStart = refStart + 1;
      for(refEnd = nameStart;
          isalnum((int)*refEnd) || *refEnd == '_' || *refEnd == '.';
          refEnd++)
        ; /* empty */
      nameLen = refEnd - nameStart;
    }

    /* Copy the value, if there is one. */
    value = FindPropertyValueByNameSized(properties, nameStart, nameLen);
    result = value != NULL ? ExtendString(result, value, strlen(value)) :
             defaultValue != NULL ?
             ExtendString(result, defaultValue, strlen(defaultValue)) :
             ExtendString(result, refStart, refEnd - refStart);

  }

  /* Copy any trailing non-reference text. */
  if(*refEnd != '\0')
    result = ExtendString(result, refEnd, strlen(refEnd));

  return result;

}


void
ResolveReferencesInList(PropertyList *list,
                        const char *defaultValue) {
  Property *property;
  char *resolved;
  const char *value;
  ForEachProperty(*list, property) {
    value = PropertyValue(*property);
    resolved = ResolveReferences(*list, value, defaultValue);
    if(strcmp(value, resolved) != 0)
      SetProperty(list, PropertyName(*property), resolved);
    free(resolved);
  }
}


/* Reading and writing property lists. */


static int
GetCh(FILE **inputFiles) {
  int ch;
  while((ch = fgetc(inputFiles[ASV_Size(inputFiles) - 1])) == EOF &&
        ASV_Size(inputFiles) > 1) {
    fclose(inputFiles[ASV_Size(inputFiles) - 1]);
    ASV_ShrinkSize(inputFiles, ASV_Size(inputFiles) - 1);
  }
  return ch;
}


static void
UngetCh(FILE **inputFiles,
        int ch) {
  if(ch != EOF)
    ungetc(ch, inputFiles[ASV_Size(inputFiles) - 1]);
}


/*
 * Returns in an allocated string a word that begins with #ch# and continues
 * up to the first occurrence of any character in #terminators#.  If #ch# is a
 * quote, strips the quotes and translates escape sequences into characters.
 */
static char *
ReadWord(FILE **inputFiles,
         int ch,
         const char *terminators) {

  char buffer[200];
  char *c;
  unsigned char escaped;
  char *last = buffer + sizeof(buffer) - 1;
  int quoted;
  char *result = NULL;

  if((quoted = ch == '"')) {
    ch = GetCh(inputFiles);
    terminators = "\n\"";
  }

  for(c = buffer;
      ch != EOF && strchr(terminators, ch) == NULL;
      ch = GetCh(inputFiles)) {
    if(c == last) {
      *c = '\0';
      result = result == NULL ? (char *)calloc(sizeof(buffer), sizeof(char)) :
        (char *)ASSTR_Realloc(result, strlen(result) + sizeof(buffer));
      strcat(result, buffer);
      c = buffer;
    }
    if(!quoted || ch != '\\') {
      *c++ = ch;
      continue;
    }
    escaped = 0;
    ch = GetCh(inputFiles);
    if(ch == '0') {
      while((ch = GetCh(inputFiles)) >= '0' && ch <= '7')
        escaped = escaped * 8 + (ch - '0');
      UngetCh(inputFiles, ch);
    }
    else if(ch == 'x') {
      while(((ch = GetCh(inputFiles)) >= '0' && ch <= '9') ||
            (toupper(ch) >= 'A' && toupper(ch) <= 'F')) 
        escaped = escaped * 16 +
                  (ch >= '0' && ch <= '9' ?
                   (ch - '0') : (toupper(ch) - 'A' + 10));
      UngetCh(inputFiles, ch);
    }
    else {
      escaped = ch == 'a' ? '\a' :
                ch == 'b' ? '\b' :
                ch == 'f' ? '\f' :
                ch == 'n' ? '\n' :
                ch == 'r' ? '\r' :
                ch == 't' ? '\t' :
                ch == 'v' ? '\v' :
                ch;
    }
    *c++ = escaped;
  }

  if(ch != '"')
    UngetCh(inputFiles, ch);
  *c = '\0';
  result = result == NULL ? (char *)calloc(sizeof(buffer), sizeof(char)) :
    (char *)ASSTR_Realloc(result, strlen(result) + sizeof(buffer));
  strcat(result, buffer);
  return result;

}


#define WHITESPACE " \f\n\r\t\v"
#define WORD_ENDERS "#;}" WHITESPACE
/*
 * Reads properties up to a closing brace and places them in #toWhere#.
 * Prepends #scopeName# to each property name.
 */
static void
ReadPropertyScope(FILE **inputFiles,
                  PropertyList *toWhere,
                  const char *scopeName) {

  int ch;
  char countImage[32];
  FILE *included;
  char *name;
  int scopeCount = 0;
  char *value;
  char *word;

  while(1) {

    /* Skip leading whitespace, property separators, and comments. */
    while(isspace((ch = GetCh(inputFiles))) || ch == ';' || ch == '#') {
      if(ch == '#') {
        /* See if this is a #include. */
        word = ReadWord(inputFiles, ch, WHITESPACE);
        if(strcmp(word, "#include") == 0) {
          while((ch = GetCh(inputFiles))!=EOF && isspace((int)ch) && ch!='\n')
            ; /* empty */
          if(ch != EOF && ch != '\n') {
            name = ReadWord(inputFiles, ch, WHITESPACE);
            if((included = fopen(name, "r")) != NULL)
              ASV_Append(inputFiles, included);
            free(name);
          }
        }
        else {
          while((ch = GetCh(inputFiles)) != EOF && ch != '\n')
            ; /* empty */
        }
        free(word);
      }
    }

    if(ch == EOF || ch == '}')
      break;

    /* Read name or first word of anonymous value and skip trailing spaces. */
    word = ReadWord(inputFiles, ch, "=" WORD_ENDERS);
    while((ch = GetCh(inputFiles)) != EOF && isspace((int)ch) && ch != '\n')
      ; /* empty */

    if(ch == '=') {
      /* Named value; skip spaces and read first word of value, if any. */
      name = (char *)malloc(strlen(scopeName) + strlen(word) + 1);
      sprintf(name, "%s%s", scopeName, word);
      free(word);
      while((ch = GetCh(inputFiles)) != EOF && isspace((int)ch) && ch != '\n')
        ; /* empty */
      if(ch != EOF && strchr(WORD_ENDERS, ch) == NULL) {
        value = ReadWord(inputFiles, ch, WORD_ENDERS);
        while((ch = GetCh(inputFiles)) != EOF && isspace((int)ch) && ch != '\n')
          ; /* empty */
      }
      else
        value = strdup("");
    }
    else {
      /* Anonymous value; name positionally. */
      sprintf(countImage, "%d", scopeCount);
      name = (char *)malloc(strlen(scopeName) + strlen(countImage) + 1);
      sprintf(name, "%s%d", scopeName, scopeCount);
      value = word;
    }

    if(*value == '{') {
      /* Nested scope. */
      UngetCh(inputFiles, ch);
      name = (char *)ASSTR_Realloc(name, strlen(name) + 2);
      strcat(name, ".");
      ReadPropertyScope(inputFiles, toWhere, name);
    }
    else {
      while(ch != EOF && strchr(WORD_ENDERS, ch) == NULL) {
        word = ReadWord(inputFiles, ch, WORD_ENDERS);
        value = (char *)
          ASSTR_Realloc(value, strlen(value) + 1 + strlen(word) + 1);
        strcat(value, " ");
        strcat(value, word);
        free(word);
      }
      UngetCh(inputFiles, ch);
      SetProperty(toWhere, name, value);
    }

    free(name);
    free(value);
    scopeCount++;

  }

}


/*
 * Writes the word #word# to #toWhere#.  Encloses the word in quotes and
 * translates any non-printing characters into escape sequences.
 */
static void
WriteWord(FILE *toWhere,
          const char *word) {
  const char *c;
  fputc('"', toWhere);
  for(c = word; *c != '\0'; c++) {
    if(*c == '"' || *c == '\\')
      fprintf(toWhere, "\\%c", *c);
    else if(*c < ' ')
      fprintf(toWhere, "\\x%X%X", *c / 16, *c % 16);
    else
      fputc(*c, toWhere);
  }
  fputc('"', toWhere);
}


/*
 * Writes to #toWhere# the elements of the array of properties pointed to by
 * #nextProperty# that belong in the scope named the #scopeNameLong# name
 * #scopeName#.  Prefixes each element with #indent# levels of indentation.
 * Updates #nextProperty# to point to the next out-of-scope element.
 */
static void
WritePropertyScope(FILE *toWhere,
                   const Property **nextProperty,
                   const char *scopeName,
                   unsigned scopeNameLen,
                   unsigned indent) {

  const char *name;
  const char *nameEnd;
  Property property;

  while((property = **nextProperty) != NO_PROPERTY &&
        strncmp(property, scopeName, scopeNameLen) == 0) {
    name = PropertyName(property) + scopeNameLen;
    if((nameEnd = strchr(name, '.')) == NULL)
      nameEnd = name + strlen(name);
    fprintf(toWhere, "%*s%.*s = ",
            (int)indent * 2, "", (int)(nameEnd - name), name);
    if(*nameEnd == '\0') {
      /* Simple value. */
      WriteWord(toWhere, PropertyValue(property));
      fprintf(toWhere, "\n");
      (*nextProperty)++;
    }
    else {
      /* Compound value. */
      fprintf(toWhere, "{\n");
      WritePropertyScope
        (toWhere, nextProperty, property, nameEnd - property + 1, indent + 1);
      fprintf(toWhere, "%*s}\n", (int)indent * 2, "");
    }
  }

}


PropertyList
ReadPropertyList(FILE *fromWhere) {
  FILE **inputFiles = ASV_VectorNew(FILE *);
  PropertyList result = PropertyListNew();
  ASV_Append(inputFiles, fromWhere);
  ReadPropertyScope(inputFiles, &result, "");
  ASV_VectorFree(inputFiles);
  return result;
}


void
WritePropertyList(FILE *toWhere,
                  const PropertyList list) {
  const Property *current = list;
  WritePropertyScope(toWhere, &current, "", 0, 0);
  fprintf(toWhere, "%s\n", "}");
}
