#! /usr/bin/perl
#
# $Id: appleseeds.pl,v 1.19 2003/12/04 19:00:21 jhayes Exp $ */
# Copyright � 2002 The Regents of the University of California. 
# All Rights Reserved. 
#
# Permission to use, copy, modify, and distribute this software and its
# documentation for educational, research and non-profit purposes, without
# fee, and without a written agreement is hereby granted, provided that the
# above copyright notice, this paragraph and the following three paragraphs
# appear in all copies. 
#
# Permission to incorporate this software into commercial products may be
# obtained by contacting
# Technology Transfer Office 
# 9500 Gilman Drive 
# 411 University Center 
# University of California 
# La Jolla, CA 92093-0093
# (858) 534-5815
# invent@ucsd.edu
#
# This software program and documentation are copyrighted by The Regents of
# the University of California. The software program and documentation are
# supplied "as is", without any accompanying services from The Regents. The
# Regents does not warrant that the operation of the program will be
# uninterrupted or error-free. The end-user understands that the program was
# developed for research purposes and is advised not to rely exclusively on
# the program for any reason. 
#
# IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
# DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
# LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
# EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
# HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
# OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
# MODIFICATIONS. 


use PolyDoc;

# Make a horizontal table of links to the logo images.
my $imageTable =
  HtmlTable(0, '<img src="applegrow.gif" alt="appleseeds">',
               '<img src="appleseeds.gif" alt="appleseeds">');

# Writes #html# packaged into an HTML page with a common appearance to #file#,
# using #title# as the page title.
sub AppleseedsPage {
  my ($file, $title, $html) = @_;
  print "Producing $file\n";
  FileWrite($file,
    HtmlHeader
      ($title,
       '  <link rel="stylesheet" href="general.css" type="text/css">' . "\n" .
       HtmlStyle('span.code', 'aqua;bold',
                 'span.doc',  'margin-left:5%;margin-bottom:0.25in',
                 'span.kept', 'margin-bottom:0.5in') . "\n") .
    HtmlBody(
      '<img src="appleseeds.gif" alt="appleseeds">' . "\n\n" .
      '<h1 class="title">' . $title . "</h1>\n\n" .
      AddLinks(ReplaceAll($html, '#(\w+)#', '<i>$1</i>'))
    )
  );
}

my %html;
my %titles = ('appleseeds'      => 'General AppleSeeds Type Definitions',
              'diagnosticseed'  => 'Diagnostic Message Utilities',
              'envseed'         => 'Process Environment Utilities',
              'execseed'        => 'Process/Thread Control Utilities',
              'fileseed'        => 'File System Utilities',
              'formatseed'      => 'Inter-machine Data Format Utilities',
              'hashseed'        => 'Hash Table Utilities',
              'ipseed'          => 'DNS and Socket Utilities',
              'oshseed'         => 'Include File Portability',
              'propertyseed'    => 'Property List Utilities',
              'semseed'         => 'Semaphore Utilities',
              'shmseed'         => 'Shared Memory Utilities',
              'strseed'         => 'String Manipulation Utilities',
              'vectorseed'      => 'Dynamic Array Utilities',
              'xmlseed'         => 'XML DOM Implementation');

foreach $seed (keys %titles) {
  Extract(FileRead("../$seed.h"), 'c', "$seed.html", 'This package');
  $html{$seed} = ExtractedHtml("$seed.html");
  while($html{$seed} =~ s/(:\n<p>)([^<]+)/$1<pre>$2<\/pre>/) { }
}

foreach $seed (keys %html) {
  AppleseedsPage("$seed.html", $titles{$seed}, $html{$seed});
}

AppleseedsPage('bugs.html', 'Bugs and Limitations', FileRead('bugs'));
AppleseedsPage('download.html', 'Download', FileRead('download'));
AppleseedsPage('install.html', 'Installation and Use', FileRead('install'));
AppleseedsPage('introduction.html', 'Introduction', FileRead('introduction'));
AppleseedsPage('release.html', 'Release Notes', FileRead('release'));
print "Producing menu.html\n";
FileWrite('menu.html',
          HtmlHeader
            ("Menu",
             '<base target=mainFrame>' .
             '<link rel="stylesheet" href="general.css" type="text/css">') .
          HtmlBody
            ("<img src=\"applegrow.gif\" alt=\"appleseeds\">\n" .
             HtmlTable(1, '<a href=introduction.html>Introduction</a>',
                          '<a href=download.html>Download</a>',
                          '<a href=install.html>Installation</a>',
                          '<a href=release.html>Release Notes</a>',
                          '<a href=bugs.html>Bugs</a>',
                          '<a href=appleseeds.html>appleseeds</a>',
                          '<a href=diagnosticseed.html>diagnosticseed</a>',
                          '<a href=envseed.html>envseed</a>',
                          '<a href=execseed.html>execseed</a>',
                          '<a href=fileseed.html>fileseed</a>',
                          '<a href=formatseed.html>formatseed</a>',
                          '<a href=hashseed.html>hashseed</a>',
                          '<a href=ipseed.html>ipseed</a>',
                          '<a href=oshseed.html>oshseed</a>',
                          '<a href=propertyseed.html>propertyseed</a>',
                          '<a href=semseed.html>semseed</a>',
                          '<a href=shmseed.html>shmseed</a>',
                          '<a href=strseed.html>strseed</a>',
                          '<a href=vectorseed.html>vectorseed</a>',
                          '<a href=xmlseed.html>xmlseed</a>',
                          '<a href=nameindex.html>Declared Names</a>'))
);
@names = DeclaredNames();
AppleseedsPage('nameindex.html', 'Declared Names', HtmlTable(1, sort @names));
print "Producing index.html\n";
FileWrite('index.html',
          HtmlHeader('AppleSeeds') .
          '<frameset cols="200,*">' . "\n" .
          '  <frame src="menu.html" name=menuFrame>' . "\n" .
          '  <frame src="introduction.html" name=mainFrame>' . "\n" .
          "</frameset>\n" .
          "<noframes>\n" .
          "  Sorry, this page requires frames\n" .
          "</html>");
