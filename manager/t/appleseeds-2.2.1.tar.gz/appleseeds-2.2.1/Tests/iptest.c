/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdio.h>  /* file functions */
#include <stdlib.h> /* free */
#include <string.h> /* string functions */
#define ASIP_SHORT_NAMES
#include "ipseed.h"


int
main(int argc,
     char **argv) {

  const unsigned char KNOWN_ADDRESS[4] = {198, 202, 75, 101};
  const char *KNOWN_ADDRESS_IMAGE = "198.202.75.101";
  const char *KNOWN_MACHINE = "www.sdsc.edu";

  union {
    char bytes[4];
    struct {
      unsigned addr : 32;
    } address;
  } addressConverter;
  Address address;

  Socket accepted;
  char *allocated = NULL;
  char buffer[32 + 1];
  Socket client;
  char *s;
  Socket server;
  Port serverPort;

  /* DNS function tests. */
  memcpy(addressConverter.bytes, KNOWN_ADDRESS, sizeof(KNOWN_ADDRESS));
  s = AddressImage(addressConverter.address.addr);
  fprintf(stdout, "%s address to image\n",
          s != NULL && strcmp(s, KNOWN_ADDRESS_IMAGE) == 0 ? "Pass" : "Fail");
  if(s != NULL)
    free(s);
  s = AddressMachine(addressConverter.address.addr);
  fprintf(stdout, "%s address to name\n",
          s != NULL && strcmp(s, KNOWN_MACHINE) == 0 ? "Pass" : "Fail");
  if(s != NULL)
    free(s);
  fprintf(stdout, "%s image to address\n",
          (AddressValue(KNOWN_ADDRESS_IMAGE, &address) &&
           address == addressConverter.address.addr) ? "Pass" : "Fail");
  fprintf(stdout, "%s name to address\n",
          (AddressValue(KNOWN_MACHINE, &address) &&
           address == addressConverter.address.addr) ? "Pass" : "Fail");
  s = MyMachineName();
  fprintf(stdout, "%s host name\n",
          s == NULL || strcmp(s, "") == 0 ? "Fail" :
          strchr(s, '.') != 0 ? "Pass" : "Pass?");
  if(s != NULL)
    free(s);

  /* IP function tests. */
  fprintf(stdout, "%s open port\n",
          ((server = OpenIpPortBuffered
             (TCP_PROTOCOL, ANY_ADDRESS, ANY_PORT, DEFAULT_BUFFER_SIZE,
              DEFAULT_BUFFER_SIZE, &serverPort)) != NO_SOCKET) ?
          "Pass" : "Fail");
  fprintf(stdout, "%s socket port\n",
          (SocketPort(server) == serverPort) ? "Pass" : "Fail");
  fprintf(stdout, "%s connect port\n",
          ((client = ConnectToIpPortBuffered
             (TCP_PROTOCOL, SocketAddress(server), serverPort,
              DEFAULT_BUFFER_SIZE, DEFAULT_BUFFER_SIZE)) != NO_SOCKET) ?
          "Pass" : "Fail");
  fprintf(stdout, "%s accept\n",
          (CheckIfReadable(server, 3.0) &&
           (accepted = Accept(server)) != NO_SOCKET) ? "Pass" : "Fail");
  fprintf(stdout, "%s peer address\n",
          (PeerAddress(accepted) == SocketAddress(client)) ? "Pass" : "Fail");
  fprintf(stdout, "%s peer port\n",
          (PeerPort(accepted) == SocketPort(client)) ? "Pass" : "Fail");
  memset(buffer, 0, sizeof(buffer));
  fprintf(stdout, "%s fixed receive\n",
          (Send(client, KNOWN_MACHINE, strlen(KNOWN_MACHINE)) &&
           Receive(accepted, buffer, strlen(KNOWN_MACHINE)) &&
           strcmp(buffer, KNOWN_MACHINE) == 0) ? "Pass" : "Fail");
  memset(buffer, 1, sizeof(buffer));
  fprintf(stdout, "%s terminated receive\n",
          (Send(client, KNOWN_MACHINE, strlen(KNOWN_MACHINE) + 1) &&
           ReceiveTerminated(accepted, buffer, sizeof(buffer), "") &&
           strcmp(buffer, KNOWN_MACHINE) == 0) ? "Pass" : "Fail");
  fprintf(stdout, "%s string receive\n",
          (Send(client, KNOWN_MACHINE, strlen(KNOWN_MACHINE) + 1) &&
           ReceiveString(accepted, &allocated) &&
           strcmp(allocated, KNOWN_MACHINE) == 0) ? "Pass" : "Fail");
  free(allocated);
  fprintf(stdout, "%s terminated string receive\n",
          (Send(client, "www.", strlen("www.") + 1) &&
           ReceiveStringTerminated(accepted, ".", &allocated) &&
           strcmp(allocated, "www.") == 0) ? "Pass" : "Fail");
  free(allocated);
  Disconnect(&accepted);
  Disconnect(&client);
  Disconnect(&server);

  return 0;

}
