/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdio.h> /* file functions */
#define ASEXEC_SHORT_NAMES
#include "execseed.h"


enum {STDIN_FD = 0, STDOUT_FD = 1, STDERR_FD = 2};
enum {PIPE_READ = 0, PIPE_WRITE = 1};


#define CHILD_CHAR "C"
#define PARENT_CHAR "P"


static int childToParent[2];
static int parentToChild[2];


static void *
MyThreadFn(void *arg) {
  char ch;
  write(childToParent[PIPE_WRITE], arg, 1);
  read(parentToChild[PIPE_READ], &ch, 1);
  return (void *)((int)*CHILD_CHAR);
}


int
main(int argc,
     char **argv) {

  const char *args[] = {NULL, NULL, NULL};
  char ch;
  ProcessId child;
  int exitCode;
  ThreadId thread;
  int result;
  void *returnValue;
  int savedStdin;
  int savedStderr;

  if(argc == 1) {

    pipe(childToParent);
    pipe(parentToChild);
    args[0] = argv[0];
    args[1] = CHILD_CHAR;

    fprintf(stdout, "%s own cpu\n",
            ProcessCpuMilliseconds(MyProcess()) >= 0 ? "Pass" : "Fail");

    savedStdin = dup(STDIN_FD);
    savedStderr = dup(STDERR_FD);
    dup2(parentToChild[PIPE_READ], STDIN_FD);
    dup2(childToParent[PIPE_WRITE], STDERR_FD);
    result = ProcessStart(argv[0], args, &child);
    dup2(savedStdin, STDIN_FD);
    dup2(savedStderr, STDERR_FD);
    close(savedStdin);
    close(savedStderr);
    fprintf(stdout, "%s process spawn\n", result ?  "Pass" : "Fail");
    fprintf(stdout, "%s child contact\n",
            read(childToParent[PIPE_READ], &ch, 1) == 1 && ch == *CHILD_CHAR ?
            "Pass" : "Fail");
    fprintf(stdout, "%s child cpu\n",
            ProcessCpuMilliseconds(child) >= 0 ? "Pass" : "Fail");
    fprintf(stdout, "%s non-blocking process wait\n",
            !ProcessStopped(child, 0, &exitCode) ? "Pass" : "Fail");
    write(parentToChild[PIPE_WRITE], PARENT_CHAR, 1);
    exitCode = 0;
    fprintf(stdout, "%s blocking process wait\n",
            ProcessStopped(child, 1, &exitCode) && exitCode == *CHILD_CHAR ?
            "Pass" : "Fail");

    savedStdin = dup(STDIN_FD);
    savedStderr = dup(STDERR_FD);
    dup2(parentToChild[PIPE_READ], STDIN_FD);
    dup2(childToParent[PIPE_WRITE], STDERR_FD);
    ProcessStart(argv[0], args, &child);
    dup2(savedStdin, STDIN_FD);
    dup2(savedStderr, STDERR_FD);
    close(savedStdin);
    close(savedStderr);
    read(childToParent[PIPE_READ], &ch, 1);
    exitCode = 0;
    fprintf(stdout, "%s process stop\n",
            ProcessStop(child) && ProcessStopped(child, 1, &exitCode) &&
            exitCode != *CHILD_CHAR ? "Pass" : "Fail");

    fprintf(stdout, "%s thread spawn\n",
            ThreadStart(&MyThreadFn, (void *)CHILD_CHAR, &thread) ?
            "Pass" : "Fail");
    fprintf(stdout, "%s thread contact\n",
            read(childToParent[PIPE_READ], &ch, 1) == 1 && ch == *CHILD_CHAR ?
            "Pass" : "Fail");
    fprintf(stdout, "%s non-blocking thread wait\n",
            !ThreadStopped(thread, 0, &returnValue) ? "Pass" : "Fail");
    write(parentToChild[PIPE_WRITE], PARENT_CHAR, 1);
    returnValue = 0;
    fprintf(stdout, "%s blocking thread wait\n",
            ThreadStopped(thread, 1, &returnValue) &&
            (int)returnValue == *CHILD_CHAR ?
            "Pass" : "Fail");
  }
  else {

    fputs(argv[1], stderr); fflush(stderr);
    ch = fgetc(stdin);
    return *CHILD_CHAR;

  }

  return 0;

}
