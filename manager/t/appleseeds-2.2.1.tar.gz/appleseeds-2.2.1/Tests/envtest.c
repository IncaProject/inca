/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdio.h>  /* file functions */
#include <stdlib.h> /* getenv */
#include <string.h> /* strcmp */
#define ASENV_SHORT_NAMES
#include "envseed.h"


#define SC ASOSH_SWITCH_CHARACTER


static ParseErrors reportedError = (ParseErrors)0;
static char *reportedBadWord = 0;
static unsigned reportedBadSwitchOffset = 0;
static unsigned reportedBadSwitchLen = 0;
static char *reportedBadValue = 0;
static int handlerReturnValue = 0;
static int handlerCalls = 0;


static int
Handler(ParseErrors error,
        const char *badWord,
        unsigned badSwitchOffset,
        unsigned badSwitchLen,
        const char *badValue) {

  reportedError = error;
  if(reportedBadWord != 0)
    free(reportedBadWord);
  reportedBadWord = strdup(badWord);
  reportedBadSwitchOffset = badSwitchOffset;
  reportedBadSwitchLen = badSwitchLen;
  if(reportedBadValue != 0)
    free(reportedBadValue);
  reportedBadValue = strdup(badValue);
  handlerCalls++;
  return handlerReturnValue;

}


int
main(int argc,
     char **argv) {

  const char *VALID = SC "boolean on|off|yes|no|true|false|y|n\n"
                      SC "char char\n"
                      SC "double double\n"
                      SC "int int\n"
                      SC "string string\n"
                      SC "void void\n"
                      SC "b on|off|yes|no|true|false|y|n (letter form)\n"
                      SC "c char   (letter form)\n"
                      SC "d double (letter form)\n"
                      SC "i int    (letter form)\n"
                      SC "s string (letter form)\n"
                      SC "v void   (letter form)";
  const char *BAD_ARGUMENT[] = {"", SC "void", "badArgument", 0};
  const char *BAD_VALUES[] =
    {"", SC "b=ye", SC "char=abc", SC "d=x", SC "int=4.3", SC "v=1", 0};
  const char *COMPACT[] = {"", SC "vvvvvi95", 0};
  const char *GOOD_CHOICES[] =
    {"", SC "boolean=on", SC "boolean=off", SC "boolean=yes", SC "boolean=no",
         SC "boolean=true", SC "boolean=false", SC "boolean=y", SC "boolean=n",
         SC "b=on", SC "b=off", SC "b=yes", SC "b=no", SC "b=true",
         SC "b=false", SC "b=y", SC "b=n", 0};
  const char *GOOD_VALUES[] =
    {"", SC "c=a", SC "d=2.1", SC "int=1", SC "void", 0};
  const char *LETTER[] = {"", SC "d",  "4.7", SC "i=42", SC "void", 0};
  const char *LONG[] = {"", SC "double",  "3.5", SC "int=7", SC "void", 0};
  const char *MISSING_VALUES[] = {"", SC "string", 0};
  const char *MULTI_VALUES[] =
    {"", SC "i", "22", SC "c", "a", SC "c", "d", SC "i", "88", 0};
  const char *UNKNOWN_SWITCHES[] = {"", SC "a=1.3", SC "blue", SC "help", 0};
  ParsedArgv pa;

  pa = ParseArgv(COMPACT, VALID, 0);
  fprintf(stdout, "%s compact switch\n",
          pa != NULL &&
          strcmp(SwitchValue(pa, SC "i", ""), "95") == 0 ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);
  pa = ParseArgv(LETTER, VALID, 0);
  fprintf(stdout, "%s letter switch\n",
          pa != NULL &&
          strcmp(SwitchValue(pa, SC "i", ""), "42") == 0 ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);
  pa = ParseArgv(LONG, VALID, 0);
  fprintf(stdout, "%s long switch\n",
          pa != NULL &&
          strcmp(SwitchValue(pa, SC "int", ""), "7") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s default value\n",
          pa != NULL &&
          strcmp(SwitchValue(pa, SC "string", "abc"), "abc") == 0 &&
          SwitchValue(pa, SC "i", NULL) == NULL ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);
  pa = ParseArgv(MULTI_VALUES, VALID, 0);
  fprintf(stdout, "%s multiple values\n",
          pa != NULL &&
          strcmp(SwitchValueN(pa, SC "i", 1, "9"), "22") == 0 &&
          strcmp(SwitchValueN(pa, SC "i", 2, "9"), "88") == 0 &&
          strcmp(SwitchValueN(pa, SC "i", 4, "9"), "9") == 0 &&
          strcmp(SwitchValueN(pa, SC "c", 2, "X"), "d") == 0 &&
          strcmp(SwitchValueN(pa, SC "c", 1, "X"), "a") == 0 ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);


  pa = ParseArgv(BAD_ARGUMENT, VALID, 0);
  fprintf(stdout, "%s null handler\n", pa == NULL ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);
  pa = ParseArgv(BAD_ARGUMENT, VALID, &Handler);
  fprintf(stdout, "%s bad argument\n",
          pa == NULL && reportedError == ARGUMENTS_NOT_ALLOWED &&
          strcmp(reportedBadWord, "badArgument") == 0 ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);
  handlerReturnValue = 1;
  handlerCalls = 0;
  pa = ParseArgv(GOOD_CHOICES, VALID, &Handler);
  fprintf(stdout, "%s valid choices\n",
          pa != NULL && handlerCalls == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s SwitchPresent\n",
          pa != NULL && SwitchPresent(pa, SC "b") && !SwitchPresent(pa, SC "i")?
          "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);
  handlerCalls = 0;
  pa = ParseArgv(GOOD_VALUES, VALID, &Handler);
  fprintf(stdout, "%s valid value\n",
          pa != NULL && handlerCalls == 0 ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);
  handlerCalls = 0;
  pa = ParseArgv(BAD_VALUES, VALID, &Handler);
  fprintf(stdout, "%s invalid value\n",
          pa != NULL && reportedError == INVALID_VALUE &&
          handlerCalls == 5 ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);
  handlerCalls = 0;
  pa = ParseArgv(MISSING_VALUES, VALID, &Handler);
  fprintf(stdout, "%s missing value\n",
          pa != NULL && reportedError == MISSING_VALUE &&
          handlerCalls == 1 ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);
  handlerCalls = 0;
  pa = ParseArgv(UNKNOWN_SWITCHES, VALID, &Handler);
  fprintf(stdout, "%s unknown switch\n",
          pa != NULL && reportedError == UNKNOWN_SWITCH &&
          handlerCalls == 3 ? "Pass" : "Fail");
  if(pa != NULL)
    ParsedArgvFree(pa);

  return 0;

}
