/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdio.h> /* file functions */
#define ASV_SHORT_NAMES
#include "vectorseed.h"


int
main(int argc,
     char **argv) {

  typedef int *IntVector;

  int i;
  IntVector ints = VectorNew(int);

  fprintf(stdout, "%s initial capacity\n",
          (Capacity(ints) == 0) ? "Pass" : "Fail");
  fprintf(stdout, "%s initial increment\n",
          (Increment(ints) == 1) ? "Pass" : "Fail");
  fprintf(stdout, "%s initial size\n", (Size(ints) == 0) ? "Pass" : "Fail");
  Append(ints, 1000);
  fprintf(stdout, "%s empty insert\n",
          (Size(ints) == 1 && *ints == 1000) ? "Pass" : "Fail");
  fprintf(stdout, "%s capacity increment\n",
          (Capacity(ints) == 1) ? "Pass" : "Fail");

  for(i = 0; i < 1000; i++)
    Append(ints, i);

  fprintf(stdout, "%s append\n",
          (Size(ints) == 1001 && ints[500] == 499) ? "Pass" : "Fail");
  ShrinkSize(ints, 2001);
  fprintf(stdout, "%s ShrinkSize noop\n",
          (Size(ints) == 1001 && ints[1000] == 999) ? "Pass" : "Fail");
  ShrinkSize(ints, 501);
  fprintf(stdout, "%s ShrinkSize\n",
          (Size(ints) == 501 && ints[500] == 499) ? "Pass" : "Fail");
 
  GrowCapacity(ints, 501);
  fprintf(stdout, "%s GrowCapacity noop\n",
          (Capacity(ints) == 1001) ? "Pass" : "Fail");
  ShrinkCapacity(ints, 2001);
  fprintf(stdout, "%s ShrinkCapacity noop\n",
          (Capacity(ints) == 1001) ? "Pass" : "Fail");
  SetCapacity(ints, 1001);
  fprintf(stdout, "%s SetCapacity noop\n",
          (Capacity(ints) == 1001) ? "Pass" : "Fail");
  GrowCapacity(ints, 2001);
  fprintf(stdout, "%s GrowCapacity\n",
          (Capacity(ints) == 2001) ? "Pass" : "Fail");
  ShrinkCapacity(ints, 701);
  fprintf(stdout, "%s ShrinkCapacity\n",
          (Capacity(ints) == 701) ? "Pass" : "Fail");
  SetCapacity(ints, 501);
  fprintf(stdout, "%s SetCapacity\n",
          (Capacity(ints) == 501 && ints[500] == 499) ? "Pass" : "Fail");
  VectorFree(ints);
  ints = VectorNew(int);
  SetIncrement(ints, 100);
  for(i = 0; i < 832; i++)
    Append(ints, i);
  fprintf(stdout, "%s SetIncrement\n",
          (Capacity(ints) == 900 && Size(ints) == 832) ? "Pass" : "Fail");
  ShrinkSize(ints, 0);
  for(i = 99; i >= 50; i--)
    Append(ints, i);
  for(i = 0; i < 50; i++)
    Insert(ints, i, 50);
  fprintf(stdout, "%s Insert\n",
          (Size(ints)==100 && ints[0]==99 && ints[50]==49 && ints[99]==0) ?
          "Pass" : "Fail");
  for(i = 99; i > 0; i -= 2)
    Remove(ints, (unsigned)i);
  fprintf(stdout, "%s Remove\n",
          (Size(ints)==50 && ints[0]==99 && ints[25]==49 && ints[49]==1) ?
          "Pass" : "Fail");
  VectorFree(ints);

  return 0;

}
