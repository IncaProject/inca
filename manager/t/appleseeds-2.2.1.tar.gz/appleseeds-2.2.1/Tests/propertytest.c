/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdlib.h> /* free getenv */
#include <stdio.h>  /* file functions */
#include <string.h> /* string functions */
#define ASPROP_SHORT_NAMES
#include "propertyseed.h"


extern char **environ;


int
main(int argc,
     char **argv) {

#define PROPERTY_COUNT 12
  const char *PROPERTY_NAMES[PROPERTY_COUNT] = {
    "zero", "one", "two", "three", "four", "five",
    "six", "seven", "eight", "nine", "ten", "eleven"
  };
  const char *PROPERTY_VALUES[PROPERTY_COUNT] = {
    "nul", "eins", "zwei", "drei", "vier", "fu:nf",
    "sechs", "seben", "acht", "neun", "zehn", "elf"
  };
  const char *WITH_REFERENCES = "$one thousand $nine hundred $ninety-$five";
  const char *WITHOUT_REFERENCES = "eins thousand neun hundred ?-fu:nf";

  char **env;
  int i;
  PropertyList properties = PropertyListNew();
  FILE *propertyFile;
  char propertyFileName[128 + 1];
  int result;
  char *s;
  char *string;
  PropertyList sublist;

  fprintf(stdout, "%s empty miss\n",
          FindPropertyByName(properties, "a") == NO_PROPERTY ?
          "Pass" : "Fail");
  fprintf(stdout, "%s empty count\n",
          PropertyCount(properties) == 0 ? "Pass" : "Fail");
  RemoveProperty(&properties, "foobaz");
  fprintf(stdout, "%s empty remove\n",
          PropertyCount(properties) == 0 ? "Pass" : "Fail");

  SetProperty(&properties, "abc", "Hello");
  fprintf(stdout, "%s singleton set\n",
          PropertyCount(properties) == 1 &&
          strcmp(PropertyName(*properties), "abc") == 0 &&
          strcmp(PropertyValue(*properties), "Hello") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s singleton find\n",
          FindPropertyByName(properties, "abc") != NO_PROPERTY ?
          "Pass" : "Fail");
  fprintf(stdout, "%s singleton miss\n",
          FindPropertyByName(properties, "abd") == NO_PROPERTY ?
          "Pass" : "Fail");
  SetProperty(&properties, "abc", "Goodbye");
  fprintf(stdout, "%s singleton property reset\n",
          PropertyCount(properties) == 1 &&
          strcmp(PropertyName(*properties), "abc") == 0 &&
          strcmp(PropertyValue(*properties), "Goodbye") == 0 ? "Pass" : "Fail");
  RemoveProperty(&properties, "foobaz");
  fprintf(stdout, "%s singleton remove miss\n",
          PropertyCount(properties) == 1 ? "Pass" : "Fail");
  RemoveProperty(&properties, "abc");
  fprintf(stdout, "%s singleton remove\n",
          PropertyCount(properties) == 0 ? "Pass" : "Fail");

  for(i = 0; i < PROPERTY_COUNT; i++)
    SetProperty(&properties, PROPERTY_NAMES[i], PROPERTY_VALUES[i]);
  fprintf(stdout, "%s multiple set\n",
          FindPropertyByName(properties, "zero") != NO_PROPERTY &&
          strcmp(FindPropertyValueByName(properties, "zero"), "nul") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s multiple count\n",
          PropertyCount(properties) == PROPERTY_COUNT ? "Pass" : "Fail");
  fprintf(stdout, "%s multiple find\n",
          FindPropertyByName(properties, "six") != NO_PROPERTY ?
          "Pass" : "Fail");
  fprintf(stdout, "%s multiple miss\n",
          FindPropertyByName(properties, "dos") == NO_PROPERTY ?
          "Pass" : "Fail");
  SetProperty(&properties, "two", "zwo");
  fprintf(stdout, "%s multiple property reset\n",
          FindPropertyByName(properties, "two") != NO_PROPERTY &&
          strcmp(FindPropertyValueByName(properties, "two"), "zwo") == 0 ?
          "Pass" : "Fail");
  RemoveProperty(&properties, "foobaz");
  fprintf(stdout, "%s multiple remove miss\n",
          PropertyCount(properties) == PROPERTY_COUNT ? "Pass" : "Fail");
  sublist = PropertySublistByPrefix(properties, "t", 0);
  fprintf(stdout, "%s sublist\n",
          (PropertyCount(sublist) == 3) ? "Pass" : "Fail");
  string = StringFromPropertyList(sublist);
  fprintf(stdout, "%s => string\n",
          (strcmp(string, "two=zwo\nthree=drei\nten=zehn\n") == 0) ?
          "Pass" : "Fail");
  PropertyListFree(&sublist);
  sublist = StringToPropertyList(string);
  fprintf(stdout, "%s <= string\n",
          FindPropertyByName(sublist, "ten") != NO_PROPERTY &&
          strcmp(FindPropertyValueByName(sublist, "ten"), "zehn") == 0 ?
          "Pass" : "Fail");
  PropertyListFree(&sublist);
  free(string);
  sublist = PropertySublistByPrefix(properties, "t", 1);
  fprintf(stdout, "%s trimmed sublist\n",
          PropertyCount(sublist) == 3 ? "Pass" : "Fail");
  string = StringFromPropertyList(sublist);
  fprintf(stdout, "%s => string\n",
          strcmp(string, "wo=zwo\nhree=drei\nen=zehn\n") == 0 ?
          "Pass" : "Fail");
  PropertyListFree(&sublist);
  free(string);
  RemoveProperty(&properties, "six");
  RemoveProperty(&properties, "eleven");
  RemoveProperty(&properties, "zero");
  fprintf(stdout, "%s multiple remove\n",
          PropertyCount(properties) == PROPERTY_COUNT - 3 ? "Pass" : "Fail");

  s = ResolveReferences(properties, WITH_REFERENCES, "?");
  fprintf(stdout, "%s dereference\n",
          strcmp(s, WITHOUT_REFERENCES) == 0 ? "Pass" : "Fail");
  free(s);
  SetProperty(&properties, "refs", WITH_REFERENCES);
  ResolveReferencesInList(&properties, "?");
  fprintf(stdout, "%s list dereference\n",
          strcmp(FindPropertyValueByName(properties, "refs"),
                 WITHOUT_REFERENCES) == 0 ? "Pass" : "Fail");

  sprintf(propertyFileName, "asp%d.tmp", (int)getpid());
  propertyFile = fopen(propertyFileName, "w");
  WritePropertyList(propertyFile, properties);
  fclose(propertyFile);
  propertyFile = fopen(propertyFileName, "r");
  if((sublist = ReadPropertyList(propertyFile)) == NO_PROPERTY_LIST ||
     PropertyCount(sublist) != PropertyCount(properties))
    result = 0;
  else {
    for(i = 0;
        properties[i] != NO_PROPERTY && strcmp(properties[i], sublist[i]) == 0;
        i++)
      ; /* empty */
    result = properties[i] == NO_PROPERTY;
  }
  fprintf(stdout, "%s read/write\n", result ? "Pass" : "Fail");

  fclose(propertyFile);
  unlink(propertyFileName);
  PropertyListFree(&properties);
  PropertyListFree(&sublist);

  properties = EnvironToPropertyList(NULL);
  for(i = 0;
      environ[i] != NULL &&
      properties[i] != NULL &&
      strcmp(getenv(PropertyName(properties[i])),
             PropertyValue(properties[i])) == 0;
      i++)
    ; /* empty */
  fprintf(stdout, "%s convert from environ\n",
          properties[i] == NULL && environ[i] == NULL ? "Pass" : "Fail");
  env = EnvironFromPropertyList(properties);
  for(i = 0;
      properties[i] != NULL &&
      env[i] != NULL &&
      strcmp(PropertyValue(properties[i]), strchr(env[i], '=') + 1) == 0;
      i++)
    ; /* empty */
  fprintf(stdout, "%s convert to environ\n",
          properties[i] == NULL && env[i] == NULL ? "Pass" : "Fail");
  for(i = 0; env[i] != NULL; i++)
    free(env[i]);
  free(env);
  PropertyListFree(&properties);

  return 0;

}
