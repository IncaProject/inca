/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#define ASSTR_SHORT_NAMES
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "strseed.h"


int
main(int argc,
     char **argv) {

  const char *UNCASED = "THe mOVIe sTAr,tHe pROFESSOr aNd MARy ANn";
  const char *CASES[] = {
    "all lower", "all upper", "initial lower", "initial upper", NULL
  };
  const char *CASED[] = {
    "the movie star,the professor and mary ann",
    "THE MOVIE STAR,THE PROFESSOR AND MARY ANN",
    "tHe mOVIe sTAr,tHe pROFESSOr aNd mARy aNn",
    "THe MOVIe STAr,THe PROFESSOr ANd MARy ANn",
    NULL
  };
  const char *MATCHERS[] = {
    "THe mOVIe sTAr,tHe pROFESSOr aNd MARy ANn",
    "T?e m?VIe s?Ar,t?e pRO?ESSOr a?d M?Ry A??",
    "*",
    "THe mOVIe sTAr,*",
    "*,tHe pROFESSOr aNd MARy ANn",
    "*THe mOVIe sTAr,tHe pROFESSOr aNd MARy ANn",
    "THe mOVIe sTAr,tHe pROFESSOr aNd MARy ANn*",
    "THe mOVIe sTAr,tHe* pROFESSOr aNd MARy ANn",
    "THe * sTAr,tHe * aNd * ANn",
    "T[H]e m[AEIOU]V[]I]e s[-T]Ar,[!x]He p[A-Z]OFESS[0-9A-Z]r [!A-Z0-9#]Nd MARy A[!]]n",
    NULL
  };
  const char *NONMATCHERS[] = {
    "THe mOVIe sTAr,tHe pROFESSOr aNd MARy AN",
    "He mOVIe sTAr,tHe pROFESSOr aNd MARy ANn",
    "THe mOVIe sTAr,te pROFESSOr aNd MARy ANn",
    "THe mOVIe sTAr,tHe pROFESSOr aNd MARy ANn?",
    "?THe mOVIe sTAr,tHe pROFESSOr aNd MARy ANn",
    "THe mOVIe sTAr,tHe ?pROFESSOr aNd MARy ANn",
    NULL
  };
  const char *UNSPLIT1 =
    "the movie star, the professor and mary ann";
  const char *UNSPLIT2 =
    "  the  movie star,  the professor\t \tand mary ann\f  ";
  const char *SPLIT[] = {
    "the", "movie", "star,", "the", "professor", "and", "mary", "ann", NULL
  };

  char buffer[1024];
  unsigned i;
  char **pieces;
  char *s;
  unsigned long where;

  s = StrAppend(NULL, CASED[0], CASED[1], NULL);
  sprintf(buffer, "%s%s", CASED[0], CASED[1]);
  fprintf(stdout, "%s malloc append\n",
          strcmp(s, buffer) == 0 ? "Pass" : "Fail");
  s = StrAppend(s, CASED[2], CASED[3], NULL);
  strcat(buffer, CASED[2]);
  strcat(buffer, CASED[3]);
  fprintf(stdout, "%s realloc append\n",
          strcmp(s, buffer) == 0 ? "Pass" : "Fail");
  free(s);

  for(i = 0; CASES[i] != NULL; i++) {
    strcpy(buffer, UNCASED);
    fprintf(stdout, "%s setcase %s\n",
            strcmp(CASED[i], StrCase(buffer, (CaseTypes)i))==0?"Pass":"Fail",
            CASES[i]);
  }

  fprintf(stdout, "%s StrArrayLen\n", StrArrayLen(CASED)==4 ? "Pass" : "Fail");
  s = StrArrayJoin((const char **)CASED, NULL);
  sprintf(buffer, "%s%s%s%s", CASED[0], CASED[1], CASED[2], CASED[3]);
  fprintf(stdout, "%s NULL sep join\n",
          strcmp(s, buffer) == 0 ? "Pass" : "Fail");
  free(s);
  s = StrArrayJoin((const char **)CASED, "");
  fprintf(stdout, "%s empty sep join\n",
          strcmp(s, buffer) == 0 ? "Pass" : "Fail");
  free(s);
  s = StrArrayJoin((const char **)CASED, ", ");
  sprintf(buffer, "%s, %s, %s, %s", CASED[0], CASED[1], CASED[2], CASED[3]);
  fprintf(stdout, "%s sep join\n",
          strcmp(s, buffer) == 0 ? "Pass" : "Fail");
  free(s);
  s = StrNDup(UNSPLIT1, 5);
  fprintf(stdout, "%s StrNDup 1\n",
          strlen(s) == 5 && strncmp(s, UNSPLIT1, 5) == 0 ? "Pass" : "Fail");
  free(s);
  s = StrNDup(UNSPLIT1, 500);
  fprintf(stdout, "%s StrNDup 2\n",
          strlen(s) == strlen(UNSPLIT1) &&
          strcmp(s, UNSPLIT1) == 0 ? "Pass" : "Fail");
  free(s);

  for(i = 0; MATCHERS[i] != NULL; i++)
    fprintf(stdout, "%s match %d\n",
            StrFnMatch(UNCASED, MATCHERS[i]) ? "Pass" : "Fail", i);
  for(i = 0; NONMATCHERS[i] != NULL; i++)
    fprintf(stdout, "%s non-match %d\n",
            !StrFnMatch(UNCASED, NONMATCHERS[i]) ? "Pass" : "Fail", i);

  s = StrRepeat("", 10);
  fprintf(stdout, "%s repeat empty\n", *s == '\0' ? "Pass" : "Fail");
  free(s);
  s = StrRepeat("abc", 0);
  fprintf(stdout, "%s repeat 0\n", *s == '\0' ? "Pass" : "Fail");
  free(s);
  s = StrRepeat("abc", 3);
  fprintf(stdout, "%s repeat\n",
          strcmp(s, "abcabcabc") == 0 ? "Pass" : "Fail");
  free(s);

  s = strdup("'Twas brillig, and the slithy toves");
  StrReplace(&s, 15, 4, NULL);
  fprintf(stdout, "%s remove\n",
          strcmp(s, "'Twas brillig, the slithy toves") == 0 ? "Pass" : "Fail");
  StrReplace(&s, 15, 0, "& ");
  fprintf(stdout, "%s insert\n",
          strcmp(s, "'Twas brillig, & the slithy toves") == 0 ?
          "Pass" : "Fail");
  StrReplace(&s, 200, 0, " did gyre");
  fprintf(stdout, "%s append\n",
          strcmp(s, "'Twas brillig, & the slithy toves did gyre") == 0 ?
          "Pass" : "Fail");
  StrReplace(&s, 20, strlen(s) - 20, NULL);
  fprintf(stdout, "%s truncate\n",
          strcmp(s, "'Twas brillig, & the") == 0 ? "Pass" : "Fail");
  StrReplace(&s, 12, 300, "ant!");
  fprintf(stdout, "%s tail replace\n",
          strcmp(s, "'Twas brilliant!") == 0 ? "Pass" : "Fail");
  StrReplace(&s, 0, 2, "That ");
  fprintf(stdout, "%s expand\n",
          strcmp(s, "That was brilliant!") == 0 ? "Pass" : "Fail");
  StrReplace(&s, 4, 3, "'");
  fprintf(stdout, "%s contract\n",
          strcmp(s, "That's brilliant!") == 0 ? "Pass" : "Fail");
  free(s);

  s = strdup("'Twas brillig, and the slithy toves");
  StrReplaceAll(&s, "i", "y");
  fprintf(stdout, "%s replace all\n",
          strcmp(s, "'Twas bryllyg, and the slythy toves") == 0 ?
          "Pass" : "Fail");
  StrReplaceAll(&s, "l", "L");
  fprintf(stdout, "%s replace back-to-back\n",
          strcmp(s, "'Twas bryLLyg, and the sLythy toves") == 0 ?
          "Pass" : "Fail");
  StrReplaceAll(&s, "Ly", "");
  fprintf(stdout, "%s remove\n",
          strcmp(s, "'Twas bryLg, and the sthy toves") == 0 ?
          "Pass" : "Fail");
  StrReplaceAll(&s, "XX", "YY");
  fprintf(stdout, "%s missing\n",
          strcmp(s, "'Twas bryLg, and the sthy toves") == 0 ?
          "Pass" : "Fail");
  StrReplaceAll(&s, "a", "aye");
  fprintf(stdout, "%s missing\n",
          strcmp(s, "'Twayes bryLg, ayend the sthy toves") == 0 ?
          "Pass" : "Fail");
  StrReplaceAll(&s, "'T", "XX");
  fprintf(stdout, "%s head\n",
          strcmp(s, "XXwayes bryLg, ayend the sthy toves") == 0 ?
          "Pass" : "Fail");
  StrReplaceAll(&s, "oves", "YY");
  fprintf(stdout, "%s tail\n",
          strcmp(s, "XXwayes bryLg, ayend the sthy tYY") == 0 ?
          "Pass" : "Fail");
  free(s);

  pieces = StrSplit(UNSPLIT1, NULL);
  for(i = 0;
      pieces[i] != NULL && SPLIT[i] != NULL && strcmp(pieces[i], SPLIT[i]) == 0;
      i++)
    ; /* empty */
  fprintf(stdout, "%s split 1\n",
          pieces[i] == NULL && SPLIT[i] == NULL ? "Pass" : "Fail");
  StrArrayFree(pieces);
  pieces = StrSplit(UNSPLIT2, NULL);
  for(i = 0;
      pieces[i] != NULL && SPLIT[i] != NULL && strcmp(pieces[i], SPLIT[i]) == 0;
      i++)
    ; /* empty */
  fprintf(stdout, "%s split 2\n",
          pieces[i] == NULL && SPLIT[i] == NULL ? "Pass" : "Fail");
  StrArrayFree(pieces);
    
  fprintf(stdout, "%s find 1\n",
          StrArrayFind(SPLIT, "the", NULL) &&
          StrArrayFind(SPLIT, "star", NULL) &&
          StrArrayFind(SPLIT, "ann", NULL) ? "Pass" : "Fail");
  fprintf(stdout, "%s find miss\n",
          !StrArrayFind(SPLIT, "eht", NULL) ? "Pass" : "Fail");
  fprintf(stdout, "%s find 2\n",
          StrArrayFind(SPLIT, "the", &where) && where == 0 &&
          StrArrayFind(SPLIT, "star", &where) && where == 2 &&
          StrArrayFind(SPLIT, "ann", &where) && where == 7 ? "Pass" : "Fail");


  return 0;

}
