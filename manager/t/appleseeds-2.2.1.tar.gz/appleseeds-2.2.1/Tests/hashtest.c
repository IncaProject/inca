/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include <stdio.h>  /* File functions */
#include <stdlib.h> /* free */
#include <string.h> /* memset strcmp strcat strdup strlen */
#include "oshseed.h"
#define ASH_SHORT_NAMES
#include "hashseed.h"


static int keyFreed = 0;


/* A ReclaimFunction that frees the key. */
static void
KeyFree(KeyType key,
        ValueType value) {
  free(key);
  keyFreed = 1;
}

/* A {Key,Value}CompareFunction that tests whether item1 < item2. */
static int
LessThan(void *item1,
         void *item2) {
  return item1 < item2;
}


/* A CompareFunction that tests whether #string# starts with #substring#. */
static int
StartsWith(void *string,
           void *substring) {
  return
    strncmp((char *)string, (char *)substring, strlen((char *)substring)) == 0;
}


int
main(int argc,
     char **argv) {

  const char *numberNames[] = {
    "zero","one","two","three","four","five","six","seven","eight","nine"
  };
  const unsigned long hashSizes[] = {
    1, 13, 517, 2023
  };

  unsigned i;
  HashIterator it;
  unsigned long len;
  HashTable table;
  char key[30] = "";
  void **selected;
  unsigned size;

  for(size = 0; size < 4; size++) {

    table =
      HashTableNew(hashSizes[size], &StringCompare, &StringHash, &KeyFree);
    fprintf(stdout, "%s table allocation [%ld]\n",
            table != NULL ? "Pass" : "Fail", hashSizes[size]);
    fprintf(stdout, "%s bucket count\n",
            GetBucketCount(table) == hashSizes[size] ? "Pass" : "Fail");
    fprintf(stdout, "%s hash function\n",
            GetHashFunction(table) == StringHash ? "Pass" : "Fail");
    fprintf(stdout, "%s initial size\n",
            GetMappingCount(table) == 0 ? "Pass" : "Fail");
    fprintf(stdout, "%s empty key lookup\n",
            GetValue(table, (KeyType)"one", StringCompare) == NULL ?
            "Pass" : "Fail");
    fprintf(stdout, "%s empty value lookup\n",
            GetKey(table, (ValueType)1, NULL) == NULL ? "Pass" : "Fail");
    RemoveMapping(table, (KeyType)"one", &StringCompare);
    fprintf(stdout, "%s empty remove\n",
            GetMappingCount(table) == 0 ? "Pass" : "Fail");
    PutMapping(table, strdup("one"), (ValueType)1);
    fprintf(stdout, "%s unary put\n",
            GetMappingCount(table) == 1 ? "Pass" : "Fail");
    fprintf(stdout, "%s unary key lookup\n",
            GetValue(table, (KeyType)"one", StringCompare) == (ValueType)1 ?
            "Pass" : "Fail");
    fprintf(stdout, "%s unary value lookup\n",
            GetKey(table, (ValueType)1, NULL) != NULL ? "Pass" : "Fail");
    fprintf(stdout, "%s unary key miss\n",
            GetValue(table, (KeyType)"two", StringCompare) == NULL ?
            "Pass" : "Fail");
    fprintf(stdout, "%s unary value miss\n",
            GetKey(table, (ValueType)2, NULL) == NULL ? "Pass" : "Fail");
    keyFreed = 0;
    PutMapping(table, (KeyType)strdup("one"), (ValueType)1);
    fprintf(stdout, "%s unary replacement\n",
            keyFreed && GetMappingCount(table) == 1 ? "Pass" : "Fail");
    RemoveMapping(table, (KeyType)"one", &StringCompare);
    fprintf(stdout, "%s unary remove\n",
            GetMappingCount(table) == 0 ? "Pass" : "Fail");

    for(i = 1; i < 1000; i++) {
      if(i >= 100)
        sprintf(key + strlen(key), "%s hundred ", numberNames[i / 100]);
      if(i % 100 >= 10)
        sprintf(key + strlen(key), "%sty ", numberNames[i % 100 / 10]);
      if(i % 10 != 0)
        strcat(key, numberNames[i % 10]);
      PutMapping(table, strdup(key), (ValueType)i);
      memset(key, 0, sizeof(key));
    }

    fprintf(stdout, "Pass hash efficiency = %f\n", HashEfficiency(table));
    fprintf(stdout, "%s multiple put\n",
            GetMappingCount(table) == 999 ? "Pass" : "Fail");
    fprintf(stdout, "%s multiple key lookup\n",
            GetValue(table, (KeyType)"one hundred two", StringCompare) ==
            (ValueType)102 ? "Pass" : "Fail");
    fprintf(stdout, "%s multiple value lookup\n",
            GetKey(table, (ValueType)957, NULL) != NULL ? "Pass" : "Fail");
    fprintf(stdout, "%s multiple key miss\n",
            GetValue(table, (KeyType)"querty", StringCompare) == NULL ?
            "Pass" : "Fail");
    fprintf(stdout, "%s multiple value miss\n",
            GetKey(table, (ValueType)-2, NULL) == NULL ? "Pass" : "Fail");
    RemoveMapping(table, (KeyType)"one", &StringCompare);
    fprintf(stdout, "%s multiple remove\n",
            GetMappingCount(table) == 998 ? "Pass" : "Fail");

    GetSelectedKeys
      (table, (KeyType)"one hundred", &StartsWith, &selected, &len);
    fprintf(stdout, "%s multiple key selection\n",
            len == 100 ? "Pass" : "Fail");
    free(selected);
    GetSelectedValues(table, (ValueType)100, &LessThan, &selected, &len);
    fprintf(stdout, "%s multiple value selection\n",
            len == 98 ? "Pass" : "Fail");
    free(selected);
    GetSelectedValues(table, (ValueType)100, NULL, &selected, &len);
    fprintf(stdout, "%s single value selection\n", len == 1 ? "Pass" : "Fail");
    free(selected);
    GetAllKeys(table, &selected, &len);
    fprintf(stdout, "%s all key selection\n", len == 998 ? "Pass" : "Fail");
    free(selected);
    i = 0;
    ForEachMapping(table, it)
      i++;
    fprintf(stdout, "%s ForEachMapping\n", i == 998 ? "Pass" : "Fail");
    RemoveAllMappings(table);
    fprintf(stdout, "%s remove all\n",
            GetMappingCount(table) == 0 ? "Pass" : "Fail");
    HashTableFree(table);

  }

  return 0;

}
