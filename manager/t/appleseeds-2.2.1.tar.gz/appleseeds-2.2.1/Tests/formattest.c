/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <limits.h> /* UINT_MAX */
#include <stddef.h> /* offsetof */
#include <stdio.h>  /* file functions */
#include <string.h> /* memcmp memset */
#define ASFMT_SHORT_NAMES
#include "formatseed.h"


typedef struct {
  char *label;
  DataDescriptor descriptor;
  void *host;
  unsigned hostSize;
  char *network;
  unsigned networkSize;
  int onePad;
} TestStruct;


typedef struct {
  double a;
  char b;
  double c;
  char d;
  double e;
} DataStruct;
static DataStruct testStruct;
static DataDescriptor dataStructDescriptor[] = {
  SIMPLE_MEMBER(DOUBLE_TYPE, 1, offsetof(DataStruct, a)),
  SIMPLE_MEMBER(CHAR_TYPE, 1, offsetof(DataStruct, b)),
  SIMPLE_MEMBER(DOUBLE_TYPE, 1, offsetof(DataStruct, c)),
  SIMPLE_MEMBER(CHAR_TYPE, 1, offsetof(DataStruct, d)),
  SIMPLE_MEMBER(DOUBLE_TYPE, 1, offsetof(DataStruct, e))
};


#define FF "\377"
static char *allOnes = FF FF FF FF FF FF FF FF;
static char *allZeros = "\0\0\0\0\0\0\0\0";
static double doubles[] = {-2.5};
static float floats[] = {(float)-2.5};
static int ints[] = {0x01020304, 0x05060708, 0x090A0B0C, 0x0D0E0F10};
static long longs[] = {0x01020304};
static short shorts[] = {0x0102};
static int signedInts[] = {-255};
static long signedLongs[] = {-255};
static short signedShorts[] = {-255};
static unsigned unsignedInts[] = {UINT_MAX};
static unsigned long unsignedLongs[] = {ULONG_MAX};
static unsigned short unsignedShorts[] = {USHRT_MAX};


int
main(int argc,
     char **argv) {

  TestStruct tests[] = {
    {"char", SIMPLE_DATA(CHAR_TYPE, 1), (char *)"\44", 1, "\44", 1, 0},
    {"double", SIMPLE_DATA(DOUBLE_TYPE, 1),
      doubles, sizeof(double), "\300\4\0\0\0\0\0\0", 8, 0},
    {"float", SIMPLE_DATA(FLOAT_TYPE, 1),
      floats, sizeof(float), "\300\40\0\0", 4, 0},
    {"int", SIMPLE_DATA(INT_TYPE, 1), ints, sizeof(int), "\1\2\3\4", 4, 0},
    {"signed int", SIMPLE_DATA(INT_TYPE, 1),
     signedInts, sizeof(int), FF FF FF "\1", 4, 1},
    {"unsigned int", SIMPLE_DATA(UNSIGNED_INT_TYPE, 1),
     unsignedInts, sizeof(unsigned int), FF FF FF FF, 4, 0},
    {"long", SIMPLE_DATA(LONG_TYPE, 1), longs, sizeof(long), "\1\2\3\4", 4},
    {"signed long", SIMPLE_DATA(LONG_TYPE, 1),
     signedLongs, sizeof(long), FF FF FF "\1", 4, 1},
    {"unsigned long", SIMPLE_DATA(UNSIGNED_LONG_TYPE, 1),
     unsignedLongs, sizeof(unsigned long), FF FF FF FF, 4, 0},
    {"short", SIMPLE_DATA(SHORT_TYPE, 1), shorts, sizeof(short), "\1\2", 2},
    {"signed short", SIMPLE_DATA(SHORT_TYPE, 1),
     signedShorts, sizeof(short), FF "\1", 2, 1},
    {"unsigned short", SIMPLE_DATA(UNSIGNED_SHORT_TYPE, 1),
     unsignedShorts, sizeof(unsigned short), FF FF, 2, 0},
    {"array", SIMPLE_DATA(INT_TYPE, 4), ints, sizeof(ints),
     "\1\2\3\4\5\6\7\10\11\12\13\14\15\16\17\20", 16, 0},
    {"struct", {STRUCT_TYPE, 1, 0, dataStructDescriptor, 5,
                PAD_BYTES(DataStruct, e, double, 1)},
     &testStruct, sizeof(testStruct),
     "\077\360\0\0\0\0\0\0" "A"
     "\300\0\0\0\0\0\0\0" "B"
     "\100\010\0\0\0\0\0\0", 26, 0}
  };

  char converted[1024 + 1];
  int pass;
  int sizeChange;
  TestStruct *test;

  memset(&testStruct, 0, sizeof(testStruct));
  testStruct.a = 1.0;
  testStruct.b = 'A';
  testStruct.c = -2.0;
  testStruct.d = 'B';
  testStruct.e = 3.0;

  for(test = tests;
      test - tests < (int)(sizeof(tests) / sizeof(tests[0]));
      test++) {

    sizeChange = (test->descriptor.type == STRUCT_TYPE ||
                  test->descriptor.type == DOUBLE_TYPE ||
                  test->descriptor.type == FLOAT_TYPE ||
                  test->descriptor.repetitions > 1) ?
                 0 : (test->networkSize - test->hostSize);

    memset(converted, 0, sizeof(converted));
    ConvertData(converted, test->host, &test->descriptor, 1, 1);
    pass = converted[test->networkSize] == 0 &&
           ((sizeChange <= 0) ?
            (memcmp(converted, test->network, test->networkSize) == 0) :
            (memcmp(converted + sizeChange,
                    (char *)test->network + sizeChange,
                    test->hostSize) == 0 &&
             memcmp(converted,
                    test->onePad ? allOnes : allZeros,
                    sizeChange) == 0));
    fprintf(stdout, "%s %s h->n\n", pass ? "Pass" : "Fail", test->label);

    memset(converted, 0, sizeof(converted));
    ConvertData(converted, test->network, &test->descriptor, 1, 0);
    pass = converted[test->hostSize] == 0 &&
           ((sizeChange >= 0) ?
            (memcmp(converted, test->host, test->hostSize) == 0) :
            DifferentOrder() ?
            (memcmp(converted, test->host, test->networkSize) == 0 &&
             memcmp(converted + test->networkSize,
                    test->onePad ? allOnes : allZeros,
                    -sizeChange) == 0) :
            (memcmp(converted - sizeChange,
                    (char *)test->host - sizeChange,
                    test->networkSize) == 0 &&
             memcmp(converted,
                    test->onePad ? allOnes : allZeros,
                    -sizeChange) == 0));
    fprintf(stdout, "%s %s n->h\n", pass ? "Pass" : "Fail", test->label);

  }

  return 0;

}
