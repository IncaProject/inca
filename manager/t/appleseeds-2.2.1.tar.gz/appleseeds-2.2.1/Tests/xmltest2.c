/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdio.h> /* file functions */
#include <string.h> /* strcmp */
#define ASXML_SHORT_NAMES
#include "xmlseed.h"


#define CONDITIONAL_VALUE "include this"
#define SIMPLE_VALUE "this is text"
#define DTD \
  "<!ENTITY text '" SIMPLE_VALUE "'>" \
  "<!ENTITY and '&amp;'>" \
  "<!ENTITY t2 '&amp;&text;&lt;'>" \
  "<!ENTITY text 'this should be ignored'>" \
  "<!NOTATION jpeg SYSTEM 'image/jpeg'>" \
  "<!NOTATION gif PUBLIC 'image/gif'>" \
  "<!NOTATION tiff PUBLIC 'image/tiff' 'image/fitt'>" \
  "<![ IGNORE [<!ENTITY cond 'ignore this'> ]]>" \
  "<![ INCLUDE [<!ENTITY cond '" CONDITIONAL_VALUE "'> ]]>" \
  "<!ATTLIST level3 a CDATA #IMPLIED>" \
  "<!ATTLIST level4 a ID #REQUIRED" \
  "                 b IDREF 'whizzo'" \
  "                 c (moe | larry | curly) #FIXED 'moe'" \
  "                 d NOTATION ( x ) 'x' " \
  ">" \
  "<!ELEMENT level3 ANY>" \
  "<!ELEMENT level4 EMPTY>" \
  "<!ELEMENT level5 (#PCDATA)*>" \
  "<!ELEMENT level6 (#PCDATA | level7)*>" \
  "<!ELEMENT level7 (#PCDATA | level7|level8)*>" \
  "<!ELEMENT level8 (level9 | level10)>" \
  "<!ELEMENT level9 (level10)>" \
  "<!ELEMENT level10 (level11 , level12)>" \
  "<!ELEMENT level11 (level12 , level13,level14)>" \
  "<!ELEMENT level12 ((level13)*, (level14,level15)?)+>" \
  "<!ELEMENT level13 ((level14|level15)| (level15,level16)?)+>"


int
main(int argc,
     char **argv) {

  char *internal =
    "<?xml version=\"1.0\"?>"
    "<!DOCTYPE dtd [" DTD "]>"
    "<level1>"
      "&text;"
      "<level2/>"
      "&amp;"
      "<level2/>"
      "&amp;amp;"
      "<level2/>"
      "&and;"
      "<level2/>"
      "&t2;"
      "<level2/>"
      "&cond;"
    "</level1>";

  XmlDocument doc;
  XmlNode n;

  doc = XmlFromString(internal, NULL, 0, 0, NULL, NULL, NULL);
  fprintf(stdout, "%s basic document\n", doc != NULL ? "Pass" : "Fail");
  n = DocumentDoctype(doc);
  fprintf(stdout, "%s DTD recognition\n", n != NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s DTD name\n",
          strcmp(DocumentTypeName(n), "dtd") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s DTD internal subset\n",
          strcmp(DocumentTypeInternalSubset(n), DTD) == 0 ? "Pass" : "Fail");
  n = NamedNodeMapItem(DocumentTypeEntities(DocumentDoctype(doc)), 0);
  fprintf(stdout, "%s DTD entities\n", n != NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s entity name\n",
          strcmp(NodeName(n), "text") == 0 ? "Pass" : "Fail");
  n = NodeFirstChild(DocumentElement(doc));
  fprintf(stdout, "%s entity substituion\n",
          strcmp(NodeValue(n), SIMPLE_VALUE) == 0 ? "Pass" : "Fail");
  n = NodeNextSiblingByType(n, SHOW_TEXT);
  fprintf(stdout, "%s predefined entity substituion\n",
          strcmp(NodeValue(n), "&") == 0 ? "Pass" : "Fail");
  n = NodeNextSiblingByType(n, SHOW_TEXT);
  fprintf(stdout, "%s embedded entity substituion\n",
          strcmp(NodeValue(n), "&amp;") == 0 ? "Pass" : "Fail");
  n = NodeNextSiblingByType(n, SHOW_TEXT);
  fprintf(stdout, "%s nested entity substituion\n",
          strcmp(NodeValue(n), "&") == 0 ? "Pass" : "Fail");
  n = NodeNextSiblingByType(n, SHOW_TEXT);
  fprintf(stdout, "%s more nested entity substituion\n",
          strcmp(NodeValue(n), "&" SIMPLE_VALUE "<") == 0 ? "Pass" : "Fail");
  n = NodeNextSiblingByType(n, SHOW_TEXT);
  fprintf(stdout, "%s conditional inclusion\n",
          strcmp(NodeValue(n), CONDITIONAL_VALUE) == 0 ? "Pass" : "Fail");
  n = NamedNodeMapItem(DocumentTypeNotations(DocumentDoctype(doc)), 0);
  fprintf(stdout, "%s DTD notations\n", n != NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s notation name\n",
          strcmp(NodeName(n), "jpeg") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s notation system id\n",
          NotationPublicId(n) == NULL &&
          strcmp(NotationSystemId(n), "image/jpeg") == 0 ? "Pass" : "Fail");
  n = NamedNodeMapItem(DocumentTypeNotations(DocumentDoctype(doc)), 1);
  fprintf(stdout, "%s notation public id\n",
          strcmp(NotationPublicId(n), "image/gif") == 0 &&
          NotationSystemId(n) == NULL ? "Pass" : "Fail");
  n = NamedNodeMapItem(DocumentTypeNotations(DocumentDoctype(doc)), 2);
  fprintf(stdout, "%s notation both id\n",
          strcmp(NotationPublicId(n), "image/tiff") == 0 &&
          strcmp(NotationSystemId(n), "image/fitt") == 0 ? "Pass" : "Fail");
  NodeFree(doc);

  return 0;

}
