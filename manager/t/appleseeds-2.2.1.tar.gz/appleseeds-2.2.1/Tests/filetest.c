/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdio.h>  /* file functions */
#include <stdlib.h> /* free getenv */
#include <string.h> /* strcmp */
#include "strseed.h"
#define ASFILE_SHORT_NAMES
#include "fileseed.h"

#define FSEP ASOSH_FILE_PATH_SEPARATOR
#define LSEP ASOSH_PATH_LIST_SEPARATOR
#ifdef WIN32
#  define SYSFILE "fc.exe"
#else
#  define SYSFILE "ls"
#endif

static unsigned
CountNonNull(char **dc) {
  unsigned result;
  for(result = 0; dc[result] != NULL; result++)
    ; /* empty */
  return result;
}


int
main(int argc,
     char **argv) {

  char c;
  char *content;
  unsigned count;
  char **dc;
  unsigned i;
  FILE *f;
  FileFacts facts;
  char filePath[128];
  char *foundPath;
  char *uniquePath;
  const char *CONTENTS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                         "abcdefghijklmnopqrstuvwxyz";
  const char *PATH = getenv("PATH");
  const char *DIRTY[] = {
    ".",
    "..",
    FSEP FSEP,
    "foo" FSEP "..",
    "foo" FSEP ".." FSEP "bar",
    "." FSEP "." FSEP "." FSEP ".",
    "a" FSEP "b" FSEP "c" FSEP FSEP "d" FSEP ".." FSEP ".." FSEP ".." FSEP "e",
    NULL
  };
  const char *CLEAN[] = {
    ".",
    "..",
    FSEP,
    ".",
    "bar",
    ".",
    "a" FSEP "e",
    NULL
  };

  for(c = 'a'; c <= 'z'; c++) {
    sprintf(filePath, "asftest.%c11", c);
    f = fopen(filePath, "w");
    fwrite(CONTENTS, sizeof(char), strlen(CONTENTS), f);
    fclose(f);
  }

  dc = DirectoryContents("/UnLiKeLy", NULL);
  fprintf(stdout, "%s missing directory \n", dc == NULL ? "Pass" : "Fail");
  dc = DirectoryContents(".", NULL);
  count = CountNonNull(dc);
  fprintf(stdout, "%s NULL directory pattern\n", count >= 26 ? "Pass" : "Fail");
  ASSTR_StrArrayFree(dc);
  dc = DirectoryContents(".", "*");
  fprintf(stdout, "%s * directory pattern\n",
          CountNonNull(dc) == count ? "Pass" : "Fail");
  ASSTR_StrArrayFree(dc);
  dc = DirectoryContents(".", "asftest.?11");
  fprintf(stdout, "%s ? directory subpattern\n",
          CountNonNull(dc) == 26 ? "Pass" : "Fail");
  ASSTR_StrArrayFree(dc);
  dc = DirectoryContents(".", "asftest.*");
  fprintf(stdout, "%s * directory subpattern 1\n",
          CountNonNull(dc) == 26 ? "Pass" : "Fail");
  ASSTR_StrArrayFree(dc);
  dc = DirectoryContents(".", "as*1");
  fprintf(stdout, "%s * directory subpattern 2\n",
          CountNonNull(dc) == 26 ? "Pass" : "Fail");
  ASSTR_StrArrayFree(dc);

  content = FileContents(filePath);
  fprintf(stdout, "%s file contents\n",
          strcmp(content, CONTENTS) == 0 ? "Pass" : "Fail");
  free(content);

  foundPath = FindFile(PATH, "UnLiKeLy");
  fprintf(stdout, "%s locate missing file\n",
          foundPath == NULL ? "Pass" : "Fail");
  if(foundPath != NULL)
    free(foundPath);
  foundPath = FindFile(PATH, SYSFILE);
  fprintf(stdout, "%s locate existing file\n",
          foundPath != NULL ? "Pass" : "Fail");
  if(foundPath != NULL)
    free(foundPath);
  foundPath = FindFile(PATH, "UnLiKeLy" LSEP SYSFILE);
  fprintf(stdout, "%s locate file choice 1\n",
          foundPath != NULL ? "Pass" : "Fail");
  if(foundPath != NULL)
    free(foundPath);
  foundPath = FindFile(PATH, SYSFILE LSEP "UnLiKeLy");
  fprintf(stdout, "%s locate file choice 2\n",
          foundPath != NULL ? "Pass" : "Fail");
  if(foundPath != NULL)
    free(foundPath);
  foundPath = FindFile(PATH, "UnLi" LSEP "KeLy");
  fprintf(stdout, "%s locate file choice 3\n",
          foundPath == NULL ? "Pass" : "Fail");
  if(foundPath != NULL)
    free(foundPath);

  fprintf(stdout, "%s file facts\n",
          GetFileFacts(filePath, &facts) &&
          !facts.isADirectory && !facts.isALink && !facts.isHidden &&
          facts.size == strlen(CONTENTS) ?
          "Pass" : "Fail");

  SetFilePermission("asftest.a11", AS_OWNER, 0, 0, 0);
  sleep(2); /* Needed by BSD */
  fprintf(stdout, "%s file up protect\n",
          (f = fopen("asftest.a11", "r")) == NULL ? "Pass" : "Fail");
  SetFilePermission("asftest.a11", AS_OWNER, 1, 1, 0);
  sleep(2); /* Needed by BSD */
  fprintf(stdout, "%s file down protect\n",
          (f = fopen("asftest.a11", "r")) != NULL ? "Pass" : "Fail");
  if(f != NULL)
    fclose(f);

  for(i = 0; DIRTY[i] != NULL; i++) {
    strcpy(filePath, DIRTY[i]);
    fprintf(stdout, "%s min path %d\n",
            strcmp(MinimizeFilePath(filePath), CLEAN[i]) == 0 ? "Pass" : "Fail",
            i);
  }

  uniquePath = UniqueFilePath(NULL);
  fprintf(stdout, "%s unique path 1\n",
          (f = fopen(uniquePath, "w")) != NULL ? "Pass" : "Fail");
  if(f != NULL) {
    fclose(f);
    unlink(uniquePath);
  }
  free(uniquePath);
  uniquePath = UniqueFilePath("goober");
  fprintf(stdout, "%s unique path 2\n",
          strncmp(uniquePath, "goober", 6) == 0 &&
          (f = fopen(uniquePath, "w")) != NULL ? "Pass" : "Fail");
  if(f != NULL) {
    fclose(f);
    unlink(uniquePath);
  }
  free(uniquePath);

  for(c = 'a'; c <= 'z'; c++) {
    sprintf(filePath, "asftest.%c11", c);
    unlink(filePath);
  }

  return 0;

}
