/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdio.h>  /* file functions */
#include <string.h> /* string functions */
#define ASDIAG_SHORT_NAMES
#include "diagnosticseed.h"


static DiagnosticState ds;


static int
FailFunc(void) {
  FAIL(ds, "Test of fail\n");
  return 1;
}


int
main(int argc,
     char **argv) {

  const int MY_MESSAGE_TYPE = 42;
  const char *TEST_MESSAGE = "Test message\n";
  char buffer[1024 + 1] = "";
  char filename[128 + 1];
  FILE *diagnostics;
  int diagnosticsFileno;
  int pos;
  int realStderr;
  int realStdout;
  char shouldBe[1024 + 1] = "";

  sprintf(filename, "asd%d.tmp", (int)getpid());
  if((diagnostics = fopen(filename, "w+")) == NULL) {
    fprintf(stdout, "Fatal: Unable to open diagnostic file\n");
    return 1;
  }
  diagnosticsFileno = fileno(diagnostics);
  ds = DiagnosticStateNew();

  if(0) {
    ABORT(ds,"");
    ABORT1(ds, "", "");
    ABORT2(ds, "", "", "");
    ABORT3(ds, "", "", "", "");
    ABORT4(ds, "", "", "", "", "");
    ABORT5(ds, "", "", "", "", "", "");
    DEBUG(ds, "");
    DEBUG1(ds, "", "");
    DEBUG2(ds, "", "", "");
    DEBUG3(ds, "", "", "", "");
    DEBUG4(ds, "", "", "", "", "");
    DEBUG5(ds, "", "", "", "", "", "");
    ERROR(ds, "");
    ERROR1(ds, "", "");
    ERROR2(ds, "", "", "");
    ERROR3(ds, "", "", "", "");
    ERROR4(ds, "", "", "", "", "");
    ERROR5(ds, "", "", "", "", "", "");
    FAIL(ds, "");
    FAIL1(ds, "", "");
    FAIL2(ds, "", "", "");
    FAIL3(ds, "", "", "", "");
    FAIL4(ds, "", "", "", "", "");
    FAIL5(ds, "", "", "", "", "", "");
    INFO(ds, "");
    INFO1(ds, "", "");
    INFO2(ds, "", "", "");
    INFO3(ds, "", "", "", "");
    INFO4(ds, "", "", "", "", "");
    INFO5(ds, "", "", "", "", "", "");
    LOG(ds, "");
    LOG1(ds, "", "");
    LOG2(ds, "", "", "");
    LOG3(ds, "", "", "", "");
    LOG4(ds, "", "", "", "", "");
    LOG5(ds, "", "", "", "", "", "");
    WARN(ds, "");
    WARN1(ds, "", "");
    WARN2(ds, "", "", "");
    WARN3(ds, "", "", "", "");
    WARN4(ds, "", "", "", "", "");
    WARN5(ds, "", "", "", "", "", "");
  }

  fprintf(stdout, "%s FAIL macro\n", !FailFunc() ? "Pass" : "Fail");

  fprintf(stdout, "%s default direction\n",
          (DiagnosticsDirection(ds, DEBUG_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, ERROR_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, FATAL_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, LOG_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, INFO_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, WARNING_MESSAGE) == SUPPRESS) ?
          "Pass" : "Fail");

  realStderr = dup(fileno(stdout));
  realStdout = dup(fileno(stdout));
  dup2(diagnosticsFileno, fileno(stdout));
  dup2(diagnosticsFileno, fileno(stdout));
  Diagnostic(ds, DEBUG_MESSAGE, TEST_MESSAGE);
  Diagnostic(ds, ERROR_MESSAGE, TEST_MESSAGE);
  Diagnostic(ds, FATAL_MESSAGE, TEST_MESSAGE);
  Diagnostic(ds, LOG_MESSAGE, TEST_MESSAGE);
  Diagnostic(ds, INFO_MESSAGE, TEST_MESSAGE);
  Diagnostic(ds, WARNING_MESSAGE, TEST_MESSAGE);
  dup2(realStderr, fileno(stdout));
  dup2(realStdout, fileno(stdout));
  close(realStderr);
  close(realStdout);
  fprintf(stdout, "%s suppress write\n",
          (lseek(diagnosticsFileno, 0, SEEK_CUR) == 0) ? "Pass" : "Fail");

  DirectDiagnostics(ds, ERROR_MESSAGE, diagnosticsFileno);
  DirectDiagnostics(ds, MY_MESSAGE_TYPE, diagnosticsFileno);
  fprintf(stdout, "%s redirection\n",
          (DiagnosticsDirection(ds, DEBUG_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, ERROR_MESSAGE) == diagnosticsFileno &&
           DiagnosticsDirection(ds, FATAL_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, LOG_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, INFO_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, WARNING_MESSAGE) == SUPPRESS &&
           DiagnosticsDirection(ds, MY_MESSAGE_TYPE) == diagnosticsFileno) ?
          "Pass" : "Fail");

  pos = (int)lseek(diagnosticsFileno, 0, SEEK_CUR);
  Diagnostic(ds, MY_MESSAGE_TYPE, "%s", TEST_MESSAGE);
  lseek(diagnosticsFileno, pos, SEEK_SET);
  fprintf(stdout, "%s write\n",
          (fgets(buffer, sizeof(buffer), diagnostics) != NULL &&
           strcmp(buffer, TEST_MESSAGE) == 0) ? "Pass" : "Fail");
  lseek(diagnosticsFileno, 0, SEEK_END);

  memset(buffer, 'a', sizeof(buffer));
  buffer[sizeof(buffer) - 1] = '\0';
  pos = (int)lseek(diagnosticsFileno, 0, SEEK_CUR);
  Diagnostic
    (ds, MY_MESSAGE_TYPE, "%s%s%s%s%s", buffer,buffer,buffer,buffer,buffer);
  fflush(diagnostics);
  fprintf(stdout, "%s long message\n",
          (int)lseek(diagnosticsFileno, 0, SEEK_CUR) ==
          (int)(pos + 5 * strlen(buffer)) ?
          "Pass" : "Fail");

  pos = (int)lseek(diagnosticsFileno, 0, SEEK_CUR);
  /* Note: the following ERROR and sprintf must be on the same line. */
  ERROR1(ds, "%s", TEST_MESSAGE); sprintf(shouldBe, "%s %d: %s", __FILE__, __LINE__, TEST_MESSAGE);
  lseek(diagnosticsFileno, pos, SEEK_SET);
  fprintf(stdout, "%s positioned write\n",
          (fgets(buffer, sizeof(buffer), diagnostics) != NULL &&
           strcmp(buffer, shouldBe) == 0) ? "Pass" : "Fail");
  lseek(diagnosticsFileno, 0, SEEK_END);

  fclose(diagnostics);
  unlink(filename);
  DiagnosticStateFree(ds);

  return 0;

}
