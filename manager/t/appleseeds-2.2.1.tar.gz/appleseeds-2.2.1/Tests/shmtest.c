/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <errno.h>
#include <stdio.h> /* file functions */
#include "execseed.h"
#define ASSHM_SHORT_NAMES
#include "shmseed.h"


enum {STDIN_FD = 0, STDOUT_FD = 1, STDERR_FD = 2};
enum {PIPE_READ = 0, PIPE_WRITE = 1};


#define HEAP_OFFSET 1024
#define HEAP_SIZE   (1024 * 6)
#define LOCK_OFFSET (1024 * 4)
#define MEMORY_SIZE (1024 * 10)
#define TEST_CHAR 42
#define TEST_DOUBLE -12345.678
#define TEST_INT 1234


static unsigned offset = 0;
static SharedMemory shared = NULL;
static char *who = "parent";


static int
ReadOffset(int fd,
           int sync) {
  int n;
  if((n = read(fd, &offset, sizeof(offset))) == sizeof(offset))
    return 1;
  fprintf(stdout, "%s: fail read #%d; returned %d(%d)\n", who, sync, n, errno);
  if(shared != NULL)
    CloseMemory(shared);
  return 0;
}


static int
WriteOffset(int fd,
            int sync) {
  int n;
  if((n = write(fd, &offset, sizeof(offset))) == sizeof(offset))
    return 1;
  fprintf(stdout, "%s: fail write %d; returned %d(%d)\n", who, sync, n, errno);
  if(shared != NULL)
    CloseMemory(shared);
  return 0;
}


int
main(int argc,
     char **argv) {

  void *allocated1;
  void *allocated2;
  char *args[3] = {NULL, NULL, NULL};
  char *base;
  int childToParent[2];
  SharedHeap heap;
  char memName[30];
  int parentToChild[2];
  int result;
  int savedStdin;
  int savedStderr;

  if(argc == 1) {

    sprintf(memName, "%d", (int)getpid());
    shared = OpenMemory(memName, 0);
    fprintf(stdout, "%s open missing memory\n",
            shared == NULL ? "Pass" : "Fail");
    if(shared != NULL)
      CloseMemory(shared);
    shared = OpenMemory(memName, MEMORY_SIZE);
    fprintf(stdout, "%s create new memory\n",
            shared != NULL ? "Pass" : "Fail");
    if(shared == NULL) {
      fprintf(stdout, "Unable to create memory: abort\n");
      return 1;
    }
    CloseMemory(shared);
    shared = OpenMemory(memName, 0);
    fprintf(stdout, "%s open deleted memory\n",
            shared == NULL ? "Pass" : "Fail");
    if(shared != NULL)
      CloseMemory(shared);
    shared = NULL;

    /* Spawn a process to test locking and read/write. */
    pipe(childToParent);
    pipe(parentToChild);
    args[0] = argv[0];
    args[1] = memName;
    savedStdin = dup(STDIN_FD);
    savedStderr = dup(STDERR_FD);
    dup2(parentToChild[PIPE_READ], STDIN_FD);
    dup2(childToParent[PIPE_WRITE], STDERR_FD);
    result = ASEXEC_ProcessStart(argv[0], (const char **)args, NULL);
    dup2(savedStdin, STDIN_FD);
    dup2(savedStderr, STDERR_FD);
    close(savedStdin);
    close(savedStderr);
    if(!result) {
      fprintf(stdout, "Spawn failed: abort\n");
      return 1;
    }
    close(childToParent[PIPE_WRITE]);
    close(parentToChild[PIPE_READ]);

    if(!ReadOffset(childToParent[PIPE_READ], 1))     /* Sync 1 */
      return 1;
    shared = OpenMemory(memName, MEMORY_SIZE);
    fprintf(stdout, "%s create existing memory\n",
            shared == NULL ? "Pass" : "Fail");
    if(shared != NULL)
      CloseMemory(shared);
    shared = OpenMemory(memName, 0);
    fprintf(stdout, "%s open existing memory\n",
            shared != NULL ? "Pass" : "Fail");
    if(shared != NULL)
      CloseMemory(shared);

    if(!WriteOffset(parentToChild[PIPE_WRITE], 2) || /* Sync 2 */
       !ReadOffset(childToParent[PIPE_READ], 3))     /* Sync 3 */
      return 1;
    shared = OpenMemory(memName, 0);
    fprintf(stdout, "%s open protected memory\n",
            shared == NULL ? "Pass" : "Fail");
    if(shared != NULL)
      CloseMemory(shared);

    if(!WriteOffset(parentToChild[PIPE_WRITE], 4) || /* Sync 4 */
       !ReadOffset(childToParent[PIPE_READ], 5))     /* Sync 5 */
      return 1;
    if((shared = OpenMemory(memName, 0)) == NULL) {
      fprintf(stdout, "Unable to reopen memory: abort\n");
      return 1;
    }

    fprintf(stdout, "%s write after write lock\n",
            !LockMemory(shared, LOCK_OFFSET, AS_READ_WRITE_LOCK, 0) ?
            "Pass" : "Fail");
    fprintf(stdout, "%s read after write lock\n",
            !LockMemory(shared, LOCK_OFFSET, AS_READ_LOCK, 0) ?
            "Pass" : "Fail");
    fprintf(stdout, "%s second lock\n",
            LockMemory(shared, LOCK_OFFSET + 1, AS_READ_WRITE_LOCK, 0) ?
            "Pass" : "Fail");
    UnlockMemory(shared, LOCK_OFFSET);
    UnlockMemory(shared, LOCK_OFFSET + 1);

    if(!WriteOffset(parentToChild[PIPE_WRITE], 6)) /* Sync 6 */
      return 1;
    fprintf(stdout, "%s blocking lock\n",
            LockMemory(shared, LOCK_OFFSET, AS_READ_WRITE_LOCK, 0) ? "Fail1" :
            !LockMemory(shared, LOCK_OFFSET, AS_READ_WRITE_LOCK, 1) ?
            "Fail2" : "Pass");
    UnlockMemory(shared, LOCK_OFFSET);
    fprintf(stdout, "%s unlock\n",
            LockMemory(shared, LOCK_OFFSET, AS_READ_WRITE_LOCK, 0) ?
            "Pass" : "Fail");
    UnlockMemory(shared, LOCK_OFFSET);
    if(!WriteOffset(parentToChild[PIPE_WRITE], 7) || /* Sync 7 */
       !ReadOffset(childToParent[PIPE_READ], 8))     /* Sync 8 */
      return 1;

    fprintf(stdout, "%s shared lock\n",
            LockMemory(shared, LOCK_OFFSET, AS_READ_LOCK, 0) ?
            "Pass" : "Fail");
    UnlockMemory(shared, LOCK_OFFSET);
    fprintf(stdout, "%s write after read lock\n",
            !LockMemory(shared, LOCK_OFFSET, AS_READ_WRITE_LOCK, 0) ?
            "Pass" : "Fail");
    UnlockMemory(shared, LOCK_OFFSET);
    if(!WriteOffset(parentToChild[PIPE_WRITE], 9)) /* Sync 9 */
      return 1;

    heap = OpenHeap(shared, HEAP_OFFSET, 0);
    base = (char *)GetBase(shared);
    if(!ReadOffset(childToParent[PIPE_READ], 10)) /* Sync 10 */
      return 1;
    allocated1 = base + offset;
    fprintf(stdout, "%s first allocate\n",
            (*((int *)allocated1) == TEST_INT) ? "Pass" : "Fail");
    if(!WriteOffset(parentToChild[PIPE_WRITE], 11) || /* Sync 11 */
       !ReadOffset(childToParent[PIPE_READ], 12))     /* Sync 12 */
      return 1;

    allocated2 = base + offset;
    fprintf(stdout, "%s second allocate\n",
            (*((double *)allocated2) == TEST_DOUBLE) ? "Pass" : "Fail");
    if(!WriteOffset(parentToChild[PIPE_WRITE], 13) || /* Sync 13 */
       !ReadOffset(childToParent[PIPE_READ], 14))     /* Sync 14 */
      return 1;

    allocated1 = base + offset;
    fprintf(stdout, "%s allocate after free\n",
            (*((int *)allocated1) == -1 * TEST_INT) ? "Pass" : "Fail");
    if(!WriteOffset(parentToChild[PIPE_WRITE], 15) || /* Sync 15 */
       !ReadOffset(childToParent[PIPE_READ], 16))     /* Sync 16 */
      return 1;

    allocated1 = base + offset;
    fprintf(stdout, "%s reallocate smaller\n",
            (*((char *)allocated1) == TEST_CHAR) ? "Pass" : "Fail");
    if(!WriteOffset(parentToChild[PIPE_WRITE], 17) || /* Sync 17 */
       !ReadOffset(childToParent[PIPE_READ], 18))     /* Sync 18 */
      return 1;

    allocated1 = base + offset;
    fprintf(stdout, "%s reallocate larger\n",
            (*((double *)allocated1) == -1 * TEST_DOUBLE) ? "Pass" : "Fail");

    CloseMemory(shared);

  }
  else {

    who = "child";
    if((shared = OpenMemory(argv[1], MEMORY_SIZE)) == NULL) {
      fprintf(stdout, "%s: Unable to create memory\n", who);
      return 1;
    }
    if(!WriteOffset(STDERR_FD, 1) || /* Sync 1 */
       !ReadOffset(STDIN_FD, 2))     /* Sync 2 */
      return 1;
    SetMemoryPermission(shared, AS_OWNER, 0, 0);

    if(!WriteOffset(STDERR_FD, 3) || /* Sync 3 */
       !ReadOffset(STDIN_FD, 4))     /* Sync 4 */
      return 1;
    SetMemoryPermission(shared, AS_OWNER, 1, 1);
    if(!LockMemory(shared, LOCK_OFFSET, AS_READ_WRITE_LOCK, 0)) {
      fprintf(stdout, "%s: Unable to lock memory\n", who);
      return 1;
    }

    if(!WriteOffset(STDERR_FD, 5) || /* Sync 5 */
       !ReadOffset(STDIN_FD, 6))     /* Sync 6 */
      return 1;
    sleep(2);
    UnlockMemory(shared, LOCK_OFFSET);

    if(!ReadOffset(STDIN_FD, 7))     /* Sync 7 */
      return 1;

    LockMemory(shared, LOCK_OFFSET, AS_READ_LOCK, 0);
    if(!WriteOffset(STDERR_FD, 8) || /* Sync 8 */
       !ReadOffset(STDIN_FD, 9))     /* Sync 9 */
      return 1;
    UnlockMemory(shared, LOCK_OFFSET);

    heap = OpenHeap(shared, HEAP_OFFSET, HEAP_SIZE);
    base = (char *)GetBase(shared);
    allocated1 = AllocateInHeap(heap, 10 * sizeof(int));
    *((int *)allocated1) = TEST_INT;
    offset = (char *)allocated1 - base;
    if(!WriteOffset(STDERR_FD, 10) || /* Sync 10 */
       !ReadOffset(STDIN_FD, 11))     /* Sync 11 */
      return 1;

    allocated2 = AllocateInHeap(heap, 10 * sizeof(double));
    *((double *)allocated2) = TEST_DOUBLE;
    offset = (char *)allocated2 - base;
    if(!WriteOffset(STDERR_FD, 12) || /* Sync 12 */
       !ReadOffset(STDIN_FD, 13))     /* Sync 13 */
      return 1;

    FreeInHeap(heap, allocated1);
    allocated1 = AllocateInHeap(heap, 10 * sizeof(int));
    *((int *)allocated1) = -1 * TEST_INT;
    offset = (char *)allocated1 - base;
    if(!WriteOffset(STDERR_FD, 14) || /* Sync 14 */
       !ReadOffset(STDIN_FD, 15))     /* Sync 15 */
      return 1;

    allocated1 = ReallocateInHeap(heap, allocated1, 10 * sizeof(char));
    *((char *)allocated1) = TEST_CHAR;
    offset = (char *)allocated1 - base;
    if(!WriteOffset(STDERR_FD, 16) || /* Sync 16 */
       !ReadOffset(STDIN_FD, 17))     /* Sync 17 */
      return 1;

    allocated1 = ReallocateInHeap(heap, allocated1, 10 * sizeof(double));
    *((double *)allocated1) = -1 * TEST_DOUBLE;
    offset = (char *)allocated1 - base;
    if(!WriteOffset(STDERR_FD, 19))
      return 1;

    CloseMemory(shared);

  }

  return 0;

}
