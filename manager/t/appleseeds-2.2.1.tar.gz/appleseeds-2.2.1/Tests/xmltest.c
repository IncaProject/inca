/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdio.h> /* file functions */
#include <stdlib.h> /* free */
#include <string.h> /* strcmp */
#define ASXML_SHORT_NAMES
#include "xmlseed.h"


/* Returns the number of nodes in the subtree rooted at #root#. */
static unsigned
CountNodes(XmlNode root) {
  XmlNode n;
  unsigned result;
  if(root == NULL)
    return 0;
  result = 1;
  for(n = NodeFirstChild(root); n != NULL; n = NodeNextSibling(n))
    result += CountNodes(n);
  return result;
}


/* A node filter that accepts CDATA and "level1" and "level3" element nodes. */
static XmlNodeFilterResultTypes
Filter(XmlNode x) {
  return NodeType(x) == CDATA_SECTION_NODE ? FILTER_ACCEPT :
         NodeType(x) != ELEMENT_NODE ? FILTER_SKIP :
         strcmp(NodeName(x), "level1") == 0 ||
         strcmp(NodeName(x), "level3") == 0 ? FILTER_ACCEPT : FILTER_SKIP;
}


static int
TreeEquivalent(XmlNode x,
               XmlNode y) {
  unsigned i;
  XmlNode n;
  if(x == y)
    return 1;
  if(x == NULL || y == NULL)
    return 0;
  if(NodeType(x) != NodeType(y) || strcmp(NodeName(x), NodeName(y)) != 0)
    return 0;
  if((NodeNamespaceUri(x) == NULL) != (NodeNamespaceUri(y) == NULL) ||
     (NodeNamespaceUri(x) != NULL &&
      strcmp(NodeNamespaceUri(x), NodeNamespaceUri(y)) != 0))
    return 0;
  if(NodeType(x) == ELEMENT_NODE) {
    for(i = 0; (n = NamedNodeMapItem(NodeAttributes(x), i)) != NULL; i++)
      if(!TreeEquivalent(n, NamedNodeMapItem(NodeAttributes(y), i)))
        return 0;
  }
  for(x = NodeFirstChild(x), y = NodeFirstChild(y);
      x != NULL || y != NULL;
      x = NodeNextSibling(x), y = NodeNextSibling(y))
    if(!TreeEquivalent(x, y))
      return 0;
  return 1;
}


#define CDATA "<this is cdata><this is more>"
#define COMMENT "This is a comment"
#define NAMESPACE1 "http://www.ufo.edu"
#define NAMESPACE2 "http://www.martian.edu"


int
main(int argc,
     char **argv) {

  char *faulty[] = {
    "<a></b>", "<a ?='hello'></a>", "<a b=5></a>", "<a><![CDATA[</a>",
    "<a>", "<a><!--</a>", "<a b></a>", "<a></a",
    "<?fred", "<?>", "<></>", "<!-- -->",
    "<a></a><b></b>", "<!GOOBER><a/>",
    NULL
  };
  const XmlParseErrorCodes ERRORS[] = {
    INVALID_CLOSING_TAG, MISSING_NAME, MISSING_STRING, MISSING_CLOSE,
    MISSING_CLOSING_TAG, MISSING_CLOSE, MISSING_EQ, MISSING_CLOSE,
    MISSING_CLOSE, MISSING_NAME, MISSING_NAME, MISSING_TOP_TAG,
    MULTIPLE_TOP_TAGS, UNKNOWN_TAG
  };
  char *unmodified =
    "<?xml version=\"1.0\"?>"
    "<level1 a='11' b='22' q='0' r='0' s='0' t='0'>\n"
    "  <![CDATA[" CDATA "]]>\n"
    "  <!--" COMMENT "-->\n"
    "</level1>";
  char *modified =
    "<?xml version=\"1.00\"?>"
    "<level1 b='44' a='33'>\n"
    "  <![CDATA[" CDATA "]]>\n"
    "  <!--" COMMENT "-->\n"
    "  This is character data\n"
    "  And this is more\n"
    "</level1>"
    "<?xml version=\"1.00\"?>"
    "<level1 b='44' a='33'>\n"
    "  <![CDATA[" CDATA "]]>\n"
    "  <!--" COMMENT "-->\n"
    "</level1>";
  char *namespaces =
    "<?xml version=\"1.0\"?>"
    "<level1 xmlns='" NAMESPACE2 "' xmlns:ufo='" NAMESPACE1 "' "
             "ufo:a='11' b='22'>"
      "<ufo:level2/>"
      "<level2 ufo:a='11' b='22'/>"
    "</level1>";
  char *valid =
    "<?xml version=\"1.0\"?>"
    "<level1 a='11' b='22'>\n"
    "  <level2 c='33'>\n"
    "    <level3>\n"
    "    </level3>\n"
    "    <level3/>\n"
    "  </level2>\n"
    "  <level2>\n"
    "    <level3/>\n"
    "  </level2>\n"
    "  <![CDATA[" CDATA "]]>\n"
    "  <!--" COMMENT "-->\n"
    "</level1>";

  unsigned count;
  XmlDocument doc;
  unsigned i;
  char *image;
  XmlNodeIterator iterator;
  XmlParseErrorCodes error;
  XmlNodeList list;
  XmlNamedNodeMap map;
  XmlNode n;
  unsigned long offset;
  char *s;
  XmlTreeWalker walker;
  XmlNode x;

  /* Parsing errors. */
  for(i = 0; faulty[i] != NULL; i++)
    fprintf(stdout, "%s error check %d\n",
            XmlFromString(faulty[i],NULL,0,0,NULL,&error,&offset) == NULL &&
            error == ERRORS[i] ? "Pass" : "Fail", i);

  /* Document creation. */
  doc = XmlFromString(valid, NULL, 0, 0, NULL, NULL, NULL);
  fprintf(stdout, "%s basic document\n", doc != NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s node count\n", CountNodes(doc) == 21 ? "Pass" : "Fail");
  image = XmlToString(doc, NULL);
  fprintf(stdout, "%s image\n",
          strcmp(image, valid) == 0 ? "Pass" : "Fail");
  free(image);

  /* Operations on document nodes. */
  n = doc;
  fprintf(stdout, "%s document node element\n",
          strcmp(NodeName(DocumentElement(n)), "level1") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s document node has attributes\n",
          !NodeHasAttributes(n) ? "Pass" : "Fail");
  fprintf(stdout, "%s document node is valid\n",
          !DocumentIsValid(n) ? "Pass" : "Fail");
  fprintf(stdout, "%s document node name\n",
          strcmp(NodeName(n), "#document") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s document node type\n",
          NodeType(n) == DOCUMENT_NODE ? "Pass" : "Fail");
  fprintf(stdout, "%s document node value\n",
          NodeValue(n) == NULL ? "Pass" : "Fail");

  /* Operations on element nodes. */
  n = DocumentElement(doc);
  fprintf(stdout, "%s element node has attributes\n",
          NodeHasAttributes(n) ? "Pass" : "Fail");
  fprintf(stdout, "%s element node name\n",
          strcmp(NodeName(n), "level1") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s element node type\n",
          NodeType(n) == ELEMENT_NODE ? "Pass" : "Fail");
  fprintf(stdout, "%s element node value\n",
          NodeValue(n) == NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s element node attribute\n",
          strcmp(ElementGetAttribute(n, "a"), "11") == 0 &&
          strcmp(ElementGetAttribute(n, "b"), "22") == 0 &&
          strcmp(ElementGetAttribute(n, "c"), "") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s element node has attribute\n",
          ElementHasAttribute(n, "a") && !ElementHasAttribute(n, "z") ?
          "Pass" : "Fail");
  fprintf(stdout, "%s element node tag name\n",
          strcmp(ElementTagName(n), "level1") == 0 ? "Pass" : "Fail");

  /* Operations on attribute nodes. */
  n = ElementGetAttributeNode(n, "b");
  fprintf(stdout, "%s attribute node has attributes\n",
          !NodeHasAttributes(n) ? "Pass" : "Fail");
  fprintf(stdout, "%s attribute node has children\n",
          NodeHasChildNodes(n) ? "Pass" : "Fail");
  fprintf(stdout, "%s attribute node name\n",
          strcmp(NodeName(n), "b") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s attribute node type\n",
          NodeType(n) == ATTRIBUTE_NODE ? "Pass" : "Fail");
  fprintf(stdout, "%s attribute node value\n",
          strcmp(NodeValue(n), "22") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s attribute name\n",
          strcmp(AttrName(n), "b") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s attribute owner\n",
          AttrOwnerElement(n) == DocumentElement(doc) ? "Pass" : "Fail");
  fprintf(stdout, "%s attribute specified\n",
          AttrSpecified(n) ? "Pass" : "Fail");
  fprintf(stdout, "%s attribute value\n",
          strcmp(AttrValue(n), "22") == 0 ? "Pass" : "Fail");

  /* Operations on text nodes. */
  n = NodeFirstChild(DocumentElement(doc));
  fprintf(stdout, "%s text node has attributes\n",
          !NodeHasAttributes(n) ? "Pass" : "Fail");
  fprintf(stdout, "%s text node name\n",
          strcmp(NodeName(n), "#text") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s text node type\n",
          NodeType(n) == TEXT_NODE ? "Pass" : "Fail");
  fprintf(stdout, "%s text node value\n",
          strcmp(NodeValue(n), "\n  ") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s character data data\n",
          strcmp(CharacterDataData(n), "\n  ") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s character data length\n",
          CharacterDataLength(n) == 3 ? "Pass" : "Fail");
  s = CharacterDataSubstringData(n, 0, 2);
  fprintf(stdout, "%s character data substring\n",
          strcmp(s, "\n ") == 0 ? "Pass" : "Fail");
  free(s);
  s = CharacterDataSubstringData(n, 1, 5);
  fprintf(stdout, "%s character data substring 1\n",
          strcmp(s, "  ") == 0 ? "Pass" : "Fail");
  free(s);

  /* Operations on implementations. */
  fprintf(stdout, "%s implementation has feature\n",
          ImplementationHasFeature(DocumentImplementation(doc),
                                   "Core", "1.0") ? "Pass" : "Fail");

  /* Operations on processing instruction nodes. */
  n = NodeFirstChild(doc);
  fprintf(stdout, "%s processing instruction data\n",
          strcmp(ProcessingInstructionData(n), "version=\"1.0\"") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s processing instruction target\n",
          strcmp(ProcessingInstructionTarget(n), "xml") == 0 ?
          "Pass" : "Fail");
  
  /* Basic tree traversal. */
  n = NodeNextSibling(NodeFirstChild(DocumentElement(doc)));
  fprintf(stdout, "%s node next sibling\n",
          strcmp(NodeName(n), "level2") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s node owner document\n",
          NodeOwnerDocument(n) == doc ? "Pass" : "Fail");
  fprintf(stdout, "%s node parent\n",
          NodeParentNode(doc) == NULL &&
          NodeParentNode(DocumentElement(doc)) == doc ? "Pass" : "Fail");
  fprintf(stdout, "%s node previous sibling\n",
          NodeNextSibling(NodePreviousSibling(n)) == n ? "Pass" : "Fail");

  /* Extended tree traversal. */
  n = DocumentElement(doc);
  x = NodeFirstChildByType(n, SHOW_ELEMENT);
  fprintf(stdout, "%s first child by type\n",
          strcmp(NodeName(x), "level2") == 0 ? "Pass" : "Fail");
  x = NodeNextSiblingByType(x, SHOW_ELEMENT);
  fprintf(stdout, "%s next sibling by type\n",
          strcmp(NodeName(x), "level2") == 0 ? "Pass" : "Fail");

  /* Named node map operations. */
  map = NodeAttributes(DocumentElement(doc));
  n = NamedNodeMapItem(map, 1);
  fprintf(stdout, "%s map item\n",
          n != NULL && strcmp(NodeName(n), "b") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s map item 1\n",
          NamedNodeMapItem(map, 2) == NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s map length\n",
          NamedNodeMapLength(map) == 2 ? "Pass" : "Fail");
  n = NamedNodeMapGetNamedItem(map, "b");
  fprintf(stdout, "%s map named item\n",
          n != NULL && strcmp(NodeValue(n), "22") == 0 ? "Pass" : "Fail");

  /* Node list operations. */
  n = DocumentElement(doc);
  list = NodeChildNodes(n);
  fprintf(stdout, "%s list item\n",
          NodeListItem(list, 0) == NodeFirstChild(n) ? "Pass" : "Fail");
  fprintf(stdout, "%s list item 1\n",
          NodeListItem(list, 9) == NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s list length\n",
          NodeListLength(list) == 9 ? "Pass" : "Fail");
  NodeListFree(list);

  list = DocumentGetElementsByTagName(doc, "level3");
  fprintf(stdout, "%s nonsequential list item\n",
          strcmp(NodeName(NodeListItem(list, 1)), "level3") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s nonsequential list item 1\n",
          NodeListItem(list, 3) == NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s nonsequential list length\n",
          NodeListLength(list) == 3 ? "Pass" : "Fail");
  NodeListFree(list);

  list = ElementGetElementsByTagName
    (NodeNextSibling(NodeFirstChild(DocumentElement(doc))), "*");
  fprintf(stdout, "%s wildcard list length\n",
          NodeListLength(list) == 2 ? "Pass" : "Fail");
  NodeListFree(list);

  list = NodeGetElementsByTagName(DocumentElement(doc), "level3");
  fprintf(stdout, "%s node tag name list\n",
          NodeListLength(list) == 3 ? "Pass" : "Fail");
  NodeListFree(list);

  n = NodeFirstChildByType(DocumentElement(doc), SHOW_ELEMENT);
  n = NodeNextSiblingByType(n, SHOW_ELEMENT);
  n = NodeFirstChildByType(n, SHOW_ELEMENT);
  list = NodeGetElementsByTagName(n, "*");
  fprintf(stdout, "%s empty tag name list\n",
          NodeListLength(list) == 0 ? "Pass" : "Fail");
  NodeListFree(list);

  /* Node iterator operations. */
  iterator = DocumentCreateNodeIterator(doc, doc, SHOW_ELEMENT, NULL, 0);
  fprintf(stdout, "%s iterator root\n",
          NodeIteratorRoot(iterator) == doc ? "Pass" : "Fail");
  fprintf(stdout, "%s iterator eer\n",
          !NodeIteratorExpandEntityReferences(iterator) ? "Pass" : "Fail");
  fprintf(stdout, "%s iterator filter\n",
          NodeIteratorFilter(iterator) == NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s iterator wts\n",
          NodeIteratorWhatToShow(iterator) == SHOW_ELEMENT ? "Pass" : "Fail");
  fprintf(stdout, "%s iterator item\n",
          strcmp(NodeName(NodeIteratorItem(iterator, 3)), "level3") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s iterator length\n",
          NodeIteratorLength(iterator) == 6 ? "Pass" : "Fail");
  fprintf(stdout, "%s iterator next\n",
          strcmp(NodeName(NodeIteratorNextNode(iterator)), "level1") == 0 &&
          strcmp(NodeName(NodeIteratorNextNode(iterator)), "level2") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s iterator previous\n",
          strcmp(NodeName(NodeIteratorPreviousNode(iterator)), "level2") == 0 &&
          strcmp(NodeName(NodeIteratorPreviousNode(iterator)), "level1") == 0 ?
          "Pass" : "Fail");
  while(NodeIteratorNextNode(iterator) != NULL)
    ; /* empty */
  fprintf(stdout, "%s iterator last\n",
          strcmp(NodeName(NodeIteratorPreviousNode(iterator)), "level3") == 0 ?
          "Pass" : "Fail");
  while(NodeIteratorPreviousNode(iterator) != NULL)
    ; /* empty */
  fprintf(stdout, "%s iterator first\n",
          strcmp(NodeName(NodeIteratorNextNode(iterator)), "level1") == 0 ?
          "Pass" : "Fail");
  NodeIteratorDetach(iterator);
  iterator = DocumentCreateNodeIterator(doc, doc, SHOW_ELEMENT, NULL, 0);

  NodeIteratorNextNode(iterator);
  n = NodeIteratorNextNode(iterator);
  NodeIteratorNextNode(iterator);
  NodeRemoveChild(n, NodeNextSibling(NodeFirstChild(n)));
  fprintf(stdout, "%s iterator remove current\n",
          NodeIteratorPreviousNode(iterator) == n ? "Pass" : "Fail");
  n = NodeIteratorNextNode(iterator);
  NodeRemoveChild(NodeParentNode(n), n);
  fprintf(stdout, "%s iterator remove ancestor\n",
          NodeIteratorPreviousNode(iterator) == DocumentElement(doc) ?
          "Pass" : "Fail");
  NodeIteratorFree(iterator);

  NodeFree(doc);
  doc = XmlFromString(valid, NULL, 0, 0, NULL, NULL, NULL);

  /* TreeWalker operations. */
  walker = DocumentCreateTreeWalker(doc, doc, SHOW_ALL, &Filter, 1);
  fprintf(stdout, "%s tree walker initial\n",
          TreeWalkerCurrentNode(walker) == doc ? "Pass" : "Fail");
  fprintf(stdout, "%s tree walker expand\n",
          TreeWalkerExpandEntityReferences(walker) ? "Pass" : "Fail");
  fprintf(stdout, "%s tree walker filter\n",
          TreeWalkerFilter(walker) == &Filter ? "Pass" : "Fail");
  fprintf(stdout, "%s tree walker root\n",
          TreeWalkerRoot(walker) == doc ? "Pass" : "Fail");
  fprintf(stdout, "%s tree walker show\n",
          TreeWalkerWhatToShow(walker) == SHOW_ALL ? "Pass" : "Fail");

  fprintf(stdout, "%s tree walker length\n",
          TreeWalkerLength(walker) == 5 ? "Pass" : "Fail");
  fprintf(stdout, "%s tree walker first child\n",
          TreeWalkerFirstChild(walker) == DocumentElement(doc) ?
          "Pass" : "Fail");
  fprintf(stdout, "%s tree walker current\n",
          TreeWalkerCurrentNode(walker) == DocumentElement(doc) ?
          "Pass" : "Fail");
  fprintf(stdout, "%s tree walker item\n",
          NodeType(TreeWalkerItem(walker, 4)) == CDATA_SECTION_NODE ?
          "Pass" : "Fail");
  fprintf(stdout, "%s tree walker next node\n",
          strcmp(NodeName(TreeWalkerNextNode(walker)), "level3") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s tree walker previous node\n",
          strcmp(NodeName(TreeWalkerPreviousNode(walker)), "level1") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s tree walker last child\n",
          NodeType(TreeWalkerLastChild(walker)) == CDATA_SECTION_NODE ?
          "Pass" : "Fail");
  TreeWalkerPreviousNode(walker);
  TreeWalkerPreviousSibling(walker);
  fprintf(stdout, "%s tree walker previous sibling\n",
          strcmp(NodeName(TreeWalkerCurrentNode(walker)), "level3") == 0 ?
          "Pass" : "Fail");
  TreeWalkerNextSibling(walker);
  fprintf(stdout, "%s tree walker next sibling\n",
          strcmp(NodeName(TreeWalkerCurrentNode(walker)), "level3") == 0 &&
          TreeWalkerNextSibling(walker) == NULL ?
          "Pass" : "Fail");
  TreeWalkerParentNode(walker);
  fprintf(stdout, "%s tree walker parent node\n",
          strcmp(NodeName(TreeWalkerCurrentNode(walker)), "level1") == 0 ?
          "Pass" : "Fail");
  TreeWalkerSetCurrentNode
    (walker, NodeFirstChildByType(TreeWalkerCurrentNode(walker), SHOW_ELEMENT));
  fprintf(stdout, "%s tree walker set current node\n",
          strcmp(NodeName(TreeWalkerCurrentNode(walker)), "level2") == 0 ?
          "Pass" : "Fail");
  TreeWalkerNextNode(walker);
  fprintf(stdout, "%s tree walker next node from invalid\n",
          strcmp(NodeName(TreeWalkerCurrentNode(walker)), "level3") == 0 ?
          "Pass" : "Fail");
  TreeWalkerFree(walker);

  /* Node creation. */
  NodeFree(doc);
  doc = ImplementationCreateDocument(NULL, NULL, "", NULL);

  n = DocumentCreateProcessingInstruction(doc, "xml", "version=\"1.0\"");
  NodeAppendChild(doc, n);
  n = DocumentCreateElement(doc, "level1");
  NodeAppendChild(doc, n);
  ElementSetAttribute(n, "a", "11");
  x = DocumentCreateAttribute(doc, "b");
  AttrSetValue(x, "22");
  ElementSetAttributeNode(n, x);
  x = DocumentCreateElement(doc, "level2");
  NodeInsertAfter(n, x, NULL);
  NodeAppendChild(x, DocumentCreateTextNode(doc, "\n    "));
  NodeAppendChild(x, DocumentCreateElement(doc, "level3"));
  NodeAppendChild(NodeLastChild(x), DocumentCreateTextNode(doc, "\n    "));
  NodeAppendChild(x, DocumentCreateTextNode(doc, "\n    "));
  NodeAppendChild(x, DocumentCreateElement(doc, "level3"));
  NodeAppendChild(x, DocumentCreateTextNode(doc, "\n  "));
  ElementSetAttribute(x, "c", "33");
  NodeInsertBefore(n, DocumentCreateTextNode(doc, "\n  "), x);
  NodeAppendChild(n, DocumentCreateTextNode(doc, "\n  "));
  x = DocumentCreateElement(doc, "level2");
  NodeAppendChild(n, x);
  NodeAppendChild(x, DocumentCreateTextNode(doc, "\n    "));
  NodeAppendChild(x, DocumentCreateElement(doc, "level3"));
  NodeAppendChild(x, DocumentCreateTextNode(doc, "\n  "));
  NodeInsertAfter(n, DocumentCreateTextNode(doc, "\n  "), x);
  NodeAppendChild(n, DocumentCreateCdataSection(doc, CDATA));
  NodeAppendChild(n, DocumentCreateTextNode(doc, "\n  "));
  NodeAppendChild(n, DocumentCreateComment(doc, COMMENT));
  NodeAppendChild(n, DocumentCreateTextNode(doc, "\n"));

  image = XmlToString(doc, NULL);
  fprintf(stdout, "%s create 1\n",
          strcmp(image, valid) == 0 ? "Pass" : "Fail");
  free(image);

  NodeFree(doc);
  doc = ImplementationCreateDocument(NULL, NULL, "", NULL);

  n = DocumentCreateProcessingInstruction(doc, "xml", "version=\"1.0\"");
  NodeAppendChild(doc, n);
  n = DocumentCreateElement(doc, "level1");
  NodeAppendChild(doc, n);
  ElementSetAttribute(n, "a", "11");
  ElementSetAttribute(n, "b", "22");
  ElementSetAttribute(n, "q", "0");
  ElementSetAttribute(n, "r", "0");
  ElementSetAttribute(n, "s", "0");
  ElementSetAttribute(n, "t", "0");
  NodeAppendChild(n, DocumentCreateTextNode(doc, "\n  "));
  NodeAppendChild(n, DocumentCreateCdataSection(doc, CDATA));
  NodeAppendChild(n, DocumentCreateTextNode(doc, "\n  "));
  NodeAppendChild(n, DocumentCreateComment(doc, COMMENT));
  NodeAppendChild(n, DocumentCreateTextNode(doc, "\n"));

  image = XmlToString(doc, NULL);
  fprintf(stdout, "%s create 2\n",
          strcmp(image, unmodified) == 0 ? "Pass" : "Fail");
  free(image);

  /* Node transformation. */
  x = DocumentCreateAttribute(doc, "a");
  AttrSetValue(x, "33");
  NamedNodeMapSetNamedItem(NodeAttributes(n), x);
  x = ElementGetAttributeNode(n, "b");
  NodeSetValue(x, "44");
  ElementRemoveAttribute(n, "q");
  NamedNodeMapRemoveNamedItem(NodeAttributes(n), "r");
  NamedNodeMapRemoveItem(NodeAttributes(n), ElementGetAttributeNode(n, "s"));
  ElementRemoveAttributeNode(n, ElementGetAttributeNode(n, "t"));
  ElementRemoveAttribute(n, "v");
  x = NodeFirstChild(doc);
  ProcessingInstructionSetData(x, "version=\"1.00\"");
  NodeAppendChild(doc, NodeCloneNode(x, 0));
  x = DocumentElement(doc);
  NodeAppendChild(doc, NodeCloneNode(x, 1));
  x = DocumentCreateTextNode(doc, "  This is character data\n");
  NodeAppendChild(n, x);
  NodeAppendChild(n, DocumentCreateTextNode(doc, "Shorttimer"));
  x = DocumentCreateTextNode(doc, "  Four score and seven\n");
  NodeReplaceChild(n, x, NodeLastChild(n));
  CharacterDataSetData(x, "  And some");
  CharacterDataAppendData(x, "is more\n");
  CharacterDataDeleteData(x, 6, 4);
  CharacterDataInsertData(x, 6, "thXXXX");
  CharacterDataReplaceData(x, 8, 4, "is ");

  image = XmlToString(doc, NULL);
  fprintf(stdout, "%s transformations\n",
          strcmp(image, modified) == 0 ? "Pass" : "Fail");
  free(image);

  /* Text split/normalize. */
  count = CountNodes(doc);
  TextSplitText(x, 5);
  x = NodeFirstChildByType(n, SHOW_CDATA_SECTION);
  TextSplitText(x, 10);
  fprintf(stdout, "%s split\n", CountNodes(doc) == count + 2 ?
          "Pass" : "Fail");
  /* Joins 4 (newline, two text sibs created above and split node) into 1. */
  NodeNormalize(doc);
  image = XmlToString(doc, NULL);
  fprintf(stdout, "%s normalize\n", CountNodes(doc) == count - 1 ?
          "Pass" : "Fail");
  free(image);

  /* NodeIsSupported--not sure what this is for. */
  fprintf(stdout, "%s node is supported\n",
          NodeIsSupported(x, "Core", NULL) ? "Pass" : "Fail");

  /* Operations on document fragments. */
  n = DocumentCreateDocumentFragment(doc);
  fprintf(stdout, "%s create document fragment\n",
          NodeType(n) == DOCUMENT_FRAGMENT_NODE ? "Pass" : "Fail");
  while(NodeHasChildNodes(DocumentElement(doc)))
    NodeAppendChild(n, NodeFirstChild(DocumentElement(doc)));
  fprintf(stdout, "%s document fragment append child\n",
          NodeType(NodeLastChild(n)) == TEXT_NODE ? "Pass" : "Fail");
  NodeAppendChild(doc, n);
  fprintf(stdout, "%s append document fragment\n",
          NodeType(NodeLastChild(doc)) == TEXT_NODE ? "Pass" : "Fail");

  /* Operations on DTD nodes. */
  x = ImplementationCreateDocumentType(NULL, "dtd", NULL, NULL);
  fprintf(stdout, "%s create DTD\n",
          NodeType(x) == DOCUMENT_TYPE_NODE && strcmp(NodeName(x), "dtd") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s DTD name\n",
          strcmp(DocumentTypeName(x), "dtd") == 0 ? "Pass" : "Fail");
  NodeFree(x);

  /* Namespaces. */
  NodeFree(doc);
  doc = XmlFromString(namespaces, NULL, 0, 0, NULL, &error, &offset);

  fprintf(stdout, "%s namespace parsing\n", doc != NULL ? "Pass" : "Fail");
  n = DocumentElement(doc);

  list = DocumentGetElementsByTagNameNS(doc, NAMESPACE2, "*");
  fprintf(stdout, "%s doc NS tag name list\n",
          NodeListLength(list) == 2 ? "Pass" : "Fail");
  NodeListFree(list);
  list = ElementGetElementsByTagNameNS(n, NAMESPACE2, "*");
  fprintf(stdout, "%s element NS tag name list\n",
          NodeListLength(list) == 1 ? "Pass" : "Fail");
  NodeListFree(list);
  list = NodeGetElementsByTagNameNS(doc, NAMESPACE1, "level2");
  fprintf(stdout, "%s node NS tag name list\n",
          NodeListLength(list) == 1 ? "Pass" : "Fail");
  NodeListFree(list);

  fprintf(stdout, "%s has namespace attr\n",
          ElementHasAttributeNS(n, NAMESPACE1, "a") &&
          !ElementHasAttributeNS(n, NAMESPACE1, "b") ?
          "Pass" : "Fail");
  fprintf(stdout, "%s get namespace attr node\n",
          ElementGetAttributeNodeNS(n, NAMESPACE1, "a") != NULL &&
          ElementGetAttributeNodeNS(n, NAMESPACE1, "b") == NULL ?
          "Pass" : "Fail");
  fprintf(stdout, "%s get namespace attr\n",
          strcmp(ElementGetAttributeNS(n, NAMESPACE1, "a"), "11") == 0 ?
          "Pass" : "Fail");
  fprintf(stdout, "%s named node map get namespace item\n",
          NamedNodeMapGetNamedItemNS(NodeAttributes(n), NAMESPACE1, "a") ==
          ElementGetAttributeNodeNS(n, NAMESPACE1, "a") ?
          "Pass" : "Fail");
  x = DocumentCreateAttributeNS(doc, NAMESPACE2, "c");
  NodeSetValue(x, "33");
  NamedNodeMapSetNamedItemNS(NodeAttributes(n), x);
  fprintf(stdout, "%s named node map set namespace item\n",
          strcmp(ElementGetAttributeNS(n, NAMESPACE2, "c"), "33") == 0 ?
          "Pass" : "Fail");
  NamedNodeMapRemoveNamedItemNS(NodeAttributes(n), NAMESPACE2, "c");
  fprintf(stdout, "%s named node map remove namespace item\n",
          ElementGetAttributeNodeNS(n, NAMESPACE2, "c") == NULL ?
          "Pass" : "Fail");
  ElementRemoveAttributeNS(n, NAMESPACE2, "c");
  NamedNodeMapSetNamedItemNS(NodeAttributes(n), x);
  ElementRemoveAttributeNS(n, NAMESPACE2, "c");
  fprintf(stdout, "%s element remove namespace attr\n",
          ElementGetAttributeNodeNS(n, NAMESPACE2, "c") == NULL ?
          "Pass" : "Fail");
  n = NodeFirstChildByType(n, SHOW_ELEMENT);
  fprintf(stdout, "%s node local name\n",
          strcmp(NodeLocalName(n), "level2") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s node namespace uri\n",
          strcmp(NodeNamespaceUri(n), NAMESPACE1) == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s node prefix\n",
          strcmp(NodePrefix(n), "ufo") == 0 ? "Pass" : "Fail");
  n = NodeNextSiblingByType(n, SHOW_ELEMENT);
  fprintf(stdout, "%s default local name\n",
          strcmp(NodeLocalName(n), "level2") == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s default namespace\n",
          strcmp(NodeNamespaceUri(n), NAMESPACE2) == 0 ? "Pass" : "Fail");
  fprintf(stdout, "%s default no prefix\n",
          NodePrefix(n) == NULL ? "Pass" : "Fail");
  fprintf(stdout, "%s attr no default namespace\n",
          ElementGetAttributeNodeNS(n, NAMESPACE2, "b") == NULL ?
          "Pass" : "Fail");
  NodeSetPrefix(n, "ufo");
  fprintf(stdout, "%s node set prefix\n",
          strcmp(NodeName(n), "ufo:level2") == 0 &&
          strcmp(NodeNamespaceUri(n), NAMESPACE2) == 0 ? "Pass" : "Fail");
  NodeSetNamespaceUri(n, NAMESPACE1);
  fprintf(stdout, "%s node set namespace uri\n",
          strcmp(NodeName(n), "ufo:level2") == 0 &&
          strcmp(NodeNamespaceUri(n), NAMESPACE1) == 0 ? "Pass" : "Fail");


  /* Namespace node creation. */
  NodeFree(doc);
  doc = ImplementationCreateDocument(NULL, NULL, "#document", NULL);

  n = DocumentCreateProcessingInstruction(doc, "xml", "version=\"1.0\"");
  NodeAppendChild(doc, n);
  n = DocumentCreateElementNS(doc, NAMESPACE2, "level1");
  NodeAppendChild(doc, n);
  ElementSetAttribute(n, "xmlns", NAMESPACE2);
  ElementSetAttribute(n, "xmlns:ufo", NAMESPACE1);
  ElementSetAttributeNS(n, NAMESPACE1, "ufo:a", "11");
  x = DocumentCreateAttribute(doc, "b");
  ElementSetAttributeNodeNS(n, x);
  x = DocumentCreateElementNS(doc, NAMESPACE1, "ufo:level2");
  NodeAppendChild(n, x);
  x = DocumentCreateElementNS(doc, NAMESPACE2, "level2");
  ElementSetAttributeNS(x, NAMESPACE1, "ufo:a", "11");
  ElementSetAttribute(x, "b", "22");
  NodeAppendChild(n, x);

  n = XmlFromString(namespaces, NULL, 0, 0, NULL, &error, &offset);
  fprintf(stdout, "%s namespace node creation\n",
          TreeEquivalent(doc, n) ? "Pass" : "Fail");
  NodeFree(n);

  n = ImplementationCreateDocument(NULL, NULL, "#document", NULL);
  for(x = NodeFirstChild(doc); x != NULL; x = NodeNextSibling(x))
    NodeAppendChild(n, DocumentImportNode(n, x, 1));
  fprintf(stdout, "%s document import node\n",
          TreeEquivalent(doc, n) ? "Pass" : "Fail");
  NodeFree(n);

  NodeFree(doc);

  return 0;

}
