/* $Id: Makefile.in,v 1.4 2001/06/01 17:56:45 jhayes Exp */

#include "oshseed.h"
#include <stdio.h>  /* file functions */
#include <string.h> /* memset */
#include "execseed.h"
#define ASSEM_SHORT_NAMES
#include "semseed.h"


static const char CHILD_CHAR  = 'C';
static const char PARENT_CHAR = 'P';
enum {STDIN_FD = 0, STDOUT_FD = 1, STDERR_FD = 2};
enum {PIPE_READ = 0, PIPE_WRITE = 1};


int
main(int argc,
     char **argv) {

  char ch;
  int i;
  int ioPipe[2];
  char *params[] = {NULL, NULL, NULL};
  int savedStdin;
  int savedStderr;
  Semaphore sem;
  Semaphore sem2;
  char semName[32 + 1];

  if(argc == 1) {

    sprintf(semName, "%d", (int)getpid());
    sem = OpenSemaphore(semName, 0);
    fprintf(stdout, "%s open missing semaphore\n",
            (sem == NO_SEMAPHORE) ? "Pass" : "Fail");
    sem = OpenSemaphore(semName, 1);
    fprintf(stdout, "%s create new semaphore\n",
            (sem != NO_SEMAPHORE) ? "Pass" : "Fail");
    fprintf(stdout, "%s initial semaphore value\n",
            (Value(sem) == 0) ? "Pass" : "Fail");
    sem2 = OpenSemaphore(semName, 1);
    fprintf(stdout, "%s create existing semaphore\n",
            (sem2 == NO_SEMAPHORE) ? "Pass" : "Fail");
    sem2 = OpenSemaphore(semName, 0);
    fprintf(stdout, "%s open existing semaphore\n",
            (sem != NO_SEMAPHORE) ? "Pass" : "Fail");
    for(i = 0; i < 10; i++)
      Up(sem);
    fprintf(stdout, "%s Up\n",
            ((int)Value(sem) == i) ? "Pass" : "Fail");
    for(; i > 0; i--)
      Down(sem);
    fprintf(stdout, "%s non-blocking Down\n",
            (Value(sem) == 0) ? "Pass" : "Fail");
    CloseSemaphore(sem2);
    sem2 = OpenSemaphore(semName, 0);
    fprintf(stdout, "%s intermediate close\n",
            (sem != NO_SEMAPHORE) ? "Pass" : "Fail");

    /* Spawn a process to check blocking Down. */
    pipe(ioPipe);
    params[0] = argv[0];
    params[1] = semName;
    savedStdin = dup(STDIN_FD);
    savedStderr = dup(STDERR_FD);
    dup2(ioPipe[PIPE_READ], STDIN_FD);
    dup2(ioPipe[PIPE_WRITE], STDERR_FD);
    ASEXEC_ProcessStart(argv[0], (const char **)params, NULL);
    dup2(savedStdin, STDIN_FD);
    dup2(savedStderr, STDERR_FD);
    close(savedStdin);
    close(savedStderr);
    read(ioPipe[PIPE_READ], &ch, 1); /* Sync 1 */
    sleep(2);
    write(ioPipe[PIPE_WRITE], &PARENT_CHAR, 1);
    read(ioPipe[PIPE_READ], &ch, 1); /* Parent write (Pass)/Post-Down (Fail) */
    fprintf(stdout, "%s blocking Down\n",
            (ch == PARENT_CHAR) ? "Pass" : "Fail");
    Up(sem);
    read(ioPipe[PIPE_READ], &ch, 1); /* Post-Down (Pass)/Parent write (Fail) */
    read(ioPipe[PIPE_READ], &ch, 1); /* Sync 2 */

    CloseSemaphore(sem2);
    CloseSemaphore(sem);
    sleep(2); /* Give the system some time to clean up. */
    sem = OpenSemaphore(semName, 0);
    fprintf(stdout, "%s final close\n",
            (sem == NO_SEMAPHORE) ? "Pass" : "Fail");

  }
  else {

    sem = OpenSemaphore(argv[1], 0);
    fputc(CHILD_CHAR, stderr); fflush(stderr); /* Sync 1 */
    Down(sem);
    fputc(CHILD_CHAR, stderr); fflush(stderr); /* Post-Down */
    CloseSemaphore(sem);
    fputc(CHILD_CHAR, stderr); fflush(stderr); /* Sync 2 */

  }

  return 0;

}
