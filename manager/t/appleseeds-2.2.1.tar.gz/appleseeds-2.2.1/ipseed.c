/* $Id: ipseed.c,v 1.54 2004/12/07 23:48:01 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#include "config.h"
#include "oshseed.h"
#ifdef WIN32
#  include <winsock.h>
#  define close closesocket
#  define WIN32_EPILOG WSACleanup();
#  define WIN32_PROLOG {WSADATA wsaData; WSAStartup(MAKEWORD(1, 1), &wsaData);}
#else
#  include <sys/socket.h>  /* AF_INET */
#  include <netinet/in.h>  /* IPPROTO_TCP struct in_addr */
#  include <arpa/inet.h>   /* inet_addr inet_ntoa */
#  include <netdb.h>       /* gethostby{addr,name} */
#  include <sys/time.h>    /* struct timeval */
#  define WIN32_EPILOG
#  define WIN32_PROLOG
#endif
#include <stdio.h>  /* sprintf */
#include <stdlib.h> /* free */
#include <string.h> /* memcpy memset strchr strncpy */
#include "strseed.h"
#include "vectorseed.h"
#define ASIP_SHORT_NAMES
#include "ipseed.h"


/*
 * Note: some systems take (char *) as the third parameter to [gs]etsockopt,
 * others (void *).  Since the former is compatable with the latter, we always
 * cast to (char *).
 */


#ifndef TCP_NODELAY
#  define TCP_NODELAY 0x01
#endif

/* Convenient shorthand for casting. */
typedef struct sockaddr *SAP;


/*
 * Looks in the name and alias entries of #hostEntry# for a fully-qualified
 * name.  Returns the fqn if found; otherwise, returns the name entry.
 */
static char *
BestHostName(const struct hostent *hostEntry) {
  int i;
  if(strchr(hostEntry->h_name, '.') == NULL) {
    for(i = 0; hostEntry->h_aliases[i] != NULL; i++) {
      if(strchr(hostEntry->h_aliases[i], '.') != NULL)
        return hostEntry->h_aliases[i];
    }
  }
  return (char *)hostEntry->h_name;
}


/* Initializes #addr# to refer to #address#:#port#. */
static void
InitSockaddrIn(struct sockaddr_in *addr,
               Address address,
               Port port) {
  memset(addr, 0, sizeof(struct sockaddr_in));
  addr->sin_addr.s_addr = address == ANY_ADDRESS ? INADDR_ANY : address;
  addr->sin_family = AF_INET;
  addr->sin_port = htons((unsigned short)(port == ANY_PORT ? 0 : port));
}


/* Returns a pointer to the DNS mapping entry for #address#, NULL on error. */
static struct hostent *
LookupByAddress(Address address) {
  struct in_addr addrAsInAddr;
  struct hostent *addrEntry;
  addrAsInAddr.s_addr = address;
  WIN32_PROLOG
  addrEntry = gethostbyaddr((char*)&addrAsInAddr,sizeof(addrAsInAddr),AF_INET);
  WIN32_EPILOG
  if(addrEntry == NULL)
    return NULL;
  else if(addrEntry->h_length != sizeof(struct in_addr))
    return NULL; /* We don't (yet) handle IPv6 addresses. */
  return addrEntry;
}


/* Returns a pointer to the DNS mapping entry for #name#, NULL on error. */
static struct hostent *
LookupByName(const char *name) {
  struct hostent *nameEntry;
  WIN32_PROLOG
  nameEntry = gethostbyname(name);
  WIN32_EPILOG
  if(nameEntry == NULL)
    return NULL;
  else if(nameEntry->h_length != sizeof(struct in_addr))
    return NULL; /* We don't (yet) handle IPv6 addresses. */
  return nameEntry;
}


/*
 * Allocates a new socket and configures it with #receiveBufferSize# and
 * #sendBufferSize#.  Returns the socket if successful, else NO_SOCKET.
 */
static Socket
NewSocket(Protocols protocol,
          unsigned receiveBufferSize,
          unsigned sendBufferSize) {

  int intSize;
  Socket sock;
  int turnOn = 1;

  WIN32_PROLOG
  sock = socket(AF_INET, protocol==TCP_PROTOCOL ? SOCK_STREAM : SOCK_DGRAM, 0);
  if(sock < 0) {
    WIN32_EPILOG
    return NO_SOCKET;
  }
  if(protocol == TCP_PROTOCOL)
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (char *)&turnOn, sizeof(turnOn));
  if(receiveBufferSize != DEFAULT_BUFFER_SIZE) {
    intSize = receiveBufferSize;
    setsockopt(sock, SOL_SOCKET, SO_RCVBUF, (char *)&intSize, sizeof(intSize));
  }
  if(sendBufferSize != DEFAULT_BUFFER_SIZE) {
    intSize = sendBufferSize;
    setsockopt(sock, SOL_SOCKET, SO_SNDBUF, (char *)&intSize, sizeof(intSize));
  }
  return sock;

}


/*
 * Receives up to #size# bytes on #sock# and copies them into #intoWhere#.  If
 * successful, returns the number of bytes copied and copies the sender address
 * and port into #addr# and #port#, if these are not null; else, returns -1.
 */
static int
ReceiveBytes(Socket sock,
             void *intoWhere,
             unsigned size,
             Address *addr,
             Port *port) {
  struct sockaddr_in peer;
  ASIP_SOCKLEN_T peerLen = sizeof(peer);
  int received = 1;
  int leftToReceive;
  for(leftToReceive = size;
      leftToReceive > 0 && received > 0;
      leftToReceive -= received, intoWhere = (char *)intoWhere + received)
    received = recvfrom(sock,intoWhere,leftToReceive,0,(SAP)&peer,&peerLen);
  if(addr != NULL)
    *addr = peer.sin_addr.s_addr;
  if(port != NULL)
    *port = ntohs(peer.sin_port);
  return received < 0 ? -1 : ((int)size - leftToReceive);
}


Socket
Accept(Socket sock) {
  struct sockaddr_in peer;
  ASIP_SOCKLEN_T peerLen = sizeof(peer);
  return accept(sock, (SAP)&peer, &peerLen);
}


char *
AddressImage(Address addr) {
  /* inet_ntoa is not thread-safe, so we roll our own here. */
  unsigned char bytes[4];
  char result[64];
  memcpy(bytes, ((char *)&addr) + sizeof(addr) - 4, 4);
  sprintf(result, "%d.%d.%d.%d", bytes[0], bytes[1], bytes[2], bytes[3]);
  return strdup(result);
}


char *
AddressMachine(Address addr) {
  const struct hostent *hostEntry;
  if((hostEntry = LookupByAddress(addr)) == NULL)
    return NULL;
  return strdup(BestHostName(hostEntry));
}


int
AddressValues(const char *machineOrAddress,
              Address *addressList,
              unsigned atMost) {

  const struct hostent *hostEntry;
  unsigned i;
  int itsAnAddress;

  /*
   * inet_addr() has the weird behavior of returning an unsigned quantity but
   * using -1 as an error value.  The most (only?) portable way of testing the
   * return value is to compare it to a returned value for a known non-address.
   */
  WIN32_PROLOG
  itsAnAddress = inet_addr(machineOrAddress) != inet_addr("invalid name");
  if(itsAnAddress && atMost < 2) {
    if(atMost == 1)
      *addressList = inet_addr(machineOrAddress);
    WIN32_EPILOG
    return 1;
  }
  hostEntry = itsAnAddress ?
              LookupByAddress(inet_addr(machineOrAddress)) :
              LookupByName(machineOrAddress);
  WIN32_EPILOG
  if(hostEntry == NULL)
    return 0;
  else if(atMost == 0)
    return 1;
  for(i = 0; i < atMost && hostEntry->h_addr_list[i] != NULL; i++)
    addressList[i] = ((struct in_addr **)hostEntry->h_addr_list)[i]->s_addr;
  return i;

}


int
CheckIfAnyReadable(Socket *socks,
                   Socket *readable,
                   double secondsToWait) {

  int i;
  Socket maxSock;
  fd_set readFDs;
  int returnValue;
  struct timeval timeOut;
  struct timeval *waitTime;

  FD_ZERO(&readFDs);
  maxSock = 0;
  for(; *socks != NO_SOCKET; socks++) {
    FD_SET(*socks, &readFDs);
    if(*socks > maxSock)
      maxSock = *socks;
  }

  if(secondsToWait < 0.0)
    waitTime = NULL;
  else {
    timeOut.tv_sec  = (int)secondsToWait;
    timeOut.tv_usec = (int)((secondsToWait - timeOut.tv_sec) * 1000000);
    waitTime = &timeOut;
  }
  returnValue = select(maxSock + 1, &readFDs, NULL, NULL, waitTime) > 0;

  if(returnValue > 0 && readable != NULL) {
    for(i = 0; i <= maxSock; i++) {
      if(FD_ISSET(i, &readFDs))
        *readable++ = i;
    }
    *readable = NO_SOCKET;
  }

  return returnValue;

}


int
CheckIfReadable(Socket sock,
                double secondsToWait) {
  Socket twoSockets[2];
  twoSockets[0] = sock;
  twoSockets[1] = NO_SOCKET;
  return CheckIfAnyReadable(twoSockets, NULL, secondsToWait);
}


Socket
ConnectToIpPortBuffered(Protocols protocol,
                        Address address,
                        Port port,
                        unsigned receiveBufferSize,
                        unsigned sendBufferSize) {
  struct sockaddr_in addrAndPort;
  Socket sock;
  if((sock = NewSocket(protocol,receiveBufferSize,sendBufferSize)) == NO_SOCKET)
    return NO_SOCKET;
  InitSockaddrIn(&addrAndPort, address, port);
  if(connect(sock, (SAP)&addrAndPort, sizeof(addrAndPort)) < 0)
    Disconnect(&sock);
  return sock;
}


void
Disconnect(Socket *sock) {
  if(*sock == NO_SOCKET)
    return;
  (void)close(*sock);
  *sock = NO_SOCKET;
  WIN32_EPILOG
}


char *
MyMachineName(void) {
  char hostName[256 + 1];
  const struct hostent *myEntry;
  /* Try the simple case first. */
  WIN32_PROLOG
  if(gethostname(hostName, sizeof(hostName)) < 0) {
    WIN32_EPILOG
    return NULL;
  }
  WIN32_EPILOG
  if(strchr(hostName, '.') != NULL)
    return strdup(hostName);
  /* See if the DNS gives us something better. */
  myEntry = LookupByName(hostName);
  return myEntry == NULL ? strdup(hostName) : strdup(BestHostName(myEntry));
}


Socket
OpenIpPortBuffered(Protocols protocol,
                   Address address,
                   Port port,
                   unsigned receiveBufferSize,
                   unsigned sendBufferSize,
                   Port *openedPort) {

  struct sockaddr_in addrAndPort;
  ASIP_SOCKLEN_T addrAndPortLen = sizeof(addrAndPort);
  int on = 1;
  Socket sock;

  if((sock = NewSocket(protocol,receiveBufferSize,sendBufferSize)) == NO_SOCKET)
    return NO_SOCKET;
#ifdef ASIP_NO_WILD_ADDRESSES
  /* Winsock waits until data transmission to resolve INADDR_ANY.  Ick. */
  if(address == ANY_ADDRESS) {
    char *myHost = MyMachineName();
    AddressValue(myHost, &address);
    free(myHost);
  }
#endif
  if(port != ANY_PORT)
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on));
  InitSockaddrIn(&addrAndPort, address, port);
  /*
   * Note: According to Stevens' book, there's no obvious best number for the
   * second parameter to listen, but 15 is reasonable.
   */
  if(bind(sock, (SAP)&addrAndPort, addrAndPortLen) < 0 ||
     (protocol == TCP_PROTOCOL && listen(sock, 15) < 0)) {
    Disconnect(&sock);
    return NO_SOCKET;
  }
  if(openedPort != NULL)
    *openedPort = SocketPort(sock);
  return sock;

}


Address
PeerAddress(Socket sock) {
  struct sockaddr_in addrAndPort;
  ASIP_SOCKLEN_T addrAndPortLen = sizeof(addrAndPort);
  return getpeername(sock, (SAP)&addrAndPort, &addrAndPortLen) < 0 ?
         ANY_ADDRESS : addrAndPort.sin_addr.s_addr;
}


Port
PeerPort(Socket sock) {
  struct sockaddr_in addrAndPort;
  ASIP_SOCKLEN_T addrAndPortLen = sizeof(addrAndPort);
  return getpeername(sock, (SAP)&addrAndPort, &addrAndPortLen) < 0 ?
         ANY_PORT : ntohs(addrAndPort.sin_port);
}


int
ReceiveFromTerminated(Socket sock,
                      void *intoWhere,
                      unsigned size,
                      const char *terminator,
                      Address *addr,
                      Port *port) {
  int received;
  if(terminator == NULL) {
    received = ReceiveBytes(sock, intoWhere, size, addr, port);
    return received < 0 ? 0 : received;
  }
  for(received = 0;
      received < (int)size;
      received++, intoWhere = (char *)intoWhere + 1) {
    if(ReceiveBytes(sock, intoWhere, 1, addr, port) != 1)
      return received;
    else if(*(char *)intoWhere == *terminator)
      return received + 1;
  }
  return size;
}


int
ReceiveStringTerminated(Socket sock,
                        const char *terminator,
                        char **intoWhere) {
  char buffer[200];
  int len;
  char *returnValue = NULL;
  unsigned totalLen = 0;
  do {
    len = ReceiveTerminated(sock, buffer, sizeof(buffer), terminator);
    if(len <= 0) {
      if(returnValue != NULL)
        free(returnValue);
      return 0;
    }
    returnValue = (char *)ASSTR_Realloc(returnValue, totalLen + len);
    memcpy(returnValue + totalLen, buffer, len);
    totalLen += len;
  } while(buffer[len - 1] != *terminator);
  if(*terminator != '\0') {
    returnValue = (char *)ASSTR_Realloc(returnValue, totalLen + 1);
    returnValue[totalLen] = '\0';
  }
  *intoWhere = returnValue;
  return 1;
}


int
SendTo(Socket sock,
       const void *fromWhere,
       unsigned size,
       Address addr,
       Port port) {
  struct sockaddr_in peer;
  int sent;
  if(addr != ANY_ADDRESS) {
    InitSockaddrIn(&peer, addr, port);
    return
      sendto(sock, fromWhere, size, 0, (SAP)&peer, sizeof(peer)) == (int)size;
  }
  for(;
      size > 0 && (sent = send(sock, fromWhere, size, 0)) > 0;
      size -= sent, fromWhere = (char *)fromWhere + sent)
    ; /* empty */
  return size == 0;
}


Address
SocketAddress(Socket sock) {
  struct sockaddr_in addrAndPort;
  ASIP_SOCKLEN_T addrAndPortLen = sizeof(addrAndPort);
  return getsockname(sock, (SAP)&addrAndPort, &addrAndPortLen) < 0 ?
         ANY_ADDRESS : addrAndPort.sin_addr.s_addr;
}


unsigned
SocketBufferSize(Socket sock,
                 int sendSize) {
  unsigned size;
  ASIP_SOCKLEN_T sizeLen = sizeof(size);
  return getsockopt(sock, SOL_SOCKET, sendSize ? SO_SNDBUF : SO_RCVBUF,
                    (char *)&size, &sizeLen) == 0 ? size : 0;
}


Port
SocketPort(Socket sock) {
  struct sockaddr_in addrAndPort;
  ASIP_SOCKLEN_T addrAndPortLen = sizeof(addrAndPort);
  return getsockname(sock, (SAP)&addrAndPort, &addrAndPortLen) < 0 ?
         ANY_PORT : ntohs(addrAndPort.sin_port);
}
