/* $Id: diagnosticseed.c,v 1.19 2003/12/04 18:58:48 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#include "config.h"
#include "oshseed.h"
#include <stdarg.h>    /* va_*, vfprintf */
#include <stdio.h>     /* vsprintf */
#include <stdlib.h>    /* free malloc strtol */
#include <string.h>    /* strchr strlen */
#define ASV_SHORT_NAMES
#include "vectorseed.h"
#define ASDIAG_SHORT_NAMES
#include "diagnosticseed.h"


typedef struct {
  int type;
  int direction;
} MessageTypeInfo;


struct ASDIAG__DiagnosticState {
  MessageTypeInfo *messageInfo;
};


/* Returns the entry for #type# in #ds#, or NULL if it has none. */
static MessageTypeInfo *
FindInfo(DiagnosticState ds,
         int type) {
  unsigned i;
  for(i = 0; i < Size(ds->messageInfo) && ds->messageInfo[i].type != type; i++)
    ; /* empty */
  return i < Size(ds->messageInfo) ? &ds->messageInfo[i] : NULL;
}


void
Diagnostic(DiagnosticState ds,
           int type,
           const char *message,
           ...) {

  va_list arguments;
  char *buffer;
  const char *c;
  int estSize;
  int fieldWidth;
  MessageTypeInfo *info;
  int minWidth = 0;
  int precision = 0;

  if((info = FindInfo(ds, type)) == NULL)
    return;

  /* Generously estimate the size of the expanded message. */
  va_start(arguments, message);
  estSize = strlen(message);
  for(c = strchr(message, '%'); c != NULL; c = strchr(c + 1, '%')) {
    for(c++; strchr("#0- +'I", *c) != NULL; c++)
      ; /* empty */
    if(*c == '*') {
      c++;
      if((minWidth = va_arg(arguments, int)) < 0)
        minWidth = -minWidth;
    }
    else
      minWidth = strtol(c, (char **)&c, 10);
    if(*c == '.') {
      c++;
      if(*c == '*') {
        c++;
        if((precision = va_arg(arguments, int)) < 0)
          precision = 0;
      }
      else
        precision = strtol(c, (char **)&c, 10);
    }
    while(strchr("hlLqjzZt", *c) != NULL)
      c++;
    if(*c == 's') {
      fieldWidth = strlen(va_arg(arguments, char *));
      if(precision > 0 && precision < fieldWidth)
        fieldWidth = precision;
    }
    else {
      (void)va_arg(arguments, int); /* Skip argument. */
      fieldWidth = *c == '%' || *c == 'c' ? 1 : 32;
      if(precision > fieldWidth)
        fieldWidth = precision;
    }
    if(*c != 'n')
      estSize += minWidth > fieldWidth ? minWidth : fieldWidth;
  }
  va_end(arguments);

  buffer = (char *)malloc(estSize + 1);
  va_start(arguments, message);
  vsprintf(buffer, message, arguments);
  va_end(arguments);
  write(info->direction, buffer, strlen(buffer));
  free(buffer);

}


void
DiagnosticStateFree(DiagnosticState ds) {
  VectorFree(ds->messageInfo);
  free(ds);
}


DiagnosticState
DiagnosticStateNew(void) {
  DiagnosticState result =
    (DiagnosticState)malloc(sizeof(struct ASDIAG__DiagnosticState));
  result->messageInfo = VectorNew(MessageTypeInfo);
  return result;
}


int
DiagnosticsDirection(DiagnosticState ds,
                     int messageType) {
  MessageTypeInfo *info = FindInfo(ds, messageType);
  return info == NULL ? ASDIAG_SUPPRESS : info->direction;
}


void
DirectDiagnostics(DiagnosticState ds,
                  int messageType,
                  int whereTo) {
  MessageTypeInfo *info = FindInfo(ds, messageType);
  if(whereTo != ASDIAG_SUPPRESS) {
    if(info == NULL) {
      MessageTypeInfo newInfo;
      newInfo.type = messageType;
      newInfo.direction = whereTo;
      Append(ds->messageInfo, newInfo);
    }
    else
      info->direction = whereTo;
  }
  else if(info != NULL)
    Remove(ds->messageInfo, (unsigned)(info - ds->messageInfo));
}
