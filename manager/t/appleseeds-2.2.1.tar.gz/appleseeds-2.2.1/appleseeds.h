/* $Id: appleseeds.h,v 1.11 2003/12/04 18:58:47 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#ifndef APPLESEEDS_H
#define APPLESEEDS_H


/* This package provides general definitions for the appleseeds library. */


#ifdef __cplusplus
extern "C" {
#endif


/* Entities for file, semaphore, and shared memory permissions. */
typedef enum {
  AS_GROUP, AS_OTHERS, AS_OWNER
} AS_Entities;
/* Levels of locking for files and shared memory. */
typedef enum {
  AS_READ_LOCK, AS_READ_WRITE_LOCK
} AS_LockTypes;


#ifdef AS_SHORT_NAMES

#define Entities AS_Entities
#define GROUP AS_GROUP
#define OTHERS AS_OTHERS
#define OWNER AS_OWNER
#define LockTypes AS_LockTypes
#define READ_LOCK AS_READ_LOCK
#define READ_WRITE_LOCK AS_READ_WRITE_LOCK

#endif


#ifdef __cplusplus
}
#endif


#endif
