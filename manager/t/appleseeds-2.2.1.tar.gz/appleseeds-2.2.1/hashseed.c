/* $Id: hashseed.c,v 1.9 2004/12/07 23:48:01 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#include "config.h"
#include <stdlib.h> /* free malloc */
#include <string.h> /* memset strcmp */
#include "strseed.h"
#define ASH_SHORT_NAMES
#include "hashseed.h"


typedef struct {
  KeyType key;
  ValueType value;
} Mapping;

typedef struct {
  Mapping *mappings;
  unsigned long mappingCount;
} Bucket;

struct ASH__HashTable {
  unsigned long bucketCount;
  Bucket *buckets;
  KeyCompareFunction comparer;
  HashFunction hasher;
  ReclaimFunction reclaimer;
  unsigned long totalMappings;
};


/* A default {Key,Value}SelectFunction/KeyCompareFunction. */
static int
AreEqual(void *item1,
         void *item2) {
  return item1 == item2;
}


/* A default HashFunction. */
static unsigned long
IdentityHash(KeyType key) {
  return (unsigned long)key;
}


/*
 * Returns in #items# a #len#-long array of items from #table#.  #wantKeys#
 * indicates whether #table#'s keys or values are returned.  If #item# is NULL,
 * all items from #table# are returned; otherwise, only those for which a call
 * to #selector# (passing #item# and the table item) that return non-zero are
 * included.
 */
static void
Collect(HashTable table,
        void *item,
        KeySelectFunction selector,
        int wantKeys,
        void ***items,
        unsigned long *len) {

  unsigned long count = 0;
  unsigned long i;
  unsigned long j;
  void **returnValue = (void **)malloc(GetMappingCount(table) * sizeof(void *));
  void *toCompare;

  for(i = 0; i < table->bucketCount; i++) {
    Bucket *bucket = &table->buckets[i];
    for(j = 0; j < bucket->mappingCount; j++) {
      toCompare =
        wantKeys ? bucket->mappings[j].key : bucket->mappings[j].value;
      if(item == NULL || selector(toCompare, item))
        returnValue[count++] = toCompare;
    }
  }
  *items = returnValue;
  *len = count;

}


/*
 * Sets #iterator# to refer to the first mapping in #table# for which a call to
 * #selector# passing the mapping's key and #key# returns non-zero.  Returns 1
 * if successful, else 0.
 */
int
KeyMapping(HashTable table,
           KeyType key,
           KeySelectFunction selector,
           HashIterator *iterator) {
  Bucket *bucket;
  iterator->table = table;
  iterator->bucket =
    table->bucketCount == 1 ? 0 : (table->hasher(key) % table->bucketCount);
  bucket = &table->buckets[iterator->bucket];
  for(iterator->mapping = 0;
      iterator->mapping < bucket->mappingCount &&
      !selector(bucket->mappings[iterator->mapping].key, key);
      iterator->mapping++)
    ; /* empty */
  return (iterator->valid = iterator->mapping < bucket->mappingCount);
}


unsigned long
GetBucketCount(HashTable table) {
  return table->bucketCount;
}

HashFunction
GetHashFunction(HashTable table) {
  return table->hasher;
}


KeyType
GetKey(HashTable table,
       ValueType value,
       ValueSelectFunction selector) {
  HashIterator iterator;
  if(selector == NULL)
    selector = &AreEqual;
  ForEachMapping(table, iterator) {
    if(selector(IteratorValue(iterator), value))
      return IteratorKey(iterator);
  }
  return NULL;
}


KeyCompareFunction
GetKeyCompareFunction(HashTable table) {
  return table->comparer;
}


unsigned long
GetMappingCount(HashTable table) {
  return table->totalMappings;
}


ReclaimFunction
GetReclaimFunction(HashTable table) {
  return table->reclaimer;
}


void
GetSelectedKeys(HashTable table,
                KeyType key,
                KeySelectFunction selector,
                KeyType **keys,
                unsigned long *len) {
  Collect(table, key, selector==NULL?table->comparer:selector, 1, keys, len);
}


void
GetSelectedValues(HashTable table,
                  ValueType value,
                  ValueSelectFunction selector,
                  ValueType **values,
                  unsigned long *len) {
  Collect(table, value, selector==NULL?&AreEqual:selector, 0, values, len);
}


ValueType
GetValue(HashTable table,
         KeyType key,
         ValueSelectFunction selector) {
  HashIterator iterator;
  if(selector == NULL)
    selector = table->comparer;
  return KeyMapping(table, key, selector, &iterator) ?
         IteratorValue(iterator) : NULL;
}


double
HashEfficiency(HashTable table) {

  unsigned long i;
  unsigned long optimal =
    (unsigned long)((double)table->totalMappings / table->bucketCount);
  unsigned long totalVariance = 0;
  long variance;

  for(i = 0; i < table->bucketCount; i++) {
    variance = table->buckets[i].mappingCount - optimal;
    if(variance > 1)
      totalVariance += variance - 1;
  }
  return table->totalMappings == 0 ?
         1.0 : (1.0 - (double)totalVariance / table->totalMappings);

}


void
HashTableFree(HashTable table) {
  RemoveAllMappings(table);
  free(table->buckets);
  free(table);
}


HashTable
HashTableNew(unsigned long buckets,
             KeyCompareFunction comparer,
             HashFunction hasher,
             ReclaimFunction reclaimer) {
  HashTable returnValue = (HashTable)malloc(sizeof(struct ASH__HashTable));
  returnValue->bucketCount = buckets;
  returnValue->buckets = (Bucket *)malloc(buckets * sizeof(Bucket));
  memset(returnValue->buckets, 0, buckets * sizeof(Bucket));
  returnValue->comparer = comparer == NULL ? &AreEqual : comparer;
  returnValue->hasher = hasher == NULL ? &IdentityHash : hasher;
  returnValue->reclaimer = reclaimer;
  returnValue->totalMappings = 0;
  return returnValue;
}


HashIterator
IteratorFirst(HashTable table) {
  HashIterator returnValue;
  returnValue.table = table;
  for(returnValue.bucket = 0;
      returnValue.bucket < table->bucketCount &&
      returnValue.table->buckets[returnValue.bucket].mappingCount == 0;
      returnValue.bucket++)
    ; /* empty */
  returnValue.mapping = 0;
  returnValue.valid = returnValue.bucket < table->bucketCount;
  return returnValue;
}


KeyType
IteratorKey(HashIterator iterator) {
  return
    iterator.table->buckets[iterator.bucket].mappings[iterator.mapping].key;
}


HashIterator
IteratorNext(HashIterator iterator) {
  HashIterator returnValue = iterator;
  returnValue.mapping++;
  if(returnValue.table->buckets[returnValue.bucket].mappingCount <=
     returnValue.mapping) {
    for(returnValue.bucket++;
        returnValue.bucket < returnValue.table->bucketCount &&
        returnValue.table->buckets[returnValue.bucket].mappingCount == 0;
        returnValue.bucket++)
      ; /* empty */
    returnValue.mapping = 0;
  }
  returnValue.valid = returnValue.bucket < returnValue.table->bucketCount;
  return returnValue;
}


KeyType
IteratorValue(HashIterator iterator) {
  return
    iterator.table->buckets[iterator.bucket].mappings[iterator.mapping].value;
}


void
PutMapping(HashTable table,
           KeyType key,
           ValueType value) {

  Bucket *bucket;
  HashIterator iterator;
  Mapping *map;

  KeyMapping(table, key, table->comparer, &iterator);
  bucket = &table->buckets[iterator.bucket];
  if(iterator.valid) {
    /* Replacing old mapping. */
    map = &bucket->mappings[iterator.mapping];
    if(table->reclaimer != NULL)
      table->reclaimer(map->key, map->value);
  }
  else {
    /* New mapping. */
    bucket->mappings = (Mapping *)ASSTR_Realloc
      (bucket->mappings, (bucket->mappingCount + 1) * sizeof(Mapping));
    map = &bucket->mappings[bucket->mappingCount];
    bucket->mappingCount++;
    table->totalMappings++;
  }
  map->key = key;
  map->value = value;

}


void
RemoveAllMappings(HashTable table) {
  Bucket *bucket;
  unsigned long i;
  unsigned long j;
  for(i = 0; i < table->bucketCount; i++) {
    bucket = &table->buckets[i];
    if(bucket->mappings != NULL) {
      if(table->reclaimer != NULL) {
        for(j = 0; j < bucket->mappingCount; j++)
          table->reclaimer(bucket->mappings[j].key, bucket->mappings[j].value);
      }
      free(bucket->mappings);
    }
  }
  memset(table->buckets, 0, table->bucketCount * sizeof(Bucket));
  table->totalMappings = 0;
}


void
RemoveMapping(HashTable table,
              KeyType key,
              KeySelectFunction selector) {
  Bucket *bucket;
  HashIterator iterator;
  if(selector == NULL)
    selector = table->comparer;
  if(!KeyMapping(table, key, selector, &iterator))
    return;
  bucket = &table->buckets[iterator.bucket];
  if(table->reclaimer != NULL)
    table->reclaimer(bucket->mappings[iterator.mapping].key,
                     bucket->mappings[iterator.mapping].value);
  bucket->mappingCount--;
  if(bucket->mappingCount > iterator.mapping)
    memmove(&bucket->mappings[iterator.mapping],
            &bucket->mappings[iterator.mapping + 1],
            (bucket->mappingCount - iterator.mapping) * sizeof(Mapping));
  table->totalMappings--;
}


int
StringCompare(void *s1,
              void *s2) {
  return strcmp((char *)s1, (char *)s2) == 0;
}


unsigned long
StringHash(void *s) {
  char *c = (char *)s;
  unsigned long returnValue = 0;
  while(*c != '\0')
    returnValue = (returnValue << 1) + *c++;
  return returnValue;
}
