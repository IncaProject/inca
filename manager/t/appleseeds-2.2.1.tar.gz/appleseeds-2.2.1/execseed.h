/* $Id: execseed.h,v 1.5 2003/12/16 14:11:13 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#ifndef EXECSEED_H
#define EXECSEED_H


/* This package provides facilities for manipulating processes and threads. */


#ifdef __cplusplus
extern "C" {
#endif


/* System identifiers for processes ... */
typedef void *ASEXEC_ProcessId;
/* ... and threads. */
typedef void *ASEXEC_ThreadId;
/* The signature of a function executed within a thread. */
typedef void *(*ASEXEC_ThreadFunction)(void *);


/* Returns the id of the calling process. */
ASEXEC_ProcessId
ASEXEC_MyProcess(void);


/* Returns the id of the calling thread. */
ASEXEC_ThreadId
ASEXEC_MyThread(void);


/* Returns the CPU milliseconds process #process# has used, or -1 on failure. */
long
ASEXEC_ProcessCpuMilliseconds(ASEXEC_ProcessId process);


/*
 * Starts a new process that runs #exec#, passing the elements of the NULL-
 * terminated array #args# as command-line parameters.  Returns 1 if successful,
 * else 0. If #process# is not NULL, it is set to the id of the new process.
 */
int
ASEXEC_ProcessStart(const char *exec,
                    const char **args,
                    ASEXEC_ProcessId *process);


/* Kills process #process#.  Returns 1 if successful, else 0. */
int
ASEXEC_ProcessStop(ASEXEC_ProcessId process);


/*
 * If #process# has terminated, returns 1 and sets #exitValue# to the process
 * exit value, else returns 0.  If #block# is true, waits until the process
 * has terminated before returning.
 */
int
ASEXEC_ProcessStopped(ASEXEC_ProcessId process,
                      int block,
                      int *exitValue);


/*
 * Starts a new thread that invokes #fn#, passing #param#.  If successful,
 * returns 1 and sets #thread#, if it is not NULL, to the thread id; otherwise,
 * returns 0.
 */
int
ASEXEC_ThreadStart(ASEXEC_ThreadFunction fn,
                   void *param,
                   ASEXEC_ThreadId *thread);


/*
 * If #thread# has terminated, returns 1 and sets #returnValue# to the thread
 * function return value, else returns 0.  If #block# is true, waits until the
 * thread has terminated before returning.
 */
int
ASEXEC_ThreadStopped(ASEXEC_ThreadId thread,
                     int block,
                     void **returnValue);


#ifdef ASEXEC_SHORT_NAMES

#define ProcessId ASEXEC_ProcessId
#define ThreadId ASEXEC_ThreadId
#define ThreadFunction ASEXEC_ThreadFunction

#define MyProcess ASEXEC_MyProcess
#define MyThread ASEXEC_MyThread
#define ProcessCpuMilliseconds ASEXEC_ProcessCpuMilliseconds
#define ProcessStart ASEXEC_ProcessStart
#define ProcessStop ASEXEC_ProcessStop
#define ProcessStopped ASEXEC_ProcessStopped
#define ThreadStart ASEXEC_ThreadStart
#define ThreadStopped ASEXEC_ThreadStopped

#endif


#ifdef __cplusplus
}
#endif


#endif
