/* $Id: execseed.c,v 1.18 2004/12/07 17:59:01 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#include "config.h"
#include "oshseed.h"
#define ASEXEC_SHORT_NAMES
#include "execseed.h"


#ifdef WIN32


ProcessId
MyProcess(void) {
  return (ProcessId)GetCurrentProcess();
}


ThreadId
MyThread(void) {
  return (ThreadId)GetCurrentThread();
}


long
ProcessCpuMilliseconds(ProcessId process) {
  FILETIME ignored;
  FILETIME kernel;
  FILETIME user;
  __int64 veryLong;
  if(!GetProcessTimes((HANDLE)process, &ignored, &ignored, &kernel, &user))
    return -1;
  veryLong = kernel.dwHighDateTime;
  veryLong += user.dwHighDateTime;
  veryLong <<= 32;
  veryLong += kernel.dwLowDateTime;
  veryLong += user.dwLowDateTime;
  return (long)(veryLong / 10000);
}


int
ProcessStart(const char *exec,
             const char **args,
             ProcessId *process) {
  int result = spawnv(_P_NOWAIT, exec, args);
  if(result < 0)
    return 0;
  if(process == NULL)
    CloseHandle((HANDLE)result);
  else
    *process = (ProcessId)result;
  return 1;
}


int
ProcessStop(ProcessId process) {
  return TerminateProcess((HANDLE)process, 1);
}


int
ProcessStopped(ProcessId process,
               int block,
               int *exitValue) {
  DWORD exitCode;
  while(1) {
    if(!GetExitCodeProcess((HANDLE)process, &exitCode))
      return 0;
    else if(exitCode != STILL_ACTIVE || !block) {
      if(exitCode == STILL_ACTIVE)
        return 0;
      if(exitValue != NULL)
        *exitValue = (int)exitCode;
      return 1;
    }
    if(WaitForSingleObject((HANDLE)process, INFINITE) == WAIT_FAILED)
      Sleep(10);
  }
}


int
ThreadStart(ThreadFunction fn,
            void *param,
            ThreadId *thread) {
  typedef DWORD (WINAPI * ThreadProc)(LPVOID);
  HANDLE h;
  DWORD id;
  if((h = CreateThread(NULL, 0, (ThreadProc)fn, param, 0, &id)) == NULL)
    return 0;
  if(thread == NULL)
    CloseHandle(h);
  else
    *thread = (ThreadId)h;
  return 1;
}


int
ThreadStopped(ThreadId thread,
              int block,
              void **returnValue) {
  DWORD returned;
  if(WaitForSingleObject((HANDLE)thread, block ? INFINITE : 0) == WAIT_FAILED ||
     !GetExitCodeThread((HANDLE)thread, &returned))
    return 0;
  if(returned == STILL_ACTIVE)
    return 0;
  CloseHandle((HANDLE)thread);
  if(returnValue != NULL)
    *returnValue = (void *)returned;
  return 1;
}


#else


#include <sys/time.h>  /* struct timeval */
#include <sys/times.h> /* times */
#include <sys/wait.h>  /* waitpid */
#include <pthread.h>   /* pthreads */
#include <signal.h>    /* kill */
#include <string.h>    /* strstr */
#include <stdio.h>     /* sprintf */
#include <stdlib.h>    /* free malloc strtol */


typedef struct _ThreadInfo {
  pthread_t thread;
  ThreadFunction fn;
  void *param;
  pthread_mutex_t mutex;
  pthread_cond_t cond;
  int stopped;
} *ThreadInfo;


static const ThreadInfo myThreadInfo = (ThreadInfo)-1;


static void *
ThreadRunner(void *arg) {
  ThreadInfo info = (ThreadInfo)arg;
  void *result = info->fn(info->param);
  info->stopped = 1;
  pthread_cond_signal(&info->cond);
  return result;
}


ProcessId
MyProcess(void) {
  return (ProcessId)getpid();
}


ThreadId
MyThread(void) {
  return myThreadInfo;
}


long
ProcessCpuMilliseconds(ProcessId process) {
  if((int)process == getpid()) {
    struct tms systemTimes;
    double ticksPerMsec = (double)sysconf(_SC_CLK_TCK) / 1000.0;
    times(&systemTimes);
    return
      (long)((systemTimes.tms_stime + systemTimes.tms_utime) / ticksPerMsec);
  }
  else {
    char *colon;
    char line[1024 + 1] = "";
    char processImage[30] = "";
    char psCommand[128 + 1] = "";
    FILE *psOutput;
#ifdef ASEXEC_PS_SUPPORTS_SYSV
    char *psFormat = "ps -o time,pid -p %d";
#else
    char *psFormat = "ps %d | awk ' {print $4 \" \" $1}'";
#endif
    long seconds = 0;
    sprintf(psCommand, psFormat, (int)process);
    if((psOutput = popen(psCommand, "r")) == NULL)
      return -1;
    sprintf(processImage, "%d", (int)process);
    while(fgets(line, sizeof(line), psOutput) != NULL &&
          strstr(line, processImage) == NULL)
      ; /* empty */
    pclose(psOutput);
    if(strstr(line, processImage) == NULL)
      return -1;
    seconds = strtol(line, &colon, 10);
    while(*colon == ':')
      seconds = seconds * 60 + strtol(colon + 1, &colon, 10);
    return seconds * 1000;
  }
}


int
ProcessStart(const char *exec,
             const char **args,
             ProcessId *process) {
  /*
   * We use a clever trick from Stevens to avoid a zombie process if #process#
   * is NULL.  The child forks a grandchild and exits immediately, allowing the
   * parent to wait on the child, thus avoiding a zombie child.  The grandchild
   * becomes an orphan on the death of the child and is made a child of init,
   * which waits on it as soon as it terminates.
   */
  int pid = fork();
  if(pid < 0)
    return 0;
  else if(pid == 0) { /* Child */
    if(process == NULL && fork() > 0)
      exit(0);
    execvp(exec, (char * const *)args);
    exit(1);
  }
  if(process == NULL)
    waitpid(pid, NULL, 0);
  else
    *process = (ProcessId)pid;
  return 1;
}


int
ProcessStopped(ProcessId process,
               int block,
               int *exitValue) {
  int status;
  int result = waitpid((int)process, &status, block ? 0 : WNOHANG);
  if(result > 0 && exitValue != NULL)
    *exitValue = WIFEXITED(status) ? WEXITSTATUS(status) :
                 WIFSIGNALED(status) ? WTERMSIG(status) : 0;
  return result > 0;
}


int
ProcessStop(ProcessId process) {
  return kill((int)process, SIGKILL) == 0;
}


int
ThreadStart(ThreadFunction fn,
            void *param,
            ThreadId *thread) {

  pthread_t detached;
  ThreadInfo info;

  if(thread == NULL) {
    if(pthread_create(&detached, NULL, fn, param) != 0)
      return 0;
    pthread_detach(detached);
    return 1;
  }

  info = (ThreadInfo)malloc(sizeof(struct _ThreadInfo));
  info->fn = fn;
  info->param = param;
  pthread_mutex_init(&info->mutex, NULL);
  pthread_cond_init(&info->cond, NULL);
  info->stopped = 0;

  if(pthread_create(&info->thread, NULL, &ThreadRunner, info) != 0) {
    pthread_cond_destroy(&info->cond);
    pthread_mutex_destroy(&info->mutex);
    free(info);
    return 0;
  }

  *thread = info;
  return 1;

}


int
ThreadStopped(ThreadId thread,
              int block,
              void **returnValue) {

  ThreadInfo info = (ThreadInfo)thread;
  struct timeval now;

  if(thread == MyThread())
    return 0;

  if(!block) {
    pthread_mutex_lock(&info->mutex);
    gettimeofday(&now, NULL);
    now.tv_usec += 1000; /* 1 millisecond from now */
    now.tv_usec *= 1000; /* Convert to nanosecs */
    pthread_cond_timedwait(&info->cond, &info->mutex, (struct timespec *)&now);
    pthread_mutex_unlock(&info->mutex);
    if(!info->stopped)
      return 0;
  }
  pthread_join(info->thread, returnValue);
  pthread_cond_destroy(&info->cond);
  pthread_mutex_destroy(&info->mutex);
  free(info);
  return 1;

}


#endif
