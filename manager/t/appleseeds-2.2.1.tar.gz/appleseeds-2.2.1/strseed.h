/* $Id: strseed.h,v 1.14 2004/12/09 19:05:27 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California.
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies.
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office
 * 9500 Gilman Drive
 * 411 University Center
 * University of California
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS.
 */


#ifndef STRINGSEED_H
#define STRINGSEED_H


/* This package provides facilities for manipulating strings/string arrays. */


#ifdef __cplusplus
extern "C" {
#endif


/* Case conversion types for ASSTR_StrCase and ASSTR_StrNCase. */
typedef enum {
  ASSTR_ALL_LOWER, ASSTR_ALL_UPPER, ASSTR_INITIAL_LOWER,
  ASSTR_INITIAL_UPPER
} ASSTR_CaseTypes;


/* Realloc that will work if #ptr# if NULL. */
void *
ASSTR_Realloc(void *ptr,
              unsigned size);


/*
 * Returns an allocated string containing the catenation of all its parameters,
 * which must be strings.  The variable parameter list must end with a NULL
 * pointer.  #s# may be NULL, in which case the catenated string is returned in
 * newly-allocated memory; otherwise, #s# is passed to realloc.
 */
char *
ASSTR_StrAppend(char *s,
                ...);


/*
 * Like ASSTR_StrArrayNFind, but expects #s# to be terminated by a NULL and
 * looks for a match of the entire string #target#.
 */
int
ASSTR_StrArrayFind(const char **s,
                   const char *target,
                   unsigned long *where);


/* Like ASSTR_StrArrayNFnMatch, but expects #s# to be terminated by a NULL. */
#define ASSTR_StrArrayFnMatch(s,pattern,where) \
  ASSTR_StrArrayNFnMatch(s, ASSTR_StrArrayLen(s), pattern, where)


/* Like ASSTR_StrArrayNFree, but expects #s# to be terminated by a NULL. */
#define ASSTR_StrArrayFree(s) \
  ASSTR_StrArrayNFree(s, ASSTR_StrArrayLen((const char **)s))


/* Like ASSTR_StrArrayNJoin, but expects #s# to be terminated by a NULL. */
#define ASSTR_StrArrayJoin(s,sep) \
  ASSTR_StrArrayNJoin(s, ASSTR_StrArrayLen(s), sep)


/* Returns the number of elements in the NULL-terminated array #s#. */
unsigned long
ASSTR_StrArrayLen(const char **s);


/*
 * Searches the elements of the #len#-long array #s# for one that matches the
 * first #targetLen# characters of #target#.  If one is found, returns 1 and
 * sets #where# (if it isn't NULL) to the matching index; else returns 0.
 */
int
ASSTR_StrArrayNFind(const char **s,
                    unsigned long len,
                    const char *target,
                    unsigned long targetLen,
                    unsigned long *where);


/*
 * Searches the elements of the #len#-long array #s# for one that matches
 * #pattern#.  If one is found, returns 1 and sets #where# (if it isn't NULL)
 * to the matching index; else returns 0.  See ASSTR_StrNFnMatch for the format
 * of #pattern#.
 */
int
ASSTR_StrArrayNFnMatch(const char **s,
                       unsigned long len,
                       const char *pattern,
                       unsigned long *where);


/* Frees all elements of the #len#-long array #s#, as well as #s# itself. */
void
ASSTR_StrArrayNFree(char **s,
                    unsigned long len);


/*
 * Returns an allocated string containing the concatenation of all elements of
 * the #len#-long array #s#.  The individual elements are separated by #sep# if
 * it is not NULL.
 */
char *
ASSTR_StrArrayNJoin(const char **s,
                    unsigned long len,
                    const char *sep);


/* Shorthand for ASSTR_StrNCase(s, strlen(s), caseType). */
char *
ASSTR_StrCase(char *s,
              ASSTR_CaseTypes caseType);


/* Shorthand for ASSTR_StrNFnMatch(s, strlen(s), pattern). */
int
ASSTR_StrFnMatch(const char *s,
                 const char *pattern);


/*
 * Changes the case of letters in the first #len# characters of #s# according
 * to #caseType#.  Returns #s# for convenience.  The #caseType# values
 * ASSTR_ALL_LOWER and ASSTR_ALL_UPPER change all letters in #s# to lower or
 * upper case, while ASSTR_INITIAL_LOWER and ASSTR_INITIAL_UPPER change the
 * case of only those letters that are not preceded by another letter.
 */
char *
ASSTR_StrNCase(char *s,
               unsigned long len,
               ASSTR_CaseTypes caseType);


/* Like strdup(), but only copies the first #len# characters. */
char *
ASSTR_StrNDup(const char *s,
              unsigned long len);


/*
 * Similar to the POSIX fnmatch(3) function without the flags parameter.
 * Returns 1 iff the first #len# characters of #s# match #pattern#, else 0.
 * #pattern# can contain the wildcards '?' and '*', which respectively match
 * any one character and any sequence of characters.  It may also contain sets
 * of characters surrounded by '[' and ']', which match any one of the
 * characters between.  A '!' as the first character in a set negates the set
 * so that it matches any character other than those in the set.  Sets can
 * include ranges such as A-Z or 0-9 as a shorthand.  A ']' can be included in
 * a set by making it the first character in the set; a '-' by making it the
 * first or last.  A '\' in #pattern# suppresses any special meaning the
 * following character has, and so can be used to include the characters '?',
 * '*', '[', or '\' in #pattern#.  All other characters in #pattern# must equal
 * the corresponding character in #s# for the match to succeed.
 */
int
ASSTR_StrNFnMatch(const char *s,
                  unsigned long len,
                  const char *pattern);


/*
 * Returns an allocated string containing #count# copies of the first #len#
 * characters of #s#.
 */
char *
ASSTR_StrNRepeat(const char *s,
                 unsigned long len,
                 unsigned long count);


/*
 * Replaces #count# characters in the allocated string pointed to by #s#,
 * starting with the #offset#'th one, with the #len#-long string #rep#.
 * If #count# is zero, #rep# is inserted; if #len# is zero, #count# characters
 * are deleted.  An #offset# or #count# value that references a position past
 * the end of the string is taken to reference the end of the string.  Returns
 * *#s# for convenience.
 */
char *
ASSTR_StrNReplace(char **s,
                  unsigned long offset,
                  unsigned long count,
                  const char *rep,
                  unsigned long len);


/*
 * Replaces all occurrences in the allocated string pointed to by #s# of the
 * #beforeLen#-long string #before# with the #afterLen#-long string #after#.
 * Returns *#s# for convenience.
 */
char *
ASSTR_StrNReplaceAll(char **s,
                     const char *before,
                     unsigned long beforeLen,
                     const char *after,
                     unsigned long afterLen);


/*
 * Returns a NULL-terminated allocated array of allocated strings copied from
 * the first #len# characters of #s#.  Each element consists of a substring of
 * #s# delimited by #delimiter#, which has the pattern format used by
 * ASSTR_StrNFnMatch.  #delimiter# may be NULL, which is treated equivalently
 * to "[ \f\n\r\t\v]+" (i.e., runs of whitespace).
 */
char **
ASSTR_StrNSplit(const char *s,
                unsigned long len,
                const char *delimiter);


/* Shorthand for ASSTR_StrNRepeat(s, strlen(s), count). */
char *
ASSTR_StrRepeat(const char *s,
                unsigned long count);


/* Shorthand for ASSTR_StrNReplace(s, offset, count, rep, strlen(rep). */
char *
ASSTR_StrReplace(char **s,
                 unsigned long offset,
                 unsigned long count,
                 const char *rep);


/*
 * Shorthand for
 * ASSTR_StrNReplaceAll(s, before, strlen(before), after, strlen(after)).
 */
char *
ASSTR_StrReplaceAll(char **s,
                    const char *before,
                    const char *after);


/* Shorthand for ASSTR_StrNSplit(s, strlen(s), delimiter). */
char **
ASSTR_StrSplit(const char *s,
               const char *delimiter);


#ifdef ASSTR_SHORT_NAMES

#define ALL_LOWER ASSTR_ALL_LOWER
#define ALL_UPPER ASSTR_ALL_UPPER
#define INITIAL_LOWER ASSTR_INITIAL_LOWER
#define INITIAL_UPPER ASSTR_INITIAL_UPPER
#define CaseTypes ASSTR_CaseTypes

#define Realloc ASSTR_Realloc
#define StrAppend ASSTR_StrAppend
#define StrArrayFind ASSTR_StrArrayFind
#define StrArrayFnMatch ASSTR_StrArrayFnMatch
#define StrArrayFree ASSTR_StrArrayFree
#define StrArrayLen ASSTR_StrArrayLen
#define StrArrayJoin ASSTR_StrArrayJoin
#define StrArrayNFind ASSTR_StrArrayNFind
#define StrArrayNFnMatch ASSTR_StrArrayNFnMatch
#define StrArrayNFree ASSTR_StrArrayNFree
#define StrArrayNJoin ASSTR_StrArrayNJoin
#define StrCase ASSTR_StrCase
#define StrFnMatch ASSTR_StrFnMatch
#define StrNCase ASSTR_StrNCase
#define StrNDup ASSTR_StrNDup
#define StrNFnMatch ASSTR_StrNFnMatch
#define StrNReplace ASSTR_StrNReplace
#define StrNReplaceAll ASSTR_StrNReplaceAll
#define StrNRepeat ASSTR_StrNRepeat
#define StrNSplit ASSTR_StrNSplit
#define StrReplace ASSTR_StrReplace
#define StrReplaceAll ASSTR_StrReplaceAll
#define StrRepeat ASSTR_StrRepeat
#define StrSplit ASSTR_StrSplit

#endif


#ifdef __cplusplus
}
#endif


#endif
