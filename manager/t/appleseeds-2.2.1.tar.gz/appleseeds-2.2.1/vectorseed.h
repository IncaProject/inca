/* $Id: vectorseed.h,v 1.20 2003/12/04 18:58:48 jhayes Exp $ */
/*
 * Copyright � 2003 The Regents of the University of California. 
 * All Rights Reserved. 
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes, without
 * fee, and without a written agreement is hereby granted, provided that the
 * above copyright notice, this paragraph and the following three paragraphs
 * appear in all copies. 
 *
 * Permission to incorporate this software into commercial products may be
 * obtained by contacting
 * Technology Transfer Office 
 * 9500 Gilman Drive 
 * 411 University Center 
 * University of California 
 * La Jolla, CA 92093-0093
 * (858) 534-5815
 * invent@ucsd.edu
 *
 * This software program and documentation are copyrighted by The Regents of
 * the University of California. The software program and documentation are
 * supplied "as is", without any accompanying services from The Regents. The
 * Regents does not warrant that the operation of the program will be
 * uninterrupted or error-free. The end-user understands that the program was
 * developed for research purposes and is advised not to rely exclusively on
 * the program for any reason. 
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION,
 * EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
 * HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO
 * OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
 * MODIFICATIONS. 
 */


#ifndef VECTORSEED_H
#define VECTORSEED_H


/*
 * This package defines facilities for dealing with vectors--allocated arrrays
 * that grow and shrink dynamically.  The facilities provided roughly
 * correspond to that of the Java Vector class.  Like all C dynamic arrays,
 * vectors are declared as a pointer to the base type, but a vector is
 * initialized via a call to ASV_VectorNew and freed by ASV_VectorFree.
 * Elements of a vector can be accessed using normal array notation.
 */


#include <stdlib.h> /* calloc free realloc */
#include <string.h> /* memmove */


/* Adds #element# to the end of #vector#. */
#define ASV_Append(vector,element) \
  do { \
    ASV__VectorBase *base = ASV__Base(vector); \
    if(base->header.size == base->header.capacity) { \
      ASV__AdjustCapacity \
        (vector, base, base->header.capacity + base->header.increment + 1); \
    } \
    (vector)[base->header.size++] = (element); \
  } while(0)


/*
 * Returns the number of elements that may be placed in #vector# before its
 * dynamic space will need to be reallocated.
 */
#define ASV_Capacity(vector) (ASV__Base(vector)->header.capacity)


/*
 * Increases the capacity of #vector# to #howBig# if it is not already at least
 * that large.  Capacity increases are normally handled automatically, but this
 * allows making a large increase in preparation for adding many elements.
 */
#define ASV_GrowCapacity(vector,howBig) \
  do { \
    ASV__VectorBase *base = ASV__Base(vector); \
    if(base->header.capacity < (howBig)) { \
      ASV__AdjustCapacity(vector, base, howBig); \
    } \
  } while(0)


/*
 * Returns the amount #vector# is expanded when room to add new elements is
 * exhausted.
 */
#define ASV_Increment(vector) (ASV__Base(vector)->header.increment + 1)


/*
 * Inserts #element# as the #index#'th element of #vector#, expanding
 * #vector#'s space if necessary.  A new element may be added in the middle of
 * #vector#, in which case existing elements are shifted to the right.  If
 * #index# > ASV_Size(#vector#) the new element is appended; no "holes" are
 * left in #vector#'s elements.
 */
#define ASV_Insert(vector,element,index) \
  do { \
    ASV__VectorBase *base = ASV__Base(vector); \
    if(base->header.size == base->header.capacity) { \
      ASV__AdjustCapacity \
        (vector, base, base->header.capacity + base->header.increment + 1); \
    } \
    if((index) < base->header.size) { \
      memmove(&(vector)[(index) + 1], \
              &(vector)[(index)], \
              sizeof((vector)[0]) * (base->header.size - (index))); \
      (vector)[(index)] = (element); \
    } \
    else \
      (vector)[base->header.size] = (element); \
    base->header.size++; \
  } while(0)


/* Returns an empty vector with elements of type #type#. */
#define ASV_VectorNew(type) \
  ((type *)((ASV__VectorBase *)calloc(1, sizeof(ASV__VectorBase)) + 1))


/*
 * Removes the #index#'th element of #vector#.  The caller must assure that
 * #index# < ASV_Size(#vector#).
 */
#define ASV_Remove(vector,index) \
  do { \
    ASV__VectorBase *base = ASV__Base(vector); \
    if((index) < --base->header.size) \
      memmove(&(vector)[(index)], \
              &(vector)[(index) + 1], \
              sizeof((vector)[0]) * (base->header.size - (index))); \
  } while(0)


/* Sets the capacity of #vector# to exactly #howBig# elements. */
#define ASV_SetCapacity(vector,howBig) \
  do { \
    ASV__VectorBase *base = ASV__Base(vector); \
    if(base->header.capacity != (howBig)) { \
      ASV__AdjustCapacity(vector, base, howBig); \
      if(base->header.size > (howBig)) \
        base->header.size = (howBig); \
    } \
  } while(0)


/*
 * Sets the amount #vector# is expanded when room to add new elements is
 * exhausted to #howMany#.  The default is 1.
 */
#define ASV_SetIncrement(vector,howMany) \
  ASV__Base(vector)->header.increment = ((howMany) - 1)


/*
 * Reduces the capacity of #vector# to #howBig# if it is not already at least
 * that small.
 */
#define ASV_ShrinkCapacity(vector,howBig) \
  do { \
    ASV__VectorBase *base = ASV__Base(vector); \
    if(base->header.capacity > (howBig)) { \
      ASV__AdjustCapacity((vector), base, (howBig)); \
      if(base->header.size > (howBig)) \
        base->header.size = (howBig); \
    } \
  } while(0)


/* Discards any elements of #vector# beyond the #howBig#'th one. */
#define ASV_ShrinkSize(vector,howBig) \
  do { \
    ASV__VectorBase *base = ASV__Base(vector); \
    if(base->header.size > (howBig)) \
      base->header.size = (howBig); \
  } while(0)


/* Returns the number of elements in #vector#. */
#define ASV_Size(vector) (ASV__Base(vector)->header.size)


/*
 * Frees the space allocated to #vector#.  To avoid memory leaks, this function
 * must be called after the use of #vector# is complete.
 */
#define ASV_VectorFree(vector) free(ASV__Base(vector))


/* The vector info structure allocated in front of the vector element space. */
typedef union {
  double aligner; /* Unused; aligns first element of vector that follows. */
  struct {
    unsigned capacity;
    unsigned increment;
    unsigned size;
  } header;
} ASV__VectorBase;


/* Internal macro; sets the capacity of #vector#, base #base#, to #howBig#. */
#define ASV__AdjustCapacity(vector,base,howBig) \
  base->header.capacity = (howBig); \
  base = (ASV__VectorBase *) \
    realloc(base, sizeof(ASV__VectorBase) + \
                  base->header.capacity * sizeof((vector)[0])); \
  *((ASV__VectorBase **)&(vector)) = base + 1; \


/* Internal macro; returns a pointer to the base of #vector#. */
#define ASV__Base(vector) (((ASV__VectorBase *)(vector)) - 1)


#ifdef ASV_SHORT_NAMES

#define Append ASV_Append
#define Capacity ASV_Capacity
#define GrowCapacity ASV_GrowCapacity
#define Increment ASV_Increment
#define Insert ASV_Insert
#define Remove ASV_Remove
#define SetCapacity ASV_SetCapacity
#define SetIncrement ASV_SetIncrement
#define ShrinkCapacity ASV_ShrinkCapacity
#define ShrinkSize ASV_ShrinkSize
#define Size ASV_Size
#define VectorFree ASV_VectorFree
#define VectorNew ASV_VectorNew

#endif


#endif
